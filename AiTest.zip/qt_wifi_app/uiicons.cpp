#include "uiicons.h"

#include <QDebug>
#include <QPixmap>
#include <QString>

namespace {

QString iconAssetName(UiIcon::Type type, const QColor &color)
{
    const QString colorHex = color.name(QColor::HexRgb).toUpper();
    switch (type) {
    case UiIcon::Board:
        return QStringLiteral("board_blue");
    case UiIcon::Wifi:
        return colorHex == QStringLiteral("#5AAAF2")
                   ? QStringLiteral("wifi_blue")
                   : QStringLiteral("wifi_secondary");
    case UiIcon::WifiConnected:
        return QStringLiteral("wifi_connected_green");
    case UiIcon::TestGrid:
        return QStringLiteral("testgrid_blue");
    case UiIcon::Rs485:
        return QStringLiteral("rs485_secondary");
    case UiIcon::Can:
        return QStringLiteral("can_secondary");
    case UiIcon::Led:
        return QStringLiteral("led_secondary");
    case UiIcon::Beep:
        return QStringLiteral("beep_secondary");
    case UiIcon::Lock:
        return colorHex == QStringLiteral("#FF8C95")
                   ? QStringLiteral("lock_red")
                   : QStringLiteral("lock_gray");
    case UiIcon::Eye:
        if (colorHex == QStringLiteral("#5AAAF2"))
            return QStringLiteral("eye_blue");
        if (colorHex == QStringLiteral("#8296AF") || colorHex == QStringLiteral("#ADBED2"))
            return QStringLiteral("eye_secondary");
        return QStringLiteral("eye_gray");
    case UiIcon::Search:
        return QStringLiteral("search_gray");
    case UiIcon::ArrowRight:
        return QStringLiteral("arrowright_dark");
    case UiIcon::Offline:
        return QStringLiteral("offline_secondary");
    case UiIcon::Back:
        return QStringLiteral("back_secondary");
    case UiIcon::Keyboard:
        return QStringLiteral("keyboard_gray");
    case UiIcon::Backspace:
        return QStringLiteral("backspace_dark");
    case UiIcon::Check:
        return QStringLiteral("check_white");
    }
    return QString();
}

} // namespace

QIcon makeUiIcon(UiIcon::Type type, const QColor &color)
{
    const QString assetName = iconAssetName(type, color);
    if (assetName.isEmpty())
        return QIcon();

    const QString resourcePath = QStringLiteral(":/ui/icons/%1.png").arg(assetName);
    const QPixmap iconPixmap(resourcePath);
    if (iconPixmap.isNull()) {
        qWarning().noquote() << "UI icon resource is missing:" << resourcePath;
        return QIcon();
    }

    // UI icons are shipped as bitmap assets; no vector icon painting is done at runtime.
    return QIcon(iconPixmap);
}
