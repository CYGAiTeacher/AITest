#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QElapsedTimer>
#include <QList>
#include <QProcess>
#include <QThread>
#include <QWidget>

#include "wificredentialstore.h"
#include "wifimanager.h"

class ModbusWorker;
class NtpSynchronizer;
class QEvent;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QStackedWidget;
class QTimer;
class XiaozhiBridge;
class SensorChart;

class MainWindow : public QWidget
{
    Q_OBJECT
public:
    explicit MainWindow(const QString &interfaceName,
                        const QString &controlDirectory,
                        QWidget *parent = nullptr);
    ~MainWindow() override;

signals:
    void scanRequested();
    void connectRequested(const QString &ssid,
                          const QString &password,
                          bool secured);
    void statusRequested();
    void timeSyncRequested();
    void modbusStartRequested();
    void modbusStopRequested();
    void modbusLedRequested(bool enabled);
    void modbusBuzzerRequested(bool enabled);

private slots:
    void startScan();
    void onScanFinished(const QList<WifiNetwork> &networks, const QString &error);
    void onConnectFinished(bool success,
                           const QString &ssid,
                           const QString &ipAddress,
                           const QString &message);
    void onStatusChanged(bool connected, const QString &ssid, const QString &ipAddress);
    void onTimeSyncFinished(bool success,
                            qint64 utcMilliseconds,
                            bool systemClockSet,
                            bool rtcWritten,
                            const QString &message);
    void updateClock();
    void updateSelection();
    void onConnectClicked();
    void onWifiScanConnectClicked();
    void onPasswordBackClicked();
    void openWifiSettings();
    void leaveWifiPage();
    void onRecordProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);
    void onPlaybackProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    QWidget *createHomePage();
    QWidget *createWifiPage();
    QWidget *createWifiScanPage();
    QWidget *createPasswordEntryPage();
    QWidget *createPasswordKeyboard(QWidget *parent);
    QWidget *createPeripheralPage();
    QWidget *createPeripheralHubPage();
    QWidget *createAudioTestPage();
    QWidget *createXiaozhiPage();
    QWidget *createRs485Page();
    void showPasswordKeyboard();
    void hidePasswordKeyboard();
    void updateKeyboardLabels();
    void insertPasswordText(const QString &text);
    void backspacePassword();
    void setBusy(bool busy);
    void setWifiStatus(bool connected, const QString &ssid);
    void setWifiConnecting();
    void startInternetTimeSync();
    void showHomeMessage(const QString &text, bool warning = false);
    bool selectedNetwork(QString *ssid, bool *secured, bool *supported) const;

    void openPeripheralHub();
    void openAudioTestPage();
    void openXiaozhiPage();
    void openRs485Page();
    void returnToHome();
    void returnToPeripheralHub();
    void startRecording();
    void stopRecording(bool playWhenFinished);
    void playAudioFile(const QString &path, const QString &purpose);
    void stopAudioProcesses();
    void updateAudioControls();
    void onXiaozhiTextReceived(const QString &text, const QString &sentenceState);
    void addChatBubble(const QString &text, bool assistant, bool systemMessage = false);
    void resetXiaozhiSessionUi(const QString &status);
    void updateXiaozhiActivationView();
    void playButtonClickSound();
    void stopButtonClickSound();

    QStackedWidget *m_stack;
    QWidget *m_homePage;
    QWidget *m_wifiPage;
    QWidget *m_peripheralPage;
    QStackedWidget *m_peripheralPageStack;
    QWidget *m_peripheralHubPage;
    QWidget *m_audioTestPage;
    QWidget *m_xiaozhiPage;
    QWidget *m_rs485Page;
    QStackedWidget *m_wifiPageStack;
    QWidget *m_scanPage;
    QWidget *m_passwordPage;
    QWidget *m_wifiHeader;
    QWidget *m_actionBar;
    QWidget *m_passwordActionBar;
    QWidget *m_passwordFooterSpacer;
    QWidget *m_keyboardPanel;
    QLabel *m_keyboardSsid;
    QPushButton *m_shiftButton;
    QPushButton *m_modeButton;
    QPushButton *m_backspaceButton;
    QPushButton *m_doneButton;
    QList<QPushButton *> m_alphaButtons;
    bool m_keyboardVisible;
    int m_keyboardMode;
    bool m_capsLock;

    QLabel *m_clockDate;
    QLabel *m_clockTime;
    QPushButton *m_wifiStatusButton;
    QLabel *m_wifiTopStatus;
    QLabel *m_wifiTopIp;
    QLabel *m_homeMessage;

    QPushButton *m_scanButton;
    QListWidget *m_networkList;
    QLabel *m_scanInfo;
    QLabel *m_passwordLabel;
    QLineEdit *m_passwordEdit;
    QPushButton *m_passwordToggle;
    QPushButton *m_keyboardButton;
    QLabel *m_wifiMessage;
    QLabel *m_passwordMessage;
    QPushButton *m_skipButton;
    QPushButton *m_connectButton;
    QPushButton *m_passwordBackButton;
    QPushButton *m_passwordConnectButton;

    QLabel *m_audioStatus;
    QPushButton *m_recordButton;
    QPushButton *m_musicButton;
    QLabel *m_xiaozhiStatus;
    QPushButton *m_xiaozhiToggleButton;
    QWidget *m_xiaozhiActivationPanel;
    QLabel *m_xiaozhiActivationTitleLabel;
    QLabel *m_xiaozhiActivationCodeCaption;
    QLabel *m_xiaozhiActivationCodeLabel;
    QLabel *m_xiaozhiActivationInstructionsLabel;
    QLabel *m_xiaozhiActivationMessage;
    QString m_xiaozhiActivationCode;
    bool m_xiaozhiActivated;
    bool m_xiaozhiAudioReady;
    bool m_xiaozhiOnline;
    bool m_xiaozhiManualRestartHint;
    QListWidget *m_chatList;
    QString m_streamingAssistantText;
    int m_streamingAssistantRow;
    QLabel *m_rs485Status;
    QLabel *m_temperatureValue;
    QLabel *m_humidityValue;
    QPushButton *m_rs485RetryButton;
    QPushButton *m_ledButton;
    QPushButton *m_buzzerButton;
    SensorChart *m_sensorChart;

    QProcess *m_recordProcess;
    QProcess *m_playProcess;
    QProcess *m_clickSoundProcess;
    XiaozhiBridge *m_xiaozhiBridge;
    ModbusWorker *m_modbusWorker;
    QThread m_modbusThread;
    QString m_musicFilePath;
    QString m_recordingPath;
    QString m_captureDevice;
    QString m_playbackDevice;
    QString m_arecordProgram;
    QString m_aplayProgram;
    QString m_playPurpose;
    QString m_clickSoundPath;
    int m_audioSampleRate;
    bool m_autoPlayAfterRecord;
    bool m_playStopRequested;

    QThread m_workerThread;
    WifiWorker *m_worker;
    QThread m_ntpThread;
    NtpSynchronizer *m_ntpWorker;
    QTimer *m_clockTimer;
    QTimer *m_statusTimer;
    QTimer *m_timeSyncRetryTimer;
    QTimer *m_connectionAnimationTimer;
    QTimer *m_xiaozhiReadyHintTimer;
    int m_connectionAnimationFrame;
    WifiCredentialStore m_credentialStore;
    WifiCredentials m_pendingCredentials;
    QString m_interfaceName;
    QString m_controlDirectory;
    QString m_ipAddress;
    QElapsedTimer m_beijingClockElapsed;
    qint64 m_beijingUtcMilliseconds;
    bool m_timeSyncInProgress;
    bool m_timeSynchronized;
    bool m_setupComplete;
    bool m_hasCredentials;
    bool m_savePendingCredentials;
    bool m_autoConnection;
    bool m_scanBusy;
    bool m_connectionBusy;
    bool m_showPassword;
};

#endif // MAINWINDOW_H
