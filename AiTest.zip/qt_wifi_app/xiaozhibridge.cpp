#include "xiaozhibridge.h"

#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QStringList>
#include <QTimer>

XiaozhiBridge::XiaozhiBridge(QObject *parent)
    : QObject(parent),
      m_socket(this),
      m_restartTimer(new QTimer(this)),
      m_restartAttempts(0),
      m_wantsRunning(false),
      m_audioRecoveryRequested(false),
      m_captureReady(false),
      m_playbackReady(false),
      m_logLineBuffer(),
      m_executablePath(QString::fromLocal8Bit(qgetenv("XIAOZHI_EXECUTABLE"))),
      m_workingDirectory(QString::fromLocal8Bit(qgetenv("XIAOZHI_WORKDIR"))),
      m_guiBindAddress(QHostAddress::LocalHost),
      m_guiPort(5679),
      m_ttsDisplayEnabled(true)
{
    if (m_executablePath.isEmpty())
        m_executablePath = QStringLiteral("/xiaozhi_linux_rs-armv7-gnueabihf");
    if (m_workingDirectory.isEmpty())
        m_workingDirectory = QFileInfo(m_executablePath).absolutePath();

    m_restartTimer->setSingleShot(true);
    connect(m_restartTimer, &QTimer::timeout, this, [this]() {
        if (!m_wantsRunning || m_process.state() != QProcess::NotRunning)
            return;
        QString error;
        if (!launchCore(&error)) {
            emit statusChanged(error);
            scheduleRestart();
        }
    });
    connect(&m_socket, &QUdpSocket::readyRead, this, &XiaozhiBridge::readDatagrams);
    connect(&m_process, &QProcess::started, this, [this]() {
        emit statusChanged(QStringLiteral("小智核心进程已启动；正在检查激活与云端连接"));
    });
    connect(&m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this](int exitCode, QProcess::ExitStatus exitStatus) {
        if (exitStatus == QProcess::CrashExit)
            emit statusChanged(QStringLiteral("小智核心异常退出（代码 %1）").arg(exitCode));
        else if (exitCode != 0)
            emit statusChanged(QStringLiteral("小智核心退出，代码 %1").arg(exitCode));
        else
            emit statusChanged(QStringLiteral("小智核心已退出"));
        if (m_wantsRunning)
            scheduleRestart();
    });
    connect(&m_process, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            emit statusChanged(QStringLiteral("无法启动小智核心：请检查程序文件、ABI、工作目录和执行权限"));
            if (m_wantsRunning)
                scheduleRestart();
        }
    });
    connect(&m_process, &QProcess::readyReadStandardOutput, this, [this]() {
        m_logLineBuffer.append(m_process.readAllStandardOutput());
        int newline = -1;
        while ((newline = m_logLineBuffer.indexOf('\n')) >= 0) {
            const QByteArray rawLine = m_logLineBuffer.left(newline).trimmed();
            m_logLineBuffer.remove(0, newline + 1);
            if (rawLine.isEmpty())
                continue;

            const QString line = QString::fromUtf8(rawLine);
            qInfo().noquote() << "[XiaoZhi Core]" << line;

            // The current Core logs the final server-side speech transcript as
            // "STT Result: ..." rather than forwarding it over GUI UDP.
            const QString sttMarker = QStringLiteral("STT Result:");
            const int sttMarkerPosition = line.indexOf(sttMarker);
            if (sttMarkerPosition >= 0) {
                const QString userText = line.mid(sttMarkerPosition + sttMarker.size()).trimmed();
                if (!userText.isEmpty())
                    emit userSpeechTextReceived(userText);
            }

            const bool wasAudioReady = m_captureReady && m_playbackReady;
            if (line.contains(QStringLiteral("Recording started:")))
                m_captureReady = true;
            if (line.contains(QStringLiteral("Playback started:")))
                m_playbackReady = true;

            const bool audioThreadFailed = line.contains(QStringLiteral("Recording thread error:")) ||
                                           line.contains(QStringLiteral("Playback thread error:"));
            if (audioThreadFailed) {
                m_captureReady = false;
                m_playbackReady = false;
                if (wasAudioReady)
                    emit audioReadyChanged(false);
                if (m_wantsRunning && !m_audioRecoveryRequested &&
                    m_process.state() != QProcess::NotRunning) {
                    m_audioRecoveryRequested = true;
                    emit statusChanged(QStringLiteral("检测到小智音频线程初始化失败，正在自动恢复核心…"));
                    m_process.terminate();
                    QTimer::singleShot(1500, this, [this]() {
                        if (m_wantsRunning && m_audioRecoveryRequested &&
                            m_process.state() != QProcess::NotRunning)
                            m_process.kill();
                    });
                }
            } else if (!wasAudioReady && m_captureReady && m_playbackReady) {
                emit audioReadyChanged(true);
            }
        }
    });
    loadRuntimeConfig();
}

XiaozhiBridge::~XiaozhiBridge()
{
    stop();
}

QString XiaozhiBridge::executablePath() const
{
    return m_executablePath;
}

bool XiaozhiBridge::isRunning() const
{
    return m_process.state() != QProcess::NotRunning;
}

bool XiaozhiBridge::isActive() const
{
    return isRunning() || (m_restartTimer && m_restartTimer->isActive());
}

bool XiaozhiBridge::bindGuiSocket(QString *error)
{
    if (m_socket.state() == QAbstractSocket::BoundState)
        return true;
    if (!m_socket.bind(m_guiBindAddress, m_guiPort)) {
        if (error)
            *error = QStringLiteral("无法监听小智 GUI UDP 端口 %1：%2")
                    .arg(m_guiPort).arg(m_socket.errorString());
        return false;
    }
    return true;
}

void XiaozhiBridge::loadRuntimeConfig()
{
    QStringList candidates;
    const QString configuredPath = QString::fromLocal8Bit(qgetenv("XIAOZHI_CONFIG_PATH"));
    const bool workingDirectoryWasExplicit = !qgetenv("XIAOZHI_WORKDIR").isEmpty();
    if (!configuredPath.isEmpty())
        candidates << configuredPath;
    candidates << QDir::current().filePath(QStringLiteral("xiaozhi_config.json"));
    candidates << QDir(m_workingDirectory).filePath(QStringLiteral("xiaozhi_config.json"));
    candidates << QStringLiteral("/xiaozhi_config.json");
    candidates.removeDuplicates();

    for (const QString &path : candidates) {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly))
            continue;
        QJsonParseError parseError;
        const QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &parseError);
        if (parseError.error != QJsonParseError::NoError || !doc.isObject())
            continue;

        const QJsonObject object = doc.object();
        const QJsonValue remotePort = object.value(QStringLiteral("gui_remote_port"));
        if (remotePort.isDouble()) {
            const int port = remotePort.toInt();
            if (port > 0 && port <= 65535)
                m_guiPort = static_cast<quint16>(port);
        }
        const QString remoteIp = object.value(QStringLiteral("gui_remote_ip")).toString();
        if (!remoteIp.isEmpty()) {
            QHostAddress address;
            if (address.setAddress(remoteIp))
                m_guiBindAddress = address;
        }
        if (object.value(QStringLiteral("enable_tts_display")).isBool())
            m_ttsDisplayEnabled = object.value(QStringLiteral("enable_tts_display")).toBool();

        if (!workingDirectoryWasExplicit)
            m_workingDirectory = QFileInfo(path).absolutePath();
        return;
    }
}

bool XiaozhiBridge::start(QString *error)
{
    if (m_process.state() != QProcess::NotRunning) {
        emit statusChanged(QStringLiteral("小智核心已在运行"));
        return true;
    }
    if (m_restartTimer)
        m_restartTimer->stop();
    m_restartAttempts = 0;
    m_wantsRunning = true;
    if (!launchCore(error)) {
        m_wantsRunning = false;
        return false;
    }
    if (!m_ttsDisplayEnabled)
        emit statusChanged(QStringLiteral("小智已启动；请在配置中启用 enable_tts_display=true 才能显示字幕"));
    else
        emit statusChanged(QStringLiteral("小智已启动，正在检查激活状态与云端连接"));
    return true;
}

bool XiaozhiBridge::launchCore(QString *error)
{
    const QFileInfo executable(m_executablePath);
    if (!executable.exists() || !executable.isFile()) {
        if (error)
            *error = QStringLiteral("未找到小智程序：%1").arg(m_executablePath);
        return false;
    }
    if (!executable.isExecutable()) {
        if (error)
            *error = QStringLiteral("小智程序没有执行权限：%1").arg(m_executablePath);
        return false;
    }
    if (!bindGuiSocket(error))
        return false;

    m_audioRecoveryRequested = false;
    m_captureReady = false;
    m_playbackReady = false;
    m_logLineBuffer.clear();
    emit audioReadyChanged(false);
    m_process.setProgram(m_executablePath);
    m_process.setArguments(QStringList());
    m_process.setWorkingDirectory(m_workingDirectory);
    m_process.setProcessChannelMode(QProcess::MergedChannels);
    m_process.start();
    return true;
}

void XiaozhiBridge::scheduleRestart()
{
    if (!m_wantsRunning || !m_restartTimer || m_restartTimer->isActive())
        return;
    if (m_restartAttempts >= 3) {
        m_wantsRunning = false;
        emit statusChanged(QStringLiteral("小智核心连续启动失败 3 次，已停止自动重试；请检查核心日志、配置和音频设备"));
        return;
    }

    ++m_restartAttempts;
    const int delayMs = m_restartAttempts == 1 ? 2000 : (m_restartAttempts == 2 ? 5000 : 12000);
    m_restartTimer->start(delayMs);
    emit statusChanged(QStringLiteral("小智核心正在自动恢复，%1 秒后重试（%2/3）")
                           .arg((delayMs + 999) / 1000).arg(m_restartAttempts));
}

void XiaozhiBridge::stop()
{
    m_wantsRunning = false;
    m_audioRecoveryRequested = false;
    m_captureReady = false;
    m_playbackReady = false;
    emit audioReadyChanged(false);
    if (m_restartTimer)
        m_restartTimer->stop();
    if (m_process.state() != QProcess::NotRunning) {
        m_process.terminate();
        if (!m_process.waitForFinished(1200)) {
            m_process.kill();
            m_process.waitForFinished(1000);
        }
    }
    m_socket.close();
}

void XiaozhiBridge::readDatagrams()
{
    while (m_socket.hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(static_cast<int>(m_socket.pendingDatagramSize()));
        if (m_socket.readDatagram(datagram.data(), datagram.size()) < 0)
            continue;

        QJsonParseError parseError;
        const QJsonDocument document = QJsonDocument::fromJson(datagram, &parseError);
        if (parseError.error != QJsonParseError::NoError || !document.isObject())
            continue;
        const QJsonObject object = document.object();
        const QString type = object.value(QStringLiteral("type")).toString();
        if (type == QLatin1String("tts")) {
            const QString text = object.value(QStringLiteral("text")).toString().trimmed();
            const QString sentenceState = object.value(QStringLiteral("state")).toString();
            if (!text.isEmpty())
                emit chatTextReceived(text, sentenceState);
        } else if (type == QLatin1String("toast")) {
            emit toastReceived(object.value(QStringLiteral("text")).toString());
        } else if (type == QLatin1String("activation")) {
            emit activationCodeReceived(object.value(QStringLiteral("code")).toString());
        }

        const QJsonValue stateValue = object.value(QStringLiteral("state"));
        if (stateValue.isDouble()) {
            const int state = stateValue.toInt();
            emit coreStateChanged(state);
        }
    }
}
