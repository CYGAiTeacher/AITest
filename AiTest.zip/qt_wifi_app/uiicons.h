#ifndef UIICONS_H
#define UIICONS_H

#include <QColor>
#include <QIcon>

namespace UiIcon {
enum Type {
    Board,
    Wifi,
    WifiConnected,
    TestGrid,
    Rs485,
    Can,
    Led,
    Beep,
    Lock,
    Eye,
    Search,
    ArrowRight,
    Offline,
    Back,
    Keyboard,
    Backspace,
    Check
};
}

QIcon makeUiIcon(UiIcon::Type type, const QColor &color);

#endif // UIICONS_H
