#include "ntpsynchronizer.h"

#include <QByteArray>
#include <QStringList>

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <linux/rtc.h>
#include <netdb.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

namespace {

const quint32 kNtpUnixEpochDelta = 2208988800U;
const int kNtpPacketSize = 48;
const int kNtpTimeoutMs = 1600;

void writeNetworkUInt32(char *bytes, quint32 value)
{
    bytes[0] = static_cast<char>((value >> 24) & 0xff);
    bytes[1] = static_cast<char>((value >> 16) & 0xff);
    bytes[2] = static_cast<char>((value >> 8) & 0xff);
    bytes[3] = static_cast<char>(value & 0xff);
}

quint32 readNetworkUInt32(const char *bytes)
{
    return (quint32(static_cast<unsigned char>(bytes[0])) << 24)
         | (quint32(static_cast<unsigned char>(bytes[1])) << 16)
         | (quint32(static_cast<unsigned char>(bytes[2])) << 8)
         | quint32(static_cast<unsigned char>(bytes[3]));
}

double timevalSeconds(const timeval &value)
{
    return double(value.tv_sec) + double(value.tv_usec) / 1000000.0;
}

void writeNtpTimestamp(char *bytes, const timeval &value)
{
    const quint32 seconds = quint32(quint64(value.tv_sec) + kNtpUnixEpochDelta);
    const quint32 fraction = quint32((quint64(value.tv_usec) << 32) / 1000000ULL);
    writeNetworkUInt32(bytes, seconds);
    writeNetworkUInt32(bytes + 4, fraction);
}

double readNtpTimestamp(const char *bytes)
{
    const quint32 ntpSeconds = readNetworkUInt32(bytes);
    const quint32 fraction = readNetworkUInt32(bytes + 4);
    return double(qint64(ntpSeconds) - qint64(kNtpUnixEpochDelta))
         + double(fraction) / 4294967296.0;
}

bool queryServer(const QString &host, qint64 *utcMilliseconds, QString *error)
{
    struct addrinfo hints;
    std::memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_protocol = IPPROTO_UDP;

    struct addrinfo *addresses = nullptr;
    const QByteArray hostName = host.toLatin1();
    const int resolveResult = ::getaddrinfo(hostName.constData(), "123", &hints, &addresses);
    if (resolveResult != 0) {
        if (error)
            *error = QString::fromLocal8Bit(::gai_strerror(resolveResult));
        return false;
    }

    bool success = false;
    QString lastError = QStringLiteral("NTP server did not respond");
    for (struct addrinfo *address = addresses; address && !success; address = address->ai_next) {
        const int socketFd = ::socket(address->ai_family, address->ai_socktype,
                                      address->ai_protocol);
        if (socketFd < 0) {
            lastError = QString::fromLocal8Bit(std::strerror(errno));
            continue;
        }

        if (::connect(socketFd, address->ai_addr, address->ai_addrlen) != 0) {
            lastError = QString::fromLocal8Bit(std::strerror(errno));
            ::close(socketFd);
            continue;
        }

        timeval requestTime;
        if (::gettimeofday(&requestTime, nullptr) != 0) {
            lastError = QString::fromLocal8Bit(std::strerror(errno));
            ::close(socketFd);
            continue;
        }

        QByteArray request(kNtpPacketSize, char(0));
        request[0] = char(0x23); // LI=0, NTP version 4, client mode.
        writeNtpTimestamp(request.data() + 40, requestTime);

        const ssize_t sent = ::send(socketFd, request.constData(),
                                    size_t(request.size()), 0);
        if (sent != request.size()) {
            lastError = QString::fromLocal8Bit(std::strerror(errno));
            ::close(socketFd);
            continue;
        }

        struct pollfd descriptor;
        descriptor.fd = socketFd;
        descriptor.events = POLLIN;
        descriptor.revents = 0;
        int pollResult;
        do {
            pollResult = ::poll(&descriptor, 1, kNtpTimeoutMs);
        } while (pollResult < 0 && errno == EINTR);

        if (pollResult <= 0 || !(descriptor.revents & POLLIN)) {
            lastError = pollResult == 0
                            ? QStringLiteral("NTP response timed out")
                            : QString::fromLocal8Bit(std::strerror(errno));
            ::close(socketFd);
            continue;
        }

        QByteArray response(kNtpPacketSize, char(0));
        const ssize_t received = ::recv(socketFd, response.data(),
                                        size_t(response.size()), 0);
        timeval receiveTime;
        const bool gotReceiveTime = ::gettimeofday(&receiveTime, nullptr) == 0;
        ::close(socketFd);

        if (received < kNtpPacketSize || !gotReceiveTime) {
            lastError = received < kNtpPacketSize
                            ? QStringLiteral("Invalid NTP response length")
                            : QString::fromLocal8Bit(std::strerror(errno));
            continue;
        }

        const unsigned char header = static_cast<unsigned char>(response.at(0));
        const int mode = header & 0x07;
        const int version = (header >> 3) & 0x07;
        const int stratum = static_cast<unsigned char>(response.at(1));
        if (mode != 4 || version < 3 || stratum < 1 || stratum > 15) {
            lastError = QStringLiteral("NTP server returned an invalid time packet");
            continue;
        }

        if (std::memcmp(response.constData() + 24, request.constData() + 40, 8) != 0) {
            lastError = QStringLiteral("NTP response did not match the request");
            continue;
        }

        const double t1 = timevalSeconds(requestTime);
        const double t2 = readNtpTimestamp(response.constData() + 32);
        const double t3 = readNtpTimestamp(response.constData() + 40);
        const double t4 = timevalSeconds(receiveTime);
        const double offset = ((t2 - t1) + (t3 - t4)) / 2.0;
        const double correctedUtc = t4 + offset;
        if (correctedUtc < 0.0) {
            lastError = QStringLiteral("NTP server returned an out-of-range time");
            continue;
        }

        *utcMilliseconds = qint64(correctedUtc * 1000.0 + 0.5);
        success = true;
    }

    ::freeaddrinfo(addresses);
    if (!success && error)
        *error = lastError;
    return success;
}

bool setSystemClock(qint64 utcMilliseconds, QString *error)
{
    struct timeval value;
    value.tv_sec = time_t(utcMilliseconds / 1000);
    value.tv_usec = suseconds_t(utcMilliseconds % 1000) * 1000;
    if (::settimeofday(&value, nullptr) == 0)
        return true;
    if (error)
        *error = QString::fromLocal8Bit(std::strerror(errno));
    return false;
}

bool writeRtcClock(qint64 utcMilliseconds, QString *deviceUsed, QString *error)
{
    const time_t utcSeconds = time_t((utcMilliseconds + 500) / 1000);
    struct tm utcFields;
    if (!::gmtime_r(&utcSeconds, &utcFields)) {
        if (error)
            *error = QStringLiteral("Unable to convert NTP time for RTC");
        return false;
    }

    struct rtc_time rtcValue;
    std::memset(&rtcValue, 0, sizeof(rtcValue));
    rtcValue.tm_sec = utcFields.tm_sec;
    rtcValue.tm_min = utcFields.tm_min;
    rtcValue.tm_hour = utcFields.tm_hour;
    rtcValue.tm_mday = utcFields.tm_mday;
    rtcValue.tm_mon = utcFields.tm_mon;
    rtcValue.tm_year = utcFields.tm_year;
    rtcValue.tm_wday = utcFields.tm_wday;
    rtcValue.tm_yday = utcFields.tm_yday;
    rtcValue.tm_isdst = 0;

    QStringList devices;
    const QByteArray overrideDevice = qgetenv("RTC_DEVICE");
    if (!overrideDevice.isEmpty())
        devices << QString::fromLocal8Bit(overrideDevice);
    devices << QStringLiteral("/dev/rtc0")
            << QStringLiteral("/dev/rtc")
            << QStringLiteral("/dev/rtc1");

    QString lastError = QStringLiteral("No usable RTC device found");
    for (const QString &device : devices) {
        const QByteArray devicePath = device.toLocal8Bit();
        const int fd = ::open(devicePath.constData(), O_RDWR);
        if (fd < 0) {
            lastError = QStringLiteral("%1: %2")
                            .arg(device, QString::fromLocal8Bit(std::strerror(errno)));
            continue;
        }

        const int result = ::ioctl(fd, RTC_SET_TIME, &rtcValue);
        const int ioctlError = errno;
        ::close(fd);
        if (result == 0) {
            if (deviceUsed)
                *deviceUsed = device;
            return true;
        }
        lastError = QStringLiteral("%1: %2")
                        .arg(device, QString::fromLocal8Bit(std::strerror(ioctlError)));
    }

    if (error)
        *error = lastError;
    return false;
}

} // namespace

NtpSynchronizer::NtpSynchronizer(QObject *parent)
    : QObject(parent)
{
}

void NtpSynchronizer::synchronize()
{
    const QStringList servers = QStringList()
        << QStringLiteral("ntp.aliyun.com")
        << QStringLiteral("ntp.tencent.com")
        << QStringLiteral("cn.pool.ntp.org")
        << QStringLiteral("ntp.ntsc.ac.cn");

    qint64 utcMilliseconds = 0;
    QString lastError;
    QString usedServer;
    for (const QString &server : servers) {
        if (queryServer(server, &utcMilliseconds, &lastError)) {
            usedServer = server;
            break;
        }
    }

    if (usedServer.isEmpty()) {
        emit synchronizationFinished(false, 0, false, false,
                                     QStringLiteral("无法从互联网获取北京时间：%1").arg(lastError));
        return;
    }

    QString clockError;
    const bool clockSet = setSystemClock(utcMilliseconds, &clockError);
    QString rtcDevice;
    QString rtcError;
    const bool rtcWritten = writeRtcClock(utcMilliseconds, &rtcDevice, &rtcError);

    QString message = QStringLiteral("北京时间已从 %1 同步").arg(usedServer);
    message += clockSet ? QStringLiteral("；系统时钟已校准")
                        : QStringLiteral("；系统时钟校准失败（%1）").arg(clockError);
    message += rtcWritten ? QStringLiteral("；已写入 RTC %1（UTC）").arg(rtcDevice)
                          : QStringLiteral("；RTC 写入失败（%1）").arg(rtcError);
    emit synchronizationFinished(true, utcMilliseconds, clockSet, rtcWritten, message);
}
