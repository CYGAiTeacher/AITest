# 开发板 Wi‑Fi 与外设测试程序（Qt 5 Widgets）

目标：Linux 开发板，4.3 英寸 480 × 272 横屏 LCD。首页顶栏强制 LTR：左侧为“硬件测试”图标/标题，中间居中显示北京时间，最右侧为 Wi-Fi 图标、连接状态和 IP；日期使用亮蓝、时分秒使用浅色正文分别显示，合起来为 `yyyy-MM-dd HH:mm:ss`。首页底部不重复显示 IP。首次联网取得 IP 后，程序通过互联网 NTP 自动同步北京时间（UTC+8），并尝试校准系统时钟及写入 RTC。首页外设入口可打开录音/播放、小智 AI 对话、RS485/STM32 温湿度曲线及 LED/蜂鸣器控制；CAN 仍未接入。Wi-Fi 凭据独立持久化，并支持启动自动连接、扫描和 WPA/WPA2-Personal 或开放网络连接。详细页面设计、寄存器表和部署边界见 [`UI_DESIGN.md`](UI_DESIGN.md)。

## 功能

- 没有独立 Wi-Fi 凭据文件时，首次启动进入 Wi-Fi 设置页；凭据文件存在时启动进入首页，并自动尝试连接。
- Wi-Fi 扫描子页不显示密码输入框；网络列表按信号强度排序并纵向扩展，占据页面主要区域，用图片锁图标区分加密网络、标记暂不支持的加密类型。底部只保留紧凑的“返回”和“连接”按钮。选择加密网络并点“连接”后进入独立密码页；开放网络直接连接。扫描使用 wpa_supplicant 控制接口；连接时由 `wpa_cli add_network/set_network/enable_network/select_network` 动态配置，**不会执行 `SAVE_CONFIG`，不会把新输入的 SSID/密码写入 `wpa_supplicant.conf`**。
- SSID、密码和安全类型保存在独立 JSON 文件 `wifi_credentials.json`；Linux 下文件权限限制为仅所有者读写。WPA 成功后运行 `udhcpc -i <接口>` 获取 IPv4。
- 首页顶栏强制从左到右排列：“硬件测试”固定最左、北京时间居中、Wi-Fi 图标/状态/IP 固定最右；点击右侧 Wi-Fi 图标打开设置。主界面底部不重复显示 IP。整体采用深蓝主题：窗口底色 `#0B1727`，顶栏 `#102036`，卡片 `#12253B`，控件 `#172B43`；以亮蓝 `#5AAAF2`、浅色正文和清晰描边分层，不用大面积纯白填充。所有 UI 图标均为适配深色背景的 PNG 图片资源。
- 触屏运行时隐藏 Qt 鼠标指针；按钮在按住期间使用高亮边框和明显的底色变化反馈触摸。部分较小的操作图标已加大。
- 可点击按钮（包含触屏键盘）按下时播放约 110 ms 的清晰轻柔单击音效。音频资源内置于 Qt Resource，运行时临时释放后由 `aplay` 播放，复用 `APLAY_PATH` 与 `AUDIO_PLAYBACK_DEVICE` 配置，不新增 Qt Multimedia 依赖；目标系统需有 `alsa-utils` 和 ALSA 播放权限。为避免不支持软件混音的 ALSA 设备被两个 `aplay` 进程争用，录音或文件播放进行中会抑制单击音效，启动录放前也会先停止短音效；录放操作优先。若音频命令无法启动，按钮操作仍正常，只是不播放声音。
- DHCP 获取到 IP 后自动通过 NTP 获取北京时间（UTC+8），依次尝试 `ntp.aliyun.com`、`ntp.tencent.com`、`cn.pool.ntp.org` 和 `ntp.ntsc.ac.cn`。成功后尝试用 `settimeofday()` 校准系统时钟，并通过 Linux `RTC_SET_TIME` 将 NTP 时间写入 RTC；RTC 按 Linux 常规约定写入 UTC，界面显示 UTC+8。默认依次尝试 `/dev/rtc0`、`/dev/rtc`、`/dev/rtc1`，可用 `RTC_DEVICE=/dev/rtcX` 指定设备。设置系统时钟/RTC 通常需要 root 或 `CAP_SYS_TIME` 及 RTC 设备写权限；权限不足时会记录失败原因，但顶栏仍使用获取到的网络时间显示。请确保 DNS 可用且出站 UDP 123 未被拦截；NTP 获取失败时每 30 秒重试。
- WPA/WPA2-Personal 普通密码按 `wpa_cli` 的方式以带引号的 `SET_NETWORK <id> psk "passphrase"` 命令传给 wpa_supplicant，由它派生 PSK；64 位十六进制输入仍按原始 PSK 设置。
- 凭据文件是明文，应用会尽量设为 `0600`，默认保存在当前运行用户的应用配置目录；可用 `WIFI_CREDENTIALS_PATH` 指定可写分区上的路径。密码也会短暂作为参数传给 `wpa_cli`，有权限查看进程参数的本机用户可能看到它。请以专用低权限用户运行并保护凭据文件。

## 外设测试面板

首页主卡片进入外设测试菜单。音频、小智、RS485 使用独立子页；首页 RS485、LED、蜂鸣器快捷项进入同一个 RS485 控制页。CAN 仍是禁用占位项。

### 音频录音与播放

- 录音由 `arecord` 执行，默认设备 `default`、格式 `S16_LE`、单声道、采样率 `16000 Hz`，输出默认写入 `/tmp/board_peripheral_recording.wav`。
- 按“开始录音”开始采集；再次按键向 `arecord` 发送终止信号，关闭 WAV 文件后自动调用 `aplay` 回放。
- “播放 /music.wav”使用 `aplay` 播放指定的音乐文件。
- 环境变量：`ARECORD_PATH`、`APLAY_PATH`、`AUDIO_CAPTURE_DEVICE`、`AUDIO_PLAYBACK_DEVICE`、`AUDIO_SAMPLE_RATE`、`AUDIO_RECORD_PATH`。采样率接受 8000–96000 Hz；默认音乐路径严格为 `/music.wav`。录音/播放用户须有 ALSA 设备访问权限，并安装 `alsa-utils`（提供 `arecord`、`aplay`）。

### 小智 Linux 语音与聊天字幕

点击菜单中的“小智语音”会先监听 GUI UDP 端口，再自动启动默认程序 `/xiaozhi_linux_rs-armv7-gnueabihf`；离开页面时会停止进程。该路径是外部部署的 ARMv7 GNU/GLIBC 可执行文件，**不包含在本 Qt 工程 ZIP 中**；板端需匹配 ABI、执行权限和依赖库。可用 `XIAOZHI_EXECUTABLE` 指定其他程序，用 `XIAOZHI_WORKDIR` 指定其工作目录。

**首次激活与首次对话：**页面提供指向官方控制台 `https://xiaozhi.me/console/` 的二维码。Core 通过 `type: "activation"` 消息返回真实六码后，界面原样显示；未收到时只显示“等待激活码”，不会伪造或预填验证码。按提示扫码打开控制台、注册/登录，在设备管理中添加设备并输入该六码完成绑定（官网界面名称可能变化，请以控制台当前指引为准）。绑定前不显示正常对话界面。Core 会先报告“设备已激活”，之后才启动音频线程和云端连接；GUI 不只等待 `state: 3`，还要从 Core 日志确认录音与播放分别出现 `Recording started` 和 `Playback started`，两项都就绪才开放对话。这样避免把“已绑定/云端已连”误当成麦克风、扬声器已经可用，降低第一次讲话落在 ALSA 初始化竞态中的风险。若 Core 异常退出，或日志出现 `Recording thread error` / `Playback thread error`（ALSA/音频线程初始化失败），GUI 会自动重启核心，并按 2、5、12 秒间隔恢复，最多 3 次；若核心经自动恢复后 30 秒仍未同时进入云端在线和音频就绪，激活卡片会提示先点“停止小智”，待按钮变为“启动小智”后再点一次；连接恢复前不开放对话区。

小智核心使用本机 UDP/JSON IPC：默认 GUI 绑定本机回环地址并监听 `5679/UDP` 接收 Core 消息；Core 在 `5678/UDP` 接收 GUI 控制指令，但当前界面不发送用户文字命令。默认 Core 向 `127.0.0.1:5679` 发送状态与字幕。桥接会从 `xiaozhi_config.json` 读取 Core 指定的 GUI 监听地址/端口（`gui_remote_ip`、`gui_remote_port`）及 `enable_tts_display`；Core 端接收控制指令的 `gui_local_port` 保持由上游配置管理。必须启用 `enable_tts_display: true` 才会收到 TTS 字幕。助手 TTS `sentence_start` / `sentence_end` 消息显示为左侧气泡；用户语音识别结果显示为右侧绿色气泡。当前上游 Core 的 GUI UDP 协议尚未发送 STT，但 Core 会在合并输出日志中记录 `STT Result: ...`；`XiaozhiBridge` 从该日志提取识别完成后的用户文本并显示，不是实时逐字字幕。如果 Core 版本关闭 INFO 日志或更改该日志格式，需由 Core 通过 UDP 发送 `type: "stt"`，或同步调整 GUI 解析规则。状态、Toast 和激活码也在页面显示。小智 Core 的标准输出/错误输出会写入 Qt 应用日志，便于排查初始化失败。麦克风采集与扬声器播放由小智核心按其配置的 ALSA 设备处理。请按上游仓库的 [GUI 适配说明](https://github.com/haoyn231/xiaozhi_linux_rs/blob/main/docs/GUI%E9%80%82%E9%85%8D%E8%AF%B4%E6%98%8E.md) 配置核心音频设备、网络激活与 `xiaozhi_config.json`。如需从指定文件读取 GUI UDP 地址/端口，可设置 `XIAOZHI_CONFIG_PATH`；桥接本身不会修改该文件。若文件不存在，小智核心会按自身行为尝试在工作目录生成默认配置，非 root 部署时请预先提供可写的 `XIAOZHI_WORKDIR` 和配置文件。

### RS485 / Modbus RTU 与 STM32

串口由 POSIX `termios` 在工作线程访问，不依赖 Qt SerialPort 插件。默认 `/dev/ttymxc2`、`19200 baud`、`8E1`、站号 `1`；每秒以功能码 `03` 读取 4 个保持寄存器，使用标准 Modbus RTU CRC-16（多项式 `0xA001`、低字节先发），控制输出使用功能码 `06`。读超时为 400 ms。运行时可以通过 `MODBUS_DEVICE`、`MODBUS_BAUD`、`MODBUS_SLAVE_ID` 覆盖默认参数。

| 保持寄存器地址 | 字段 | 编码 / 写入约定 |
|---|---|---|
| `0x0000` | LED 输出 | `0` 关闭、`1` 打开；功能码 `06` 单寄存器写入 |
| `0x0001` | 蜂鸣器输出 | `0` 关闭、`1` 打开；功能码 `06` 单寄存器写入 |
| `0x0002` | 温度 | 有符号 16 位补码，单位 `0.01 °C`（例如 `2350` 表示 `23.50 °C`） |
| `0x0003` | 相对湿度 | 无符号 16 位，单位 `0.01 %RH`（例如 `4567` 表示 `45.67 %RH`） |

寄存器地址和传感器缩放是本项目约定，STM32 固件需按同一映射实现；标准只规定 Modbus RTU 帧、CRC 和功能码。客户端尝试用 Linux `TIOCSRS485` 配置发送方向；若 BSP/驱动不支持该 ioctl，页面会提示检查设备树/驱动方向控制，不能仅靠应用假定硬件已切换收发方向。曲线保留最近 60 次有效采样，温度显示范围按 `−10…60 °C`、湿度按 `0…100 %RH`；超出温度图范围的点会贴边显示，但状态值仍以寄存器解码。

当前不支持 WPA-Enterprise、WEP、仅 WPA3-SAE、隐藏网络手动添加、门户认证等特殊情形。

## 编译

需要目标机/交叉编译环境中安装 Qt 5 Widgets、Qt Network 开发包和 C++11 编译器（建议 Qt 5.9 或更新版本；Network 用于小智 UDP IPC）。项目同时提供 qmake 和 CMake：

### qmake

```sh
cd qt_wifi_app
qmake board_wifi_ui.pro
make -j4
```

### CMake

```sh
cd qt_wifi_app
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/target/qt5
cmake --build build -j4
```

生成程序：`board_wifi_ui`。在开发板上以全屏、无边框方式运行。

## ARM 屏幕字体与颜色

- 程序可优先加载可执行文件旁 `fonts/NotoSansSC-Regular.otf`，也可用 `QT_APP_FONT=/path/to/font.otf` 指定板端字体；缺少该文件时会回退到系统中文字体。为缩小交付包，工程 ZIP 不包含字体文件；如需随程序携带 Noto Sans SC（SIL OFL 1.1），可单独将字体放入 `fonts/` 目录再构建。
- Qt 默认字体改为 13 像素，设置 FreeType full hinting 与 `QFont::PreferAntialias`；网络列表文字显式启用 `QPainter::TextAntialiasing`；UI 图标全部从 Qt 资源中的 PNG 图片加载并以平滑变换缩放，不使用运行时矢量绘图。界面小字加大并提高文字/边框对比度。针对固定 480×272 屏幕，在 Qt 5.6+ 禁用高 DPI 自动缩放，避免界面被非整数比例重采样。
- 正式 UI 使用深蓝色调色板：窗口/页面 `#0B1727`、顶栏 `#102036`、卡片 `#12253B`、按键 `#172B43`、描边 `#2A405A`、正文 `#E8F0FA`、辅助文字 `#ADBED2`、主操作亮蓝 `#5AAAF2`，并为 Wi-Fi、网络状态与告警使用高对比绿/红。各层使用不同深浅和描边区分；不使用浅蓝灰主背景或大面积纯白填充。正式页面的白色只保留在二维码局部扫码底和少量文字/图标上；纯白大色块仅出现在 `--display-test` 诊断模式。图标 PNG 按深色表面重配亮蓝与浅色，编入 Qt 资源。程序启动日志打印 Qt 实际 `Window` 色、屏幕分辨率、色深和 DPR，便于核对目标板渲染。
- 若文字仍像缺笔/方框，确认 Buildroot Qt 启用了 FreeType 字体引擎，且程序能读到字体文件。若整套颜色仍偏色、红蓝互换或灰阶不正常，这通常是 framebuffer/DRM 的通道位域或像素格式与 Qt QPA 平台插件不一致，单改 QSS 调色板无法可靠修复；请记录 `Qt display` 日志，并提供 Qt 版本、`QT_QPA_PLATFORM`、显示栈（linuxfb/EGLFS/X11/Wayland）及一张界面照片，再按实际像素格式修正驱动/平台插件。

## 显示左侧色差诊断

正常 UI 使用深蓝调色板背景（`#0B1727`），卡片以更亮的深蓝表面区分；不再使用全屏 PNG。若屏幕左侧仍有色差，可运行同一程序的纯色诊断模式：

```sh
./board_wifi_ui --display-test
```

此模式不创建主界面和控件，只用 Qt `QPainter` 的 `CompositionMode_Source` 全屏依次填充灰、红、绿、蓝、白、黑，每 3 秒切换。用手机拍摄灰/白和红绿蓝画面，并观察色差是否始终固定在屏幕最左侧；按 `Ctrl+C` 或结束进程退出。

- 若纯色测试中仍在同一位置出现色条，问题不在主界面背景图或卡片样式，应进一步检查 Qt QPA 输出、Framebuffer/DRM 的像素格式/stride/offset，以及面板扫描和连接。
- 若纯色测试正常、只有正式界面出现色条，则问题仍在控件层级或页面重绘，我们再按实际界面布局定位。

设备树 porch/sync/clock 配置影响整帧扫描时序；目前不建议仅凭照片改动 timing。`bus-width=24` 与 framebuffer `16 bpp` 是否匹配要按显示控制器驱动约定判断，不能只看数值决定。

## wpa_supplicant 前置配置

程序不会替系统启动 wpa_supplicant 守护进程或在 `/run` 中创建 socket。扫描通过 Unix 控制套接字工作；连接和状态操作通过 `wpa_cli`，因此目标板需安装 `wpa_cli` 并确保它在 `PATH` 中（或设置 `WPA_CLI_PATH`）。WPA 握手成功后，程序调用 BusyBox `udhcpc -i <接口>` 获取地址；目标板也需安装 `udhcpc`，并配置可用的 DHCP 事件脚本（默认通常为 `/usr/share/udhcpc/default.script`，具体以 Buildroot 配置为准）。**socket 不是单独的配置文件**：`ctrl_interface` 写在 wpa_supplicant 正在使用的配置文件里，守护进程启动后才会创建类似 `/run/wpa_supplicant/wlan0` 的 socket。示例见 `wpa_supplicant.conf.example`。

将下面配置合并到开发板当前实际使用的 wpa_supplicant 配置文件中，不要覆盖厂商已有的其他设置：

```ini
ctrl_interface=DIR=/run/wpa_supplicant
```

先用 root 联调时可不指定组；若 Qt 程序以普通用户运行，应改为板上确实存在的组，例如 `ctrl_interface=DIR=/run/wpa_supplicant GROUP=netdev`，并让运行用户加入该组后重新登录。若系统通过 systemd、NetworkManager 或其他服务管理 Wi-Fi，请修改/重启现有服务使用的配置，不要再启动第二个 wpa_supplicant 实例。此程序不会调用 `SAVE_CONFIG`，因此不依赖 `update_config=1`。请检查并删除活动 `wpa_supplicant.conf` 中旧版本遗留的含密码 `network={...}` 配置块；新凭据只由程序从独立凭据文件读取。

启动或重启现有服务后检查 socket 和权限：

```sh
ls -l /run/wpa_supplicant
wpa_cli -p /run/wpa_supplicant -i wlan0 ping   # 正常应返回 PONG
wpa_cli -p /run/wpa_supplicant -i wlan0 scan
sleep 3
wpa_cli -p /run/wpa_supplicant -i wlan0 scan_results
```

若 socket 在其他位置，用 `WPA_CTRL_DIR` 或 `WPA_CTRL_PATH` 指向实际路径。普通 WPA/WPA2-Personal 密码只通过控制接口以带引号的口令传给 wpa_supplicant，不写回活动配置文件；64 位十六进制 PSK 则直接按原始 PSK 设置。

### Buildroot / BusyBox 快速核对

1. 用 `ps | grep wpa_supplicant` 找出当前启动命令和 `-c` 指向的配置文件；编辑这份活动配置，不要只新建一份未被服务读取的文件。
2. 在活动配置中加入上面的 `ctrl_interface`。本程序不写回网络配置，`update_config=1` 不是必需项。首次联调建议以 root 启动 Qt 程序；如以普通用户运行，先确认组名存在并配置 `GROUP=...`。
3. 若已写入 `ctrl_interface` 但仍没有 socket，检查 Buildroot `make menuconfig` 中 wpa_supplicant 的 **Enable the Unix-socket control interface**（`BR2_PACKAGE_WPA_SUPPLICANT_CTRL_IFACE`）是否启用；wpa_supplicant 构建配置应包含 `CONFIG_CTRL_IFACE=y`。这是编译选项，后期版本并没有普遍取消每接口 socket。
4. 重启板上现有的 init 脚本/服务；不要在已有进程旁边再启动一个实例。若确认当前没有运行进程，才按板上实际配置路径手动测试，例如：

```sh
mkdir -p /run/wpa_supplicant
wpa_supplicant -B -D nl80211 -i wlan0 -c /etc/wpa_supplicant.conf
```

将示例中的接口名、驱动和配置路径替换成该板实际值。随后确认 `/run/wpa_supplicant/wlan0` 存在，并运行 `wpa_cli -p /run/wpa_supplicant -i wlan0 ping`（返回 `PONG` 表示控制接口可用）。
5. 确认 BusyBox 启用了 `udhcpc`，应用运行用户有权配置网卡，并且 DHCP 脚本存在且可执行。程序以 `udhcpc -i <接口> -p /run/udhcpc-<接口>.pid` 启动/复用客户端；等待最多 20 秒读取接口 IPv4 地址。没有地址时，Qt 仍会报告 Wi-Fi 已连接，但显示“未获取到 IP”；检查 DHCP 服务、脚本路径及其 `bound` 处理。程序通过 pidfile 避免重复启动，并在复用时请求续租。

如果 Buildroot 使用只读 rootfs，请把配置和启动脚本改动放进 rootfs overlay/镜像配置，否则重启后会丢失。

## 接口名称与控制目录

默认接口为 `wlan0`，控制目录为 `/run/wpa_supplicant`。可通过环境变量覆盖：

```sh
WIFI_IFACE=wlan0 WPA_CTRL_DIR=/run/wpa_supplicant \
WIFI_CREDENTIALS_PATH=/data/wifi_credentials.json \
WPA_CLI_PATH=/usr/sbin/wpa_cli UDHCPC_PATH=/sbin/udhcpc ./board_wifi_ui
```

`WIFI_CREDENTIALS_PATH` 可选；默认在当前运行用户的 Qt 应用配置目录中。`WPA_CLI_PATH`、`UDHCPC_PATH` 也可省略；程序会搜索常见目录，或从 `PATH` 查找。

或使用参数：

```sh
./board_wifi_ui --interface wlan0 --ctrl-dir /run/wpa_supplicant
```

也支持通过 `WPA_CTRL_PATH` 指定控制套接字完整路径，例如 `/run/wpa_supplicant/wlan0`。

## 触摸屏软键盘

密码输入使用程序内置的 **Qt Widgets 触摸键盘**，不依赖 Qt Virtual Keyboard 插件或系统输入法。扫描页不显示密码框；选择加密网络后点击“连接”进入独立密码页，密码输入行靠近页面上沿。键盘打开时隐藏密码页其他控件和底部操作栏；输入行与键盘之间留有约 8 px 间距，键盘底色仍铺满屏幕宽度，最外侧按键与屏幕边缘留约 6 px 空隙。点击绿色“完成”键会校验密码：格式合法时切回扫描页并发起连接，扫描页显示带动态省略号的“正在连接 Wi-Fi”提示；密码为空或格式不合法时返回扫描页提示用户点击“连接”重新输入。连接失败会留在扫描页显示失败/重试提示；密码认证失败会提示可能密码错误并引导点击“连接”重新输入。连接成功后自动返回主界面。Wi-Fi 扫描、密码页均不显示当前 IP（IP 只在首页顶栏显示）。底部操作按钮高 30 px，靠近屏幕下沿。

键盘包含 QWERTY 字母、大小写切换、数字/符号页、空格和退格；字母键字体约 15 px、功能键约 13 px，按键随键盘区域高度伸展（约 32–50 px）。模式键按字母、数字、符号循环显示 `ABC`、`123`、`#+=`，默认 `ABC` 为蓝色底，切换后的模式状态使用深蓝底；完成键使用绿色底色。WPA/WPA2 密码格式为 8–63 位可见 ASCII 或 64 位十六进制 PSK。密码默认隐藏，可用眼睛图标切换显示；输入上限 64 个字符。底部操作按钮高 30 px，建议在目标板上确认触摸驱动的点击精度和按键响应。

## 状态与凭据

- 默认凭据文件为 `QStandardPaths::AppConfigLocation/wifi_credentials.json`（Linux 通常位于当前用户的 `~/.config/BoardLab/PeripheralTest/`）；可设置 `WIFI_CREDENTIALS_PATH=/data/wifi_credentials.json` 改到持久可写分区。应用首次保存时创建目录，并将凭据文件限制为仅所有者读写（`0600`）。
- 文件字段为 `version`、`ssid`、`password`、`secured`，例如 `{"version":1,"ssid":"your-ssid","password":"your-password","secured":true}`。内容为明文 JSON，不是加密保险箱；不要把该文件放入公开可读目录或打包进固件源码仓库。
- 没有可读且有效的凭据文件时显示 Wi-Fi 设置页；成功连接后写入独立文件。后续启动先进入首页，并从该文件读取凭据，通过 `wpa_cli` 发起连接。
- 所有网络配置只在运行中的 wpa_supplicant 内存中动态创建；应用不执行 `SAVE_CONFIG`，也不要求 `update_config=1`。若旧版曾保存过密码，请手动清理活动 `wpa_supplicant.conf` 中的旧 `network={...}` 块。
- 连接超时会附带最后一次 `STATUS` 的 `wpa_state`；`4WAY_HANDSHAKE`/`GROUP_HANDSHAKE` 表示关联后仍未完成密钥协商，可据此区分密码/安全模式问题与界面状态判断问题。
- Wi-Fi 扫描页的“返回”按钮离开设置页；未保存凭据时，下次启动仍会进入 Wi-Fi 设置。首页顶栏显示实时连接状态和 IP，点击 Wi-Fi 图标可重新设置网络。

## 本机验证限制

此工作区没有 Qt 开发库、目标板或小智 ARMv7 二进制，因此未完成 Qt 编译、ALSA 播放/录音、小智 Core UDP 联调及 STM32 RS485 硬件验证。请在目标板/交叉编译环境构建后检查 Wi-Fi 控制套接字、凭据权限、DHCP 脚本、触屏布局、ALSA 设备/权限、`/music.wav`、小智 ABI/配置/激活、UDP 5679、激活后 `state: 3` 就绪时序及自动恢复，以及 STM32 是否实现上述 Modbus 地址映射和 RS485 方向控制。
