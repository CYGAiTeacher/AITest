#include "mainwindow.h"
#include "modbusworker.h"
#include "ntpsynchronizer.h"
#include "uiicons.h"
#include "xiaozhibridge.h"

#include <QApplication>
#include <QAbstractButton>
#include <QAbstractItemView>
#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QDateTime>
#include <QDebug>
#include <QEvent>
#include <QFont>
#include <QFontMetrics>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMetaObject>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QPushButton>
#include <QSizePolicy>
#include <QStackedWidget>
#include <QStyle>
#include <QStyledItemDelegate>
#include <QStringList>
#include <QTemporaryFile>
#include <QTimer>
#include <QtGlobal>
#include <QToolButton>
#include <QVBoxLayout>
#include <QVariant>
#include <QVector>

namespace {

enum NetworkRoles {
    FlagsRole = Qt::UserRole + 1,
    SignalRole,
    SecuredRole,
    SupportedRole
};

bool isValidWpaPasswordFormat(const QString &password, QString *reason)
{
    const QByteArray bytes = password.toUtf8();
    if (bytes.size() == 64) {
        bool allHex = true;
        for (unsigned char c : bytes) {
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
                  (c >= 'A' && c <= 'F'))) {
                allHex = false;
                break;
            }
        }
        if (allHex) {
            if (reason)
                reason->clear();
            return true;
        }
    }

    if (bytes.size() < 8 || bytes.size() > 63) {
        if (reason)
            *reason = QStringLiteral("WPA/WPA2 密码需为 8–63 个 ASCII 字符，或 64 位十六进制 PSK。");
        return false;
    }
    for (unsigned char c : bytes) {
        if (c < 0x20 || c > 0x7e) {
            if (reason)
                *reason = QStringLiteral("WPA/WPA2 密码请使用可见 ASCII 字符。");
            return false;
        }
    }

    if (reason)
        reason->clear();
    return true;
}

QPixmap loadUiPixmap(const QString &resourcePath, const QSize &size)
{
    const QPixmap source(resourcePath);
    return source.isNull() ? QPixmap()
                           : source.scaled(size, Qt::KeepAspectRatio, Qt::SmoothTransformation);
}

class NetworkDelegate : public QStyledItemDelegate
{
public:
    explicit NetworkDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent),
          m_lockIcon(loadUiPixmap(QStringLiteral(":/ui/icons/lock_gray.png"), QSize(20, 20))),
          m_unsupportedLockIcon(loadUiPixmap(QStringLiteral(":/ui/icons/lock_red.png"), QSize(20, 20))),
          m_signal1(loadUiPixmap(QStringLiteral(":/ui/icons/signal_1.png"), QSize(28, 22))),
          m_signal2(loadUiPixmap(QStringLiteral(":/ui/icons/signal_2.png"), QSize(28, 22))),
          m_signal3(loadUiPixmap(QStringLiteral(":/ui/icons/signal_3.png"), QSize(28, 22))),
          m_signal4(loadUiPixmap(QStringLiteral(":/ui/icons/signal_4.png"), QSize(28, 22))),
          m_unsupportedIcon(loadUiPixmap(QStringLiteral(":/ui/icons/unsupported.png"), QSize(14, 14))),
          m_selectedIcon(loadUiPixmap(QStringLiteral(":/ui/icons/selected.png"), QSize(8, 8)))
    {
    }

    QSize sizeHint(const QStyleOptionViewItem &, const QModelIndex &) const override
    {
        return QSize(440, 28);
    }

    void paint(QPainter *painter,
               const QStyleOptionViewItem &option,
               const QModelIndex &index) const override
    {
        painter->save();
        painter->setRenderHint(QPainter::Antialiasing, true);
        painter->setRenderHint(QPainter::TextAntialiasing, true);
        painter->setRenderHint(QPainter::SmoothPixmapTransform, true);

        const QRect row = option.rect.adjusted(1, 1, -1, -1);
        const bool selected = (option.state & QStyle::State_Selected) != 0;
        const bool supported = index.data(SupportedRole).toBool();
        const QColor background = selected ? QColor(QStringLiteral("#1A3450"))
                                           : QColor(QStringLiteral("#12253B"));
        const QColor border = selected ? QColor(QStringLiteral("#5AAAF2"))
                                       : QColor(QStringLiteral("#2A405A"));
        painter->setPen(QPen(border, 1));
        painter->setBrush(background);
        painter->drawRoundedRect(row, 6, 6);

        const QString ssid = index.data(Qt::DisplayRole).toString();
        const bool secured = index.data(SecuredRole).toBool();
        const int signalLevel = index.data(SignalRole).toInt();
        const int bars = signalLevel >= -55 ? 4 : signalLevel >= -67 ? 3 : signalLevel >= -78 ? 2 : 1;

        int textLeft = row.left() + 10;
        if (secured) {
            const QPixmap &lock = supported ? m_lockIcon : m_unsupportedLockIcon;
            if (!lock.isNull())
                painter->drawPixmap(row.left() + 7, row.top() + 4, lock);
            textLeft = row.left() + 31;
        }

        QFont nameFont = option.font;
        nameFont.setPixelSize(13);
        nameFont.setWeight(QFont::DemiBold);
        painter->setFont(nameFont);
        painter->setPen(supported ? QColor(QStringLiteral("#E8F0FA"))
                                  : QColor(QStringLiteral("#8296AF")));
        const QRect nameRect(textLeft, row.top(), row.right() - textLeft - 70, row.height());
        painter->drawText(nameRect, Qt::AlignVCenter | Qt::AlignLeft,
                          painter->fontMetrics().elidedText(ssid, Qt::ElideRight, nameRect.width()));

        const QPixmap *signal = bars == 4 ? &m_signal4
                                 : bars == 3 ? &m_signal3
                                 : bars == 2 ? &m_signal2
                                             : &m_signal1;
        if (!signal->isNull())
            painter->drawPixmap(row.right() - 39, row.top() + 3, *signal);

        if (!supported && !m_unsupportedIcon.isNull())
            painter->drawPixmap(row.right() - 55, row.top() + 7, m_unsupportedIcon);

        if (selected && !m_selectedIcon.isNull())
            painter->drawPixmap(row.right() - 10, row.center().y() - 4, m_selectedIcon);

        painter->restore();
    }

private:
    QPixmap m_lockIcon;
    QPixmap m_unsupportedLockIcon;
    QPixmap m_signal1;
    QPixmap m_signal2;
    QPixmap m_signal3;
    QPixmap m_signal4;
    QPixmap m_unsupportedIcon;
    QPixmap m_selectedIcon;
};

enum ChatBubbleRoles {
    ChatSideRole = Qt::UserRole + 101,
    ChatSystemRole
};

class ChatBubbleDelegate : public QStyledItemDelegate
{
public:
    explicit ChatBubbleDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent),
          m_assistantAvatar(loadUiPixmap(QStringLiteral(":/ui/icons/robot_blue.png"), QSize(24, 24))),
          m_userAvatar(loadUiPixmap(QStringLiteral(":/ui/icons/board_blue.png"), QSize(24, 24)))
    {
    }

    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const override
    {
        const QString text = index.data(Qt::DisplayRole).toString();
        if (index.data(ChatSystemRole).toBool())
            return QSize(option.rect.width(), 31);
        const int width = option.rect.width() > 0 ? option.rect.width() : 440;
        const int bubbleWidth = qMax(80, qMin(310, width - 64));
        const QFontMetrics metrics(option.font);
        const QRect textRect = metrics.boundingRect(QRect(0, 0, bubbleWidth - 20, 1000),
                                                    Qt::TextWordWrap, text);
        return QSize(width, qMax(42, textRect.height() + 18) + 4);
    }

    void paint(QPainter *painter,
               const QStyleOptionViewItem &option,
               const QModelIndex &index) const override
    {
        painter->save();
        painter->setRenderHint(QPainter::Antialiasing, true);
        painter->setRenderHint(QPainter::TextAntialiasing, true);
        painter->setRenderHint(QPainter::SmoothPixmapTransform, true);

        const QRect area = option.rect.adjusted(4, 2, -4, -2);
        const QString text = index.data(Qt::DisplayRole).toString();
        const QFontMetrics metrics(option.font);
        if (index.data(ChatSystemRole).toBool()) {
            const int textWidth = metrics.boundingRect(QRect(0, 0, area.width() - 24, 200),
                                                       Qt::TextWordWrap, text).width();
            const int bubbleWidth = qMin(area.width() - 12, qMax(80, textWidth + 20));
            const QRect bubble(area.center().x() - bubbleWidth / 2,
                               area.top() + 2, bubbleWidth, 25);
            painter->setPen(Qt::NoPen);
            painter->setBrush(QColor(QStringLiteral("#1A3450")));
            painter->drawRoundedRect(bubble, 10, 10);
            painter->setPen(QColor(QStringLiteral("#ADBED2")));
            painter->drawText(bubble.adjusted(8, 0, -8, 0), Qt::AlignCenter | Qt::TextWordWrap, text);
            painter->restore();
            return;
        }

        const bool assistant = index.data(ChatSideRole).toInt() == 0;
        const int maxBubbleWidth = qMax(80, qMin(310, area.width() - 64));
        const QRect measured = metrics.boundingRect(QRect(0, 0, maxBubbleWidth - 20, 1000),
                                                    Qt::TextWordWrap, text);
        const int bubbleWidth = qMin(maxBubbleWidth, qMax(55, measured.width() + 20));
        const int bubbleHeight = qMax(30, measured.height() + 14);
        const int y = area.top() + qMax(2, (area.height() - bubbleHeight) / 2);
        const int avatarX = assistant ? area.left() : area.right() - 23;
        const QRect avatarRect(avatarX, y + 2, 22, 22);
        const int bubbleX = assistant ? area.left() + 30 : area.right() - 30 - bubbleWidth;
        const QRect bubble(bubbleX, y, bubbleWidth, bubbleHeight);

        const QPixmap &avatar = assistant ? m_assistantAvatar : m_userAvatar;
        if (!avatar.isNull())
            painter->drawPixmap(avatarRect, avatar);
        painter->setPen(QPen(QColor(QStringLiteral("#2A405A")), 1));
        painter->setBrush(assistant ? QColor(QStringLiteral("#12253B"))
                                   : QColor(QStringLiteral("#1B4036")));
        painter->drawRoundedRect(bubble, 9, 9);
        painter->setPen(QColor(QStringLiteral("#E8F0FA")));
        painter->drawText(bubble.adjusted(9, 6, -9, -6), Qt::AlignLeft | Qt::AlignVCenter |
                          Qt::TextWordWrap, text);
        painter->restore();
    }

private:
    QPixmap m_assistantAvatar;
    QPixmap m_userAvatar;
};

} // namespace

class SensorChart : public QWidget
{
public:
    explicit SensorChart(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        setMinimumHeight(98);
        setMaximumHeight(120);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    }

    QSize sizeHint() const override
    {
        return QSize(440, 108);
    }

    void appendReading(double temperature, double humidity)
    {
        m_temperatures.append(temperature);
        m_humidities.append(humidity);
        if (m_temperatures.size() > 60) {
            m_temperatures.remove(0);
            m_humidities.remove(0);
        }
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setRenderHint(QPainter::TextAntialiasing, true);
        const QRectF card = QRectF(rect()).adjusted(1, 1, -1, -1);
        painter.setPen(QPen(QColor(QStringLiteral("#2A405A")), 1));
        painter.setBrush(QColor(QStringLiteral("#12253B")));
        painter.drawRoundedRect(card, 11, 11);

        QFont labelFont = font();
        labelFont.setPixelSize(9);
        painter.setFont(labelFont);
        const QColor temperatureColor(QStringLiteral("#FF8C95"));
        const QColor humidityColor(QStringLiteral("#5AAAF2"));
        painter.setPen(temperatureColor);
        painter.drawText(QRect(12, 4, 86, 17), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("● 温度 °C"));
        painter.setPen(humidityColor);
        painter.drawText(QRect(98, 4, 98, 17), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("● 湿度 %RH"));

        const QRect plot = rect().adjusted(39, 23, -36, -15);
        if (plot.width() < 20 || plot.height() < 20)
            return;
        for (int i = 0; i <= 4; ++i) {
            const int y = plot.top() + i * plot.height() / 4;
            painter.setPen(QPen(QColor(QStringLiteral("#263C55")), 1));
            painter.drawLine(plot.left(), y, plot.right(), y);
        }
        painter.setPen(QColor(QStringLiteral("#8296AF")));
        painter.drawText(QRect(1, plot.top() - 7, 35, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("60"));
        painter.drawText(QRect(1, plot.center().y() - 7, 35, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("25"));
        painter.drawText(QRect(1, plot.bottom() - 7, 35, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("-10"));
        painter.drawText(QRect(plot.right() + 3, plot.top() - 7, 31, 14), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("100"));
        painter.drawText(QRect(plot.right() + 3, plot.center().y() - 7, 31, 14), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("50"));
        painter.drawText(QRect(plot.right() + 3, plot.bottom() - 7, 31, 14), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("0"));

        if (m_temperatures.isEmpty()) {
            painter.setPen(QColor(QStringLiteral("#8296AF")));
            painter.drawText(plot, Qt::AlignCenter, QStringLiteral("等待温湿度数据…"));
            return;
        }

        QPainterPath temperaturePath;
        QPainterPath humidityPath;
        for (int i = 0; i < m_temperatures.size(); ++i) {
            const double x = m_temperatures.size() == 1
                                 ? plot.right()
                                 : plot.left() + static_cast<double>(i) * (plot.width() - 1) /
                                       static_cast<double>(m_temperatures.size() - 1);
            const double tempRatio = qBound(0.0, (m_temperatures.at(i) + 10.0) / 70.0, 1.0);
            const double humidityRatio = qBound(0.0, m_humidities.at(i) / 100.0, 1.0);
            const QPointF tempPoint(x, plot.bottom() - tempRatio * plot.height());
            const QPointF humidityPoint(x, plot.bottom() - humidityRatio * plot.height());
            if (i == 0) {
                temperaturePath.moveTo(tempPoint);
                humidityPath.moveTo(humidityPoint);
            } else {
                temperaturePath.lineTo(tempPoint);
                humidityPath.lineTo(humidityPoint);
            }
        }
        painter.setClipRect(plot.adjusted(-1, -1, 1, 1));
        painter.setPen(QPen(temperatureColor, 2));
        painter.drawPath(temperaturePath);
        painter.setPen(QPen(humidityColor, 2));
        painter.drawPath(humidityPath);
        if (m_temperatures.size() == 1) {
            const double tempY = plot.bottom() - qBound(0.0, (m_temperatures.first() + 10.0) / 70.0, 1.0) * plot.height();
            const double humidityY = plot.bottom() - qBound(0.0, m_humidities.first() / 100.0, 1.0) * plot.height();
            painter.setBrush(temperatureColor);
            painter.drawEllipse(QPointF(plot.right(), tempY), 3, 3);
            painter.setBrush(humidityColor);
            painter.drawEllipse(QPointF(plot.right(), humidityY), 3, 3);
        }
    }

private:
    QVector<double> m_temperatures;
    QVector<double> m_humidities;
};

MainWindow::MainWindow(const QString &interfaceName,
                       const QString &controlDirectory,
                       QWidget *parent)
    : QWidget(parent),
      m_stack(nullptr),
      m_homePage(nullptr),
      m_wifiPage(nullptr),
      m_peripheralPage(nullptr),
      m_peripheralPageStack(nullptr),
      m_peripheralHubPage(nullptr),
      m_audioTestPage(nullptr),
      m_xiaozhiPage(nullptr),
      m_rs485Page(nullptr),
      m_wifiPageStack(nullptr),
      m_scanPage(nullptr),
      m_passwordPage(nullptr),
      m_wifiHeader(nullptr),
      m_actionBar(nullptr),
      m_passwordActionBar(nullptr),
      m_passwordFooterSpacer(nullptr),
      m_keyboardPanel(nullptr),
      m_keyboardSsid(nullptr),
      m_shiftButton(nullptr),
      m_modeButton(nullptr),
      m_backspaceButton(nullptr),
      m_doneButton(nullptr),
      m_keyboardVisible(false),
      m_keyboardMode(0),
      m_capsLock(false),
      m_clockDate(nullptr),
      m_clockTime(nullptr),
      m_wifiStatusButton(nullptr),
      m_wifiTopStatus(nullptr),
      m_wifiTopIp(nullptr),
      m_homeMessage(nullptr),
      m_scanButton(nullptr),
      m_networkList(nullptr),
      m_scanInfo(nullptr),
      m_passwordLabel(nullptr),
      m_passwordEdit(nullptr),
      m_passwordToggle(nullptr),
      m_keyboardButton(nullptr),
      m_wifiMessage(nullptr),
      m_passwordMessage(nullptr),
      m_skipButton(nullptr),
      m_connectButton(nullptr),
      m_passwordBackButton(nullptr),
      m_passwordConnectButton(nullptr),
      m_audioStatus(nullptr),
      m_recordButton(nullptr),
      m_musicButton(nullptr),
      m_xiaozhiStatus(nullptr),
      m_xiaozhiToggleButton(nullptr),
      m_xiaozhiActivationPanel(nullptr),
      m_xiaozhiActivationTitleLabel(nullptr),
      m_xiaozhiActivationCodeCaption(nullptr),
      m_xiaozhiActivationCodeLabel(nullptr),
      m_xiaozhiActivationInstructionsLabel(nullptr),
      m_xiaozhiActivationMessage(nullptr),
      m_xiaozhiActivationCode(),
      m_xiaozhiActivated(false),
      m_xiaozhiAudioReady(false),
      m_xiaozhiOnline(false),
      m_xiaozhiManualRestartHint(false),
      m_chatList(nullptr),
      m_streamingAssistantText(),
      m_streamingAssistantRow(-1),
      m_rs485Status(nullptr),
      m_temperatureValue(nullptr),
      m_humidityValue(nullptr),
      m_rs485RetryButton(nullptr),
      m_ledButton(nullptr),
      m_buzzerButton(nullptr),
      m_sensorChart(nullptr),
      m_recordProcess(nullptr),
      m_playProcess(nullptr),
      m_clickSoundProcess(nullptr),
      m_xiaozhiBridge(nullptr),
      m_modbusWorker(nullptr),
      m_musicFilePath(QStringLiteral("/music.wav")),
      m_recordingPath(QStringLiteral("/tmp/board_peripheral_recording.wav")),
      m_captureDevice(QStringLiteral("default")),
      m_playbackDevice(QStringLiteral("default")),
      m_arecordProgram(QStringLiteral("arecord")),
      m_aplayProgram(QStringLiteral("aplay")),
      m_playPurpose(),
      m_clickSoundPath(),
      m_audioSampleRate(16000),
      m_autoPlayAfterRecord(false),
      m_playStopRequested(false),
      m_worker(nullptr),
      m_ntpWorker(nullptr),
      m_clockTimer(nullptr),
      m_statusTimer(nullptr),
      m_timeSyncRetryTimer(nullptr),
      m_connectionAnimationTimer(nullptr),
      m_xiaozhiReadyHintTimer(nullptr),
      m_connectionAnimationFrame(0),
      m_interfaceName(interfaceName),
      m_controlDirectory(controlDirectory),
      m_ipAddress(),
      m_beijingUtcMilliseconds(0),
      m_timeSyncInProgress(false),
      m_timeSynchronized(false),
      m_setupComplete(false),
      m_hasCredentials(false),
      m_savePendingCredentials(false),
      m_autoConnection(false),
      m_scanBusy(false),
      m_connectionBusy(false),
      m_showPassword(false)
{
    setObjectName(QStringLiteral("appRoot"));
    setWindowTitle(QStringLiteral("开发板 Wi-Fi 设置"));
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setFixedSize(480, 272);
    setAttribute(Qt::WA_StyledBackground, true);
    setAutoFillBackground(true);

    setStyleSheet(QStringLiteral(
        "QWidget#appRoot, QWidget#homePage, QWidget#wifiPage, QWidget#wifiScanPage, QWidget#passwordPage, QWidget#peripheralPage, QWidget#peripheralHubPage, QWidget#audioTestPage, QWidget#xiaozhiPage, QWidget#rs485Page { background:#0B1727; color:#E8F0FA; }"
        "QStackedWidget { background:transparent; border:0; }"
        "QWidget { font-size:13px; }"
        "QToolTip { background:#1B2D43; color:#E8F0FA; border:1px solid #365270; padding:3px; }"
        "QScrollBar:vertical { background:#0F1C2C; width:7px; margin:2px 1px; border:0; }"
        "QScrollBar::handle:vertical { background:#35506D; min-height:22px; border-radius:3px; }"
        "QScrollBar::handle:vertical:hover { background:#5AAAF2; }"
        "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; border:0; }"
        "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background:transparent; }"
        "QFrame#topBar { background:#102036; border-bottom:1px solid #2A405A; }"
        "QLabel#brandMark { background:#1A3450; border-radius:8px; }"
        "QLabel#brandName { color:#E8F0FA; font-size:14px; font-weight:750; }"
        "QLabel#clockDate { color:#5AAAF2; font-size:12px; font-weight:700; }"
        "QLabel#clockTime { color:#E8F0FA; font-size:12px; font-weight:750; }"
        "QLabel#wifiTopStatus { color:#FF8C95; font-size:11px; font-weight:700; }"
        "QLabel#wifiTopStatus[connected=\"true\"] { color:#55D49A; }"
        "QLabel#wifiTopStatus[connecting=\"true\"] { color:#75BEFF; }"
        "QLabel#wifiTopIp { color:#ADBED2; font-size:11px; }"
        "QPushButton { background:#172B43; color:#E8F0FA; border:1px solid #2A405A; border-radius:10px; padding:4px 8px; font-size:13px; }"
        "QPushButton:hover { border-color:#5AAAF2; background:#203850; }"
        "QPushButton:pressed { background:#254A6A; color:#E8F0FA; border:2px solid #5AAAF2; padding-top:6px; }"
        "QPushButton:disabled { color:#8296AF; background:#142337; border-color:#263C55; }"
        "QPushButton#primaryButton { background:#2169A5; border:1px solid #3A8BD0; color:#F3F7FD; font-weight:700; padding:3px 10px; }"
        "QPushButton#primaryButton:hover { background:#2C7DC0; }"
        "QPushButton#primaryButton:pressed { background:#1A568C; border:2px solid #153F68; padding-top:3px; }"
        "QPushButton#skipButton:pressed { background:#254A6A; border:2px solid #5AAAF2; padding:2px 10px; }"
        "QPushButton#wifiStatusButton { min-width:30px; max-width:30px; min-height:30px; max-height:30px; padding:0; background:transparent; border:1px solid transparent; }"
        "QPushButton#wifiStatusButton:hover { background:#1A3450; border-color:#365574; }"
        "QPushButton#wifiStatusButton:pressed { background:#254A6A; border:2px solid #5AAAF2; padding:0; }"
        "QPushButton#wifiStatusButton[connected=\"true\"] { background:#153C32; border-color:#2B6654; }"
        "QPushButton#wifiStatusButton[connected=\"true\"]:pressed { background:#1E5143; border:2px solid #35A978; padding:0; }"
        "QPushButton#iconButton { background:transparent; border:1px solid transparent; padding:0; }"
        "QPushButton#iconButton:hover { background:#1A3450; border-color:#365574; }"
        "QPushButton#iconButton:pressed { background:#254A6A; border:2px solid #5AAAF2; padding:0; }"
        "QPushButton#skipButton { font-size:12px; padding:3px 11px; }"
        "QLabel#pageTitle { font-size:17px; font-weight:750; color:#E8F0FA; }"
        "QLabel#scanInfo { color:#ADBED2; font-size:11px; }"
        "QLabel#message { color:#FF8C95; font-size:11px; }"
        "QLineEdit { min-height:28px; border:1px solid #354D68; border-radius:10px; background:#101F32; padding:3px 9px; color:#E8F0FA; selection-background-color:#2169A5; font-size:12px; }"
        "QLineEdit:focus { border-color:#5AAAF2; }"
        "QListWidget { background:transparent; border:0; outline:0; padding:0; }"
        "QListWidget::item { border:0; padding:0; margin:0 0 2px 0; }"
        "QFrame#heroCard { background:#12253B; border:1px solid #2A405A; border-radius:15px; }"
        "QLabel#heroIcon { background:#1A3450; border-radius:12px; }"
        "QLabel#heroTitle { font-size:18px; font-weight:750; color:#E8F0FA; }"
        "QLabel#heroSub { font-size:11px; color:#ADBED2; }"
        "QPushButton#heroArrow { background:#1A3450; border:0; border-radius:12px; padding:0; }"
        "QPushButton#heroArrow:hover { background:#254A6A; }"
        "QPushButton#heroArrow:pressed { background:#2D4F70; border:2px solid #5AAAF2; }"
        "QToolButton#quickTile { background:#12253B; border:1px solid #2A405A; border-radius:12px; color:#E8F0FA; font-size:11px; padding:4px; }"
        "QToolButton#quickTile:disabled { background:#12253B; color:#8296AF; border-color:#263C55; }"
        "QToolButton#quickTile:pressed { background:#1A3450; border:2px solid #5AAAF2; }"
        "QFrame#subPageHeader { background:#102036; border-bottom:1px solid #2A405A; }"
        "QLabel#subPageTitle { color:#E8F0FA; font-size:16px; font-weight:750; }"
        "QLabel#peripheralStatus { color:#ADBED2; font-size:11px; }"
        "QToolButton#featureTile { background:#12253B; border:1px solid #2A405A; border-radius:13px; color:#E8F0FA; font-size:13px; font-weight:650; padding:8px; }"
        "QToolButton#featureTile:pressed { background:#1A3450; border:2px solid #5AAAF2; }"
        "QPushButton#largeAction { background:#12253B; border:1px solid #2A405A; border-radius:14px; color:#E8F0FA; font-size:14px; font-weight:700; padding:8px; }"
        "QPushButton#largeAction:pressed { background:#1A3450; border:2px solid #5AAAF2; }"
        "QPushButton#hardwareToggle { background:#172B43; border:1px solid #2A405A; border-radius:10px; color:#E8F0FA; font-weight:700; padding:5px 12px; }"
        "QPushButton#hardwareToggle:checked { background:#153C32; border-color:#35A978; color:#8DE0B6; }"
        "QPushButton#hardwareToggle:pressed { border:2px solid #5AAAF2; }"
        "QFrame#sensorValueCard { background:#12253B; border:1px solid #2A405A; border-radius:10px; }"
        "QLabel#sensorCaption { color:#ADBED2; font-size:10px; }"
        "QLabel#sensorValue { color:#E8F0FA; font-size:17px; font-weight:750; }"
        "QWidget#keyboardPanel { background:#0F1C2C; border:0; border-radius:0; }"
        "QLabel#keyboardSsid { color:#ADBED2; font-size:12px; font-weight:700; }"
        "QPushButton#softKey { min-height:32px; max-height:50px; padding:0; border:1px solid #354D68; border-radius:6px; background:#172B43; color:#E8F0FA; font-size:15px; font-weight:600; }"
        "QPushButton#softKey:pressed { background:#254A6A; border:1px solid #5AAAF2; color:#F3F7FD; padding:0; }"
        "QPushButton#softKeySpecial { min-height:32px; max-height:50px; padding:0 3px; border:1px solid #3F5874; border-radius:6px; background:#233B54; color:#E8F0FA; font-size:13px; font-weight:700; }"
        "QPushButton#softKeySpecial:pressed { background:#435B75; border:1px solid #8296AF; color:#F3F7FD; padding:0; }"
        "QPushButton#softKeyDone { min-height:32px; max-height:50px; padding:0 3px; border:1px solid #287D59; border-radius:6px; background:#25855F; color:#F3F7FD; font-size:13px; font-weight:700; }"
        "QPushButton#softKeyDone:pressed { background:#1C6147; border:1px solid #174D3A; color:#F3F7FD; padding:0; }"
        "QPushButton#softKeySpecial[active=\"true\"] { background:#2169A5; color:#F3F7FD; border-color:#2C7DC0; }"
        "QPushButton#softKeySpecial[active=\"true\"]:pressed { background:#1A568C; border:1px solid #153F68; padding:0; }"
        "QPushButton#softKeyMode { min-height:32px; max-height:50px; padding:0 3px; border:1px solid #2C7DC0; border-radius:6px; background:#2169A5; color:#F3F7FD; font-size:13px; font-weight:700; }"
        "QPushButton#softKeyMode:hover { background:#2C7DC0; border-color:#1A568C; }"
        "QPushButton#softKeyMode:pressed { background:#1A568C; border-color:#153F68; }"
        "QPushButton#softKeyMode[active=\"true\"] { background:#1A568C; border-color:#153F68; }"
        "QLabel#smallNote { color:#ADBED2; font-size:11px; }"
        "QFrame#activationCard { background:#12253B; border:1px solid #365574; border-radius:12px; }"
        "QLabel#activationTitle { color:#E8F0FA; font-size:13px; font-weight:750; }"
        "QLabel#activationCodeCaption { color:#ADBED2; font-size:10px; }"
        "QLabel#activationCode { background:#0F1C2C; color:#75BEFF; border:1px solid #365574; border-radius:7px; padding:2px 8px; font-size:21px; font-weight:800; }"
        "QLabel#activationInstructions { color:#D1DEEC; font-size:10px; }"
        "QLabel#activationMessage { color:#75BEFF; font-size:10px; font-weight:650; }"
        "QLabel#activationQr { background:#FFFFFF; border:1px solid #CBD5E1; border-radius:4px; }"
        "QLabel#activationQrCaption { color:#ADBED2; font-size:9px; }"
    ));

    m_stack = new QStackedWidget(this);
    m_stack->setFrameShape(QFrame::NoFrame);
    m_stack->setContentsMargins(0, 0, 0, 0);
    m_homePage = createHomePage();
    m_wifiPage = createWifiPage();
    m_peripheralPage = createPeripheralPage();
    m_stack->addWidget(m_homePage);
    m_stack->addWidget(m_wifiPage);
    m_stack->addWidget(m_peripheralPage);
    QVBoxLayout *rootLayout = new QVBoxLayout(this);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);
    rootLayout->addWidget(m_stack);

    const QList<QAbstractButton *> buttons = findChildren<QAbstractButton *>();
    for (QAbstractButton *button : buttons)
        connect(button, &QAbstractButton::pressed,
                this, &MainWindow::playButtonClickSound);

    qRegisterMetaType<QList<WifiNetwork> >("QList<WifiNetwork>");
    m_worker = new WifiWorker(m_interfaceName, m_controlDirectory);
    m_worker->moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(this, &MainWindow::scanRequested, m_worker, &WifiWorker::scan, Qt::QueuedConnection);
    connect(this, &MainWindow::connectRequested, m_worker, &WifiWorker::connectNetwork, Qt::QueuedConnection);
    connect(this, &MainWindow::statusRequested, m_worker, &WifiWorker::checkStatus, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::scanFinished, this, &MainWindow::onScanFinished, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::connectFinished, this, &MainWindow::onConnectFinished, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::statusChanged, this, &MainWindow::onStatusChanged, Qt::QueuedConnection);
    m_workerThread.setObjectName(QStringLiteral("wpa-control-worker"));
    m_workerThread.start();

    m_ntpWorker = new NtpSynchronizer;
    m_ntpWorker->moveToThread(&m_ntpThread);
    connect(&m_ntpThread, &QThread::finished, m_ntpWorker, &QObject::deleteLater);
    connect(this, &MainWindow::timeSyncRequested,
            m_ntpWorker, &NtpSynchronizer::synchronize, Qt::QueuedConnection);
    connect(m_ntpWorker, &NtpSynchronizer::synchronizationFinished,
            this, &MainWindow::onTimeSyncFinished, Qt::QueuedConnection);
    m_ntpThread.setObjectName(QStringLiteral("internet-time-sync"));
    m_ntpThread.start();

    const QString captureDevice = QString::fromLocal8Bit(qgetenv("AUDIO_CAPTURE_DEVICE"));
    const QString playbackDevice = QString::fromLocal8Bit(qgetenv("AUDIO_PLAYBACK_DEVICE"));
    const QString arecordProgram = QString::fromLocal8Bit(qgetenv("ARECORD_PATH"));
    const QString aplayProgram = QString::fromLocal8Bit(qgetenv("APLAY_PATH"));
    const QString recordingFile = QString::fromLocal8Bit(qgetenv("AUDIO_RECORD_PATH"));
    const QString sampleRate = QString::fromLocal8Bit(qgetenv("AUDIO_SAMPLE_RATE"));
    if (!captureDevice.isEmpty()) m_captureDevice = captureDevice;
    if (!playbackDevice.isEmpty()) m_playbackDevice = playbackDevice;
    if (!arecordProgram.isEmpty()) m_arecordProgram = arecordProgram;
    if (!aplayProgram.isEmpty()) m_aplayProgram = aplayProgram;
    if (!recordingFile.isEmpty()) m_recordingPath = recordingFile;
    if (!sampleRate.isEmpty()) {
        bool ok = false;
        const int rate = sampleRate.toInt(&ok);
        if (ok && rate >= 8000 && rate <= 96000)
            m_audioSampleRate = rate;
    }

    m_clickSoundProcess = new QProcess(this);
    m_clickSoundProcess->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_clickSoundProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        m_clickSoundProcess->readAllStandardOutput();
    });

    m_recordProcess = new QProcess(this);
    m_recordProcess->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_recordProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        m_recordProcess->readAllStandardOutput();
    });
    connect(m_recordProcess, &QProcess::started, this, [this]() {
        m_audioStatus->setText(QStringLiteral("录音中 · 再按一次停止并自动回放"));
        updateAudioControls();
    });
    connect(m_recordProcess,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &MainWindow::onRecordProcessFinished);
    connect(m_recordProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            m_autoPlayAfterRecord = false;
            m_audioStatus->setText(QStringLiteral("无法启动 arecord：请安装 ALSA 工具并检查路径"));
            updateAudioControls();
        }
    });

    m_playProcess = new QProcess(this);
    m_playProcess->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_playProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        m_playProcess->readAllStandardOutput();
    });
    connect(m_playProcess,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &MainWindow::onPlaybackProcessFinished);
    connect(m_playProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            m_audioStatus->setText(QStringLiteral("无法启动 aplay：请安装 ALSA 工具并检查路径"));
            updateAudioControls();
        }
    });

    m_xiaozhiBridge = new XiaozhiBridge(this);
    connect(m_xiaozhiBridge, &XiaozhiBridge::statusChanged, this, [this](const QString &status) {
        const bool restarting = status.contains(QStringLiteral("自动恢复")) ||
                                status.contains(QStringLiteral("核心退出")) ||
                                status.contains(QStringLiteral("核心已退出")) ||
                                status.contains(QStringLiteral("无法启动小智核心")) ||
                                status.contains(QStringLiteral("连续启动失败"));
        if (restarting) {
            m_xiaozhiOnline = false;
            if (!m_xiaozhiActivated) {
                m_xiaozhiActivationCode.clear();
                if (m_xiaozhiActivationCodeLabel)
                    m_xiaozhiActivationCodeLabel->setText(QStringLiteral("等待激活码"));
            }
        }
        if (m_xiaozhiStatus)
            m_xiaozhiStatus->setText(status);
        if (m_xiaozhiToggleButton) {
            m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isActive()
                                               ? QStringLiteral("停止小智")
                                               : QStringLiteral("启动小智"));
        }
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::chatTextReceived,
            this, &MainWindow::onXiaozhiTextReceived);
    connect(m_xiaozhiBridge, &XiaozhiBridge::userSpeechTextReceived, this, [this](const QString &text) {
        const QString userText = text.trimmed();
        if (!userText.isEmpty())
            addChatBubble(userText, false, false);
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::toastReceived, this, [this](const QString &text) {
        if (text.contains(QStringLiteral("设备已激活"))) {
            m_xiaozhiActivated = true;
            m_xiaozhiActivationCode.clear();
            if (m_xiaozhiActivationCodeLabel)
                m_xiaozhiActivationCodeLabel->setText(QStringLiteral("已完成绑定"));
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(QStringLiteral("设备已绑定 · 正在初始化音频并连接云端…"));
        } else if (m_xiaozhiStatus && !text.isEmpty()) {
            m_xiaozhiStatus->setText(text);
        }
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::activationCodeReceived, this, [this](const QString &code) {
        m_xiaozhiActivationCode = code.trimmed();
        m_xiaozhiActivated = false;
        m_xiaozhiOnline = false;
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(m_xiaozhiActivationCode.isEmpty()
                                                      ? QStringLiteral("等待激活码")
                                                      : m_xiaozhiActivationCode);
        if (m_xiaozhiStatus)
            m_xiaozhiStatus->setText(m_xiaozhiActivationCode.isEmpty()
                                         ? QStringLiteral("等待设备激活码")
                                         : QStringLiteral("设备激活码：%1").arg(m_xiaozhiActivationCode));
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::coreStateChanged, this, [this](int state) {
        if (state == 3) {
            m_xiaozhiActivated = true;
            m_xiaozhiOnline = true;
            m_xiaozhiActivationCode.clear();
            if (m_xiaozhiActivationCodeLabel)
                m_xiaozhiActivationCodeLabel->setText(QStringLiteral("已完成绑定"));
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(m_xiaozhiAudioReady
                                             ? QStringLiteral("小智已就绪 · 现在可以开始对话")
                                             : QStringLiteral("云端已连接 · 正在确认麦克风和扬声器就绪"));
        } else if (state == 4) {
            m_xiaozhiOnline = false;
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(m_xiaozhiActivated
                                             ? QStringLiteral("云端连接中断 · 小智核心正在尝试恢复")
                                             : QStringLiteral("小智网络断开"));
        } else if (state == 5) {
            m_xiaozhiActivated = true;
            m_xiaozhiOnline = true;
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(QStringLiteral("正在聆听本地麦克风…"));
        } else if (state == 6) {
            m_xiaozhiActivated = true;
            m_xiaozhiOnline = true;
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(QStringLiteral("小智正在说话…"));
        }
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::audioReadyChanged, this, [this](bool ready) {
        m_xiaozhiAudioReady = ready;
        if (m_xiaozhiStatus && m_xiaozhiOnline) {
            const QString currentStatus = m_xiaozhiStatus->text();
            if (ready) {
                if (!currentStatus.contains(QStringLiteral("聆听")) &&
                    !currentStatus.contains(QStringLiteral("说话")))
                    m_xiaozhiStatus->setText(QStringLiteral("小智已就绪 · 现在可以开始对话"));
            } else {
                m_xiaozhiStatus->setText(QStringLiteral("云端已连接 · 正在初始化麦克风和扬声器"));
            }
        }
        updateXiaozhiActivationView();
    });

    QString modbusDevice = QString::fromLocal8Bit(qgetenv("MODBUS_DEVICE"));
    if (modbusDevice.isEmpty())
        modbusDevice = QStringLiteral("/dev/ttymxc2");
    int modbusBaud = 19200;
    const QString modbusBaudText = QString::fromLocal8Bit(qgetenv("MODBUS_BAUD"));
    if (!modbusBaudText.isEmpty()) {
        bool ok = false;
        const int value = modbusBaudText.toInt(&ok);
        if (ok) modbusBaud = value;
    }
    int modbusSlave = 1;
    const QString modbusSlaveText = QString::fromLocal8Bit(qgetenv("MODBUS_SLAVE_ID"));
    if (!modbusSlaveText.isEmpty()) {
        bool ok = false;
        const int value = modbusSlaveText.toInt(&ok);
        if (ok && value >= 1 && value <= 247) modbusSlave = value;
    }
    m_modbusWorker = new ModbusWorker(modbusDevice, modbusBaud, modbusSlave);
    m_modbusWorker->moveToThread(&m_modbusThread);
    connect(&m_modbusThread, &QThread::finished, m_modbusWorker, &QObject::deleteLater);
    connect(this, &MainWindow::modbusStartRequested,
            m_modbusWorker, &ModbusWorker::start, Qt::QueuedConnection);
    connect(this, &MainWindow::modbusStopRequested,
            m_modbusWorker, &ModbusWorker::stop, Qt::QueuedConnection);
    connect(this, &MainWindow::modbusLedRequested,
            m_modbusWorker, &ModbusWorker::setLed, Qt::QueuedConnection);
    connect(this, &MainWindow::modbusBuzzerRequested,
            m_modbusWorker, &ModbusWorker::setBuzzer, Qt::QueuedConnection);
    connect(m_modbusWorker, &ModbusWorker::statusChanged, this, [this](const QString &status) {
        if (m_rs485Status) {
            m_rs485Status->setToolTip(status);
            m_rs485Status->setText(QFontMetrics(m_rs485Status->font()).elidedText(
                status, Qt::ElideRight, qMax(40, m_rs485Status->width() - 4)));
        }
    }, Qt::QueuedConnection);
    connect(m_modbusWorker, &ModbusWorker::sensorReading, this,
            [this](double temperature, double humidity, bool ledOn, bool buzzerOn) {
        m_temperatureValue->setText(QStringLiteral("%1 °C").arg(temperature, 0, 'f', 2));
        m_humidityValue->setText(QStringLiteral("%1 %RH").arg(humidity, 0, 'f', 2));
        m_ledButton->blockSignals(true);
        m_buzzerButton->blockSignals(true);
        m_ledButton->setChecked(ledOn);
        m_buzzerButton->setChecked(buzzerOn);
        m_ledButton->setText(ledOn ? QStringLiteral("LED 开") : QStringLiteral("LED 关"));
        m_buzzerButton->setText(buzzerOn ? QStringLiteral("蜂鸣器 开") : QStringLiteral("蜂鸣器 关"));
        m_ledButton->blockSignals(false);
        m_buzzerButton->blockSignals(false);
        m_sensorChart->appendReading(temperature, humidity);
    }, Qt::QueuedConnection);
    connect(m_modbusWorker, &ModbusWorker::outputWriteFinished, this,
            [this](bool isLed, bool enabled, bool success, const QString &message) {
        if (success)
            return;
        QPushButton *button = isLed ? m_ledButton : m_buzzerButton;
        if (button) {
            button->blockSignals(true);
            button->setChecked(!enabled);
            button->setText(isLed
                                ? (enabled ? QStringLiteral("LED 关") : QStringLiteral("LED 开"))
                                : (enabled ? QStringLiteral("蜂鸣器 关") : QStringLiteral("蜂鸣器 开")));
            button->blockSignals(false);
        }
        if (m_rs485Status) {
            m_rs485Status->setToolTip(message);
            m_rs485Status->setText(QFontMetrics(m_rs485Status->font()).elidedText(
                message, Qt::ElideRight, qMax(40, m_rs485Status->width() - 4)));
        }
    }, Qt::QueuedConnection);
    m_modbusThread.setObjectName(QStringLiteral("modbus-rtu-worker"));
    m_modbusThread.start();

    WifiCredentials credentials;
    QString credentialError;
    m_hasCredentials = m_credentialStore.load(&credentials, &credentialError);
    m_setupComplete = m_hasCredentials;
    setWifiStatus(false, QString());
    m_skipButton->setText(QStringLiteral("返回"));
    m_skipButton->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    m_stack->setCurrentWidget(m_hasCredentials ? m_homePage : m_wifiPage);

    m_clockTimer = new QTimer(this);
    connect(m_clockTimer, &QTimer::timeout, this, &MainWindow::updateClock);
    m_clockTimer->start(1000);
    updateClock();

    m_statusTimer = new QTimer(this);
    connect(m_statusTimer, &QTimer::timeout, this, [this]() {
        if (!m_connectionBusy)
            emit statusRequested();
    });
    m_statusTimer->start(5000);

    m_timeSyncRetryTimer = new QTimer(this);
    m_timeSyncRetryTimer->setSingleShot(true);
    connect(m_timeSyncRetryTimer, &QTimer::timeout,
            this, &MainWindow::startInternetTimeSync);

    m_connectionAnimationTimer = new QTimer(this);
    m_connectionAnimationTimer->setInterval(350);
    connect(m_connectionAnimationTimer, &QTimer::timeout, this, [this]() {
        if (!m_connectionBusy || m_wifiPageStack->currentWidget() != m_scanPage) {
            m_connectionAnimationTimer->stop();
            return;
        }
        m_connectionAnimationFrame = (m_connectionAnimationFrame + 1) % 4;
        const QString dots(m_connectionAnimationFrame, QLatin1Char('.'));
        m_scanInfo->setText(QStringLiteral("连接中%1").arg(dots));
        m_wifiMessage->setText(QStringLiteral("正在连接 Wi-Fi%1").arg(dots));
        m_connectButton->setText(QStringLiteral("连接中%1").arg(dots));
    });

    m_xiaozhiReadyHintTimer = new QTimer(this);
    m_xiaozhiReadyHintTimer->setSingleShot(true);
    m_xiaozhiReadyHintTimer->setInterval(30000);
    connect(m_xiaozhiReadyHintTimer, &QTimer::timeout, this, [this]() {
        if (!m_xiaozhiActivated || (m_xiaozhiOnline && m_xiaozhiAudioReady))
            return;
        m_xiaozhiManualRestartHint = true;
        updateXiaozhiActivationView();
    });

    if (m_hasCredentials) {
        m_autoConnection = true;
        setBusy(true);
        setWifiConnecting();
        QTimer::singleShot(250, this, [this, credentials]() {
            emit connectRequested(credentials.ssid, credentials.password, credentials.secured);
        });
    } else {
        QTimer::singleShot(250, this, [this]() { emit statusRequested(); });
        QTimer::singleShot(450, this, [this, credentialError]() {
            startScan();
            if (!credentialError.isEmpty()) {
                m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
                m_wifiMessage->setText(QStringLiteral("Wi-Fi 配置文件无效，请重新配置"));
                m_wifiMessage->setVisible(true);
                m_wifiMessage->setToolTip(credentialError);
            }
        });
    }
}

MainWindow::~MainWindow()
{
    stopAudioProcesses();
    stopButtonClickSound();
    if (!m_clickSoundPath.isEmpty())
        QFile::remove(m_clickSoundPath);
    if (m_xiaozhiBridge)
        m_xiaozhiBridge->stop();
    if (m_modbusThread.isRunning()) {
        if (m_modbusWorker)
            QMetaObject::invokeMethod(m_modbusWorker, "stop", Qt::BlockingQueuedConnection);
        m_modbusThread.quit();
        m_modbusThread.wait();
    }
    m_ntpThread.quit();
    m_workerThread.quit();
    m_ntpThread.wait();
    m_workerThread.wait();
}

void MainWindow::playButtonClickSound()
{
    if (!m_clickSoundProcess || m_clickSoundProcess->state() != QProcess::NotRunning)
        return;
    if ((m_playProcess && m_playProcess->state() != QProcess::NotRunning) ||
        (m_recordProcess && m_recordProcess->state() != QProcess::NotRunning))
        return;

    if (m_clickSoundPath.isEmpty()) {
        QFile clickSoundResource(QStringLiteral(":/ui/sounds/button_click.wav"));
        if (!clickSoundResource.open(QIODevice::ReadOnly))
            return;

        const QByteArray soundData = clickSoundResource.readAll();
        QTemporaryFile tempFile(QDir::tempPath() + QStringLiteral("/qt_wifi_click_XXXXXX.wav"));
        if (!tempFile.open())
            return;
        if (soundData.isEmpty() || tempFile.write(soundData) != soundData.size() || !tempFile.flush())
            return;

        m_clickSoundPath = tempFile.fileName();
        tempFile.setAutoRemove(false);
    }

    QStringList arguments;
    arguments << QStringLiteral("-q");
    if (!m_playbackDevice.isEmpty())
        arguments << QStringLiteral("-D") << m_playbackDevice;
    arguments << m_clickSoundPath;

    m_clickSoundProcess->setProgram(m_aplayProgram);
    m_clickSoundProcess->setArguments(arguments);
    m_clickSoundProcess->start();
}

void MainWindow::stopButtonClickSound()
{
    if (!m_clickSoundProcess || m_clickSoundProcess->state() == QProcess::NotRunning)
        return;

    m_clickSoundProcess->kill();
    m_clickSoundProcess->waitForFinished(500);
}

QWidget *MainWindow::createHomePage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("homePage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *pageLayout = new QVBoxLayout(page);
    pageLayout->setContentsMargins(0, 0, 0, 0);
    pageLayout->setSpacing(0);

    QFrame *topBar = new QFrame(page);
    topBar->setObjectName(QStringLiteral("topBar"));
    topBar->setLayoutDirection(Qt::LeftToRight);
    topBar->setFixedHeight(40);
    QGridLayout *barLayout = new QGridLayout(topBar);
    barLayout->setOriginCorner(Qt::TopLeftCorner);
    barLayout->setContentsMargins(2, 0, 2, 0);
    barLayout->setHorizontalSpacing(0);
    barLayout->setVerticalSpacing(0);
    barLayout->setColumnMinimumWidth(0, 154);
    barLayout->setColumnMinimumWidth(1, 154);
    barLayout->setColumnMinimumWidth(2, 154);
    barLayout->setColumnStretch(0, 1);
    barLayout->setColumnStretch(1, 1);
    barLayout->setColumnStretch(2, 1);

    QWidget *brandWidget = new QWidget(topBar);
    QHBoxLayout *brandLayout = new QHBoxLayout(brandWidget);
    brandLayout->setContentsMargins(0, 0, 0, 0);
    brandLayout->setSpacing(5);
    QLabel *brandMark = new QLabel(brandWidget);
    brandMark->setObjectName(QStringLiteral("brandMark"));
    brandMark->setAlignment(Qt::AlignCenter);
    brandMark->setFixedSize(24, 24);
    brandMark->setPixmap(makeUiIcon(UiIcon::Board, QColor(QStringLiteral("#5AAAF2"))).pixmap(20, 20));
    QLabel *brandName = new QLabel(QStringLiteral("硬件测试"), brandWidget);
    brandName->setObjectName(QStringLiteral("brandName"));
    brandLayout->addWidget(brandMark);
    brandLayout->addWidget(brandName);

    QWidget *dateTimeWidget = new QWidget(topBar);
    QHBoxLayout *dateTimeLayout = new QHBoxLayout(dateTimeWidget);
    dateTimeLayout->setContentsMargins(0, 0, 0, 0);
    dateTimeLayout->setSpacing(5);
    dateTimeLayout->setAlignment(Qt::AlignCenter);
    m_clockDate = new QLabel(dateTimeWidget);
    m_clockDate->setObjectName(QStringLiteral("clockDate"));
    m_clockTime = new QLabel(dateTimeWidget);
    m_clockTime->setObjectName(QStringLiteral("clockTime"));
    dateTimeLayout->addWidget(m_clockDate);
    dateTimeLayout->addWidget(m_clockTime);
    dateTimeWidget->setFixedWidth(154);

    QWidget *wifiGroup = new QWidget(topBar);
    QHBoxLayout *wifiLayout = new QHBoxLayout(wifiGroup);
    wifiLayout->setContentsMargins(0, 0, 0, 0);
    wifiLayout->setSpacing(4);
    m_wifiStatusButton = new QPushButton(wifiGroup);
    m_wifiStatusButton->setObjectName(QStringLiteral("wifiStatusButton"));
    m_wifiStatusButton->setFixedSize(30, 30);
    m_wifiStatusButton->setIconSize(QSize(22, 22));
    m_wifiStatusButton->setToolTip(QStringLiteral("打开 Wi-Fi 设置"));
    connect(m_wifiStatusButton, &QPushButton::clicked, this, &MainWindow::openWifiSettings);

    QWidget *wifiInfoWidget = new QWidget(wifiGroup);
    wifiInfoWidget->setFixedWidth(115);
    QVBoxLayout *wifiInfoLayout = new QVBoxLayout(wifiInfoWidget);
    wifiInfoLayout->setContentsMargins(0, 0, 0, 0);
    wifiInfoLayout->setSpacing(0);
    m_wifiTopStatus = new QLabel(QStringLiteral("WIFI 未连接"), wifiInfoWidget);
    m_wifiTopStatus->setObjectName(QStringLiteral("wifiTopStatus"));
    m_wifiTopStatus->setProperty("connected", false);
    m_wifiTopStatus->setProperty("connecting", false);
    m_wifiTopIp = new QLabel(QStringLiteral("IP：--"), wifiInfoWidget);
    m_wifiTopIp->setObjectName(QStringLiteral("wifiTopIp"));
    wifiInfoLayout->addWidget(m_wifiTopStatus);
    wifiInfoLayout->addWidget(m_wifiTopIp);
    wifiLayout->addWidget(m_wifiStatusButton);
    wifiLayout->addWidget(wifiInfoWidget);

    // Forced LTR: hardware test stays far left, time stays centered, Wi-Fi status stays far right.
    barLayout->addWidget(brandWidget, 0, 0, Qt::AlignLeft | Qt::AlignVCenter);
    barLayout->addWidget(dateTimeWidget, 0, 1, Qt::AlignCenter);
    barLayout->addWidget(wifiGroup, 0, 2, Qt::AlignRight | Qt::AlignVCenter);
    pageLayout->addWidget(topBar);

    QWidget *body = new QWidget(page);
    QVBoxLayout *bodyLayout = new QVBoxLayout(body);
    bodyLayout->setContentsMargins(10, 10, 10, 7);
    bodyLayout->setSpacing(8);

    QFrame *hero = new QFrame(body);
    hero->setObjectName(QStringLiteral("heroCard"));
    hero->setFixedHeight(96);
    QHBoxLayout *heroLayout = new QHBoxLayout(hero);
    heroLayout->setContentsMargins(16, 10, 12, 10);
    heroLayout->setSpacing(12);

    QLabel *heroIcon = new QLabel(hero);
    heroIcon->setObjectName(QStringLiteral("heroIcon"));
    heroIcon->setAlignment(Qt::AlignCenter);
    heroIcon->setFixedSize(52, 52);
    heroIcon->setPixmap(makeUiIcon(UiIcon::TestGrid, QColor(QStringLiteral("#5AAAF2"))).pixmap(40, 40));
    heroLayout->addWidget(heroIcon);

    QVBoxLayout *heroTextLayout = new QVBoxLayout;
    heroTextLayout->setContentsMargins(0, 0, 0, 0);
    heroTextLayout->setSpacing(4);
    QLabel *heroTitle = new QLabel(QStringLiteral("外设测试"), hero);
    heroTitle->setObjectName(QStringLiteral("heroTitle"));
    QLabel *heroSub = new QLabel(QStringLiteral("音频录放 · 小智语音 · RS485 温湿度"), hero);
    heroSub->setObjectName(QStringLiteral("heroSub"));
    heroTextLayout->addWidget(heroTitle);
    heroTextLayout->addWidget(heroSub);
    heroLayout->addLayout(heroTextLayout, 1);

    QPushButton *futureButton = new QPushButton(hero);
    futureButton->setObjectName(QStringLiteral("heroArrow"));
    futureButton->setIcon(makeUiIcon(UiIcon::ArrowRight, QColor(QStringLiteral("#E8F0FA"))));
    futureButton->setIconSize(QSize(25, 25));
    futureButton->setFixedSize(40, 40);
    heroLayout->addWidget(futureButton);
    connect(futureButton, &QPushButton::clicked, this, &MainWindow::openPeripheralHub);
    bodyLayout->addWidget(hero);

    QHBoxLayout *quickRow = new QHBoxLayout;
    quickRow->setContentsMargins(0, 0, 0, 0);
    quickRow->setSpacing(7);
    const UiIcon::Type iconTypes[] = {UiIcon::Rs485, UiIcon::Can, UiIcon::Led, UiIcon::Beep};
    const QString labels[] = {QStringLiteral("RS485"), QStringLiteral("CAN"),
                              QStringLiteral("LED"), QStringLiteral("蜂鸣器")};
    for (int i = 0; i < 4; ++i) {
        QToolButton *button = new QToolButton(body);
        button->setObjectName(QStringLiteral("quickTile"));
        button->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        button->setIcon(makeUiIcon(iconTypes[i], QColor(QStringLiteral("#8296AF"))));
        button->setIconSize(QSize(29, 29));
        button->setText(labels[i]);
        button->setFixedHeight(68);
        button->setEnabled(i != 1);
        quickRow->addWidget(button, 1);
        connect(button, &QToolButton::clicked, this, [this, i]() {
            if (i == 1) {
                showHomeMessage(QStringLiteral("CAN 测试接口尚未接入"), true);
                return;
            }
            openRs485Page();
        });
    }
    bodyLayout->addLayout(quickRow);

    m_homeMessage = new QLabel(QStringLiteral("点击主卡片进入外设测试"), body);
    m_homeMessage->setObjectName(QStringLiteral("smallNote"));
    m_homeMessage->setAlignment(Qt::AlignCenter);
    m_homeMessage->setFixedHeight(18);
    bodyLayout->addStretch(1);
    bodyLayout->addWidget(m_homeMessage);
    pageLayout->addWidget(body, 1);
    return page;
}

QWidget *MainWindow::createPeripheralPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("peripheralPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    m_peripheralPageStack = new QStackedWidget(page);
    m_peripheralPageStack->setFrameShape(QFrame::NoFrame);
    m_peripheralPageStack->setContentsMargins(0, 0, 0, 0);
    m_peripheralHubPage = createPeripheralHubPage();
    m_audioTestPage = createAudioTestPage();
    m_xiaozhiPage = createXiaozhiPage();
    m_rs485Page = createRs485Page();
    m_peripheralPageStack->addWidget(m_peripheralHubPage);
    m_peripheralPageStack->addWidget(m_audioTestPage);
    m_peripheralPageStack->addWidget(m_xiaozhiPage);
    m_peripheralPageStack->addWidget(m_rs485Page);
    m_peripheralPageStack->setCurrentWidget(m_peripheralHubPage);
    layout->addWidget(m_peripheralPageStack);
    return page;
}

QWidget *MainWindow::createPeripheralHubPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("peripheralHubPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 5, 9, 6);
    layout->setSpacing(7);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    back->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("外设测试"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    QLabel *count = new QLabel(QStringLiteral("3 项"), header);
    count->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(count);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToHome);

    QHBoxLayout *tiles = new QHBoxLayout;
    tiles->setContentsMargins(0, 0, 0, 0);
    tiles->setSpacing(8);
    const QString iconPaths[] = {
        QStringLiteral(":/ui/icons/microphone_blue.png"),
        QStringLiteral(":/ui/icons/robot_blue.png"),
        QStringLiteral(":/ui/icons/rs485_secondary.png")
    };
    const QString captions[] = {
        QStringLiteral("录音 / 播放"), QStringLiteral("小智语音"), QStringLiteral("RS485 / STM32")
    };
    for (int i = 0; i < 3; ++i) {
        QToolButton *button = new QToolButton(page);
        button->setObjectName(QStringLiteral("featureTile"));
        button->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        button->setIcon(QIcon(iconPaths[i]));
        button->setIconSize(QSize(43, 43));
        button->setText(captions[i]);
        button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        tiles->addWidget(button, 1);
        if (i == 0)
            connect(button, &QToolButton::clicked, this, &MainWindow::openAudioTestPage);
        else if (i == 1)
            connect(button, &QToolButton::clicked, this, &MainWindow::openXiaozhiPage);
        else
            connect(button, &QToolButton::clicked, this, &MainWindow::openRs485Page);
    }
    layout->addLayout(tiles, 1);

    QLabel *note = new QLabel(QStringLiteral("LED 与蜂鸣器控制、温湿度曲线位于 RS485 页面"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(18);
    layout->addWidget(note);
    return page;
}

QWidget *MainWindow::createAudioTestPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("audioTestPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(4);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    back->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("音频测试"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    m_audioStatus = new QLabel(QStringLiteral("录音停止后自动回放 · 默认采样率 16000 Hz"), page);
    m_audioStatus->setObjectName(QStringLiteral("peripheralStatus"));
    m_audioStatus->setFixedHeight(18);
    layout->addWidget(m_audioStatus);

    QHBoxLayout *actions = new QHBoxLayout;
    actions->setContentsMargins(0, 0, 0, 0);
    actions->setSpacing(8);
    m_recordButton = new QPushButton(QStringLiteral("开始录音"), page);
    m_recordButton->setObjectName(QStringLiteral("largeAction"));
    m_recordButton->setIcon(QIcon(QStringLiteral(":/ui/icons/microphone_blue.png")));
    m_recordButton->setIconSize(QSize(34, 34));
    m_recordButton->setMinimumHeight(94);
    m_musicButton = new QPushButton(QStringLiteral("播放 /music.wav"), page);
    m_musicButton->setObjectName(QStringLiteral("largeAction"));
    m_musicButton->setIcon(QIcon(QStringLiteral(":/ui/icons/music_blue.png")));
    m_musicButton->setIconSize(QSize(34, 34));
    m_musicButton->setMinimumHeight(94);
    actions->addWidget(m_recordButton, 1);
    actions->addWidget(m_musicButton, 1);
    layout->addLayout(actions, 1);

    QLabel *note = new QLabel(QStringLiteral("第二次按录音键停止并回放；播放按钮读取 /music.wav"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(18);
    layout->addWidget(note);

    connect(m_recordButton, &QPushButton::clicked, this, [this]() {
        if (m_recordProcess && m_recordProcess->state() != QProcess::NotRunning)
            stopRecording(true);
        else
            startRecording();
    });
    connect(m_musicButton, &QPushButton::clicked, this, [this]() {
        if (m_playProcess && m_playProcess->state() != QProcess::NotRunning) {
            m_playStopRequested = true;
            m_playProcess->terminate();
            m_audioStatus->setText(QStringLiteral("正在停止播放…"));
            QTimer::singleShot(1200, this, [this]() {
                if (m_playProcess && m_playProcess->state() != QProcess::NotRunning)
                    m_playProcess->kill();
            });
            return;
        }
        playAudioFile(m_musicFilePath, QStringLiteral("音乐播放"));
    });
    updateAudioControls();
    return page;
}

QWidget *MainWindow::createXiaozhiPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("xiaozhiPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(8, 4, 8, 5);
    layout->setSpacing(3);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(6);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    back->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("小智语音对话"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    m_xiaozhiToggleButton = new QPushButton(QStringLiteral("启动小智"), header);
    m_xiaozhiToggleButton->setObjectName(QStringLiteral("primaryButton"));
    m_xiaozhiToggleButton->setFixedSize(92, 29);
    headerLayout->addWidget(m_xiaozhiToggleButton);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);
    connect(m_xiaozhiToggleButton, &QPushButton::clicked, this, [this]() {
        if (m_xiaozhiBridge->isActive()) {
            m_xiaozhiBridge->stop();
            resetXiaozhiSessionUi(QStringLiteral("小智已停止"));
            m_xiaozhiStatus->setText(QStringLiteral("小智已停止"));
        } else {
            resetXiaozhiSessionUi(QStringLiteral("正在启动小智核心…"));
            QString error;
            if (!m_xiaozhiBridge->start(&error)) {
                m_xiaozhiStatus->setText(error);
                if (m_xiaozhiActivationMessage)
                    m_xiaozhiActivationMessage->setText(error);
            }
        }
        m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isActive()
                                           ? QStringLiteral("停止小智")
                                           : QStringLiteral("启动小智"));
        updateXiaozhiActivationView();
    });

    m_xiaozhiStatus = new QLabel(QStringLiteral("未运行"), page);
    m_xiaozhiStatus->setObjectName(QStringLiteral("peripheralStatus"));
    m_xiaozhiStatus->setFixedHeight(17);
    layout->addWidget(m_xiaozhiStatus);

    m_xiaozhiActivationPanel = new QFrame(page);
    m_xiaozhiActivationPanel->setObjectName(QStringLiteral("activationCard"));
    m_xiaozhiActivationPanel->setMinimumHeight(130);
    QHBoxLayout *activationLayout = new QHBoxLayout(m_xiaozhiActivationPanel);
    activationLayout->setContentsMargins(7, 6, 8, 6);
    activationLayout->setSpacing(9);

    QVBoxLayout *qrLayout = new QVBoxLayout;
    qrLayout->setContentsMargins(0, 0, 0, 0);
    qrLayout->setSpacing(3);
    QLabel *qr = new QLabel(m_xiaozhiActivationPanel);
    qr->setObjectName(QStringLiteral("activationQr"));
    qr->setAlignment(Qt::AlignCenter);
    qr->setFixedSize(82, 82);
    const QPixmap qrPixmap(QStringLiteral(":/ui/activation_qr.png"));
    if (!qrPixmap.isNull())
        qr->setPixmap(qrPixmap);
    else
        qr->setText(QStringLiteral("二维码未加载"));
    QLabel *qrCaption = new QLabel(QStringLiteral("官方控制台\nxiaozhi.me/console"), m_xiaozhiActivationPanel);
    qrCaption->setObjectName(QStringLiteral("activationQrCaption"));
    qrCaption->setAlignment(Qt::AlignCenter);
    qrLayout->addWidget(qr, 0, Qt::AlignHCenter);
    qrLayout->addWidget(qrCaption, 0, Qt::AlignHCenter);
    activationLayout->addLayout(qrLayout, 0);

    QVBoxLayout *activationInfo = new QVBoxLayout;
    activationInfo->setContentsMargins(0, 0, 0, 0);
    activationInfo->setSpacing(2);
    m_xiaozhiActivationTitleLabel = new QLabel(QStringLiteral("首次使用 · 绑定小智设备"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationTitleLabel->setObjectName(QStringLiteral("activationTitle"));
    m_xiaozhiActivationCodeCaption = new QLabel(QStringLiteral("小智核心实时返回的 6 位激活码"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationCodeCaption->setObjectName(QStringLiteral("activationCodeCaption"));
    m_xiaozhiActivationCodeLabel = new QLabel(QStringLiteral("等待激活码"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationCodeLabel->setObjectName(QStringLiteral("activationCode"));
    m_xiaozhiActivationCodeLabel->setAlignment(Qt::AlignCenter);
    m_xiaozhiActivationCodeLabel->setMinimumHeight(31);
    m_xiaozhiActivationInstructionsLabel = new QLabel(
        QStringLiteral("扫码注册/登录 → 添加设备 → 输入上方六码并完成绑定。未激活前，语音对话不可用。"),
        m_xiaozhiActivationPanel);
    m_xiaozhiActivationInstructionsLabel->setObjectName(QStringLiteral("activationInstructions"));
    m_xiaozhiActivationInstructionsLabel->setWordWrap(true);
    m_xiaozhiActivationMessage = new QLabel(QStringLiteral("正在检查设备激活状态…"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationMessage->setObjectName(QStringLiteral("activationMessage"));
    m_xiaozhiActivationMessage->setWordWrap(true);
    m_xiaozhiActivationMessage->setMinimumHeight(24);
    activationInfo->addWidget(m_xiaozhiActivationTitleLabel);
    activationInfo->addWidget(m_xiaozhiActivationCodeCaption);
    activationInfo->addWidget(m_xiaozhiActivationCodeLabel);
    activationInfo->addWidget(m_xiaozhiActivationInstructionsLabel, 1);
    activationInfo->addWidget(m_xiaozhiActivationMessage);
    activationLayout->addLayout(activationInfo, 1);
    layout->addWidget(m_xiaozhiActivationPanel, 1);

    m_chatList = new QListWidget(page);
    m_chatList->setItemDelegate(new ChatBubbleDelegate(m_chatList));
    m_chatList->setSelectionMode(QAbstractItemView::NoSelection);
    m_chatList->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_chatList->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    m_chatList->setSpacing(1);
    m_chatList->setWordWrap(true);
    layout->addWidget(m_chatList, 1);
    m_chatList->hide();

    QLabel *note = new QLabel(QStringLiteral("已就绪后开始说话 · 用户消息靠右，小智消息靠左"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setFixedHeight(16);
    note->setAlignment(Qt::AlignCenter);
    layout->addWidget(note);
    return page;
}

QWidget *MainWindow::createRs485Page()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("rs485Page"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(8, 4, 8, 4);
    layout->setSpacing(3);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(34);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(6);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    back->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    back->setIconSize(QSize(20, 20));
    back->setFixedSize(31, 30);
    QLabel *title = new QLabel(QStringLiteral("RS485 / STM32"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    m_rs485Status = new QLabel(QStringLiteral("Modbus RTU 未启动"), page);
    m_rs485Status->setObjectName(QStringLiteral("peripheralStatus"));
    m_rs485Status->setFixedHeight(16);
    layout->addWidget(m_rs485Status);

    QHBoxLayout *values = new QHBoxLayout;
    values->setContentsMargins(0, 0, 0, 0);
    values->setSpacing(7);
    QFrame *temperatureCard = new QFrame(page);
    temperatureCard->setObjectName(QStringLiteral("sensorValueCard"));
    QVBoxLayout *temperatureLayout = new QVBoxLayout(temperatureCard);
    temperatureLayout->setContentsMargins(9, 3, 9, 3);
    temperatureLayout->setSpacing(0);
    QLabel *temperatureCaption = new QLabel(QStringLiteral("温度"), temperatureCard);
    temperatureCaption->setObjectName(QStringLiteral("sensorCaption"));
    m_temperatureValue = new QLabel(QStringLiteral("-- °C"), temperatureCard);
    m_temperatureValue->setObjectName(QStringLiteral("sensorValue"));
    temperatureLayout->addWidget(temperatureCaption);
    temperatureLayout->addWidget(m_temperatureValue);
    QFrame *humidityCard = new QFrame(page);
    humidityCard->setObjectName(QStringLiteral("sensorValueCard"));
    QVBoxLayout *humidityLayout = new QVBoxLayout(humidityCard);
    humidityLayout->setContentsMargins(9, 3, 9, 3);
    humidityLayout->setSpacing(0);
    QLabel *humidityCaption = new QLabel(QStringLiteral("相对湿度"), humidityCard);
    humidityCaption->setObjectName(QStringLiteral("sensorCaption"));
    m_humidityValue = new QLabel(QStringLiteral("-- %RH"), humidityCard);
    m_humidityValue->setObjectName(QStringLiteral("sensorValue"));
    humidityLayout->addWidget(humidityCaption);
    humidityLayout->addWidget(m_humidityValue);
    values->addWidget(temperatureCard, 1);
    values->addWidget(humidityCard, 1);
    layout->addLayout(values);

    m_sensorChart = new SensorChart(page);
    layout->addWidget(m_sensorChart, 1);

    QHBoxLayout *controls = new QHBoxLayout;
    controls->setContentsMargins(0, 0, 0, 0);
    controls->setSpacing(7);
    m_ledButton = new QPushButton(QStringLiteral("LED 关"), page);
    m_ledButton->setObjectName(QStringLiteral("hardwareToggle"));
    m_ledButton->setIcon(makeUiIcon(UiIcon::Led, QColor(QStringLiteral("#ADBED2"))));
    m_ledButton->setIconSize(QSize(20, 20));
    m_ledButton->setCheckable(true);
    m_ledButton->setFixedSize(120, 31);
    m_buzzerButton = new QPushButton(QStringLiteral("蜂鸣器 关"), page);
    m_buzzerButton->setObjectName(QStringLiteral("hardwareToggle"));
    m_buzzerButton->setIcon(makeUiIcon(UiIcon::Beep, QColor(QStringLiteral("#ADBED2"))));
    m_buzzerButton->setIconSize(QSize(20, 20));
    m_buzzerButton->setCheckable(true);
    m_buzzerButton->setFixedSize(132, 31);
    m_rs485RetryButton = new QPushButton(QStringLiteral("重连"), page);
    m_rs485RetryButton->setObjectName(QStringLiteral("skipButton"));
    m_rs485RetryButton->setFixedSize(68, 30);
    controls->addWidget(m_ledButton);
    controls->addWidget(m_buzzerButton);
    controls->addStretch(1);
    controls->addWidget(m_rs485RetryButton);
    layout->addLayout(controls);

    connect(m_ledButton, &QPushButton::clicked, this, [this](bool enabled) {
        m_ledButton->setText(enabled ? QStringLiteral("LED 开") : QStringLiteral("LED 关"));
        emit modbusLedRequested(enabled);
    });
    connect(m_buzzerButton, &QPushButton::clicked, this, [this](bool enabled) {
        m_buzzerButton->setText(enabled ? QStringLiteral("蜂鸣器 开") : QStringLiteral("蜂鸣器 关"));
        emit modbusBuzzerRequested(enabled);
    });
    connect(m_rs485RetryButton, &QPushButton::clicked, this, [this]() {
        emit modbusStopRequested();
        QTimer::singleShot(120, this, [this]() { emit modbusStartRequested(); });
    });
    return page;
}

QWidget *MainWindow::createWifiPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("wifiPage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);

    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    m_wifiPageStack = new QStackedWidget(page);
    m_wifiPageStack->setFrameShape(QFrame::NoFrame);
    m_wifiPageStack->setContentsMargins(0, 0, 0, 0);
    m_scanPage = createWifiScanPage();
    m_passwordPage = createPasswordEntryPage();
    m_wifiPageStack->addWidget(m_scanPage);
    m_wifiPageStack->addWidget(m_passwordPage);
    m_wifiPageStack->setCurrentWidget(m_scanPage);
    layout->addWidget(m_wifiPageStack);
    return page;
}

QWidget *MainWindow::createWifiScanPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("wifiScanPage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);

    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(10, 6, 10, 2);
    layout->setSpacing(3);

    m_wifiHeader = new QWidget(page);
    QHBoxLayout *header = new QHBoxLayout(m_wifiHeader);
    header->setContentsMargins(0, 0, 0, 0);
    header->setSpacing(6);

    QLabel *wifiIcon = new QLabel(m_wifiHeader);
    wifiIcon->setFixedSize(27, 27);
    wifiIcon->setAlignment(Qt::AlignCenter);
    wifiIcon->setPixmap(makeUiIcon(UiIcon::Wifi, QColor(QStringLiteral("#5AAAF2"))).pixmap(24, 24));
    QLabel *title = new QLabel(QStringLiteral("Wi-Fi"), m_wifiHeader);
    title->setObjectName(QStringLiteral("pageTitle"));
    header->addWidget(wifiIcon);
    header->addWidget(title);
    header->addStretch(1);

    m_scanInfo = new QLabel(QString(), m_wifiHeader);
    m_scanInfo->setObjectName(QStringLiteral("scanInfo"));
    header->addWidget(m_scanInfo);

    m_scanButton = new QPushButton(m_wifiHeader);
    m_scanButton->setObjectName(QStringLiteral("iconButton"));
    m_scanButton->setIcon(makeUiIcon(UiIcon::Search, QColor(QStringLiteral("#ADBED2"))));
    m_scanButton->setIconSize(QSize(20, 20));
    m_scanButton->setFixedSize(34, 32);
    m_scanButton->setToolTip(QStringLiteral("扫描网络"));
    header->addWidget(m_scanButton);
    layout->addWidget(m_wifiHeader);

    m_networkList = new QListWidget(page);
    m_networkList->setItemDelegate(new NetworkDelegate(m_networkList));
    m_networkList->setSelectionMode(QAbstractItemView::SingleSelection);
    m_networkList->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_networkList->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    m_networkList->setMinimumHeight(84);
    m_networkList->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    layout->addWidget(m_networkList, 1);

    m_wifiMessage = new QLabel(QString(), page);
    m_wifiMessage->setObjectName(QStringLiteral("message"));
    m_wifiMessage->setFixedHeight(18);
    m_wifiMessage->setToolTip(QString());
    m_wifiMessage->hide();
    layout->addWidget(m_wifiMessage);

    m_actionBar = new QWidget(page);
    QHBoxLayout *actionRow = new QHBoxLayout(m_actionBar);
    actionRow->setContentsMargins(0, 0, 0, 0);
    actionRow->setSpacing(7);

    m_skipButton = new QPushButton(QStringLiteral("返回"), m_actionBar);
    m_skipButton->setObjectName(QStringLiteral("skipButton"));
    m_skipButton->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    m_skipButton->setIconSize(QSize(18, 18));
    m_skipButton->setFixedHeight(30);

    m_connectButton = new QPushButton(QStringLiteral("连接"), m_actionBar);
    m_connectButton->setObjectName(QStringLiteral("primaryButton"));
    m_connectButton->setIcon(makeUiIcon(UiIcon::Check, QColor(QStringLiteral("#F3F7FD"))));
    m_connectButton->setIconSize(QSize(18, 18));
    m_connectButton->setFixedSize(100, 30);

    actionRow->addWidget(m_skipButton);
    actionRow->addStretch(1);
    actionRow->addWidget(m_connectButton);
    layout->addWidget(m_actionBar);

    connect(m_scanButton, &QPushButton::clicked, this, &MainWindow::startScan);
    connect(m_networkList, &QListWidget::itemSelectionChanged, this, &MainWindow::updateSelection);
    connect(m_connectButton, &QPushButton::clicked, this, &MainWindow::onWifiScanConnectClicked);
    connect(m_skipButton, &QPushButton::clicked, this, &MainWindow::leaveWifiPage);
    return page;
}

QWidget *MainWindow::createPasswordEntryPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("passwordPage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);

    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 6, 0, 2);
    layout->setSpacing(8);

    QHBoxLayout *passwordRow = new QHBoxLayout;
    passwordRow->setContentsMargins(10, 0, 10, 0);
    passwordRow->setSpacing(6);

    m_passwordLabel = new QLabel(page);
    m_passwordLabel->setFixedSize(22, 22);
    m_passwordLabel->setAlignment(Qt::AlignCenter);
    m_passwordLabel->setPixmap(makeUiIcon(UiIcon::Lock, QColor(QStringLiteral("#ADBED2"))).pixmap(18, 18));

    m_passwordEdit = new QLineEdit(page);
    m_passwordEdit->setPlaceholderText(QStringLiteral("密码"));
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_passwordEdit->setMaxLength(64);
    m_passwordEdit->setReadOnly(true);
    m_passwordEdit->setAttribute(Qt::WA_InputMethodEnabled, false);
    m_passwordEdit->setAttribute(Qt::WA_AcceptTouchEvents, true);
    m_passwordEdit->installEventFilter(this);
    m_passwordEdit->setFixedHeight(31);

    m_keyboardButton = new QPushButton(page);
    m_keyboardButton->setObjectName(QStringLiteral("iconButton"));
    m_keyboardButton->setIcon(makeUiIcon(UiIcon::Keyboard, QColor(QStringLiteral("#ADBED2"))));
    m_keyboardButton->setIconSize(QSize(20, 20));
    m_keyboardButton->setFixedSize(34, 32);
    m_keyboardButton->setToolTip(QStringLiteral("打开软键盘"));
    m_keyboardButton->setEnabled(false);

    m_passwordToggle = new QPushButton(page);
    m_passwordToggle->setObjectName(QStringLiteral("iconButton"));
    m_passwordToggle->setIcon(makeUiIcon(UiIcon::Eye, QColor(QStringLiteral("#ADBED2"))));
    m_passwordToggle->setIconSize(QSize(20, 20));
    m_passwordToggle->setFixedSize(34, 32);
    m_passwordToggle->setToolTip(QStringLiteral("显示 / 隐藏密码"));

    passwordRow->addWidget(m_passwordLabel);
    passwordRow->addWidget(m_passwordEdit, 1);
    passwordRow->addWidget(m_keyboardButton);
    passwordRow->addWidget(m_passwordToggle);
    layout->addLayout(passwordRow);

    m_passwordMessage = new QLabel(QString(), page);
    m_passwordMessage->setObjectName(QStringLiteral("message"));
    m_passwordMessage->setFixedHeight(18);
    m_passwordMessage->hide();
    layout->addWidget(m_passwordMessage);

    m_keyboardPanel = createPasswordKeyboard(page);
    m_keyboardPanel->hide();
    layout->addWidget(m_keyboardPanel, 1);

    m_passwordFooterSpacer = new QWidget(page);
    m_passwordFooterSpacer->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
    layout->addWidget(m_passwordFooterSpacer, 1);

    m_passwordActionBar = new QWidget(page);
    QHBoxLayout *actionRow = new QHBoxLayout(m_passwordActionBar);
    actionRow->setContentsMargins(10, 0, 10, 0);
    actionRow->setSpacing(7);

    m_passwordBackButton = new QPushButton(QStringLiteral("返回"), m_passwordActionBar);
    m_passwordBackButton->setObjectName(QStringLiteral("skipButton"));
    m_passwordBackButton->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    m_passwordBackButton->setIconSize(QSize(18, 18));
    m_passwordBackButton->setFixedHeight(30);

    m_passwordConnectButton = new QPushButton(QStringLiteral("连接"), m_passwordActionBar);
    m_passwordConnectButton->setObjectName(QStringLiteral("primaryButton"));
    m_passwordConnectButton->setIcon(makeUiIcon(UiIcon::Check, QColor(QStringLiteral("#F3F7FD"))));
    m_passwordConnectButton->setIconSize(QSize(18, 18));
    m_passwordConnectButton->setFixedSize(100, 30);

    actionRow->addWidget(m_passwordBackButton);
    actionRow->addStretch(1);
    actionRow->addWidget(m_passwordConnectButton);
    layout->addWidget(m_passwordActionBar);

    connect(m_keyboardButton, &QPushButton::clicked, this, &MainWindow::showPasswordKeyboard);
    connect(m_passwordEdit, &QLineEdit::returnPressed, this, &MainWindow::onConnectClicked);
    connect(m_passwordBackButton, &QPushButton::clicked, this, &MainWindow::onPasswordBackClicked);
    connect(m_passwordConnectButton, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    connect(m_passwordToggle, &QPushButton::clicked, this, [this]() {
        m_showPassword = !m_showPassword;
        m_passwordEdit->setEchoMode(m_showPassword ? QLineEdit::Normal : QLineEdit::Password);
        m_passwordToggle->setIcon(makeUiIcon(UiIcon::Eye,
                                              QColor(m_showPassword ? QStringLiteral("#5AAAF2")
                                                                    : QStringLiteral("#8296AF"))));
        m_passwordToggle->setToolTip(m_showPassword ? QStringLiteral("隐藏密码") : QStringLiteral("显示密码"));
    });
    return page;
}

QWidget *MainWindow::createPasswordKeyboard(QWidget *parent)
{
    QWidget *panel = new QWidget(parent);
    panel->setObjectName(QStringLiteral("keyboardPanel"));
    panel->setMinimumHeight(160);
    panel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    QVBoxLayout *panelLayout = new QVBoxLayout(panel);
    panelLayout->setContentsMargins(6, 0, 6, 0);
    panelLayout->setSpacing(2);

    m_keyboardSsid = new QLabel(panel);
    m_keyboardSsid->setObjectName(QStringLiteral("keyboardSsid"));
    m_keyboardSsid->setFixedHeight(20);
    panelLayout->addWidget(m_keyboardSsid);

    auto makeKey = [panel](const QString &text, bool special, int width) {
        QPushButton *key = new QPushButton(text, panel);
        key->setObjectName(special ? QStringLiteral("softKeySpecial") : QStringLiteral("softKey"));
        key->setFocusPolicy(Qt::NoFocus);
        key->setMinimumHeight(32);
        key->setMaximumHeight(50);
        key->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        if (width > 0)
            key->setMinimumWidth(width);
        return key;
    };

    QHBoxLayout *row1 = new QHBoxLayout;
    row1->setContentsMargins(0, 0, 0, 0);
    row1->setSpacing(3);
    const QString row1Chars = QStringLiteral("qwertyuiop");
    for (int i = 0; i < row1Chars.size(); ++i) {
        QPushButton *key = makeKey(row1Chars.mid(i, 1), false, 43);
        m_alphaButtons << key;
        row1->addWidget(key, 1);
        connect(key, &QPushButton::clicked, this, [this, key]() {
            insertPasswordText(key->text());
        });
    }
    panelLayout->addLayout(row1, 1);

    QHBoxLayout *row2 = new QHBoxLayout;
    row2->setContentsMargins(0, 0, 0, 0);
    row2->setSpacing(3);
    row2->addStretch(1);
    const QString row2Chars = QStringLiteral("asdfghjkl");
    for (int i = 0; i < row2Chars.size(); ++i) {
        QPushButton *key = makeKey(row2Chars.mid(i, 1), false, 43);
        m_alphaButtons << key;
        row2->addWidget(key, 1);
        connect(key, &QPushButton::clicked, this, [this, key]() {
            insertPasswordText(key->text());
        });
    }
    row2->addStretch(1);
    panelLayout->addLayout(row2, 1);

    QHBoxLayout *row3 = new QHBoxLayout;
    row3->setContentsMargins(0, 0, 0, 0);
    row3->setSpacing(3);
    m_shiftButton = makeKey(QStringLiteral("⇧"), true, 42);
    row3->addWidget(m_shiftButton, 1);
    connect(m_shiftButton, &QPushButton::clicked, this, [this]() {
        if (m_keyboardMode == 0) {
            m_capsLock = !m_capsLock;
            updateKeyboardLabels();
        } else {
            insertPasswordText(m_shiftButton->text());
        }
    });
    const QString row3Chars = QStringLiteral("zxcvbnm");
    for (int i = 0; i < row3Chars.size(); ++i) {
        QPushButton *key = makeKey(row3Chars.mid(i, 1), false, 43);
        m_alphaButtons << key;
        row3->addWidget(key, 1);
        connect(key, &QPushButton::clicked, this, [this, key]() {
            insertPasswordText(key->text());
        });
    }
    m_backspaceButton = makeKey(QString(), true, 44);
    m_backspaceButton->setIcon(makeUiIcon(UiIcon::Backspace, QColor(QStringLiteral("#E8F0FA"))));
    m_backspaceButton->setIconSize(QSize(20, 20));
    m_backspaceButton->setToolTip(QStringLiteral("删除"));
    row3->addWidget(m_backspaceButton, 1);
    connect(m_backspaceButton, &QPushButton::clicked, this, &MainWindow::backspacePassword);
    panelLayout->addLayout(row3, 1);

    QHBoxLayout *row4 = new QHBoxLayout;
    row4->setContentsMargins(0, 0, 0, 0);
    row4->setSpacing(3);
    m_modeButton = makeKey(QStringLiteral("ABC"), true, 54);
    m_modeButton->setObjectName(QStringLiteral("softKeyMode"));
    row4->addWidget(m_modeButton);
    connect(m_modeButton, &QPushButton::clicked, this, [this]() {
        m_keyboardMode = (m_keyboardMode + 1) % 3;
        m_capsLock = false;
        updateKeyboardLabels();
    });

    QPushButton *commaKey = makeKey(QStringLiteral(","), true, 36);
    row4->addWidget(commaKey);
    connect(commaKey, &QPushButton::clicked, this, [this]() { insertPasswordText(QStringLiteral(",")); });

    QPushButton *spaceKey = makeKey(QStringLiteral("空格"), true, 0);
    row4->addWidget(spaceKey, 1);
    connect(spaceKey, &QPushButton::clicked, this, [this]() { insertPasswordText(QStringLiteral(" ")); });

    QPushButton *periodKey = makeKey(QStringLiteral("."), true, 36);
    row4->addWidget(periodKey);
    connect(periodKey, &QPushButton::clicked, this, [this]() { insertPasswordText(QStringLiteral(".")); });

    m_doneButton = makeKey(QStringLiteral("完成"), true, 58);
    m_doneButton->setObjectName(QStringLiteral("softKeyDone"));
    m_doneButton->setIcon(makeUiIcon(UiIcon::Check, QColor(QStringLiteral("#F3F7FD"))));
    m_doneButton->setIconSize(QSize(17, 17));
    row4->addWidget(m_doneButton);
    connect(m_doneButton, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    row4->setStretch(0, 0);
    row4->setStretch(1, 0);
    row4->setStretch(2, 1);
    row4->setStretch(3, 0);
    row4->setStretch(4, 0);
    panelLayout->addLayout(row4, 1);

    updateKeyboardLabels();
    return panel;
}

void MainWindow::showPasswordKeyboard()
{
    if (!m_passwordEdit || !m_passwordEdit->isEnabled() || m_connectionBusy)
        return;
    QString ssid;
    selectedNetwork(&ssid, nullptr, nullptr);
    m_keyboardSsid->setText(QFontMetrics(m_keyboardSsid->font()).elidedText(ssid, Qt::ElideMiddle, 450));
    if (!m_keyboardVisible) {
        m_keyboardMode = 0;
        m_capsLock = false;
    }
    m_wifiPageStack->setCurrentWidget(m_passwordPage);
    m_keyboardVisible = true;
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->setStyleSheet(QString());
    m_passwordMessage->hide();
    m_passwordFooterSpacer->hide();
    m_passwordActionBar->hide();
    m_keyboardPanel->show();
    m_passwordEdit->setCursorPosition(m_passwordEdit->text().size());
    updateKeyboardLabels();
}

void MainWindow::hidePasswordKeyboard()
{
    if (!m_keyboardVisible)
        return;
    m_keyboardVisible = false;
    m_keyboardPanel->hide();
    m_passwordMessage->setVisible(!m_passwordMessage->text().isEmpty());
    m_passwordFooterSpacer->show();
    m_passwordActionBar->show();
}

void MainWindow::updateKeyboardLabels()
{
    QStringList labels;
    QString shiftLabel;
    if (m_keyboardMode == 0) {
        labels = QStringList() << QStringLiteral("q") << QStringLiteral("w") << QStringLiteral("e")
                               << QStringLiteral("r") << QStringLiteral("t") << QStringLiteral("y")
                               << QStringLiteral("u") << QStringLiteral("i") << QStringLiteral("o")
                               << QStringLiteral("p") << QStringLiteral("a") << QStringLiteral("s")
                               << QStringLiteral("d") << QStringLiteral("f") << QStringLiteral("g")
                               << QStringLiteral("h") << QStringLiteral("j") << QStringLiteral("k")
                               << QStringLiteral("l") << QStringLiteral("z") << QStringLiteral("x")
                               << QStringLiteral("c") << QStringLiteral("v") << QStringLiteral("b")
                               << QStringLiteral("n") << QStringLiteral("m");
        if (m_capsLock) {
            for (QString &label : labels)
                label = label.toUpper();
        }
        shiftLabel = QStringLiteral("⇧");
        m_modeButton->setText(QStringLiteral("ABC"));
        m_modeButton->setToolTip(QStringLiteral("字母键盘"));
    } else if (m_keyboardMode == 1) {
        labels = QStringList() << QStringLiteral("1") << QStringLiteral("2") << QStringLiteral("3")
                               << QStringLiteral("4") << QStringLiteral("5") << QStringLiteral("6")
                               << QStringLiteral("7") << QStringLiteral("8") << QStringLiteral("9")
                               << QStringLiteral("0") << QStringLiteral("@") << QStringLiteral("#")
                               << QStringLiteral("$") << QStringLiteral("%") << QStringLiteral("&")
                               << QStringLiteral("-") << QStringLiteral("+") << QStringLiteral("(")
                               << QStringLiteral(")") << QStringLiteral("*") << QStringLiteral("/")
                               << QStringLiteral(":") << QStringLiteral("\"") << QStringLiteral("'")
                               << QStringLiteral("!") << QStringLiteral("?");
        shiftLabel = QStringLiteral("=");
        m_modeButton->setText(QStringLiteral("123"));
        m_modeButton->setToolTip(QStringLiteral("数字键盘"));
    } else {
        labels = QStringList() << QStringLiteral("!") << QStringLiteral("@") << QStringLiteral("#")
                               << QStringLiteral("$") << QStringLiteral("%") << QStringLiteral("^")
                               << QStringLiteral("&") << QStringLiteral("*") << QStringLiteral("(")
                               << QStringLiteral(")") << QStringLiteral("-") << QStringLiteral("_")
                               << QStringLiteral("+") << QStringLiteral("[") << QStringLiteral("]")
                               << QStringLiteral("{") << QStringLiteral("}") << QStringLiteral("\\")
                               << QStringLiteral("|") << QStringLiteral(";") << QStringLiteral(":")
                               << QStringLiteral("\"") << QStringLiteral("'") << QStringLiteral("<")
                               << QStringLiteral(">") << QStringLiteral("?");
        shiftLabel = QStringLiteral("~");
        m_modeButton->setText(QStringLiteral("#+="));
        m_modeButton->setToolTip(QStringLiteral("符号键盘"));
    }

    const int count = qMin(labels.size(), m_alphaButtons.size());
    for (int i = 0; i < count; ++i)
        m_alphaButtons.at(i)->setText(labels.at(i));
    m_shiftButton->setText(shiftLabel);
    m_shiftButton->setProperty("active", m_keyboardMode == 0 && m_capsLock);
    m_shiftButton->style()->unpolish(m_shiftButton);
    m_shiftButton->style()->polish(m_shiftButton);
    m_modeButton->setProperty("active", m_keyboardMode != 0);
    m_modeButton->style()->unpolish(m_modeButton);
    m_modeButton->style()->polish(m_modeButton);
}

void MainWindow::insertPasswordText(const QString &text)
{
    if (text.isEmpty() || !m_passwordEdit)
        return;
    QString value = m_passwordEdit->text();
    const int room = 64 - value.size();
    if (room <= 0)
        return;
    value.append(text.left(room));
    m_passwordEdit->setText(value);
    m_passwordEdit->setCursorPosition(value.size());
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    if (m_keyboardVisible)
        m_passwordMessage->hide();
}

void MainWindow::backspacePassword()
{
    QString value = m_passwordEdit->text();
    if (value.isEmpty()) {
        m_passwordMessage->clear();
        m_passwordMessage->setToolTip(QString());
        if (m_keyboardVisible)
            m_passwordMessage->hide();
        return;
    }
    value.chop(1);
    m_passwordEdit->setText(value);
    m_passwordEdit->setCursorPosition(value.size());
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    if (m_keyboardVisible)
        m_passwordMessage->hide();
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == m_passwordEdit &&
        (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::TouchBegin)) {
        showPasswordKeyboard();
        event->accept();
        return true;
    }
    return QWidget::eventFilter(watched, event);
}

void MainWindow::startScan()
{
    if (m_scanBusy || m_connectionBusy)
        return;
    hidePasswordKeyboard();
    m_scanBusy = true;
    m_scanButton->setEnabled(false);
    m_networkList->setEnabled(false);
    m_connectButton->setEnabled(false);
    m_passwordConnectButton->setEnabled(false);
    m_passwordEdit->setEnabled(false);
    m_passwordToggle->setEnabled(false);
    m_keyboardButton->setEnabled(false);
    m_scanButton->setText(QString());
    m_scanInfo->setText(QStringLiteral("扫描…"));
    m_wifiMessage->setStyleSheet(QString());
    m_wifiMessage->clear();
    m_wifiMessage->hide();
    m_wifiMessage->setToolTip(QString());
    emit scanRequested();
}

void MainWindow::onScanFinished(const QList<WifiNetwork> &networks, const QString &error)
{
    m_scanBusy = false;
    m_scanButton->setEnabled(!m_connectionBusy);
    m_networkList->setEnabled(!m_connectionBusy);
    m_scanButton->setText(QString());
    m_networkList->clear();

    for (const WifiNetwork &network : networks) {
        QListWidgetItem *item = new QListWidgetItem(network.ssid, m_networkList);
        item->setData(FlagsRole, network.flags);
        item->setData(SignalRole, network.signalLevel);
        item->setData(SecuredRole, network.secured);
        item->setData(SupportedRole, network.supported);
        item->setSizeHint(QSize(440, 28));
    }

    if (!error.isEmpty()) {
        m_scanInfo->setText(QStringLiteral("扫描失败"));
        m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
        m_wifiMessage->setText(QFontMetrics(m_wifiMessage->font()).elidedText(error, Qt::ElideRight, 445));
        m_wifiMessage->setVisible(true);
        m_wifiMessage->setToolTip(error);
        updateSelection();
        return;
    }

    m_scanInfo->setText(QStringLiteral("%1 个").arg(networks.size()));
    if (networks.isEmpty()) {
        m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
        m_wifiMessage->setText(QStringLiteral("未发现网络"));
        m_wifiMessage->setVisible(true);
        m_wifiMessage->setToolTip(QString());
        updateSelection();
        return;
    }

    int preferred = 0;
    for (int i = 0; i < m_networkList->count(); ++i) {
        if (m_networkList->item(i)->data(SupportedRole).toBool()) {
            preferred = i;
            break;
        }
    }
    m_networkList->setCurrentRow(preferred);
    m_wifiMessage->clear();
    m_wifiMessage->setToolTip(QString());
    updateSelection();
}

void MainWindow::updateSelection()
{
    const QListWidgetItem *item = m_networkList->currentItem();
    if (!item) {
        m_passwordEdit->clear();
        m_passwordEdit->setEnabled(false);
        m_passwordToggle->setEnabled(false);
        m_keyboardButton->setEnabled(false);
        m_passwordLabel->clear();
        m_connectButton->setEnabled(false);
        m_passwordConnectButton->setEnabled(false);
        return;
    }

    const bool secured = item->data(SecuredRole).toBool();
    const bool supported = item->data(SupportedRole).toBool();
    m_passwordEdit->clear();
    m_showPassword = false;
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_passwordToggle->setIcon(makeUiIcon(UiIcon::Eye, QColor(QStringLiteral("#8296AF"))));
    m_passwordEdit->setEnabled(secured && supported && !m_connectionBusy);
    m_passwordToggle->setEnabled(secured && supported && !m_connectionBusy);
    m_keyboardButton->setEnabled(secured && supported && !m_connectionBusy);
    m_passwordEdit->setPlaceholderText(!supported ? QStringLiteral("暂不支持")
                                               : (secured ? QStringLiteral("密码")
                                                          : QStringLiteral("无需密码")));
    if (secured) {
        m_passwordLabel->setPixmap(makeUiIcon(UiIcon::Lock,
                                               supported ? QColor(QStringLiteral("#ADBED2"))
                                                         : QColor(QStringLiteral("#FF8C95"))).pixmap(18, 18));
    } else {
        m_passwordLabel->clear();
    }
    m_connectButton->setEnabled(supported && !m_connectionBusy && !m_scanBusy);
    m_passwordConnectButton->setEnabled(supported && !m_connectionBusy && !m_scanBusy);
    if (!supported) {
        m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
        m_wifiMessage->setText(QStringLiteral("暂不支持此网络"));
        m_wifiMessage->setVisible(true);
        m_wifiMessage->setToolTip(QString());
    } else {
        m_wifiMessage->setStyleSheet(QString());
        m_wifiMessage->clear();
        m_wifiMessage->hide();
        m_wifiMessage->setToolTip(QString());
    }
}

bool MainWindow::selectedNetwork(QString *ssid,
                                 bool *secured,
                                 bool *supported) const
{
    const QListWidgetItem *item = m_networkList->currentItem();
    if (!item)
        return false;
    if (ssid)
        *ssid = item->text();
    if (secured)
        *secured = item->data(SecuredRole).toBool();
    if (supported)
        *supported = item->data(SupportedRole).toBool();
    return true;
}

void MainWindow::onWifiScanConnectClicked()
{
    if (m_scanBusy || m_connectionBusy)
        return;

    bool secured = false;
    bool supported = false;
    if (!selectedNetwork(nullptr, &secured, &supported)) {
        m_wifiMessage->setText(QStringLiteral("请选择网络"));
        m_wifiMessage->setVisible(true);
        return;
    }
    if (!supported) {
        m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
        m_wifiMessage->setText(QStringLiteral("暂不支持此网络"));
        m_wifiMessage->setVisible(true);
        return;
    }

    if (!secured) {
        m_passwordEdit->clear();
        onConnectClicked();
        return;
    }

    m_passwordEdit->clear();
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_showPassword = false;
    m_passwordToggle->setIcon(makeUiIcon(UiIcon::Eye, QColor(QStringLiteral("#ADBED2"))));
    m_passwordToggle->setToolTip(QStringLiteral("显示 / 隐藏密码"));
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();
    m_wifiPageStack->setCurrentWidget(m_passwordPage);
    showPasswordKeyboard();
}

void MainWindow::onPasswordBackClicked()
{
    hidePasswordKeyboard();
    m_passwordEdit->clear();
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();
    m_wifiPageStack->setCurrentWidget(m_scanPage);
}

void MainWindow::onConnectClicked()
{
    QLabel *statusMessage = m_wifiPageStack->currentWidget() == m_passwordPage
                                ? m_passwordMessage
                                : m_wifiMessage;
    QString ssid;
    bool secured = false;
    bool supported = false;
    if (!selectedNetwork(&ssid, &secured, &supported)) {
        statusMessage->setText(QStringLiteral("请选择网络"));
        statusMessage->setVisible(true);
        return;
    }
    if (!supported) {
        statusMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
        statusMessage->setText(QStringLiteral("暂不支持此网络"));
        statusMessage->setVisible(true);
        return;
    }

    const QString password = m_passwordEdit->text();
    QString passwordFormatError;
    if (secured && !isValidWpaPasswordFormat(password, &passwordFormatError)) {
        hidePasswordKeyboard();
        m_wifiPageStack->setCurrentWidget(m_scanPage);
        m_passwordEdit->clear();
        m_passwordMessage->clear();
        m_passwordMessage->setToolTip(QString());
        m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
        m_wifiMessage->setText(password.isEmpty()
                                   ? QStringLiteral("密码不能为空，请点击“连接”重新输入密码。")
                                   : QStringLiteral("密码格式不合法，请点击“连接”重新输入密码。"));
        m_wifiMessage->setVisible(true);
        m_wifiMessage->setToolTip(passwordFormatError);
        return;
    }

    hidePasswordKeyboard();
    m_wifiPageStack->setCurrentWidget(m_scanPage);
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_wifiMessage->setStyleSheet(QStringLiteral("color:#5AAAF2;font-size:11px;"));
    m_wifiMessage->setText(QStringLiteral("正在连接 Wi-Fi"));
    m_wifiMessage->setVisible(true);
    m_wifiMessage->setToolTip(QString());
    m_ipAddress.clear();
    if (m_timeSyncRetryTimer)
        m_timeSyncRetryTimer->stop();
    m_pendingCredentials.ssid = ssid;
    m_pendingCredentials.password = password;
    m_pendingCredentials.secured = secured;
    m_savePendingCredentials = true;
    m_autoConnection = false;
    setWifiConnecting();
    setBusy(true);
    m_connectionAnimationFrame = 0;
    m_scanInfo->setText(QStringLiteral("连接中"));
    m_connectionAnimationTimer->start();
    emit connectRequested(ssid, password, secured);
}

void MainWindow::setBusy(bool busy)
{
    m_connectionBusy = busy;
    if (!busy && m_connectionAnimationTimer && m_connectionAnimationTimer->isActive()) {
        m_connectionAnimationTimer->stop();
        if (m_wifiPageStack->currentWidget() == m_scanPage)
            m_scanInfo->setText(QStringLiteral("%1 个").arg(m_networkList->count()));
    }
    m_scanButton->setEnabled(!busy && !m_scanBusy);
    m_networkList->setEnabled(!busy);
    m_skipButton->setEnabled(!busy);
    m_passwordBackButton->setEnabled(!busy);
    m_connectButton->setText(busy ? QStringLiteral("连接中…") : QStringLiteral("连接"));
    m_passwordConnectButton->setText(busy ? QStringLiteral("连接中…") : QStringLiteral("连接"));

    if (busy) {
        m_connectButton->setEnabled(false);
        m_passwordConnectButton->setEnabled(false);
        m_passwordEdit->setEnabled(false);
        m_passwordToggle->setEnabled(false);
        m_keyboardButton->setEnabled(false);
    } else {
        const QListWidgetItem *item = m_networkList->currentItem();
        const bool secured = item && item->data(SecuredRole).toBool();
        const bool supported = item && item->data(SupportedRole).toBool();
        m_passwordEdit->setEnabled(secured && supported);
        m_passwordToggle->setEnabled(secured && supported);
        m_keyboardButton->setEnabled(secured && supported);
        m_connectButton->setEnabled(supported && !m_scanBusy);
        m_passwordConnectButton->setEnabled(supported && !m_scanBusy);
    }
}

void MainWindow::onConnectFinished(bool success,
                                   const QString &ssid,
                                   const QString &ipAddress,
                                   const QString &message)
{
    const bool wasAutoConnection = m_autoConnection;
    const bool wasSecuredAttempt = m_pendingCredentials.secured;
    setBusy(false);
    m_autoConnection = false;

    if (!success) {
        m_ipAddress.clear();
        if (m_timeSyncRetryTimer)
            m_timeSyncRetryTimer->stop();
        setWifiStatus(false, QString());
        m_pendingCredentials.password.clear();
        m_savePendingCredentials = false;
        if (wasAutoConnection) {
            showHomeMessage(QStringLiteral("Wi-Fi 自动连接失败：%1。点击顶栏 Wi-Fi 图标可重新设置。")
                                .arg(message), true);
        } else {
            m_wifiPageStack->setCurrentWidget(m_scanPage);
            m_passwordEdit->clear();

            const bool passwordFormatError = message.contains(QStringLiteral("WPA/WPA2 密码")) ||
                                             message.contains(QStringLiteral("可见 ASCII"));
            const bool authenticationFailure = message.contains(QStringLiteral("4WAY_HANDSHAKE")) ||
                                               message.contains(QStringLiteral("GROUP_HANDSHAKE")) ||
                                               message.contains(QStringLiteral("密码")) ||
                                               message.contains(QStringLiteral("握手"));
            QString prompt;
            if (passwordFormatError) {
                prompt = QStringLiteral("密码格式无效，请点击“连接”重新输入密码。");
            } else if (wasSecuredAttempt && authenticationFailure) {
                prompt = QStringLiteral("Wi-Fi 连接失败，密码可能不正确。请点击“连接”重新输入密码。");
            } else if (wasSecuredAttempt) {
                prompt = QStringLiteral("Wi-Fi 连接失败，请检查网络后点击“连接”重新输入密码重试。");
            } else {
                prompt = QStringLiteral("Wi-Fi 连接失败，请检查网络后点击“连接”重试。");
            }

            m_wifiMessage->setStyleSheet(QStringLiteral("color:#FF8C95;font-size:11px;"));
            m_wifiMessage->setText(QFontMetrics(m_wifiMessage->font()).elidedText(prompt, Qt::ElideRight, 445));
            m_wifiMessage->setVisible(true);
            m_wifiMessage->setToolTip(message);
        }
        return;
    }

    m_ipAddress = ipAddress;
    QString saveError;
    bool credentialsSaved = true;
    if (m_savePendingCredentials) {
        credentialsSaved = m_credentialStore.save(m_pendingCredentials, &saveError);
        if (credentialsSaved)
            m_hasCredentials = true;
    }
    m_savePendingCredentials = false;
    m_pendingCredentials.password.clear();

    m_wifiMessage->clear();
    m_wifiMessage->hide();
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();

    m_setupComplete = true;
    m_skipButton->setText(QStringLiteral("返回"));
    m_skipButton->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    m_passwordEdit->clear();
    setWifiStatus(true, ssid);
    m_stack->setCurrentWidget(m_homePage);
    if (!credentialsSaved)
        showHomeMessage(QStringLiteral("Wi-Fi 凭据未保存"), true);
    else
        showHomeMessage(QStringLiteral("RS485  ↔  STM32"), false);
    if (!ipAddress.isEmpty())
        startInternetTimeSync();
}

void MainWindow::onStatusChanged(bool connected,
                                 const QString &ssid,
                                 const QString &ipAddress)
{
    m_ipAddress = connected ? ipAddress : QString();
    setWifiStatus(connected, ssid);
    if (connected && !ipAddress.isEmpty()) {
        startInternetTimeSync();
    } else if (!connected) {
        if (m_timeSyncRetryTimer)
            m_timeSyncRetryTimer->stop();
        if (m_stack->currentWidget() == m_homePage && m_setupComplete)
            showHomeMessage(QStringLiteral("Wi-Fi 未连接"), true);
    }
}

void MainWindow::setWifiStatus(bool connected, const QString &ssid)
{
    if (!m_wifiStatusButton)
        return;
    m_wifiStatusButton->setProperty("connected", connected);
    m_wifiStatusButton->setText(QString());
    m_wifiStatusButton->setIcon(connected
                                    ? makeUiIcon(UiIcon::WifiConnected, QColor(QStringLiteral("#35A978")))
                                    : makeUiIcon(UiIcon::Wifi, QColor(QStringLiteral("#8296AF"))));

    if (m_wifiTopStatus) {
        m_wifiTopStatus->setProperty("connected", connected);
        m_wifiTopStatus->setProperty("connecting", false);
        m_wifiTopStatus->setText(connected ? QStringLiteral("WIFI 已连接")
                                           : QStringLiteral("WIFI 未连接"));
        m_wifiTopStatus->style()->unpolish(m_wifiTopStatus);
        m_wifiTopStatus->style()->polish(m_wifiTopStatus);
    }
    if (m_wifiTopIp) {
        m_wifiTopIp->setText(connected
                                 ? (m_ipAddress.isEmpty()
                                        ? QStringLiteral("IP：未获取")
                                        : QStringLiteral("IP：%1").arg(m_ipAddress))
                                 : QStringLiteral("IP：--"));
    }

    QString tooltip = connected && !ssid.isEmpty()
                          ? QStringLiteral("Wi-Fi 已连接：%1").arg(ssid)
                          : QStringLiteral("Wi-Fi 未连接");
    if (connected && !m_ipAddress.isEmpty())
        tooltip += QStringLiteral("\nIP：%1").arg(m_ipAddress);
    m_wifiStatusButton->setToolTip(tooltip);
    m_wifiStatusButton->style()->unpolish(m_wifiStatusButton);
    m_wifiStatusButton->style()->polish(m_wifiStatusButton);
}

void MainWindow::setWifiConnecting()
{
    if (m_wifiTopStatus) {
        m_wifiTopStatus->setProperty("connected", false);
        m_wifiTopStatus->setProperty("connecting", true);
        m_wifiTopStatus->setText(QStringLiteral("WIFI 连接中…"));
        m_wifiTopStatus->style()->unpolish(m_wifiTopStatus);
        m_wifiTopStatus->style()->polish(m_wifiTopStatus);
    }
    if (m_wifiTopIp)
        m_wifiTopIp->setText(QStringLiteral("IP：获取中…"));
    if (m_wifiStatusButton) {
        m_wifiStatusButton->setProperty("connected", false);
        m_wifiStatusButton->setIcon(makeUiIcon(UiIcon::Wifi, QColor(QStringLiteral("#5AAAF2"))));
        m_wifiStatusButton->setToolTip(QStringLiteral("Wi-Fi 连接中…"));
        m_wifiStatusButton->style()->unpolish(m_wifiStatusButton);
        m_wifiStatusButton->style()->polish(m_wifiStatusButton);
    }
}

void MainWindow::startInternetTimeSync()
{
    if (m_ipAddress.isEmpty() || m_timeSynchronized || m_timeSyncInProgress ||
        (m_timeSyncRetryTimer && m_timeSyncRetryTimer->isActive()))
        return;

    if (m_timeSyncRetryTimer)
        m_timeSyncRetryTimer->stop();
    m_timeSyncInProgress = true;
    if (m_clockTime)
        m_clockTime->setToolTip(QStringLiteral("Wi-Fi 已联网，正在获取北京时间…"));
    emit timeSyncRequested();
}

void MainWindow::onTimeSyncFinished(bool success,
                                    qint64 utcMilliseconds,
                                    bool systemClockSet,
                                    bool rtcWritten,
                                    const QString &message)
{
    m_timeSyncInProgress = false;
    if (success && utcMilliseconds > 0) {
        m_beijingUtcMilliseconds = utcMilliseconds;
        m_beijingClockElapsed.start();
        m_timeSynchronized = true;
        if (m_timeSyncRetryTimer)
            m_timeSyncRetryTimer->stop();

        QString clockTooltip = systemClockSet
                                   ? QStringLiteral("北京时间 · 系统时钟已同步")
                                   : QStringLiteral("北京时间 · 系统时钟未修改");
        clockTooltip += rtcWritten
                            ? QStringLiteral(" · 已写入 RTC（UTC）")
                            : QStringLiteral(" · RTC 写入失败");
        if (m_clockDate)
            m_clockDate->setToolTip(clockTooltip);
        if (m_clockTime)
            m_clockTime->setToolTip(clockTooltip);
        qInfo().noquote() << message;
        updateClock();
        return;
    }

    if (m_clockDate)
        m_clockDate->setToolTip(QStringLiteral("北京时间校时失败，网络可用后重试"));
    if (m_clockTime)
        m_clockTime->setToolTip(QStringLiteral("北京时间校时失败，网络可用后重试"));
    qWarning().noquote() << message;
    if (!m_ipAddress.isEmpty() && m_timeSyncRetryTimer)
        m_timeSyncRetryTimer->start(30000);
}

void MainWindow::showHomeMessage(const QString &text, bool warning)
{
    if (!m_homeMessage)
        return;
    m_homeMessage->setText(text);
    m_homeMessage->setToolTip(text);
    m_homeMessage->setStyleSheet(warning ? QStringLiteral("color:#FF8C95;font-size:11px;")
                                         : QStringLiteral("color:#ADBED2;font-size:11px;"));
}

void MainWindow::updateClock()
{
    const qint64 utcMilliseconds = m_timeSynchronized && m_beijingClockElapsed.isValid()
                                      ? m_beijingUtcMilliseconds + m_beijingClockElapsed.elapsed()
                                      : QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    const QDateTime beijingTime = QDateTime::fromMSecsSinceEpoch(utcMilliseconds, Qt::UTC)
                                      .addSecs(8 * 60 * 60);
    if (m_clockDate)
        m_clockDate->setText(beijingTime.toString(QStringLiteral("yyyy-MM-dd")));
    if (m_clockTime)
        m_clockTime->setText(beijingTime.toString(QStringLiteral("HH:mm:ss")));
}

void MainWindow::openWifiSettings()
{
    hidePasswordKeyboard();
    m_wifiPageStack->setCurrentWidget(m_scanPage);
    m_skipButton->setText(QStringLiteral("返回"));
    m_skipButton->setIcon(makeUiIcon(UiIcon::Back, QColor(QStringLiteral("#8296AF"))));
    m_passwordEdit->clear();
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_showPassword = false;
    m_passwordToggle->setIcon(makeUiIcon(UiIcon::Eye, QColor(QStringLiteral("#ADBED2"))));
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();
    m_wifiMessage->setStyleSheet(QString());
    m_wifiMessage->clear();
    m_wifiMessage->hide();
    m_wifiMessage->setToolTip(QString());
    m_stack->setCurrentWidget(m_wifiPage);
    startScan();
}

void MainWindow::leaveWifiPage()
{
    hidePasswordKeyboard();
    if (!m_setupComplete) {
        // Keep the user in the home screen for this run; without a credential
        // file the next launch will return to Wi-Fi setup.
        m_setupComplete = true;
    }
    m_stack->setCurrentWidget(m_homePage);
}

void MainWindow::openPeripheralHub()
{
    m_peripheralPageStack->setCurrentWidget(m_peripheralHubPage);
    m_stack->setCurrentWidget(m_peripheralPage);
}

void MainWindow::openAudioTestPage()
{
    m_peripheralPageStack->setCurrentWidget(m_audioTestPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    updateAudioControls();
}

void MainWindow::openXiaozhiPage()
{
    m_peripheralPageStack->setCurrentWidget(m_xiaozhiPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    if (!m_xiaozhiBridge->isActive()) {
        resetXiaozhiSessionUi(QStringLiteral("正在启动小智核心…"));
        QString error;
        if (!m_xiaozhiBridge->start(&error)) {
            m_xiaozhiStatus->setText(error);
            if (m_xiaozhiActivationMessage)
                m_xiaozhiActivationMessage->setText(error);
        }
    }
    m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isActive()
                                       ? QStringLiteral("停止小智")
                                       : QStringLiteral("启动小智"));
    updateXiaozhiActivationView();
}

void MainWindow::openRs485Page()
{
    m_peripheralPageStack->setCurrentWidget(m_rs485Page);
    m_stack->setCurrentWidget(m_peripheralPage);
    emit modbusStartRequested();
}

void MainWindow::returnToHome()
{
    returnToPeripheralHub();
    m_stack->setCurrentWidget(m_homePage);
}

void MainWindow::returnToPeripheralHub()
{
    QWidget *current = m_peripheralPageStack->currentWidget();
    if (current == m_audioTestPage) {
        stopAudioProcesses();
    } else if (current == m_xiaozhiPage) {
        if (m_xiaozhiBridge)
            m_xiaozhiBridge->stop();
        resetXiaozhiSessionUi(QStringLiteral("小智已停止"));
    } else if (current == m_rs485Page) {
        emit modbusStopRequested();
        if (m_rs485Status)
            m_rs485Status->setText(QStringLiteral("正在关闭 RS485…"));
    }
    m_peripheralPageStack->setCurrentWidget(m_peripheralHubPage);
}

void MainWindow::startRecording()
{
    if (!m_recordProcess || !m_playProcess ||
        m_recordProcess->state() != QProcess::NotRunning ||
        m_playProcess->state() != QProcess::NotRunning)
        return;

    // Release the ALSA device before starting the longer recording process.
    stopButtonClickSound();
    const QFileInfo outputInfo(m_recordingPath);
    if (!QDir().mkpath(outputInfo.absolutePath())) {
        m_audioStatus->setText(QStringLiteral("无法创建录音目录：%1").arg(outputInfo.absolutePath()));
        return;
    }
    QFile::remove(m_recordingPath);
    m_autoPlayAfterRecord = false;
    m_recordProcess->setProgram(m_arecordProgram);
    QStringList arguments;
    arguments << QStringLiteral("-D") << m_captureDevice
              << QStringLiteral("-f") << QStringLiteral("S16_LE")
              << QStringLiteral("-r") << QString::number(m_audioSampleRate)
              << QStringLiteral("-c") << QStringLiteral("1")
              << QStringLiteral("-t") << QStringLiteral("wav")
              << m_recordingPath;
    m_recordProcess->setArguments(arguments);
    m_recordProcess->start();
    m_audioStatus->setText(QStringLiteral("正在启动录音…"));
    updateAudioControls();
}

void MainWindow::stopRecording(bool playWhenFinished)
{
    if (!m_recordProcess || m_recordProcess->state() == QProcess::NotRunning)
        return;
    stopButtonClickSound();
    m_autoPlayAfterRecord = playWhenFinished;
    m_audioStatus->setText(playWhenFinished
                               ? QStringLiteral("正在结束录音并准备回放…")
                               : QStringLiteral("正在结束录音…"));
    m_recordProcess->terminate();
    updateAudioControls();
    QTimer::singleShot(1800, this, [this]() {
        if (m_recordProcess && m_recordProcess->state() != QProcess::NotRunning)
            m_recordProcess->kill();
    });
}

void MainWindow::playAudioFile(const QString &path, const QString &purpose)
{
    if (!m_playProcess || !m_recordProcess)
        return;
    if (m_recordProcess->state() != QProcess::NotRunning) {
        m_audioStatus->setText(QStringLiteral("录音进行中，请先停止录音"));
        return;
    }
    if (m_playProcess->state() != QProcess::NotRunning) {
        m_audioStatus->setText(QStringLiteral("当前已有音频正在播放"));
        return;
    }
    const QFileInfo fileInfo(path);
    if (!fileInfo.exists() || !fileInfo.isFile()) {
        m_audioStatus->setText(QStringLiteral("音频文件不存在：%1").arg(path));
        updateAudioControls();
        return;
    }

    // The click tone uses a separate aplay process; never let it contend with
    // the requested file playback on ALSA devices without software mixing.
    stopButtonClickSound();
    m_playStopRequested = false;
    m_playPurpose = purpose;
    m_playProcess->setProgram(m_aplayProgram);
    m_playProcess->setArguments(QStringList() << QStringLiteral("-D") << m_playbackDevice << path);
    m_playProcess->start();
    m_audioStatus->setText(QStringLiteral("正在播放：%1").arg(path));
    updateAudioControls();
}

void MainWindow::stopAudioProcesses()
{
    m_autoPlayAfterRecord = false;
    if (m_recordProcess && m_recordProcess->state() != QProcess::NotRunning) {
        m_recordProcess->terminate();
        if (!m_recordProcess->waitForFinished(700)) {
            m_recordProcess->kill();
            m_recordProcess->waitForFinished(700);
        }
    }
    if (m_playProcess && m_playProcess->state() != QProcess::NotRunning) {
        m_playStopRequested = true;
        m_playProcess->terminate();
        if (!m_playProcess->waitForFinished(700)) {
            m_playProcess->kill();
            m_playProcess->waitForFinished(700);
        }
    }
    m_playPurpose.clear();
    m_playStopRequested = false;
    updateAudioControls();
}

void MainWindow::updateAudioControls()
{
    if (!m_recordButton || !m_musicButton)
        return;
    const bool recording = m_recordProcess && m_recordProcess->state() != QProcess::NotRunning;
    const bool playing = m_playProcess && m_playProcess->state() != QProcess::NotRunning;
    const bool stoppingRecord = recording && m_autoPlayAfterRecord;
    m_recordButton->setText(recording
                                ? (stoppingRecord ? QStringLiteral("正在结束录音…")
                                                  : QStringLiteral("停止录音并回放"))
                                : QStringLiteral("开始录音"));
    m_recordButton->setEnabled(recording ? !stoppingRecord : !playing);
    m_musicButton->setText(playing ? QStringLiteral("停止播放")
                                   : QStringLiteral("播放 /music.wav"));
    m_musicButton->setEnabled(playing || !recording);
}

void MainWindow::onRecordProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    Q_UNUSED(exitCode)
    Q_UNUSED(exitStatus)
    const bool playAfterStop = m_autoPlayAfterRecord;
    m_autoPlayAfterRecord = false;
    updateAudioControls();

    const QFileInfo recording(m_recordingPath);
    if (playAfterStop && recording.exists() && recording.isFile() && recording.size() > 44) {
        m_audioStatus->setText(QStringLiteral("录音完成，正在自动回放…"));
        playAudioFile(m_recordingPath, QStringLiteral("录音回放"));
        return;
    }
    if (playAfterStop) {
        m_audioStatus->setText(QStringLiteral("录音文件无效或为空，无法回放"));
    } else if (recording.exists() && recording.size() > 44) {
        m_audioStatus->setText(QStringLiteral("录音已保存：%1").arg(m_recordingPath));
    } else {
        m_audioStatus->setText(QStringLiteral("录音结束；请检查麦克风、arecord 和 ALSA 设备"));
    }
    updateAudioControls();
}

void MainWindow::onPlaybackProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    const QString purpose = m_playPurpose;
    m_playPurpose.clear();
    const bool stoppedByUser = m_playStopRequested;
    m_playStopRequested = false;
    if (stoppedByUser)
        m_audioStatus->setText(QStringLiteral("播放已停止"));
    else if (exitStatus == QProcess::NormalExit && exitCode == 0)
        m_audioStatus->setText(QStringLiteral("%1完成").arg(purpose));
    else
        m_audioStatus->setText(QStringLiteral("%1失败或异常结束（代码 %2）").arg(purpose).arg(exitCode));
    updateAudioControls();
}

void MainWindow::onXiaozhiTextReceived(const QString &text, const QString &sentenceState)
{
    if (text.trimmed().isEmpty() || !m_chatList)
        return;

    if (sentenceState == QLatin1String("sentence_start")) {
        addChatBubble(text, true, false);
        m_streamingAssistantRow = m_chatList->count() - 1;
        m_streamingAssistantText = text;
        return;
    }
    if (sentenceState == QLatin1String("sentence_end")) {
        if (m_streamingAssistantRow >= 0 && m_streamingAssistantRow < m_chatList->count()) {
            QListWidgetItem *item = m_chatList->item(m_streamingAssistantRow);
            if (text != m_streamingAssistantText && !text.startsWith(m_streamingAssistantText))
                item->setText(text);
            else if (text.startsWith(m_streamingAssistantText))
                item->setText(text);
            m_streamingAssistantRow = -1;
            m_streamingAssistantText.clear();
            m_chatList->scrollToBottom();
        } else {
            addChatBubble(text, true, false);
        }
        return;
    }
    addChatBubble(text, true, false);
}

void MainWindow::resetXiaozhiSessionUi(const QString &status)
{
    m_xiaozhiActivationCode.clear();
    m_xiaozhiActivated = false;
    m_xiaozhiAudioReady = false;
    m_xiaozhiOnline = false;
    m_xiaozhiManualRestartHint = false;
    if (m_xiaozhiReadyHintTimer)
        m_xiaozhiReadyHintTimer->stop();
    m_streamingAssistantText.clear();
    m_streamingAssistantRow = -1;
    if (m_xiaozhiActivationCodeLabel)
        m_xiaozhiActivationCodeLabel->setText(QStringLiteral("等待激活码"));
    if (m_xiaozhiStatus && !status.isEmpty())
        m_xiaozhiStatus->setText(status);
    updateXiaozhiActivationView();
}

void MainWindow::updateXiaozhiActivationView()
{
    if (!m_xiaozhiActivationPanel || !m_chatList)
        return;

    const bool conversationReady = m_xiaozhiOnline && m_xiaozhiAudioReady;
    if (m_xiaozhiReadyHintTimer) {
        if (conversationReady) {
            m_xiaozhiReadyHintTimer->stop();
            m_xiaozhiManualRestartHint = false;
        } else if (m_xiaozhiActivated) {
            if (!m_xiaozhiManualRestartHint && !m_xiaozhiReadyHintTimer->isActive())
                m_xiaozhiReadyHintTimer->start();
        } else {
            m_xiaozhiReadyHintTimer->stop();
            m_xiaozhiManualRestartHint = false;
        }
    }

    m_xiaozhiActivationPanel->setVisible(!conversationReady);
    m_chatList->setVisible(conversationReady);
    if (!m_xiaozhiActivationMessage)
        return;

    if (conversationReady) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("小智服务、麦克风和扬声器均已就绪。现在可以开始说话。"));
        return;
    }

    if (m_xiaozhiManualRestartHint) {
        if (m_xiaozhiStatus)
            m_xiaozhiStatus->setText(QStringLiteral("连接未就绪 · 请停止小智后重新启动"));
        if (m_xiaozhiActivationTitleLabel)
            m_xiaozhiActivationTitleLabel->setText(QStringLiteral("小智连接长时间未就绪"));
        if (m_xiaozhiActivationCodeCaption)
            m_xiaozhiActivationCodeCaption->setText(QStringLiteral("建议手动重新启动"));
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(QStringLiteral("连接未就绪"));
        if (m_xiaozhiActivationInstructionsLabel)
            m_xiaozhiActivationInstructionsLabel->setText(
                QStringLiteral("若右上角显示“停止小智”，请先点击停止；按钮变为“启动小智”后，再点击一次。"));
        m_xiaozhiActivationMessage->setText(
            QStringLiteral("等待 30 秒仍未显示“已就绪”。重启后请等状态恢复再开始说话。"));
        return;
    }

    const QString status = m_xiaozhiStatus ? m_xiaozhiStatus->text() : QString();
    if (m_xiaozhiActivated) {
        if (m_xiaozhiActivationTitleLabel)
            m_xiaozhiActivationTitleLabel->setText(m_xiaozhiOnline && !m_xiaozhiAudioReady
                                                       ? QStringLiteral("云端已连接 · 正在准备音频设备")
                                                       : QStringLiteral("设备已绑定 · 正在连接小智服务"));
        if (m_xiaozhiActivationCodeCaption)
            m_xiaozhiActivationCodeCaption->setText(QStringLiteral("设备激活状态"));
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(QStringLiteral("已完成绑定"));
        if (m_xiaozhiActivationInstructionsLabel) {
            if (status.contains(QStringLiteral("中断")) || status.contains(QStringLiteral("网络断开")))
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("云端连接暂时中断，请检查 Wi-Fi；小智核心会自动尝试恢复。"));
            else if (status.contains(QStringLiteral("自动恢复")) || status.contains(QStringLiteral("音频线程初始化失败")))
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("核心正在自动恢复音频与云端连接，无需手动停止或重启。"));
            else if (m_xiaozhiOnline && !m_xiaozhiAudioReady)
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("核心正在确认麦克风录音和扬声器播放均可用；完成后会提示“已就绪”。"));
            else
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("核心正在初始化麦克风并连接云端；显示“已就绪”后再开始说话。"));
        }
    } else {
        if (m_xiaozhiActivationTitleLabel)
            m_xiaozhiActivationTitleLabel->setText(QStringLiteral("首次使用 · 绑定小智设备"));
        if (m_xiaozhiActivationCodeCaption)
            m_xiaozhiActivationCodeCaption->setText(QStringLiteral("小智核心实时返回的 6 位激活码"));
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(m_xiaozhiActivationCode.isEmpty()
                                                      ? QStringLiteral("等待激活码")
                                                      : m_xiaozhiActivationCode);
        if (m_xiaozhiActivationInstructionsLabel)
            m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("扫码注册/登录 → 添加设备 → 输入上方六码并完成绑定。未激活前，语音对话不可用。"));
    }

    if (status.contains(QStringLiteral("自动恢复")) ||
        status.contains(QStringLiteral("音频线程初始化失败"))) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("检测到核心音频初始化异常，正在自动重启恢复；无需手动操作。"));
    } else if (!m_xiaozhiBridge || !m_xiaozhiBridge->isActive()) {
        if (status == QLatin1String("小智已停止")) {
            m_xiaozhiActivationMessage->setText(QStringLiteral("小智核心已停止；如需使用，请点击右上角启动。"));
        } else if (status.contains(QStringLiteral("未找到")) ||
                   status.contains(QStringLiteral("执行权限")) ||
                   status.contains(QStringLiteral("无法监听")) ||
                   status.contains(QStringLiteral("连续启动失败")) ||
                   status.contains(QStringLiteral("异常退出"))) {
            m_xiaozhiActivationMessage->setText(status);
        } else {
            m_xiaozhiActivationMessage->setText(QStringLiteral("正在等待小智核心启动；语音对话会在服务连接就绪后开放。"));
        }
    } else if (!m_xiaozhiBridge->isRunning()) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("小智核心正在自动恢复；恢复连接后会提示“已就绪”，无需手动停止或重启。"));
    } else if (m_xiaozhiActivated) {
        if (status.contains(QStringLiteral("中断")) || status.contains(QStringLiteral("网络断开")))
            m_xiaozhiActivationMessage->setText(QStringLiteral("云端网络暂不可用；小智核心正在自动恢复连接，请检查 Wi-Fi。"));
        else
            m_xiaozhiActivationMessage->setText(QStringLiteral("设备已绑定；核心正在初始化麦克风并连接云端。请等状态显示“已就绪”后再说话。"));
    } else if (!m_xiaozhiActivationCode.isEmpty()) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("请按步骤完成设备绑定；激活确认前不会开启正常语音对话。"));
    } else {
        m_xiaozhiActivationMessage->setText(QStringLiteral("正在检查设备激活状态；如需绑定，将显示核心实际返回的六码。"));
    }
}

void MainWindow::addChatBubble(const QString &text, bool assistant, bool systemMessage)
{
    if (!m_chatList)
        return;
    while (m_chatList->count() >= 100) {
        delete m_chatList->takeItem(0);
        if (m_streamingAssistantRow > 0)
            --m_streamingAssistantRow;
        else if (m_streamingAssistantRow == 0)
            m_streamingAssistantRow = -1;
    }
    QListWidgetItem *item = new QListWidgetItem(text, m_chatList);
    item->setData(ChatSideRole, assistant ? 0 : 1);
    item->setData(ChatSystemRole, systemMessage);
    m_chatList->scrollToBottom();
}
