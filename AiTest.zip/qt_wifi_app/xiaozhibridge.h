#ifndef XIAOZHIBRIDGE_H
#define XIAOZHIBRIDGE_H

#include <QObject>
#include <QHostAddress>
#include <QProcess>
#include <QUdpSocket>
#include <QByteArray>

class QTimer;

class XiaozhiBridge : public QObject
{
    Q_OBJECT
public:
    explicit XiaozhiBridge(QObject *parent = nullptr);
    ~XiaozhiBridge() override;

    bool start(QString *error = nullptr);
    void stop();
    bool isRunning() const;
    bool isActive() const;
    QString executablePath() const;

signals:
    void statusChanged(const QString &status);
    void chatTextReceived(const QString &text, const QString &sentenceState);
    void userSpeechTextReceived(const QString &text);
    void toastReceived(const QString &text);
    void activationCodeReceived(const QString &code);
    void coreStateChanged(int state);
    void audioReadyChanged(bool ready);

private slots:
    void readDatagrams();

private:
    bool bindGuiSocket(QString *error);
    bool launchCore(QString *error);
    void scheduleRestart();
    void loadRuntimeConfig();

    QProcess m_process;
    QUdpSocket m_socket;
    QTimer *m_restartTimer;
    int m_restartAttempts;
    bool m_wantsRunning;
    bool m_audioRecoveryRequested;
    bool m_captureReady;
    bool m_playbackReady;
    QByteArray m_logLineBuffer;
    QString m_executablePath;
    QString m_workingDirectory;
    QHostAddress m_guiBindAddress;
    quint16 m_guiPort;
    bool m_ttsDisplayEnabled;
};

#endif // XIAOZHIBRIDGE_H
