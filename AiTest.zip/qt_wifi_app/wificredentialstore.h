#ifndef WIFI_CREDENTIAL_STORE_H
#define WIFI_CREDENTIAL_STORE_H

#include <QString>

struct WifiCredentials
{
    QString ssid;
    QString password;
    bool secured;

    WifiCredentials() : secured(false) {}
};

// Stores Wi-Fi credentials in a dedicated JSON file, separate from
// wpa_supplicant.conf and the application's non-sensitive settings.
class WifiCredentialStore
{
public:
    WifiCredentialStore();

    QString filePath() const;
    bool load(WifiCredentials *credentials, QString *error = nullptr) const;
    bool save(const WifiCredentials &credentials, QString *error = nullptr) const;
    bool clear(QString *error = nullptr) const;

private:
    QString m_filePath;
    bool m_customPath;
};

#endif // WIFI_CREDENTIAL_STORE_H
