#include "wificredentialstore.h"

#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QFileDevice>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QSaveFile>
#include <QStandardPaths>
#include <QtGlobal>

namespace {

QFileDevice::Permissions ownerOnlyPermissions()
{
    return QFileDevice::ReadOwner | QFileDevice::WriteOwner;
}

void setError(QString *error, const QString &message)
{
    if (error)
        *error = message;
}

} // namespace

WifiCredentialStore::WifiCredentialStore()
    : m_customPath(false)
{
    m_filePath = QString::fromLocal8Bit(qgetenv("WIFI_CREDENTIALS_PATH"));
    if (!m_filePath.isEmpty()) {
        m_customPath = true;
    } else {
        QString directory = QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation);
        if (directory.isEmpty())
            directory = QDir::home().filePath(QStringLiteral(".config/BoardLab/PeripheralTest"));
        m_filePath = QDir(directory).filePath(QStringLiteral("wifi_credentials.json"));
    }

    if (QFileInfo(m_filePath).isRelative())
        m_filePath = QDir::current().absoluteFilePath(m_filePath);
}

QString WifiCredentialStore::filePath() const
{
    return m_filePath;
}

bool WifiCredentialStore::load(WifiCredentials *credentials, QString *error) const
{
    if (!credentials) {
        setError(error, QStringLiteral("Wi-Fi 凭据接收对象无效。"));
        return false;
    }

    QFile file(m_filePath);
    if (!file.exists()) {
        if (error)
            error->clear();
        return false;
    }
#ifdef Q_OS_UNIX
    if (!QFile::setPermissions(m_filePath, ownerOnlyPermissions())) {
        setError(error, QStringLiteral("无法将 Wi-Fi 凭据文件权限限制为仅所有者可读写。"));
        return false;
    }
#endif
    if (!file.open(QIODevice::ReadOnly)) {
        setError(error, QStringLiteral("无法读取 Wi-Fi 凭据文件：%1").arg(file.errorString()));
        return false;
    }

    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(file.readAll(), &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        setError(error, QStringLiteral("Wi-Fi 凭据文件格式无效：%1").arg(parseError.errorString()));
        return false;
    }

    const QJsonObject object = document.object();
    WifiCredentials loaded;
    loaded.ssid = object.value(QStringLiteral("ssid")).toString();
    loaded.password = object.value(QStringLiteral("password")).toString();
    loaded.secured = object.value(QStringLiteral("secured")).toBool(!loaded.password.isEmpty());
    if (loaded.ssid.isEmpty()) {
        setError(error, QStringLiteral("Wi-Fi 凭据文件中没有 SSID。"));
        return false;
    }
    if (loaded.secured && loaded.password.isEmpty()) {
        setError(error, QStringLiteral("Wi-Fi 凭据文件中缺少密码。"));
        return false;
    }

    *credentials = loaded;
    if (error)
        error->clear();
    return true;
}

bool WifiCredentialStore::save(const WifiCredentials &credentials, QString *error) const
{
    if (credentials.ssid.trimmed().isEmpty()) {
        setError(error, QStringLiteral("Wi-Fi 名称不能为空，无法保存凭据。"));
        return false;
    }
    if (credentials.secured && credentials.password.isEmpty()) {
        setError(error, QStringLiteral("加密网络缺少密码，无法保存凭据。"));
        return false;
    }

    const QFileInfo fileInfo(m_filePath);
    QDir directory = fileInfo.absoluteDir();
    if (!directory.exists() && !directory.mkpath(QStringLiteral("."))) {
        setError(error, QStringLiteral("无法创建 Wi-Fi 凭据目录：%1").arg(directory.absolutePath()));
        return false;
    }

#ifdef Q_OS_UNIX
    if (!m_customPath) {
        QFile::setPermissions(directory.absolutePath(),
                              QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner);
    }
#endif

    QJsonObject object;
    object.insert(QStringLiteral("version"), 1);
    object.insert(QStringLiteral("ssid"), credentials.ssid);
    object.insert(QStringLiteral("password"), credentials.password);
    object.insert(QStringLiteral("secured"), credentials.secured);
    const QByteArray data = QJsonDocument(object).toJson(QJsonDocument::Indented);

    QSaveFile file(m_filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        setError(error, QStringLiteral("无法写入 Wi-Fi 凭据文件：%1").arg(file.errorString()));
        return false;
    }

    if (!file.setPermissions(ownerOnlyPermissions())) {
        const QString detail = file.errorString();
        file.cancelWriting();
        setError(error, QStringLiteral("无法限制 Wi-Fi 凭据文件权限：%1").arg(detail));
        return false;
    }
    if (file.write(data) != data.size()) {
        const QString detail = file.errorString();
        file.cancelWriting();
        setError(error, QStringLiteral("写入 Wi-Fi 凭据文件失败：%1").arg(detail));
        return false;
    }
    if (!file.commit()) {
        setError(error, QStringLiteral("保存 Wi-Fi 凭据文件失败：%1").arg(file.errorString()));
        return false;
    }

    if (!QFile::setPermissions(m_filePath, ownerOnlyPermissions())) {
        setError(error, QStringLiteral("凭据已写入，但无法将文件权限设为仅所有者可读写。"));
        return false;
    }

    if (error)
        error->clear();
    return true;
}

bool WifiCredentialStore::clear(QString *error) const
{
    if (!QFileInfo::exists(m_filePath)) {
        if (error)
            error->clear();
        return true;
    }
    if (!QFile::remove(m_filePath)) {
        setError(error, QStringLiteral("无法删除 Wi-Fi 凭据文件。"));
        return false;
    }
    if (error)
        error->clear();
    return true;
}
