#ifndef NTPSYNCHRONIZER_H
#define NTPSYNCHRONIZER_H

#include <QObject>
#include <QString>
#include <QtGlobal>

class NtpSynchronizer : public QObject
{
    Q_OBJECT
public:
    explicit NtpSynchronizer(QObject *parent = nullptr);

public slots:
    void synchronize();

signals:
    void synchronizationFinished(bool success,
                                qint64 utcMilliseconds,
                                bool systemClockSet,
                                bool rtcWritten,
                                const QString &message);
};

#endif // NTPSYNCHRONIZER_H
