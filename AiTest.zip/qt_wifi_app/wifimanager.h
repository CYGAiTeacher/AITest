#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <QObject>
#include <QList>
#include <QMetaType>
#include <QString>

struct WifiNetwork
{
    QString ssid;
    QString flags;
    int signalLevel;       // dBm, as reported by wpa_supplicant
    bool secured;
    bool supported;
};

Q_DECLARE_METATYPE(WifiNetwork)
Q_DECLARE_METATYPE(QList<WifiNetwork>)

// Runs Wi-Fi work on a worker thread. Scanning uses the control socket;
// connection/status commands invoke wpa_cli through QProcess without a shell.
class WifiWorker : public QObject
{
    Q_OBJECT
public:
    explicit WifiWorker(const QString &interfaceName,
                        const QString &controlDirectory,
                        QObject *parent = nullptr);

public slots:
    void scan();
    void connectNetwork(const QString &ssid,
                        const QString &password,
                        bool secured);
    void checkStatus();

signals:
    void scanFinished(const QList<WifiNetwork> &networks, const QString &error);
    void connectFinished(bool success,
                         const QString &ssid,
                         const QString &ipAddress,
                         const QString &message);
    void statusChanged(bool connected, const QString &ssid, const QString &ipAddress);

private:
    QString m_interfaceName;
    QString m_controlDirectory;
};

#endif // WIFI_MANAGER_H
