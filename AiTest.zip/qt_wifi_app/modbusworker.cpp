#include "modbusworker.h"

#include <QElapsedTimer>
#include <QTimer>

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/serial.h>

namespace {

quint16 modbusCrc16(const QByteArray &bytes)
{
    quint16 crc = 0xFFFF;
    for (unsigned char byte : bytes) {
        crc ^= static_cast<quint16>(byte);
        for (int bit = 0; bit < 8; ++bit) {
            if (crc & 1)
                crc = static_cast<quint16>((crc >> 1) ^ 0xA001);
            else
                crc = static_cast<quint16>(crc >> 1);
        }
    }
    return crc;
}

QByteArray frameWithCrc(const QByteArray &body)
{
    QByteArray frame(body);
    const quint16 crc = modbusCrc16(body);
    frame.append(static_cast<char>(crc & 0xFF));
    frame.append(static_cast<char>((crc >> 8) & 0xFF));
    return frame;
}

quint16 readU16(const QByteArray &bytes, int offset)
{
    return static_cast<quint16>((static_cast<quint8>(bytes.at(offset)) << 8) |
                                 static_cast<quint8>(bytes.at(offset + 1)));
}

bool verifyCrc(const QByteArray &frame)
{
    if (frame.size() < 4)
        return false;
    const quint16 expected = modbusCrc16(frame.left(frame.size() - 2));
    const quint16 received = static_cast<quint8>(frame.at(frame.size() - 2)) |
                             (static_cast<quint16>(static_cast<quint8>(frame.at(frame.size() - 1))) << 8);
    return expected == received;
}

speed_t baudConstant(int baudRate)
{
    switch (baudRate) {
    case 1200: return B1200;
    case 2400: return B2400;
    case 4800: return B4800;
    case 9600: return B9600;
    case 19200: return B19200;
    case 38400: return B38400;
    case 57600: return B57600;
    case 115200: return B115200;
#ifdef B230400
    case 230400: return B230400;
#endif
    default: return 0;
    }
}

QString errnoText(const QString &operation)
{
    return QStringLiteral("%1：%2").arg(operation, QString::fromLocal8Bit(std::strerror(errno)));
}

} // namespace

ModbusWorker::ModbusWorker(const QString &devicePath,
                           int baudRate,
                           int slaveAddress,
                           QObject *parent)
    : QObject(parent),
      m_devicePath(devicePath),
      m_baudRate(baudRate),
      m_slaveAddress(slaveAddress),
      m_fileDescriptor(-1),
      m_pollTimer(new QTimer(this)),
      m_running(false),
      m_directionIoctlFailed(false)
{
    m_pollTimer->setInterval(1000);
    connect(m_pollTimer, &QTimer::timeout, this, &ModbusWorker::pollSensors);
}

ModbusWorker::~ModbusWorker()
{
    closePort();
}

void ModbusWorker::setStatus(const QString &status)
{
    if (status == m_lastStatus)
        return;
    m_lastStatus = status;
    emit statusChanged(status);
}

bool ModbusWorker::openPort(QString *error)
{
    if (m_fileDescriptor >= 0)
        return true;

    const speed_t speed = baudConstant(m_baudRate);
    if (speed == 0) {
        if (error)
            *error = QStringLiteral("不支持的波特率：%1").arg(m_baudRate);
        return false;
    }

    const QByteArray nativePath = m_devicePath.toLocal8Bit();
    m_fileDescriptor = ::open(nativePath.constData(), O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
    if (m_fileDescriptor < 0) {
        if (error)
            *error = errnoText(QStringLiteral("打开 %1 失败").arg(m_devicePath));
        return false;
    }

    termios options;
    std::memset(&options, 0, sizeof(options));
    if (tcgetattr(m_fileDescriptor, &options) != 0) {
        if (error)
            *error = errnoText(QStringLiteral("读取串口参数失败"));
        closePort();
        return false;
    }

    cfmakeraw(&options);
    options.c_cflag &= ~(CSIZE | CSTOPB | PARODD);
    options.c_cflag |= (CS8 | CLOCAL | CREAD | PARENB);
#ifdef CRTSCTS
    options.c_cflag &= ~CRTSCTS;
#endif
#ifdef CMSPAR
    options.c_cflag &= ~CMSPAR;
#endif
    options.c_iflag &= ~(IXON | IXOFF | IXANY);
    options.c_iflag |= INPCK;
    options.c_cc[VMIN] = 0;
    options.c_cc[VTIME] = 0;
    if (cfsetispeed(&options, speed) != 0 || cfsetospeed(&options, speed) != 0 ||
        tcsetattr(m_fileDescriptor, TCSANOW, &options) != 0) {
        if (error)
            *error = errnoText(QStringLiteral("设置串口为 %1 baud、8E1 失败").arg(m_baudRate));
        closePort();
        return false;
    }
    tcflush(m_fileDescriptor, TCIOFLUSH);

#ifdef TIOCSRS485
    struct serial_rs485 rs485;
    std::memset(&rs485, 0, sizeof(rs485));
    rs485.flags = SER_RS485_ENABLED | SER_RS485_RTS_ON_SEND;
    m_directionIoctlFailed = ioctl(m_fileDescriptor, TIOCSRS485, &rs485) != 0;
    if (m_directionIoctlFailed)
        setStatus(QStringLiteral("串口已打开；内核未接受 RS-485 自动方向配置，检查 BSP/设备树"));
#else
    m_directionIoctlFailed = true;
    setStatus(QStringLiteral("串口已打开；当前 Linux 头文件不支持 TIOCSRS485，检查 BSP/设备树"));
#endif
    return true;
}

void ModbusWorker::closePort()
{
    if (m_fileDescriptor >= 0) {
        ::close(m_fileDescriptor);
        m_fileDescriptor = -1;
    }
    m_running = false;
}

void ModbusWorker::start()
{
    if (m_running)
        return;
    m_running = true;
    QString error;
    if (!openPort(&error)) {
        setStatus(QStringLiteral("RS485 未连接：%1").arg(error));
        m_running = false;
        return;
    }
    if (m_lastStatus.isEmpty())
        setStatus(QStringLiteral("串口已打开，正在等待 STM32 Modbus 响应…"));
    m_pollTimer->start();
    pollSensors();
}

void ModbusWorker::stop()
{
    m_running = false;
    m_pollTimer->stop();
    closePort();
    setStatus(QStringLiteral("RS485 已停止"));
}

bool ModbusWorker::exchange(const QByteArray &request,
                            int expectedLength,
                            QByteArray *response,
                            QString *error)
{
    if (m_fileDescriptor < 0) {
        if (error)
            *error = QStringLiteral("串口未打开");
        return false;
    }
    if (expectedLength < 5 || expectedLength > 256) {
        if (error)
            *error = QStringLiteral("Modbus 帧长度无效");
        return false;
    }

    // Respect the RTU 3.5-character silent interval (fixed 1.75 ms above 19200).
    const useconds_t silentIntervalUs = m_baudRate > 19200
                                           ? 1750
                                           : static_cast<useconds_t>((38500000 + m_baudRate - 1) / m_baudRate);
    ::usleep(silentIntervalUs);
    tcflush(m_fileDescriptor, TCIFLUSH);
    int written = 0;
    QElapsedTimer writeTimer;
    writeTimer.start();
    while (written < request.size()) {
        const ssize_t count = ::write(m_fileDescriptor,
                                      request.constData() + written,
                                      static_cast<size_t>(request.size() - written));
        if (count > 0) {
            written += static_cast<int>(count);
            continue;
        }
        if (count < 0 && errno != EAGAIN && errno != EINTR) {
            if (error)
                *error = errnoText(QStringLiteral("发送 Modbus 请求失败"));
            return false;
        }
        if (writeTimer.elapsed() > 200) {
            if (error)
                *error = QStringLiteral("串口发送超时");
            return false;
        }
        pollfd out;
        out.fd = m_fileDescriptor;
        out.events = POLLOUT;
        out.revents = 0;
        ::poll(&out, 1, 10);
    }
    if (tcdrain(m_fileDescriptor) != 0) {
        if (error)
            *error = errnoText(QStringLiteral("等待串口发送完成失败"));
        return false;
    }

    QByteArray received;
    QElapsedTimer readTimer;
    readTimer.start();
    const int timeoutMs = 400;
    while (readTimer.elapsed() < timeoutMs) {
        pollfd in;
        in.fd = m_fileDescriptor;
        in.events = POLLIN;
        in.revents = 0;
        const int waitMs = qMax(1, timeoutMs - static_cast<int>(readTimer.elapsed()));
        const int ready = ::poll(&in, 1, waitMs);
        if (ready < 0) {
            if (errno == EINTR)
                continue;
            if (error)
                *error = errnoText(QStringLiteral("等待 Modbus 响应失败"));
            return false;
        }
        if (ready == 0)
            break;
        if (in.revents & (POLLERR | POLLHUP | POLLNVAL)) {
            if (error)
                *error = QStringLiteral("RS485 串口出现 I/O 错误");
            return false;
        }
        char buffer[256];
        const ssize_t count = ::read(m_fileDescriptor, buffer, sizeof(buffer));
        if (count > 0)
            received.append(buffer, static_cast<int>(count));
        else if (count < 0 && errno != EAGAIN && errno != EINTR) {
            if (error)
                *error = errnoText(QStringLiteral("读取 Modbus 响应失败"));
            return false;
        }

        if (received.size() >= 2) {
            const quint8 function = static_cast<quint8>(received.at(1));
            const int frameLength = (function & 0x80) ? 5 : expectedLength;
            if (received.size() >= frameLength) {
                received.truncate(frameLength);
                if (response)
                    *response = received;
                return true;
            }
        }
    }

    if (error) {
        if (!received.isEmpty())
            *error = QStringLiteral("Modbus 响应帧不完整（%1/%2 字节）")
                    .arg(received.size()).arg(expectedLength);
        else
            *error = QStringLiteral("等待 STM32 响应超时（%1 ms）").arg(timeoutMs);
    }
    return false;
}

bool ModbusWorker::readHoldingRegisters(quint16 address,
                                       quint16 count,
                                       QList<quint16> *values,
                                       QString *error)
{
    QByteArray body;
    body.append(static_cast<char>(m_slaveAddress));
    body.append(static_cast<char>(0x03));
    body.append(static_cast<char>((address >> 8) & 0xFF));
    body.append(static_cast<char>(address & 0xFF));
    body.append(static_cast<char>((count >> 8) & 0xFF));
    body.append(static_cast<char>(count & 0xFF));
    const QByteArray request = frameWithCrc(body);

    QByteArray response;
    const int responseLength = 5 + count * 2;
    if (!exchange(request, responseLength, &response, error))
        return false;
    if (response.size() == 5 && (static_cast<quint8>(response.at(1)) & 0x80)) {
        if (verifyCrc(response) && static_cast<quint8>(response.at(0)) == m_slaveAddress) {
            if (error)
                *error = QStringLiteral("STM32 返回 Modbus 异常码 0x%1")
                        .arg(static_cast<quint8>(response.at(2)), 2, 16, QLatin1Char('0'));
        } else if (error) {
            *error = QStringLiteral("Modbus 异常帧 CRC 或站号错误");
        }
        return false;
    }
    if (response.size() != responseLength ||
        static_cast<quint8>(response.at(0)) != m_slaveAddress ||
        static_cast<quint8>(response.at(1)) != 0x03 ||
        static_cast<quint8>(response.at(2)) != count * 2 ||
        !verifyCrc(response)) {
        if (error)
            *error = QStringLiteral("Modbus 读响应站号、长度、功能码或 CRC 校验失败");
        return false;
    }

    if (values) {
        values->clear();
        for (int i = 0; i < count; ++i)
            values->append(readU16(response, 3 + i * 2));
    }
    return true;
}

bool ModbusWorker::writeSingleRegister(quint16 address,
                                       quint16 value,
                                       QString *error)
{
    QByteArray body;
    body.append(static_cast<char>(m_slaveAddress));
    body.append(static_cast<char>(0x06));
    body.append(static_cast<char>((address >> 8) & 0xFF));
    body.append(static_cast<char>(address & 0xFF));
    body.append(static_cast<char>((value >> 8) & 0xFF));
    body.append(static_cast<char>(value & 0xFF));
    const QByteArray request = frameWithCrc(body);

    QByteArray response;
    if (!exchange(request, 8, &response, error))
        return false;
    if (response.size() == 5 && (static_cast<quint8>(response.at(1)) & 0x80)) {
        if (verifyCrc(response) && static_cast<quint8>(response.at(0)) == m_slaveAddress) {
            if (error)
                *error = QStringLiteral("STM32 拒绝写入，Modbus 异常码 0x%1")
                        .arg(static_cast<quint8>(response.at(2)), 2, 16, QLatin1Char('0'));
        } else if (error) {
            *error = QStringLiteral("Modbus 异常帧 CRC 或站号错误");
        }
        return false;
    }
    if (response.size() != 8 || response.left(6) != request.left(6) || !verifyCrc(response)) {
        if (error)
            *error = QStringLiteral("Modbus 写响应回显或 CRC 校验失败");
        return false;
    }
    return true;
}

void ModbusWorker::pollSensors()
{
    if (!m_running || m_fileDescriptor < 0)
        return;
    QList<quint16> registers;
    QString error;
    if (!readHoldingRegisters(0x0000, 4, &registers, &error)) {
        setStatus(QStringLiteral("RS485 通信异常：%1").arg(error));
        return;
    }

    qint32 temperatureRaw = registers.at(2);
    if (temperatureRaw & 0x8000)
        temperatureRaw -= 0x10000;
    const double temperature = static_cast<double>(temperatureRaw) / 100.0;
    const double humidity = static_cast<double>(registers.at(3)) / 100.0;
    if (registers.at(0) > 1 || registers.at(1) > 1 ||
        temperature < -40.0 || temperature > 125.0 || humidity > 100.0) {
        setStatus(QStringLiteral("RS485 数据超出寄存器约定范围，请核对 STM32 映射"));
        return;
    }

    const QString onlineStatus = m_directionIoctlFailed
                                     ? QStringLiteral("Modbus RTU 在线 · 站号 %1 · 自动方向待核对").arg(m_slaveAddress)
                                     : QStringLiteral("Modbus RTU 在线 · 站号 %1").arg(m_slaveAddress);
    setStatus(onlineStatus);
    emit sensorReading(temperature, humidity, registers.at(0) != 0, registers.at(1) != 0);
}

void ModbusWorker::setLed(bool enabled)
{
    QString error;
    const bool success = writeSingleRegister(0x0000, enabled ? 1 : 0, &error);
    if (!success)
        setStatus(QStringLiteral("RS485 写 LED 失败：%1").arg(error));
    emit outputWriteFinished(true, enabled, success,
                             success ? QStringLiteral("LED 已更新") : error);
}

void ModbusWorker::setBuzzer(bool enabled)
{
    QString error;
    const bool success = writeSingleRegister(0x0001, enabled ? 1 : 0, &error);
    if (!success)
        setStatus(QStringLiteral("RS485 写蜂鸣器失败：%1").arg(error));
    emit outputWriteFinished(false, enabled, success,
                             success ? QStringLiteral("蜂鸣器已更新") : error);
}
