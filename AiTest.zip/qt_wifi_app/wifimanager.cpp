#include "wifimanager.h"

#include <QByteArray>
#include <QElapsedTimer>
#include <QFile>
#include <QFileInfo>
#include <QMap>
#include <QProcess>
#include <QThread>
#include <QStringList>

#include <algorithm>
#include <cerrno>
#include <cstring>
#include <atomic>

#ifdef Q_OS_UNIX
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <poll.h>
#include <unistd.h>
#include <stddef.h>
#endif

namespace {

class WpaControl
{
public:
    WpaControl(const QString &interfaceName, const QString &controlDirectory)
        : m_interfaceName(interfaceName),
          m_controlDirectory(controlDirectory),
          m_fd(-1)
    {
    }

    ~WpaControl() { closeSocket(); }

    bool openSocket(QString *error)
    {
#ifndef Q_OS_UNIX
        if (error)
            *error = QStringLiteral("wpa_supplicant 控制接口仅支持 Linux/Unix。");
        return false;
#else
        static std::atomic<int> counter(0);
        QStringList remotePaths;
        const QString explicitPath = QString::fromLocal8Bit(qgetenv("WPA_CTRL_PATH"));
        if (!explicitPath.isEmpty()) {
            remotePaths << explicitPath;
        } else {
            const QString envDir = QString::fromLocal8Bit(qgetenv("WPA_CTRL_DIR"));
            const QString primaryDir = envDir.isEmpty() ? m_controlDirectory : envDir;
            if (!primaryDir.isEmpty())
                remotePaths << primaryDir + QLatin1Char('/') + m_interfaceName;
            remotePaths << QStringLiteral("/run/wpa_supplicant/") + m_interfaceName;
            remotePaths << QStringLiteral("/var/run/wpa_supplicant/") + m_interfaceName;
        }
        remotePaths.removeDuplicates();

        QString lastError = QStringLiteral("找不到 wpa_supplicant 控制套接字。");
        for (const QString &remotePath : remotePaths) {
            const QByteArray remoteBytes = remotePath.toLocal8Bit();
            if (remoteBytes.size() >= int(sizeof(sockaddr_un::sun_path))) {
                lastError = QStringLiteral("控制套接字路径过长。");
                continue;
            }

            const int fd = ::socket(AF_UNIX, SOCK_DGRAM, 0);
            if (fd < 0) {
                lastError = QStringLiteral("无法创建 Wi-Fi 控制接口：%1")
                                .arg(QString::fromLocal8Bit(std::strerror(errno)));
                continue;
            }

            sockaddr_un localAddress;
            std::memset(&localAddress, 0, sizeof(localAddress));
            localAddress.sun_family = AF_UNIX;
            const QString localPath = QStringLiteral("/tmp/wpa_ctrl_qt_%1_%2")
                                          .arg(static_cast<qlonglong>(::getpid()))
                                          .arg(counter.fetch_add(1));
            const QByteArray localBytes = localPath.toLocal8Bit();
            if (localBytes.size() >= int(sizeof(localAddress.sun_path))) {
                ::close(fd);
                lastError = QStringLiteral("本地控制套接字路径过长。");
                continue;
            }
            std::memcpy(localAddress.sun_path, localBytes.constData(), size_t(localBytes.size()));
            localAddress.sun_path[localBytes.size()] = '\0';
            ::unlink(localAddress.sun_path);
            const socklen_t localLength = socklen_t(offsetof(sockaddr_un, sun_path) + localBytes.size() + 1);
            if (::bind(fd, reinterpret_cast<sockaddr *>(&localAddress), localLength) < 0) {
                lastError = QStringLiteral("无法绑定本地控制套接字：%1")
                                .arg(QString::fromLocal8Bit(std::strerror(errno)));
                ::close(fd);
                continue;
            }

            sockaddr_un remoteAddress;
            std::memset(&remoteAddress, 0, sizeof(remoteAddress));
            remoteAddress.sun_family = AF_UNIX;
            std::memcpy(remoteAddress.sun_path, remoteBytes.constData(), size_t(remoteBytes.size()));
            remoteAddress.sun_path[remoteBytes.size()] = '\0';
            const socklen_t remoteLength = socklen_t(offsetof(sockaddr_un, sun_path) + remoteBytes.size() + 1);
            if (::connect(fd, reinterpret_cast<sockaddr *>(&remoteAddress), remoteLength) < 0) {
                lastError = QStringLiteral("无法连接 %1：%2")
                                .arg(remotePath, QString::fromLocal8Bit(std::strerror(errno)));
                ::close(fd);
                ::unlink(localPath.toLocal8Bit().constData());
                continue;
            }

            m_fd = fd;
            m_localPath = localPath;
            if (error)
                error->clear();
            return true;
        }

        if (error)
            *error = lastError + QStringLiteral(" 请检查 wpa_supplicant 是否运行、接口名和控制权限。");
        return false;
#endif
    }

    QString request(const QString &command, int timeoutMs, QString *error = nullptr)
    {
#ifndef Q_OS_UNIX
        Q_UNUSED(command)
        Q_UNUSED(timeoutMs)
        if (error)
            *error = QStringLiteral("当前平台不支持 wpa_supplicant 控制接口。");
        return QString();
#else
        if (m_fd < 0) {
            if (error)
                *error = QStringLiteral("Wi-Fi 控制接口尚未打开。");
            return QString();
        }
        const QByteArray bytes = command.toUtf8();
        const ssize_t sent = ::send(m_fd, bytes.constData(), size_t(bytes.size()), 0);
        if (sent != ssize_t(bytes.size())) {
            if (error)
                *error = QStringLiteral("发送 Wi-Fi 控制命令失败：%1")
                             .arg(QString::fromLocal8Bit(std::strerror(errno)));
            return QString();
        }

        QElapsedTimer elapsed;
        elapsed.start();
        while (elapsed.elapsed() < timeoutMs) {
            QByteArray message;
            const int remaining = qMax(1, timeoutMs - int(elapsed.elapsed()));
            if (!receiveMessage(remaining, &message, error))
                return QString();
            const QString text = QString::fromUtf8(message.constData(), message.size()).trimmed();
            if (isUnsolicitedEvent(text)) {
                m_pendingEvents << text;
                continue;
            }
            if (error)
                error->clear();
            return text;
        }
        if (error)
            *error = QStringLiteral("wpa_supplicant 响应超时。");
        return QString();
#endif
    }

    bool waitForScanEvent(int timeoutMs)
    {
#ifndef Q_OS_UNIX
        Q_UNUSED(timeoutMs)
        return false;
#else
        QElapsedTimer elapsed;
        elapsed.start();
        while (elapsed.elapsed() < timeoutMs) {
            for (int i = 0; i < m_pendingEvents.size(); ++i) {
                const QString event = m_pendingEvents.at(i);
                if (event.contains(QStringLiteral("CTRL-EVENT-SCAN-RESULTS"))) {
                    m_pendingEvents.removeAt(i);
                    return true;
                }
                if (event.contains(QStringLiteral("CTRL-EVENT-SCAN-FAILED"))) {
                    m_pendingEvents.removeAt(i);
                    return false;
                }
            }
            QByteArray message;
            QString ignored;
            const int remaining = qMax(1, qMin(500, timeoutMs - int(elapsed.elapsed())));
            if (!receiveMessage(remaining, &message, &ignored))
                continue;
            const QString text = QString::fromUtf8(message.constData(), message.size()).trimmed();
            if (text.contains(QStringLiteral("CTRL-EVENT-SCAN-RESULTS")))
                return true;
            if (text.contains(QStringLiteral("CTRL-EVENT-SCAN-FAILED")))
                return false;
            if (isUnsolicitedEvent(text))
                m_pendingEvents << text;
        }
        return false;
#endif
    }

    void closeSocket()
    {
#ifdef Q_OS_UNIX
        if (m_fd >= 0) {
            ::close(m_fd);
            m_fd = -1;
        }
        if (!m_localPath.isEmpty()) {
            ::unlink(m_localPath.toLocal8Bit().constData());
            m_localPath.clear();
        }
#endif
    }

private:
#ifdef Q_OS_UNIX
    static bool isUnsolicitedEvent(const QString &message)
    {
        // wpa_supplicant prefixes monitor events with a numeric priority
        // (for example, <3>WPS-AP-AVAILABLE). Do not treat such messages as
        // replies to SCAN_RESULTS or other control commands.
        const int marker = message.indexOf(QLatin1Char('<'));
        const int end = marker >= 0 ? message.indexOf(QLatin1Char('>'), marker + 1) : -1;
        if (end > marker + 1) {
            bool numericPriority = true;
            for (int i = marker + 1; i < end; ++i) {
                if (!message.at(i).isDigit()) {
                    numericPriority = false;
                    break;
                }
            }
            if (numericPriority)
                return true;
        }
        return message.contains(QStringLiteral("CTRL-EVENT-")) ||
               message.startsWith(QStringLiteral("WPS-")) ||
               message.startsWith(QStringLiteral("P2P-")) ||
               message.contains(QStringLiteral("WPA: Key negotiation"));
    }

    bool receiveMessage(int timeoutMs, QByteArray *message, QString *error)
    {
        pollfd descriptor;
        descriptor.fd = m_fd;
        descriptor.events = POLLIN;
        descriptor.revents = 0;
        int result;
        do {
            result = ::poll(&descriptor, 1, timeoutMs);
        } while (result < 0 && errno == EINTR);

        if (result == 0) {
            if (error)
                *error = QStringLiteral("wpa_supplicant 响应超时。");
            return false;
        }
        if (result < 0 || (descriptor.revents & (POLLERR | POLLHUP | POLLNVAL))) {
            if (error)
                *error = QStringLiteral("读取 Wi-Fi 控制响应失败：%1")
                             .arg(QString::fromLocal8Bit(std::strerror(errno)));
            return false;
        }

        char buffer[16384];
        const ssize_t received = ::recv(m_fd, buffer, sizeof(buffer), 0);
        if (received < 0) {
            if (error)
                *error = QStringLiteral("读取 Wi-Fi 控制响应失败：%1")
                             .arg(QString::fromLocal8Bit(std::strerror(errno)));
            return false;
        }
        message->append(buffer, int(received));
        if (error)
            error->clear();
        return true;
    }
#endif

    QString m_interfaceName;
    QString m_controlDirectory;
    int m_fd;
    QString m_localPath;
    QStringList m_pendingEvents;
};

bool isHexPsk(const QByteArray &bytes)
{
    if (bytes.size() != 64)
        return false;
    for (char c : bytes) {
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
            return false;
    }
    return true;
}

QString quoteWpaConfigString(const QByteArray &value)
{
    // Match wpa_cli's SET_NETWORK psk "passphrase" syntax. Escape the two
    // characters that have special meaning inside a quoted config string.
    QByteArray quoted;
    quoted.reserve(value.size() + 2);
    quoted.append('"');
    for (char c : value) {
        if (c == '"' || c == '\\')
            quoted.append('\\');
        quoted.append(c);
    }
    quoted.append('"');
    return QString::fromLatin1(quoted);
}

QString wpaPskValue(const QString &password, QString *error)
{
    const QByteArray passphrase = password.toUtf8();
    if (isHexPsk(passphrase)) {
        if (error)
            error->clear();
        // A 64-digit hexadecimal value is already a raw 256-bit PSK.
        return QString::fromLatin1(passphrase.toLower());
    }

    if (passphrase.size() < 8 || passphrase.size() > 63) {
        if (error)
            *error = QStringLiteral("WPA/WPA2 密码需为 8–63 个 ASCII 字符，或 64 位十六进制 PSK。");
        return QString();
    }
    for (unsigned char c : passphrase) {
        if (c < 0x20 || c > 0x7e) {
            if (error)
                *error = QStringLiteral("WPA/WPA2 密码请使用可见 ASCII 字符。");
            return QString();
        }
    }

    if (error)
        error->clear();
    // Let wpa_supplicant derive the PMK from the quoted passphrase, exactly
    // as it does for: wpa_cli set_network <id> psk "passphrase".
    return quoteWpaConfigString(passphrase);
}

QString statusValue(const QString &status, const QString &key)
{
    const QStringList lines = status.split(QLatin1Char('\n'));
    const QString prefix = key + QLatin1Char('=');
    for (const QString &line : lines) {
        if (line.startsWith(prefix))
            return line.mid(prefix.size()).trimmed();
    }
    return QString();
}

QString interfaceIpv4Address(const QString &interfaceName)
{
#ifdef Q_OS_UNIX
    struct ifaddrs *interfaces = nullptr;
    if (::getifaddrs(&interfaces) != 0)
        return QString();

    QString address;
    for (struct ifaddrs *entry = interfaces; entry; entry = entry->ifa_next) {
        if (!entry->ifa_addr || entry->ifa_addr->sa_family != AF_INET ||
            QString::fromLocal8Bit(entry->ifa_name) != interfaceName)
            continue;

        const struct sockaddr_in *ipv4 =
            reinterpret_cast<const struct sockaddr_in *>(entry->ifa_addr);
        char text[INET_ADDRSTRLEN] = {0};
        if (::inet_ntop(AF_INET, &ipv4->sin_addr, text, sizeof(text))) {
            const QString candidate = QString::fromLatin1(text);
            if (candidate != QStringLiteral("0.0.0.0")) {
                address = candidate;
                break;
            }
        }
    }
    ::freeifaddrs(interfaces);
    return address;
#else
    Q_UNUSED(interfaceName)
    return QString();
#endif
}

bool startUdhcpc(const QString &interfaceName, QString *error)
{
#ifdef Q_OS_UNIX
    QString program = QString::fromLocal8Bit(qgetenv("UDHCPC_PATH"));
    if (program.isEmpty()) {
        const QStringList candidates = QStringList()
            << QStringLiteral("/sbin/udhcpc")
            << QStringLiteral("/usr/sbin/udhcpc")
            << QStringLiteral("/bin/udhcpc")
            << QStringLiteral("/usr/bin/udhcpc");
        for (const QString &candidate : candidates) {
            if (QFileInfo(candidate).isExecutable()) {
                program = candidate;
                break;
            }
        }
        if (program.isEmpty())
            program = QStringLiteral("udhcpc");
    }

    const QString pidFilePath = QStringLiteral("/run/udhcpc-%1.pid").arg(interfaceName);
    QFile pidFile(pidFilePath);
    if (pidFile.open(QIODevice::ReadOnly)) {
        bool pidOk = false;
        const qint64 savedPid = QString::fromLatin1(pidFile.readAll().trimmed()).toLongLong(&pidOk);
        pidFile.close();
        if (pidOk && savedPid > 1 &&
            (::kill(static_cast<pid_t>(savedPid), 0) == 0 || errno == EPERM)) {
            QFile commandLine(QStringLiteral("/proc/%1/cmdline").arg(savedPid));
            if (commandLine.open(QIODevice::ReadOnly)) {
                const QByteArray command = commandLine.readAll();
                if (command.contains(QByteArrayLiteral("udhcpc"))) {
                    ::kill(static_cast<pid_t>(savedPid), SIGUSR1); // renew the current lease
                    if (error)
                        error->clear();
                    return true;
                }
            }
        }
        QFile::remove(pidFilePath);
    }

    const QStringList arguments = QStringList()
        << QStringLiteral("-i") << interfaceName
        << QStringLiteral("-p") << pidFilePath;
    qint64 processId = 0;
    if (!QProcess::startDetached(program, arguments, QString(), &processId)) {
        if (error)
            *error = QStringLiteral("无法启动 udhcpc（%1）。请确认 udhcpc 已安装、PATH 正确且有网络管理权限。")
                         .arg(program);
        return false;
    }
    if (error)
        error->clear();
    return true;
#else
    Q_UNUSED(interfaceName)
    if (error)
        *error = QStringLiteral("当前平台不支持 udhcpc。");
    return false;
#endif
}

bool runWpaCli(const QString &interfaceName,
               const QString &controlDirectory,
               const QStringList &commandArguments,
               int timeoutMs,
               QString *response,
               QString *error)
{
    QString program = QString::fromLocal8Bit(qgetenv("WPA_CLI_PATH"));
    if (program.isEmpty()) {
        const QStringList candidates = QStringList()
            << QStringLiteral("/usr/sbin/wpa_cli")
            << QStringLiteral("/sbin/wpa_cli")
            << QStringLiteral("/usr/bin/wpa_cli")
            << QStringLiteral("/bin/wpa_cli");
        for (const QString &candidate : candidates) {
            if (QFileInfo(candidate).isExecutable()) {
                program = candidate;
                break;
            }
        }
        if (program.isEmpty())
            program = QStringLiteral("wpa_cli"); // Let QProcess search PATH.
    }

    QString cliInterface = interfaceName;
    QString cliControlDirectory = QString::fromLocal8Bit(qgetenv("WPA_CTRL_DIR"));
    const QString explicitSocket = QString::fromLocal8Bit(qgetenv("WPA_CTRL_PATH"));
    if (!explicitSocket.isEmpty()) {
        const QFileInfo socketInfo(explicitSocket);
        cliControlDirectory = socketInfo.path();
        if (!socketInfo.fileName().isEmpty())
            cliInterface = socketInfo.fileName();
    } else if (cliControlDirectory.isEmpty()) {
        cliControlDirectory = controlDirectory;
    }
    if (cliControlDirectory.isEmpty())
        cliControlDirectory = QStringLiteral("/run/wpa_supplicant");

    QStringList arguments;
    arguments << QStringLiteral("-p") << cliControlDirectory
              << QStringLiteral("-i") << cliInterface;
    arguments << commandArguments;

    QProcess process;
    process.start(program, arguments); // No shell: arguments are passed separately.
    if (!process.waitForStarted(2000)) {
        if (error)
            *error = QStringLiteral("无法启动 wpa_cli（%1）：%2")
                         .arg(program, process.errorString());
        return false;
    }
    if (!process.waitForFinished(timeoutMs)) {
        process.kill();
        process.waitForFinished();
        if (error)
            *error = QStringLiteral("wpa_cli 命令执行超时：%1")
                         .arg(commandArguments.value(0));
        return false;
    }

    const QByteArray standardOutput = process.readAllStandardOutput();
    const QByteArray standardError = process.readAllStandardError();
    const QString output = QString::fromUtf8(standardOutput).trimmed();
    if (response)
        *response = output;

    if (process.exitStatus() != QProcess::NormalExit || process.exitCode() != 0) {
        QString detail = QString::fromLocal8Bit(standardError).trimmed();
        if (detail.isEmpty())
            detail = output;
        if (detail.isEmpty())
            detail = process.errorString();
        if (error)
            *error = QStringLiteral("wpa_cli 命令失败（%1）：%2")
                         .arg(commandArguments.value(0), detail);
        return false;
    }

    if (error)
        error->clear();
    return true;
}

bool wpaCliCommandOk(const QString &interfaceName,
                     const QString &controlDirectory,
                     const QStringList &commandArguments,
                     QString *reason = nullptr)
{
    QString response;
    QString processError;
    if (!runWpaCli(interfaceName, controlDirectory, commandArguments,
                   3000, &response, &processError)) {
        if (reason)
            *reason = processError;
        return false;
    }
    if (response.trimmed() == QStringLiteral("OK"))
        return true;
    if (reason) {
        *reason = response.isEmpty()
                      ? QStringLiteral("wpa_supplicant 未接受网络配置。")
                      : QStringLiteral("wpa_supplicant 返回：%1").arg(response);
    }
    return false;
}

QList<WifiNetwork> parseScanResults(const QString &text)
{
    QMap<QString, WifiNetwork> bestBySsid;
    const QStringList lines = text.split(QLatin1Char('\n'), QString::SkipEmptyParts);
    for (int i = 1; i < lines.size(); ++i) {
        const QStringList fields = lines.at(i).split(QLatin1Char('\t'), QString::KeepEmptyParts);
        if (fields.size() < 5)
            continue;
        const QString ssid = fields.mid(4).join(QStringLiteral("\t")).trimmed();
        if (ssid.isEmpty())
            continue; // Hidden networks need a manually-entered SSID; not in this first version.

        WifiNetwork network;
        network.ssid = ssid;
        network.signalLevel = fields.at(2).toInt();
        network.flags = fields.at(3);
        const QString upperFlags = network.flags.toUpper();
        const bool hasPsk = upperFlags.contains(QStringLiteral("PSK"));
        const bool hasSecurity = upperFlags.contains(QStringLiteral("WPA")) ||
                                 upperFlags.contains(QStringLiteral("RSN")) ||
                                 upperFlags.contains(QStringLiteral("WEP")) ||
                                 upperFlags.contains(QStringLiteral("EAP")) ||
                                 upperFlags.contains(QStringLiteral("SAE")) ||
                                 upperFlags.contains(QStringLiteral("OWE"));
        network.secured = hasSecurity;
        network.supported = !hasSecurity || hasPsk;

        if (!bestBySsid.contains(ssid) ||
            bestBySsid.value(ssid).signalLevel < network.signalLevel) {
            bestBySsid.insert(ssid, network);
        }
    }

    QList<WifiNetwork> networks = bestBySsid.values();
    std::sort(networks.begin(), networks.end(), [](const WifiNetwork &a, const WifiNetwork &b) {
        return a.signalLevel > b.signalLevel;
    });
    return networks;
}

} // namespace

WifiWorker::WifiWorker(const QString &interfaceName,
                       const QString &controlDirectory,
                       QObject *parent)
    : QObject(parent),
      m_interfaceName(interfaceName),
      m_controlDirectory(controlDirectory)
{
}

void WifiWorker::scan()
{
    WpaControl control(m_interfaceName, m_controlDirectory);
    QString error;
    if (!control.openSocket(&error)) {
        emit scanFinished(QList<WifiNetwork>(), error);
        return;
    }

    // ATTACH subscribes this client to monitor events. Some vendor drivers do
    // not report scan completion reliably; use a conservative fallback when
    // monitor attachment is unavailable.
    const QString attachResponse = control.request(QStringLiteral("ATTACH"), 1500, &error).trimmed();
    const bool attached = attachResponse == QStringLiteral("OK");
    const QString scanResponse = control.request(QStringLiteral("SCAN"), 2500, &error).trimmed();
    if (scanResponse != QStringLiteral("OK")) {
        control.request(QStringLiteral("DETACH"), 500, nullptr);
        emit scanFinished(QList<WifiNetwork>(),
                          error.isEmpty() ? QStringLiteral("扫描命令失败：%1").arg(scanResponse) : error);
        return;
    }

    if (attached) {
        control.waitForScanEvent(12000);
    } else {
        QThread::msleep(4000);
    }

    QString response = control.request(QStringLiteral("SCAN_RESULTS"), 4000, &error);
    control.request(QStringLiteral("DETACH"), 500, nullptr);
    if (response.startsWith(QStringLiteral("FAIL")) || response.isEmpty()) {
        emit scanFinished(QList<WifiNetwork>(),
                          error.isEmpty() ? QStringLiteral("读取扫描结果失败。") : error);
        return;
    }

    const QList<WifiNetwork> networks = parseScanResults(response);
    emit scanFinished(networks, QString());
}

void WifiWorker::connectNetwork(const QString &ssid,
                                const QString &password,
                                bool secured)
{
    QString error;

    const QByteArray ssidBytes = ssid.toUtf8();
    if (ssidBytes.isEmpty()) {
        emit connectFinished(false, ssid, QString(),
                             QStringLiteral("Wi-Fi 名称不能为空。"));
        return;
    }

    const bool openNetwork = !secured;

    QString pskValue;
    if (!openNetwork) {
        pskValue = wpaPskValue(password, &error);
        if (pskValue.isEmpty()) {
            emit connectFinished(false, ssid, QString(), error);
            return;
        }
    }

    QString idText;
    QString commandError;
    if (!runWpaCli(m_interfaceName, m_controlDirectory,
                   QStringList() << QStringLiteral("add_network"),
                   3000, &idText, &commandError)) {
        emit connectFinished(false, ssid, QString(), commandError);
        return;
    }
    bool idOk = false;
    const int networkId = idText.trimmed().toInt(&idOk);
    if (!idOk) {
        emit connectFinished(false, ssid, QString(),
                             QStringLiteral("wpa_cli 未返回有效网络 ID：%1").arg(idText));
        return;
    }

    const QString id = QString::number(networkId);
    QString configError;
    const bool ssidSet = wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                                         QStringList() << QStringLiteral("set_network") << id
                                                       << QStringLiteral("ssid")
                                                       << QString::fromLatin1(ssidBytes.toHex()),
                                         &configError);
    bool securitySet = false;
    if (ssidSet && openNetwork) {
        securitySet = wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                                      QStringList() << QStringLiteral("set_network") << id
                                                    << QStringLiteral("key_mgmt")
                                                    << QStringLiteral("NONE"),
                                      &configError);
    } else if (ssidSet) {
        // The quoted pskValue is passed as one argv item; wpa_cli sends the
        // resulting SET_NETWORK command to the existing supplicant instance.
        securitySet = wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                                      QStringList() << QStringLiteral("set_network") << id
                                                    << QStringLiteral("psk") << pskValue,
                                      &configError) &&
                      wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                                      QStringList() << QStringLiteral("set_network") << id
                                                    << QStringLiteral("key_mgmt")
                                                    << QStringLiteral("WPA-PSK"),
                                      &configError);
    }

    if (!ssidSet || !securitySet ||
        !wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                         QStringList() << QStringLiteral("set_network") << id
                                       << QStringLiteral("priority") << QStringLiteral("10"),
                         &configError) ||
        !wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                         QStringList() << QStringLiteral("enable_network") << id,
                         &configError) ||
        !wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                         QStringList() << QStringLiteral("select_network") << id,
                         &configError)) {
        wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                        QStringList() << QStringLiteral("remove_network") << id, nullptr);
        emit connectFinished(false, ssid, QString(),
                             configError.isEmpty() ? QStringLiteral("配置 Wi-Fi 网络失败。") : configError);
        return;
    }

    bool connected = false;
    QString lastWpaState;
    QString lastCurrentSsid;
    QString lastStatusError;
    QElapsedTimer elapsed;
    elapsed.start();
    while (elapsed.elapsed() < 18000) {
        QString statusError;
        QString status;
        runWpaCli(m_interfaceName, m_controlDirectory,
                  QStringList() << QStringLiteral("status"),
                  2500, &status, &statusError);
        const QString state = statusValue(status, QStringLiteral("wpa_state"));
        const QString current = statusValue(status, QStringLiteral("ssid"));
        if (!state.isEmpty())
            lastWpaState = state;
        if (!current.isEmpty())
            lastCurrentSsid = current;
        if (!statusError.isEmpty())
            lastStatusError = statusError;
        if (state == QStringLiteral("COMPLETED")) {
            if (current.isEmpty() || current == ssid) {
                connected = true;
                break;
            }
        }
        QThread::msleep(500);
    }

    if (!connected) {
        QString detail = lastWpaState.isEmpty()
                             ? QStringLiteral("STATUS 无有效状态")
                             : QStringLiteral("wpa_state=%1").arg(lastWpaState);
        if (!lastCurrentSsid.isEmpty())
            detail += QStringLiteral("，当前 SSID=%1").arg(lastCurrentSsid);
        if (!lastStatusError.isEmpty())
            detail += QStringLiteral("，%1").arg(lastStatusError);

        QString hint;
        if (lastWpaState == QStringLiteral("4WAY_HANDSHAKE") ||
            lastWpaState == QStringLiteral("GROUP_HANDSHAKE")) {
            hint = QStringLiteral("请检查密码、路由器安全模式或驱动的 WPA 握手兼容性。");
        } else if (lastWpaState == QStringLiteral("ASSOCIATING") ||
                   lastWpaState == QStringLiteral("ASSOCIATED")) {
            hint = QStringLiteral("已开始关联，但安全握手尚未完成；请检查密码和加密模式。");
        } else {
            hint = QStringLiteral("请检查密码、信号强度和开发板 Wi-Fi 驱动配置。");
        }

        wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                        QStringList() << QStringLiteral("remove_network") << id, nullptr);
        wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                        QStringList() << QStringLiteral("reconnect"), nullptr);
        emit connectFinished(false, ssid, QString(),
                             QStringLiteral("连接超时（%1）。%2").arg(detail, hint));
        return;
    }

    // Report the 802.11/WPA connection before DHCP finishes so the UI can
    // distinguish an associated link from an address-acquisition delay.
    emit statusChanged(true, ssid, QString());

    QString dhcpError;
    const bool dhcpStarted = startUdhcpc(m_interfaceName, &dhcpError);
    QString ipAddress;
    QElapsedTimer dhcpWait;
    dhcpWait.start();
    while (dhcpWait.elapsed() < 20000) {
        ipAddress = interfaceIpv4Address(m_interfaceName);
        if (!ipAddress.isEmpty())
            break;
        if (!dhcpStarted)
            break;
        QThread::msleep(500);
    }

    QString message;
    if (ipAddress.isEmpty()) {
        message = QStringLiteral("Wi-Fi 已连接，但未获取到 IPv4 地址。");
        if (!dhcpStarted && !dhcpError.isEmpty())
            message += QStringLiteral("%1").arg(dhcpError);
        else
            message += QStringLiteral("请检查 DHCP 服务和 udhcpc 默认脚本。");
    } else {
        message = QStringLiteral("Wi-Fi 已连接，IP：%1。").arg(ipAddress);
    }

    emit statusChanged(true, ssid, ipAddress);
    emit connectFinished(true, ssid, ipAddress, message);
}

void WifiWorker::checkStatus()
{
    QString response;
    QString error;
    if (!runWpaCli(m_interfaceName, m_controlDirectory,
                   QStringList() << QStringLiteral("status"),
                   2500, &response, &error)) {
        emit statusChanged(false, QString(), QString());
        return;
    }
    const bool connected = statusValue(response, QStringLiteral("wpa_state")) == QStringLiteral("COMPLETED");
    const QString ssid = connected ? statusValue(response, QStringLiteral("ssid")) : QString();
    const QString ipAddress = connected ? interfaceIpv4Address(m_interfaceName) : QString();
    emit statusChanged(connected, ssid, ipAddress);
}
