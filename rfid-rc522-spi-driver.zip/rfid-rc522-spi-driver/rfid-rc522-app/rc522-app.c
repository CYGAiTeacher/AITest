#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include "rc522.h"

int fd;

//需要自己实现
void WriteRawRC(uint8_t Address,uint8_t Value)
{
    int ret;
    uint8_t reg[2] = {Address,Value};

    ret = write(fd,reg,sizeof(reg));
    if(ret < 0){
        perror("Fail to write");
         exit(EXIT_FAILURE);
    }

    return;
}

//需要自己实现
uint8_t ReadRawRC(uint8_t Address)
{
    int ret;
    uint8_t reg[2] = {Address,0};

    ret = read(fd,reg,sizeof(reg));
    if(ret < 0){
        perror("Fail to read");
        exit(EXIT_FAILURE);
    }

    return reg[1];
}

int PCDRequestCard(void)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t rxBuf[2]= {0};
    uint8_t txBuf[] = {PICC_REQIDL};

    ClearBitMask(Status2Reg,0x08);
    WriteRawRC(BitFramingReg, 0x07);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf, sizeof(txBuf),rxBuf,&rxBits);
    if(ret != MI_OK){
        //printf("Fail to PcdComMF522 for request card\n");
        return ret;
    }

    printf("Request Card Ack:");
    for(i = 0;i < rxBits/8;i ++){
        printf("%02x ",rxBuf[i]);
    }
    printf("\n");

    return MI_OK;
}

int PCDAnticollision(uint8_t *IDBuf,uint8_t size)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[5]= {0};
    uint8_t txBuf[] = {PICC_ANTICOLL1,0x20};

    if(size != 5){
        printf("Invalid size:%d\n",size);
        return MI_ERR;
    }

    WriteRawRC(BitFramingReg, 0x00);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf, sizeof(txBuf),rxBuf,&rxBits);
    if(ret != MI_OK){
        //printf("Fail to PcdComMF522 for request card\n");
        return ret;
    }

    printf("Anticollision Card Ack ID:");
    for(i = 0;i < rxBits/8;i ++){
        printf("%02x ",rxBuf[i]);
    }
    printf("\n");

    IDCheckValue = rxBuf[0] ^ rxBuf[1] ^ rxBuf[2] ^ rxBuf[3];
    if(IDCheckValue != rxBuf[4]){
        printf("Card ID error\n");
        return MI_ERR;
    }
    
    memcpy(IDBuf,rxBuf,size);

    return MI_OK;
}

int PCDSelect(uint8_t *IDBuf,uint8_t size)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[5]= {0};
    uint8_t txBuf[9] = {PICC_ANTICOLL1,0x70};

    if(size != 5){
        printf("Invalid size:%d\n",size);
        return MI_ERR;
    }

    WriteRawRC(BitFramingReg, 0x00);

    memcpy(&txBuf[2],IDBuf,size);
    CalulateCRC(txBuf,7,&txBuf[7]);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf, sizeof(txBuf),rxBuf,&rxBits);
    if(ret != MI_OK){
        //printf("Fail to PcdComMF522 for select card\n");
        return ret;
    }

    printf("Select Card Ack:");
    for(i = 0;i < rxBits/8;i ++){
        printf("%02x ",rxBuf[i]);
    }
    printf("\n");

    return MI_OK;
}

int PCDAuthentication(uint8_t *IDBuf,uint8_t IDSize,uint8_t sectorNumber,
                      uint8_t keyType,uint8_t *keyBuf,uint8_t keySize)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[16]  = {0};
    uint8_t txBuf[12]  = {0};

    if(IDSize != 4 || keySize != 6){
        printf("Invalid IDSize or keySize\n");
        return MI_ERR;
    }

    WriteRawRC(BitFramingReg, 0x00);
    ClearBitMask(Status2Reg,0x08);

    txBuf[0] = keyType;
    txBuf[1] = sectorNumber * 4 + 3;
    memcpy(&txBuf[2],keyBuf,keySize);
    memcpy(&txBuf[8],IDBuf,IDSize);
    
    ret = PcdComMF522 (PCD_AUTHENT,txBuf, sizeof(txBuf),rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for Authentication key\n");
        return ret;
    }

    if(ReadRawRC(Status2Reg) & 0x08){
        printf("Authentication sector:%d key success\n",sectorNumber);
    }else{
        return MI_ERR;
    }
    return MI_OK;
}

int PCDReadBlock(uint8_t sectorNumber,uint8_t blockNumber,uint8_t *dataBuf,uint8_t dataSize)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[16]  = {0};
    uint8_t txBuf[4]   = {0};

    if(dataSize != 16){
        printf("Invalid dataSize:%d\n",dataSize);
        return MI_ERR;
    }

    WriteRawRC(BitFramingReg, 0x00);

    txBuf[0] = PICC_READ;
    txBuf[1] = sectorNumber * 4 + blockNumber;
    CalulateCRC(txBuf,2,&txBuf[2]);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf, sizeof(txBuf),rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for read block\n");
        return ret;
    }

    printf("Read Sector:%d Block:%d\n",sectorNumber,blockNumber);
    for(i = 0;i < rxBits/8;i ++){
        printf("%02x ",rxBuf[i]);
    }
    printf("\n");

    return MI_OK;
}

int PCDWriteBlock(uint8_t sectorNumber,uint8_t blockNumber,uint8_t *dataBuf,uint8_t dataSize)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[18]  = {0};
    uint8_t txBuf[18]   = {0};

    if(dataSize != 16){
        printf("Invalid dataSize:%d\n",dataSize);
        return MI_ERR;
    }

    WriteRawRC(BitFramingReg, 0x00);

    txBuf[0] = PICC_WRITE;
    txBuf[1] = sectorNumber * 4 + blockNumber;
    CalulateCRC(txBuf,2,&txBuf[2]);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,4,rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for write block\n");
        return ret;
    }

    memcpy(txBuf,dataBuf,dataSize);
    CalulateCRC(txBuf,dataSize,&txBuf[dataSize]);
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,sizeof(txBuf),rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for write block data\n");
        return ret;
    }

    return MI_OK;
}

int PCDIncrement(uint8_t sectorNumber,uint8_t blockNumber,uint32_t money)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[18]    = {0};
    uint8_t txBuf[18]    = {0};

    WriteRawRC(BitFramingReg, 0x00);

    txBuf[0] = PICC_INCREMENT;
    txBuf[1] = sectorNumber * 4 + blockNumber;
    CalulateCRC(txBuf,2,&txBuf[2]);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,4,rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for Increment\n");
        return ret;
    }

    memcpy(txBuf,&money,sizeof(money));
    CalulateCRC(txBuf,4,&txBuf[4]);
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,6,rxBuf,&rxBits);
    if(ret == MI_ERR){
        printf("Fail to PcdComMF522 for write block money\n");
       return ret;
    }

    txBuf[0] = PICC_TRANSFER;
    txBuf[1] = sectorNumber * 4 + blockNumber;
    CalulateCRC(txBuf,2,&txBuf[2]);
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,4,rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for transfer\n");
        return ret;
    }

    return MI_OK;
}

int PCDDecrement(uint8_t sectorNumber,uint8_t blockNumber,uint32_t money)
{
    int i;
    int ret;
    uint8_t rxBits;
    uint8_t IDCheckValue;
    uint8_t rxBuf[18]    = {0};
    uint8_t txBuf[18]    = {0};

    WriteRawRC(BitFramingReg, 0x00);

    txBuf[0] = PICC_DECREMENT;
    txBuf[1] = sectorNumber * 4 + blockNumber;
    CalulateCRC(txBuf,2,&txBuf[2]);
    
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,4,rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for Increment\n");
        return ret;
    }

    memcpy(txBuf,&money,sizeof(money));
    CalulateCRC(txBuf,4,&txBuf[4]);
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,6,rxBuf,&rxBits);
    if(ret == MI_ERR){
        printf("Fail to PcdComMF522 for write block money\n");
       return ret;
    }

    txBuf[0] = PICC_TRANSFER;
    txBuf[1] = sectorNumber * 4 + blockNumber;
    CalulateCRC(txBuf,2,&txBuf[2]);
    ret = PcdComMF522 (PCD_TRANSCEIVE,txBuf,4,rxBuf,&rxBits);
    if(ret != MI_OK){
        printf("Fail to PcdComMF522 for transfer\n");
        return ret;
    }

    return MI_OK;
}

int main(int argc, const char *argv[])
{
    int ret;
    uint8_t cardID[5];
    uint8_t blockData[16] = {0};
    uint8_t blockWriteData[16] = {0x00,0x00,0x00,0x00,0xff,0xff,0xff,0xff,
                                  0x00,0x00,0x00,0x00,0x01,0xfe,0x01,0xfe};
    uint8_t keyABuf[] = {0xff,0xff,0xff,0xff,0xff,0xff}; 

	fd = open("/dev/rc522",O_RDWR);
	if(fd < 0){
		perror("Fail to open");
		return -1;
	}

    ret = PcdReset();
    if(ret != MI_OK){
        printf("Fail to PcdReset\n");
        return ret;
    }

    ret = M500PcdConfigISOType('A');
    if(ret != MI_OK){
        printf("Fail to M500PcdConfigISOType A\n");
        return ret;
    }

    while(1){
        ret = PCDRequestCard();
        if(ret != MI_OK){
            //printf("Fail to PCDRequestCard\n");
            continue;
        }

        ret = PCDAnticollision(cardID,sizeof(cardID));
        if(ret != MI_OK){
            continue;
        }

        ret = PCDSelect(cardID,sizeof(cardID));
        if(ret != MI_OK){
            continue;
        }

        ret = PCDAuthentication(cardID,4,0,KEYA,keyABuf,sizeof(keyABuf));
        if(ret != MI_OK){
            continue;
        }
#if 0
        ret = PCDReadBlock(0,0,blockData,sizeof(blockData));
        if(ret != MI_OK){
            continue;
        }

        ret = PCDWriteBlock(0,1,blockWriteData,sizeof(blockWriteData));
        if(ret != MI_OK){
            continue;
        }
#endif 
        ret = PCDReadBlock(0,1,blockData,sizeof(blockData));
        if(ret != MI_OK){
            continue;
        }

#if 0
        ret = PCDIncrement(0,1,1);
        if(ret != MI_OK){
            continue;
        }
#endif 
        ret = PCDDecrement(0,1,1);
        if(ret != MI_OK){
            continue;
        }

        ret = PCDReadBlock(0,1,blockData,sizeof(blockData));
        if(ret != MI_OK){
            continue;
        }

    }

    return 0;
}