#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/types.h>
#include "rc522.h"

void SetBitMask(uint8_t ucReg,uint8_t ucMask)  
{
    uint8_t ucTemp;

    ucTemp = ReadRawRC ( ucReg );
    WriteRawRC (ucReg, ucTemp | ucMask); // set bit mask
        
        return;
}
 
void ClearBitMask(uint8_t ucReg,uint8_t ucMask)  
{
    uint8_t ucTemp;
 
    ucTemp = ReadRawRC (ucReg);
    WriteRawRC (ucReg, ucTemp & ( ~ ucMask)); // clear bit mask
        
    return;
}
 
void PcdAntennaOn(void)
{
   uint8_t uc;
 
   uc = ReadRawRC (TxControlReg);
   if (! ( uc & 0x03 )){
           SetBitMask(TxControlReg, 0x03);         
   }
        
   return;
}


void PcdAntennaOff(void)
{
        ClearBitMask(TxControlReg, 0x03);
}


int PcdReset(void)
{        
       int res;
    
       //soft Reset 1111 Resets the MFRC522
       WriteRawRC ( CommandReg, 0x0f );
    
       //等待复位完成
       usleep(1000);
    
       //bit[4] A logic 0 indicates that the MFRC522 is ready for operations
       while ( ReadRawRC ( CommandReg ) & 0x10 );
  
        //定义发送和接收常用模式 和Mifare卡通讯，CRC初始值0x6363
        WriteRawRC ( ModeReg, 0x3D );

        WriteRawRC ( TReloadRegL, 30 );        //16位定时器低位   
        WriteRawRC ( TReloadRegH, 0 );         //16位定时器高位 

        //分频系数:高4bit 1111
        WriteRawRC ( TModeReg, 0x8D );        //定义内部定时器的设置 
        //分频系数:低8bit 0011 1110
        WriteRawRC ( TPrescalerReg, 0x3E );   //设置定时器分频系数 
        //最终的分频系数:1111 0011 1110 = 0xf3e = 3902
        //ftimer = 6.78MHz / 3902 = 1.7KHZ = 1700HZ
        
        WriteRawRC ( TxAutoReg, 0x40 ); //调制发送信号为100%ASK 
 
        res = ReadRawRC(VersionReg);
        printf("Current PCD Version:%#x\n",res);
        
        res = ReadRawRC(ModeReg);
        if(res!=0x3d){
            printf("Config ModeReg:%#x error\n",ModeReg);
            return MI_ERR;
        }
    
        res = ReadRawRC(TReloadRegL);
        if(res!=30){
            printf("Config TReloadRegL:%#x error\n",TReloadRegL);
            return MI_ERR;
        }               
       
        res = ReadRawRC(TReloadRegH);
        if(res!=0){
            printf("Config TReloadRegH:%#x error\n",TReloadRegH); 
            return MI_ERR;
        }       

        res = ReadRawRC(TModeReg);
        if(res!=0x8D){
            printf("Config TModeReg:%#x error\n",TModeReg); 
            return MI_ERR;
        }

        res = ReadRawRC(TPrescalerReg);
        if(res!=0x3e){
            printf("Config TPrescalerReg:%#x error\n",TPrescalerReg);
            return MI_ERR;
        }

        res = ReadRawRC(TxAutoReg);
        if(res!=0x40){
             printf("Config TxControlReg:%#x error\n",TxAutoReg);
             return MI_ERR;
        }
   
        return MI_OK;
}
 

char M500PcdConfigISOType ( unsigned char ucType )
{
       //ISO14443_A
       if ( ucType == 'A'){
               //清除通信加密
               ClearBitMask ( Status2Reg, 0x08 );         
               WriteRawRC ( ModeReg, 0x3D );                 //3F         
               WriteRawRC ( RxSelReg, 0x86 );                 //84         
               WriteRawRC( RFCfgReg, 0x7F );                 //4F         
               WriteRawRC( TReloadRegL, 30 );                         
               WriteRawRC ( TReloadRegH, 0 );         
               WriteRawRC ( TModeReg, 0x8D );         
               WriteRawRC ( TPrescalerReg, 0x3E );         
               usleep(10000);         
               PcdAntennaOn ();//开天线         
       }else{
               return MI_ERR;
        }

        return MI_OK;        
}

int PcdComMF522 ( uint8_t ucCommand, uint8_t * pInData, uint8_t ucInLenByte,
                  uint8_t * pOutData,uint8_t * pOutLenBit )         
{
        int8_t  cStatus = MI_ERR;
        uint8_t ucIrqEn   = 0x00;
        uint8_t ucWaitFor = 0x00;
        uint8_t ucLastBits;
        uint8_t ucN;
        uint32_t ul;

        switch ( ucCommand )
        {
        case PCD_AUTHENT:          //Mifare认证
                ucIrqEn   = 0x12;  //允许错误中断请求ErrIEn  允许空闲中断IdleIEn
                ucWaitFor = 0x10;  //认证寻卡等待时候 查询空闲中断标志位
                break;

        case PCD_TRANSCEIVE:         //接收发送 发送接收
                ucIrqEn   = 0x77;    //允许TxIEn RxIEn IdleIEn LoAlertIEn ErrIEn TimerIEn
                ucWaitFor = 0x30;    //寻卡等待时候 查询接收中断标志位与 空闲中断标志位
                break;

        default:
                break;           
        }
        //IRqInv置位管脚IRQ与Status1Reg的IRq位的值相反 
        WriteRawRC ( ComIEnReg, ucIrqEn | 0x80 );
        //Set1该位清零时，CommIRqReg的屏蔽位清零
        ClearBitMask ( ComIrqReg, 0x80 );  
        //写空闲命令
        WriteRawRC ( CommandReg, PCD_IDLE );         

        //置位FlushBuffer清除内部FIFO的读和写指针以及ErrReg的BufferOvfl标志位被清除
        SetBitMask ( FIFOLevelReg, 0x80 );           

        for ( ul = 0; ul < ucInLenByte; ul ++ ){
                WriteRawRC ( FIFODataReg, pInData [ ul ] ); //写数据进FIFOdata
        }

        WriteRawRC ( CommandReg, ucCommand );                 //写命令

        if ( ucCommand == PCD_TRANSCEIVE ){  
                //StartSend置位启动数据发送 该位与收发命令使用时才有效
                SetBitMask(BitFramingReg,0x80);                         
        }

        ul = 1000; //根据时钟频率调整，操作M1卡最大等待时间25ms

        do   //认证 与寻卡等待时间 
        {
                ucN = ReadRawRC ( ComIrqReg );          //查询事件中断
                ul --;
        } while ( ( ul != 0 ) && ( ! ( ucN & 0x01 ) ) && ( ! ( ucN & ucWaitFor ) ) ); 

        ClearBitMask ( BitFramingReg, 0x80 );  //清理允许StartSend位


        if ( ul != 0 ){
                //读错误标志寄存器BufferOfI CollErr ParityErr ProtocolErr
                if ( ! ( ReadRawRC ( ErrorReg ) & 0x1B ) ){
                        cStatus = MI_OK;

                        if ( ucN & ucIrqEn & 0x01) //是否发生定时器中断 -----01
                                cStatus = MI_NOTAGERR; 


                        if ( ucCommand == PCD_TRANSCEIVE ){
                                //读FIFO中保存的字节数
                                ucN = ReadRawRC ( FIFOLevelReg );                           

                                //最后接收到得字节的有效位数
                                ucLastBits = ReadRawRC ( ControlReg ) & 0x07; 

                                if ( ucLastBits )

                              //N个字节数减去1（最后一个字节）+最后一位的位数 读取到的数据总位数
                                        * pOutLenBit = ( ucN - 1 ) * 8 + ucLastBits;    
                                else
                                        * pOutLenBit = ucN * 8;  //最后接收到的字节整个字节有效

                                if ( ucN == 0 )   
                                        ucN = 1;    

                                if ( ucN > MAXRLEN )
                                        ucN = MAXRLEN;        

                                for ( ul = 0; ul < ucN; ul ++ )
                                        pOutData [ ul ] = ReadRawRC ( FIFODataReg );
                        }                  
                }else{

                        cStatus = MI_ERR;           
                }
        }

        SetBitMask ( ControlReg, 0x80 ); // stop timer now
        WriteRawRC ( CommandReg, PCD_IDLE ); 

        return cStatus;
}



void CalulateCRC(uint8_t * pIndata,uint8_t ucLen,uint8_t *pOutData )
{
   uint8_t uc, ucN;
 
   ClearBitMask(DivIrqReg,0x04);
   WriteRawRC(CommandReg,PCD_IDLE);
   SetBitMask(FIFOLevelReg,0x80);
 
   for ( uc = 0; uc < ucLen; uc ++){
         WriteRawRC ( FIFODataReg, * ( pIndata + uc ) );  
   }
 
   WriteRawRC ( CommandReg, PCD_CALCCRC );
   uc = 0xFF;
   do 
   {
           ucN = ReadRawRC ( DivIrqReg );
           uc --;
   } while ( ( uc != 0 ) && ! ( ucN & 0x04 ) );
   
   pOutData [ 0 ] = ReadRawRC ( CRCResultRegL );
   pOutData [ 1 ] = ReadRawRC ( CRCResultRegM );   

   return;
}