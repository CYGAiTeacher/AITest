#include "gpio.h"
#include "smartcar.h"
#include <stdio.h>
#include <stdbool.h>

#define MOTOR_PWM_SPEED 420
#define MOTOR_PWM_MAX_SPEED 600
#define MOTOR_PWM_MIN_SPEED 300

#define PID_KP 40
#define PID_KI 0.01
#define PID_KD 25


typedef struct{
	int8_t error;
	int8_t last_error;
	int8_t kp;
	float   ki;
	int8_t kd;
}pid_t;

bool pid_control = true;
pid_t pid;

int32_t left_motor_pwm_speed  = MOTOR_PWM_SPEED;
int32_t right_motor_pwm_speed = MOTOR_PWM_SPEED;

uint8_t read_irs_state(void)
{
	int i;
	uint8_t status = 0;
	uint8_t state[5];
	
	state[0] = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0);
	state[1] = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_1);
	state[2] = HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2);
	state[3] = HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13);
	state[4] = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_4);
	
	for(i = 0;i < 5;i ++){
		status |= (state[i] << i);
	}
	
	return status;
}

uint8_t get_middle_filter_irs_state(void)
{
	 int i = 0;
	 uint8_t state[9];
	
	 for(i = 0;i < 5;i ++){
		 state[i] = read_irs_state();
	 }
	 
#if 0
	 printf("irs:");
	 for(i = 4;i >= 0;i --){
			if(state[4] & (1 << i)){
				printf("1");
			}else{
				printf("0");
			}
	 }
	 printf("\r\n");
#endif 	 
	 return state[3];
}

#if 0
int8_t calc_error_by_irs(uint8_t state)
{
	int8_t cur_error = pid.error;
	
	switch(state){
	case 0B11110: cur_error = -8;break; 
	case 0B10000:
	case 0B11000: cur_error = -7;break;
	case 0B11100: cur_error = -6;break;
	case 0B11101: cur_error = -4;break;
	case 0B11001: cur_error = -2;break;
	case 0B00000:
	case 0B11011: cur_error = 0;break;
	case 0B10011: cur_error = 2;break;
	case 0B10111: cur_error = 4;break;
	case 0B00111: cur_error = 6;break;
	case 0B00011:
	case 0B00001: cur_error = 7;break;
	case 0B01111: cur_error = 8;break;
	case 0B11111: cur_error = pid.error > 0 ? 9 : - 9;
	}
	
	return cur_error;
}
#else

int8_t calc_error_by_irs(uint8_t state)
{
	int8_t cur_error = pid.error;
	
	switch(state){
	case 0B11110: cur_error = 6;break; 
	case 0B10000:
	case 0B11000: cur_error = 4;break;
	case 0B11100: cur_error = 3;break;
	case 0B11101: cur_error = 2;break;
	case 0B11001: cur_error = 1;break;
	case 0B00000:
	case 0B11011: cur_error = 0;break;
	case 0B10011: cur_error = -1;break;
	case 0B10111: cur_error = -2;break;
	case 0B00111: cur_error = -3;break;
	case 0B00011:
	case 0B00001: cur_error = -4;break;
	case 0B01111: cur_error = -6;break;
	case 0B11111: cur_error = pid.error > 0 ? 9 : -9;
	}
	
	return cur_error;
}
#endif

int8_t get_current_irs_error(void)
{
#if 0
	int i;
	int sum = 0;
	
	for(i = 0;i < 10;i ++){
		uint8_t state = get_middle_filter_irs_state();
		int8_t error = calc_error_by_irs(state);
		sum += error;
	}
	return sum/10;
#else
		uint8_t state = get_middle_filter_irs_state();
		int8_t error = calc_error_by_irs(state);
		return error;
#endif 
	
}

int32_t pid_calc_output(void)
{
	int32_t P;
	static float I = 0;
	int32_t D;
	int32_t pid_output;
	
	pid.error = get_current_irs_error();
	P  = pid.kp * pid.error;
	I += pid.ki * pid.error;
	D  = pid.kd * (pid.error - pid.last_error);
	
	pid.last_error = pid.error;
	
	pid_output = P + I + D;
	
	return pid_output;
}


void update_motor_speed_by_pid(int32_t pid_output)
{
	if(!pid.error){
		left_motor_pwm_speed  = MOTOR_PWM_SPEED;
		right_motor_pwm_speed = MOTOR_PWM_SPEED;
		return;
	}
	
	
#if 1
	left_motor_pwm_speed  = MOTOR_PWM_SPEED + pid_output;
	if(left_motor_pwm_speed <= MOTOR_PWM_MIN_SPEED){
		left_motor_pwm_speed = MOTOR_PWM_MIN_SPEED;
	}else if(left_motor_pwm_speed >= MOTOR_PWM_MAX_SPEED){
		left_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
	}
	
	right_motor_pwm_speed = MOTOR_PWM_SPEED - pid_output;
	if(right_motor_pwm_speed <= MOTOR_PWM_MIN_SPEED){
		 right_motor_pwm_speed = MOTOR_PWM_MIN_SPEED;
	}else if(right_motor_pwm_speed >= MOTOR_PWM_MAX_SPEED){
		right_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
	}
#else
    left_motor_pwm_speed  = MOTOR_PWM_SPEED + pid_output;
    right_motor_pwm_speed = MOTOR_PWM_SPEED - pid_output;

    // ���Ʒ�Χ��ȷ�����ʼ������Ч��������
    if(left_motor_pwm_speed > MOTOR_PWM_MAX_SPEED) left_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
    if(left_motor_pwm_speed < 0) left_motor_pwm_speed = 0; // ��������0����������̫��

    if(right_motor_pwm_speed > MOTOR_PWM_MAX_SPEED) right_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
    if(right_motor_pwm_speed < 0) right_motor_pwm_speed = 0;	
#endif 

	return;
}

void pid_init(void)
{
	pid.error = 0;
	pid.last_error = 0;
	pid.kp = PID_KP;
	pid.ki = PID_KI;
	pid.kd = PID_KD;
	
	return;
}

void pid_control_motor(void)
{
#if 1
	if(pid.error > 1 && pid.error <= 9){
		 car_turn_right(MOTOR_PWM_SPEED);
		 return;
		
	}else if(pid.error >= -9 && pid.error < -1){
		 car_turn_left(MOTOR_PWM_SPEED);
		 return;
	}
	
#else
	if(pid.error >= 6 && pid.error <= 9){
			right_motor_pwm_speed = 0;
			left_motor_pwm_speed = MOTOR_PWM_MAX_SPEED; 
	}else if(pid.error >= -9 && pid.error <= -6){
		  right_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
			left_motor_pwm_speed = 0; 
		 return;
	}
#endif 
	//printf("lef_motor_speed:%d\r\n",left_motor_pwm_speed);
	//printf("right_motor_speed:%d\r\n",right_motor_pwm_speed);

	left_motor_forward(left_motor_pwm_speed);
	right_motor_forward(right_motor_pwm_speed);
	if(!pid.error){
		 HAL_Delay(10);
	}
}

void pid_control_car(void)
{
	int32_t pid_output;
	
	pid_init();
	
	while(pid_control){
		pid_output = pid_calc_output();
		update_motor_speed_by_pid(pid_output);
	  pid_control_motor();
		HAL_Delay(5);
	}
	
	return;
}


void pid_test(void)
{
	pid_control_car();
	
	return;
}
