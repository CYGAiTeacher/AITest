#include "gpio.h"
#include "smartcar.h"
#include <stdio.h>
#include <stdbool.h>

#define MOTOR_PWM_SPEED 200
#define MOTOR_PWM_MAX_SPEED 800
#define MOTOR_PWM_MIN_SPEED 300

#define PID_KP 5
#define PID_KI 0.1
#define PID_KD 7

typedef struct{
	int8_t error;
	int8_t last_error;
	uint8_t kp;
	float   ki;
	uint8_t kd;
}pid_t;

bool pid_control = true;
pid_t pid;

int32_t left_motor_pwm_speed  = MOTOR_PWM_SPEED;
int32_t right_motor_pwm_speed = MOTOR_PWM_SPEED;

uint8_t read_irs_state(void)
{
	int i;
	uint8_t status = 0;
	uint8_t state[5];
	
	state[0] = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0);
	state[1] = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_1);
	state[2] = HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2);
	state[3] = HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13);
	state[4] = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_4);
	
	for(i = 0;i < 5;i ++){
		status |= (state[i] << i);
	}
	
	return status;
}

uint8_t get_middle_filter_irs_state(void)
{
	 int i = 0;
	 uint8_t state[9];
	
	 for(i = 0;i < 9;i ++){
		 state[i] = read_irs_state();
	 }
	 
	 printf("irs:");
	 for(i = 4;i >= 0;i --){
			if(state[4] & (1 << i)){
				printf("1");
			}else{
				printf("0");
			}
	 }
	 printf("\r\n");
	 
	 return state[4];
}

#if 0
int8_t calc_error_by_irs(uint8_t state)
{
	int8_t cur_error = pid.error;
	
	switch(state){
	case 0B11110: cur_error = -8;break; 
	case 0B10000:
	case 0B11000: cur_error = -7;break;
	case 0B11100: cur_error = -6;break;
	case 0B11101: cur_error = -4;break;
	case 0B11001: cur_error = -2;break;
	case 0B00000:
	case 0B11011: cur_error = 0;break;
	case 0B10011: cur_error = 2;break;
	case 0B10111: cur_error = 4;break;
	case 0B00111: cur_error = 6;break;
	case 0B00011:
	case 0B00001: cur_error = 7;break;
	case 0B01111: cur_error = 8;break;
	case 0B11111: cur_error = pid.error > 0 ? 9 : - 9;
	}
	
	return cur_error;
}
#else

int8_t calc_error_by_irs(uint8_t state)
{
	int8_t cur_error = pid.error;
	
	switch(state){
	case 0B11110: cur_error = 6;break; 
	case 0B10000:
	case 0B11000: cur_error = 4;break;
	case 0B11100: cur_error = 3;break;
	case 0B11101: cur_error = 2;break;
	case 0B11001: cur_error = 1;break;
	case 0B00000:
	case 0B11011: cur_error = 0;break;
	case 0B10011: cur_error = -1;break;
	case 0B10111: cur_error = -2;break;
	case 0B00111: cur_error = -3;break;
	case 0B00011:
	case 0B00001: cur_error = -4;break;
	case 0B01111: cur_error = -6;break;
	case 0B11111: cur_error = pid.error > 0 ? 9 : -9;
	}
	
	return cur_error;
}
#endif

int8_t get_current_irs_error(void)
{
	int i;
	int sum = 0;
	
	for(i = 0;i < 10;i ++){
		uint8_t state = get_middle_filter_irs_state();
		int8_t error = calc_error_by_irs(state);
		sum += error;
	}
	
	return sum/10;
}

int32_t pid_calc_output(void)
{
	int32_t P;
	static float I = 0;
	int32_t D;
	int32_t pid_output;
	
	pid.error = get_current_irs_error();
	P  = pid.kp * pid.error;
	I += pid.ki * pid.error;
	D  = pid.kd * (pid.error - pid.last_error);
	
	pid.last_error = pid.error;
	
	pid_output = P + I + D;
	
	return pid_output;
}


void update_motor_speed_by_pid(int32_t pid_output)
{
	if(!pid.error){
		left_motor_pwm_speed  = MOTOR_PWM_SPEED;
		right_motor_pwm_speed = MOTOR_PWM_SPEED;
		return;
	}
	
	left_motor_pwm_speed  = left_motor_pwm_speed + pid_output;
	if(left_motor_pwm_speed <= MOTOR_PWM_MIN_SPEED){
		left_motor_pwm_speed = MOTOR_PWM_MIN_SPEED;
	}else if(left_motor_pwm_speed >= MOTOR_PWM_MAX_SPEED){
		left_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
	}
	
	right_motor_pwm_speed = right_motor_pwm_speed - pid_output;
	if(right_motor_pwm_speed <= MOTOR_PWM_MIN_SPEED){
		 right_motor_pwm_speed = MOTOR_PWM_MIN_SPEED;
	}else if(right_motor_pwm_speed >= MOTOR_PWM_MAX_SPEED){
		right_motor_pwm_speed = MOTOR_PWM_MAX_SPEED;
	}
	
	return;
}

void pid_init(void)
{
	pid.error = 0;
	pid.last_error = 0;
	pid.kp = PID_KP;
	pid.ki = PID_KI;
	pid.kd = PID_KD;
	
	return;
}

void pid_control_motor(void)
{
#if 1
	if(pid.error >= 6 && pid.error <= 9){
		 car_turn_right(MOTOR_PWM_MAX_SPEED);
		 return;
	}else if(pid.error >= -9 && pid.error <= -6){
		 car_turn_left(MOTOR_PWM_MAX_SPEED);
		 return;
	}
#endif 
	
	left_motor_forward(left_motor_pwm_speed);
	right_motor_forward(right_motor_pwm_speed);
}

void pid_control_car(void)
{
	int32_t pid_output;
	
	pid_init();
	
	while(pid_control){
		pid_output = pid_calc_output();
		update_motor_speed_by_pid(pid_output);
	  pid_control_motor();
		HAL_Delay(10);
	}
	
	return;
}


void pid_test(void)
{
	pid_control_car();
	
	return;
}
