#ifndef _SMARTCAR_HEAD_H
#define _SMARTCAR_HEAD_H

#include <stdint.h>
#include <stdio.h>
extern void led_on_off(void);
extern void key_scan(void);
extern void uart_test(void);
extern void motor_test(void);
extern uint16_t read_ps2_data(void);
extern void ps2_test(void);
extern void car_stop(void);
extern void car_forward(uint32_t speed);
extern void car_reverse(uint32_t speed);
extern void car_turn_left(uint32_t speed);
extern void car_turn_right(uint32_t speed);
extern void uart_interrupt_init(void);
extern void esp8266_test(void);
extern void uart_interrupt_init(void);
extern void esp8266_car_control(uint8_t *buffer,uint32_t size);
extern void bluetooth_car_control(uint8_t *buffer,uint32_t size);
extern void bluetooth_test(void);
extern void tm1637_test(void);
extern void sht31_test(void);
extern void relay_test(void);
extern void pid_test(void);
extern void left_motor_forward(uint32_t speed);
extern void right_motor_forward(uint32_t speed);
extern void key_scan_test(void);
extern void key_scan(void);
extern void tm1637_rtc(void);
extern void ps2_control_car(void);
extern uint8_t get_middle_filter_irs_state(void);
extern void left_motor_stop(void);


#endif