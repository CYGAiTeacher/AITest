#include "gpio.h"
#include "rtc.h"

#define TM1637_CLK_H   HAL_GPIO_WritePin(GPIOB,GPIO_PIN_6, GPIO_PIN_SET)
#define TM1637_CLK_L   HAL_GPIO_WritePin(GPIOB,GPIO_PIN_6, GPIO_PIN_RESET)

#define TM1637_DAT_H   HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5, GPIO_PIN_SET)
#define TM1637_DAT_L   HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5, GPIO_PIN_RESET)

#define TM1637_DELAY_TIME 1

void tm1637_start(void)
{
	TM1637_CLK_H;
	TM1637_DAT_H;
	HAL_Delay(TM1637_DELAY_TIME);
	
	TM1637_DAT_L;
	HAL_Delay(TM1637_DELAY_TIME);
	
	return;
}

void tm1637_stop(void)
{
	TM1637_CLK_L;
	TM1637_DAT_L;
	HAL_Delay(TM1637_DELAY_TIME);
		
	TM1637_CLK_H;
	HAL_Delay(TM1637_DELAY_TIME);
	
  TM1637_DAT_H;
	HAL_Delay(TM1637_DELAY_TIME);
	
	return;
}

void tm1637_ack(void)
{
	TM1637_CLK_L;
	HAL_Delay(TM1637_DELAY_TIME);
	
	TM1637_CLK_H;
	HAL_Delay(TM1637_DELAY_TIME);
	
	//we do't care ack signal
	
	return;
}

void tm1637_write_byte(uint8_t data)
{
	 int i;
		
	 for(i = 0;i < 8;i ++){
		 	TM1637_CLK_L;
		  HAL_Delay(TM1637_DELAY_TIME);
		  if(data & 1){
				TM1637_DAT_H;
			}else{
				TM1637_DAT_L;
			}
			
			TM1637_CLK_H;
		  HAL_Delay(TM1637_DELAY_TIME);
			
			data = data >> 1;
	 }
	
	 return;
}

void tm1637_write_cmd(uint8_t cmd)
{
	tm1637_start();
	tm1637_write_byte(cmd);
	tm1637_ack();
	tm1637_stop();
	
	return;
}

void tm1637_write_data(uint8_t addr,uint8_t data)
{
	tm1637_start();
	tm1637_write_byte(addr);
	tm1637_ack();
	tm1637_write_byte(data);
	tm1637_ack();
	tm1637_stop();
	
	return;
}

//12:34
void tm1637_display_time(uint8_t hour,uint8_t minute)
{
	const uint8_t segmentMap[] = {
       0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, // 0-7
       0x7f, 0x6f, 0x77, 0x7c, 0x39, 0x5e, 0x79, 0x71, // 8-9, A-F
       0x00
  };
	
	tm1637_write_cmd(0x44);
	tm1637_write_data(0xc0,segmentMap[hour/10]);
	tm1637_write_data(0xc1,segmentMap[hour%10] + 0x80);
	
	tm1637_write_data(0xc2,segmentMap[minute/10]);
	tm1637_write_data(0xc3,segmentMap[minute%10]);
	
	tm1637_write_cmd(0x8a);
	
	return;
}

void tm1637_test(void)
{
	int i;
	RTC_TimeTypeDef time;
	
	while(1){
	  for(i = 0;i < 60;i ++){
			HAL_RTC_GetTime(&hrtc,&time,RTC_FORMAT_BIN);
			tm1637_display_time(time.Minutes,time.Seconds);
		}
	}
	
	return;
}

void tm1637_rtc(void)
{
		RTC_TimeTypeDef time;
		HAL_RTC_GetTime(&hrtc,&time,RTC_FORMAT_BIN);
		tm1637_display_time(time.Minutes,time.Seconds);
		return;
}
