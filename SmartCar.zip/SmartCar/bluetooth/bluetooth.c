#include "usart.h"
#include "tim.h"
#include "smartcar.h"
#include <stdio.h>
#include <string.h>

void bluetooth_car_control(uint8_t *buffer,uint32_t size)
{
	int ret;
	
	switch(buffer[0]){
		case 'w':
			car_forward(800);
			printf("forward\r\n");
		  break;
		
	 case 's':
		  car_reverse(800);
			printf("reverse\r\n");
		  break;
	case 'a':
		  car_turn_left(800);
			printf("turn left\r\n");
		  break;
	
	case 'd':
		  car_turn_right(800);
			printf("turn right\r\n");
		  break;
	}
	
	__HAL_TIM_SET_COUNTER(&htim4,0);
	__HAL_TIM_CLEAR_FLAG(&htim4,TIM_FLAG_UPDATE);
	HAL_TIM_Base_Start_IT(&htim4);
	
	return;
}

void bluetooth_test(void)
{
	uart_interrupt_init();
	return;
}