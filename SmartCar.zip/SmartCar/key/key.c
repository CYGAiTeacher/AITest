#include "gpio.h"

void key_scan_test(void)
{
		while(1){
			GPIO_PinState pinState = HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_7);
			
			if(pinState == GPIO_PIN_SET){
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
			}else{
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
			}
		}
		
		return;
}

void key_scan(void)
{
			GPIO_PinState pinState = HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_7);
			
			if(pinState == GPIO_PIN_SET){
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
			}else{
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
			}
		
		return;
}