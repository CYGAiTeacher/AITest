#include "i2c.h"
#include <stdio.h>

#define SHT31_RESET_CMD 0x30a2
#define SHT31_MEASUREMENT_CMD 0x2130
#define SHT31_FETCH_DATA_CMD  0xe000

#define SHT31_SLAVE_ADDR 0x44
#define SHT31_SLAVE_READ_ADDR	  ((SHT31_SLAVE_ADDR << 1)|1)
#define SHT31_SLAVE_WRITE_ADDR	((SHT31_SLAVE_ADDR << 1)|0)

void sht31_send_cmd(uint16_t cmd)
{
	uint8_t tx[2];
	HAL_StatusTypeDef ret;
	
	tx[0] = cmd >> 8;
	tx[1] = cmd & 0xff;
	
	ret = HAL_I2C_Master_Transmit(&hi2c1,SHT31_SLAVE_WRITE_ADDR,tx,2,HAL_MAX_DELAY);
	if(ret != HAL_OK){
		printf("Fail to HAL_I2C_Master_Transmit,ret:%d\r\n",ret);
		return;
	}
	
	return;
}

void sht31_init(void)
{
	//reset sht31
	sht31_send_cmd(SHT31_RESET_CMD);
	HAL_Delay(1000);
	
	sht31_send_cmd(SHT31_MEASUREMENT_CMD);
	
	return;
}


void sht31_sample_temp_humi(float *ptemp,float *phumi)
{
	int i;
	uint16_t data;
	uint8_t rx[6];
	HAL_StatusTypeDef  ret;
	
	sht31_send_cmd(SHT31_FETCH_DATA_CMD);
	
	ret = HAL_I2C_Master_Receive(&hi2c1,SHT31_SLAVE_READ_ADDR,rx,6,HAL_MAX_DELAY);
	if(ret != HAL_OK){
		printf("Fail to HAL_I2C_Master_Receive,ret:%d\r\n",ret);
		return;
	}
	
	printf("Sample Data:");
	for(i = 0;i < 6;i ++){
		printf("%#x ",rx[i]);
	}
	printf("\r\n");
	
	data   = (rx[0] << 8) | rx[1];
	*ptemp = -45 + (float)(175 * data) / 65535;
	
	data   = (rx[3] << 8) | rx[4];
	*phumi = (float)(100 * data) / 65535; 
	
	return;
}


void sht31_test(void)
{
	float temp;
	float humi;
	
	sht31_init();
	
	
	while(1){
		sht31_sample_temp_humi(&temp,&humi);
		printf("Temp:%.2f ,Humi:%.2f\r\n",temp,humi);
		HAL_Delay(1000);
	}
	
	return;
}
