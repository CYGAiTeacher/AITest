#include "usart.h"
#include "smartcar.h"
#include <stdio.h>
#include <string.h>

uint8_t uart1_rx_buffer[1024];
uint8_t uart2_rx_buffer[1024];
void led_on_off(void);

int fputc(int ch,FILE *fp)
{
	int ret;
	
	ret = HAL_UART_Transmit(&huart1,(uint8_t *)&ch,1,HAL_MAX_DELAY);
	if(ret != HAL_OK){
		 return EOF;
	}
	
	return EOF;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	int i;
	
	if(huart == &huart1){
			printf("uart1 recv interrupt\r\n");
		  for(i = 0;i < sizeof(uart1_rx_buffer);i ++){
				printf("%c:%d\r\n",uart1_rx_buffer[i],uart1_rx_buffer[i]);
			}
			
			HAL_UART_Receive_IT(&huart1,uart1_rx_buffer,sizeof(uart1_rx_buffer));
	 }
	
	 return;
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
  int i;
	void esp8266_control_car(uint8_t *buffer,uint32_t size);
	
	if(huart == &huart1){
			printf("uart1 recv interrupt\r\n");
		  for(i = 0;i < Size;i ++){
				printf("%c:%d\r\n",uart1_rx_buffer[i],uart1_rx_buffer[i]);
			}
			
			//recv data to uart2
			HAL_UART_Transmit(&huart2,uart1_rx_buffer,Size,HAL_MAX_DELAY);
			HAL_UARTEx_ReceiveToIdle_IT(&huart1,uart1_rx_buffer,sizeof(uart1_rx_buffer));
	 }else if(huart == &huart2){
		  //bluetooth_car_control(uart2_rx_buffer,Size);
		  esp8266_car_control(uart2_rx_buffer,Size);
			HAL_UART_Transmit(&huart1,uart2_rx_buffer,Size,HAL_MAX_DELAY);
		  HAL_UARTEx_ReceiveToIdle_IT(&huart2,uart2_rx_buffer,sizeof(uart2_rx_buffer));
	 }
	
	 return;
}

void uart_interrupt_init(void)
{
	//HAL_UART_Receive_IT(&huart1,uart1_rx_buffer,sizeof(uart1_rx_buffer));
	HAL_UARTEx_ReceiveToIdle_IT(&huart1,uart1_rx_buffer,sizeof(uart1_rx_buffer));
	HAL_UARTEx_ReceiveToIdle_IT(&huart2,uart2_rx_buffer,sizeof(uart2_rx_buffer));
}



void uart_test(void)
{
	float fdata = 1.23;
	int data = 100;
	HAL_StatusTypeDef ret;
	const char *str = "hello world\r\n";
	uint8_t rx_buffer[10];
	
	printf("str = %s\r\n",str);
	printf("data = %d\r\n",data);
	printf("fdata = %f\r\n",fdata);
	
	uart_interrupt_init();
	
	while(1){
		printf("hello world\r\n");
		//HAL_Delay(1000);
		led_on_off();
	}
	
	return;
}