#include "spi.h"
#include <stdio.h>
#include "smartcar.h"

#define PS2_EMPTY_KEYCODE1 0xffff
#define PS2_EMPTY_KEYCODE2 0x0000
#define PS2_EMPTY_KEY      -1

typedef enum{
          PS2_SELECT = 0,
          PS2_L_3,
          PS2_R_3,
          PS2_START,
          PS2_L_UP,
          PS2_L_RIGHT,
          PS2_L_DOWN,
          PS2_L_LEFT,
          PS2_L_2,
          PS2_R_2,
          PS2_L_1,
          PS2_R_1,
          PS2_R_UP,
          PS2_R_RIGHT,
          PS2_R_DOWN,
          PS2_R_LEFT
}ps2_key_t;

uint16_t read_ps2_data(void)
{
	int i;
	HAL_StatusTypeDef ret;
	uint16_t key_code;
	uint8_t rx[9] = {0};
	uint8_t tx[9] = {0x01,0x42};
	
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
	for(i = 0;i < 9;i ++){
		 ret = HAL_SPI_TransmitReceive(&hspi2,&tx[i],&rx[i],1,1000);
		 if(ret != HAL_OK){
				printf("Fail to HAL_SPI_TransmitReceive,err:%d\r\n",ret);
				break;
		 }
	}
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
	
#if 0
	for(i = 0;i < 9;i ++){
		 printf("%#x ",rx[i]);
	}
	printf("\r\n");
#endif
	
	key_code = (rx[4] << 8) | rx[3];
	
	return key_code;
}

int8_t read_ps2_press_key(void)
{
	int i;
	int press_flag;
	int8_t key_number = PS2_EMPTY_KEY;
	uint16_t key_code = read_ps2_data();
	
	if(key_code == PS2_EMPTY_KEYCODE1 || key_code == PS2_EMPTY_KEYCODE2){
		return PS2_EMPTY_KEY;
	}
	
	for(i = 0;i < 16;i ++){
		  //xxxx xx?x
		  //0000 0010
			press_flag = !(key_code & (1 << i));
		  if(press_flag){
				key_number = i;
				printf("press key number:%d\r\n",key_number);
			}
	}
	
	return key_number;
}

void ps2_control_car(void)
{
	int8_t key_number = read_ps2_press_key();
	
	if(key_number == PS2_EMPTY_KEY){
		car_stop();
		return;
	}
	
	switch(key_number){
		case PS2_L_UP:
		case PS2_R_UP:
			car_forward(600);
			break;
		
		case PS2_L_DOWN:
		case PS2_R_DOWN:
			car_reverse(600);
			break;
		
		case PS2_L_LEFT:
		case PS2_R_LEFT:
			car_turn_left(600);
			break;
		case PS2_L_RIGHT:
		case PS2_R_RIGHT:
			car_turn_right(600);
			break;
	}
}

void ps2_test(void)
{
	uint16_t key_code;
	void tm1637_display_time(uint8_t hour,uint8_t minute);
	tm1637_display_time(12,24);
	
	while(1){
		ps2_control_car();
		HAL_Delay(10);
	}
	
	return;
}