#include "usart.h"
#include "tim.h"
#include "smartcar.h"
#include <stdio.h>
#include <string.h>

void esp8266_send_cmd(const char *cmd)
{
  int ret;

	printf("Send AT CMD:%s\r\n",cmd);
	
	ret = HAL_UART_Transmit(&huart2,(uint8_t *)cmd,strlen(cmd),1000);
	if(ret != HAL_OK){
		printf("Fail to send AT cmd:%s\r\n",cmd);
		return;
	}
	
	return;
}

int esp8266_recv_ack(void)
{
	int count = 0;
	uint8_t rx_buffer[300];
	uint8_t ack_buffer[1024] = {0};
	
	
	while(count < 3){
		memset(rx_buffer,0,sizeof(rx_buffer));
		HAL_UART_Receive(&huart2,rx_buffer,sizeof(rx_buffer),1000);
		if(strstr((const char *)rx_buffer,"OK")){
			  printf("Recv AT ACK:%s\r\n",rx_buffer);
			  return 0;
		}
		strcat((char *)ack_buffer,(const char *)rx_buffer);
		count ++;
	}
	
	printf("Recv AT ACK:%s\r\n",ack_buffer);
	if(strstr((const char *)ack_buffer,"OK")){
		return 0;
	}
	
	return -1;
}

int esp8266_reset(void)
{
	int ret;
	
	//send "+++" quit passthrough mode
	esp8266_send_cmd("+++");
	HAL_Delay(1000);
	
	//send "AT+RST\r\n" reset esp8266
	esp8266_send_cmd("AT+RST\r\n");
	HAL_Delay(3000);
	
	//send "AT\r\n" test
	esp8266_send_cmd("AT\r\n");
	
	ret = esp8266_recv_ack();
	if(ret < 0){
		 printf("ESP8266 is not alive\r\n");
		 return -1;
	}
	
	printf("Reset ESP8266 Success\r\n");
	
	return 0;
}

int esp8266_enter_ap_mode(void)
{
	int ret;
	
	//send "AT+CWMODE=2\r\n" to ap mode
	esp8266_send_cmd("AT+CWMODE=2\r\n");
	ret = esp8266_recv_ack();
	if(ret < 0){
		 printf("ESP8266 enter ap mode failed\r\n");
		 return -1;
	}
	
	//config ap ssid and pwd
	esp8266_send_cmd("AT+CWSAP=\"ESP8266-WIFI\",\"0123456789\",11,4\r\n");
	ret = esp8266_recv_ack();
	if(ret < 0){
		 printf("ESP8266 config ap ssid and pwd failed\r\n");
		 return -1;
	}
	
	printf("ESP8266 AP mode,SSID:ESP8266-WIFI,PWD:0123456789\r\n");
	
	return 0;
}

int esp8266_create_tcp_server(void)
{
	int ret;
	
	//send "AT+SAVETRANSLINK=0\r\n" to close start auto passthrough mode
	esp8266_send_cmd("AT+SAVETRANSLINK=0\r\n");
	ret = esp8266_recv_ack();
	if(ret < 0){
		 printf("ESP8266 close start auto passthrough mode failed\r\n");
		 return -1;
	}
	
	//allow muti connections
	esp8266_send_cmd("AT+CIPMUX=1\r\n");
	ret = esp8266_recv_ack();
	if(ret < 0){
		 printf("ESP8266 allow muti connections failed\r\n");
		 return -1;
	}
	
  //build tcp server
	esp8266_send_cmd("AT+CIPSERVER=1,8888\r\n");
	ret = esp8266_recv_ack();
	if(ret < 0){
		 printf("ESP8266 build tcp server failed\r\n");
		 return -1;
	}
	
	printf("ESP8266 create tcp server success,port:8888\r\n");
	
	return 0;
}

void esp8266_init(void)
{
	 int ret;
	 
	 ret = esp8266_reset();
	 if(ret < 0){
			return;
	 }	
	 
	 ret = esp8266_enter_ap_mode();
	 if(ret < 0){
			return;
	 }
	 
	 ret = esp8266_create_tcp_server();
	 if(ret < 0){
		 return;
	 }
	 
	 uart_interrupt_init();
}

void esp8266_car_control(uint8_t *buffer,uint32_t size)
{
	int ret;
	int id;
	int len;
	uint8_t cmd[100] = {0};
	
	//\r\n+IPD,0,1:w
	ret = sscanf((const char *)buffer,"\r\n+IPD,%d,%d:%s\r\n",&id,&len,cmd);
	if(ret != 3){
		return;
	}
	
	switch(cmd[0]){
		case 'w':
			car_forward(800);
			printf("forward\r\n");
		  break;
		
	 case 's':
		  car_reverse(800);
			printf("reverse\r\n");
		  break;
	case 'a':
		  car_turn_left(800);
			printf("turn left\r\n");
		  break;
	
	case 'd':
		  car_turn_right(800);
			printf("turn right\r\n");
		  break;
	}
	
	__HAL_TIM_SET_COUNTER(&htim4,0);
	__HAL_TIM_CLEAR_FLAG(&htim4,TIM_FLAG_UPDATE);
	HAL_TIM_Base_Start_IT(&htim4);
	
	return;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim == &htim4){
		 car_stop();
		 printf("time over\r\n");
		 HAL_TIM_Base_Stop_IT(&htim4);
	}
}

void esp8266_test(void)
{
	esp8266_init();

	return;
}