#include "gpio.h"

void open_relay(void)
{
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15, GPIO_PIN_SET);
	return;
}

void close_relay(void)
{
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_15, GPIO_PIN_RESET);
	return;
}

void relay_test(void)
{
	
	while(1){
		open_relay();
		HAL_Delay(1000);
		close_relay();
		HAL_Delay(1000);
	}
	
	return;
}