#include "tim.h"
#if 1
//0~1000
void right_motor_reverse(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_4);
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
	
	 return;
}

void right_motor_forward(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_3);
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
	
	 return;
}
#else 
void right_motor_forward(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_4);
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
	
	 return;
}

void right_motor_reverse(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_4,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_3);
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
	
	 return;
}

#endif 

void right_motor_stop(void)
{
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_3);
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_4);
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
}

#if 1
//0~1000
void left_motor_reverse(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_1);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
	
	 return;
}

//0~1000
void left_motor_forward(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_2);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
	
	 return;
}
#else

//0~1000
void left_motor_forward(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_1);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
	
	 return;
}

//0~1000
void left_motor_reverse(uint32_t speed)
{
	 __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,speed);
	 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
	
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_2);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
	
	 return;
}

#endif 

void left_motor_stop(void)
{
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_1);
	 HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_2);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
}

void car_forward(uint32_t speed)
{
		left_motor_forward(speed); 
		right_motor_forward(speed);
}

void car_reverse(uint32_t speed)
{
		left_motor_reverse(speed); 
		right_motor_reverse(speed);
}

void car_stop(void)
{
		left_motor_stop();
		right_motor_stop();
}

void car_turn_left(uint32_t speed)
{
	 right_motor_forward(speed);
	 left_motor_reverse(speed); 
}

void car_turn_right(uint32_t speed)
{
	 left_motor_forward(speed);
	 right_motor_reverse(speed); 
}

void motor_test(void)
{
	
	while(1){
		  car_forward(800);
			HAL_Delay(5000);
			car_stop();
			HAL_Delay(1000);
		  car_reverse(800);
			HAL_Delay(5000);
			car_stop();
			HAL_Delay(1000);
	}
	car_turn_left(800);
	HAL_Delay(3000);
	car_stop();
	
	HAL_Delay(1000);
	
	car_turn_right(800);
	HAL_Delay(3000);
	
	car_stop();
	
	return;
}