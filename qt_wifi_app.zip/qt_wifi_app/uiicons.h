#ifndef UIICONS_H
#define UIICONS_H

#include <QColor>
#include <QIcon>

namespace UiIcon {
enum Type {
    Board,
    Wifi,
    WifiConnected,
    TestGrid,
    Rs485,
    Can,
    Led,
    Beep,
    Lock,
    Eye,
    Search,
    ArrowRight,
    Offline,
    Back,
    Keyboard,
    Backspace,
    Check
};
}

QIcon makeUiIcon(UiIcon::Type type, const QColor &color);

// 图标染色角色（对应 Theme 语义色）。主题切换后按角色重新取色即可
// 重新生成同风格图标，调用方无需感知具体色值。
enum class IconTint { Hint, Secondary, Primary, Bright, Accent, Success, Danger };

QColor iconTintColor(IconTint tint);

#endif // UIICONS_H
