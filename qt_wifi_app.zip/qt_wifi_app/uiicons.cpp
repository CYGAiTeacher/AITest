#include "uiicons.h"

#include "uitheme.h"

#include <QDebug>
#include <QPixmap>
#include <QString>

namespace {

QString iconAssetName(UiIcon::Type type, const QColor &color)
{
    switch (type) {
    case UiIcon::Board:
        return QStringLiteral("board_blue");
    case UiIcon::Wifi:
        return color == Theme::Accent
                   ? QStringLiteral("wifi_blue")
                   : QStringLiteral("wifi_secondary");
    case UiIcon::WifiConnected:
        return QStringLiteral("wifi_connected_green");
    case UiIcon::TestGrid:
        return QStringLiteral("testgrid_blue");
    case UiIcon::Rs485:
        return QStringLiteral("rs485_secondary");
    case UiIcon::Can:
        return QStringLiteral("can_secondary");
    case UiIcon::Led:
        return QStringLiteral("led_secondary");
    case UiIcon::Beep:
        return QStringLiteral("beep_secondary");
    case UiIcon::Lock:
        return color == Theme::Danger
                   ? QStringLiteral("lock_red")
                   : QStringLiteral("lock_gray");
    case UiIcon::Eye:
        if (color == Theme::Accent)
            return QStringLiteral("eye_blue");
        if (color == Theme::TextHint || color == Theme::TextSecondary)
            return QStringLiteral("eye_secondary");
        return QStringLiteral("eye_gray");
    case UiIcon::Search:
        return QStringLiteral("search_gray");
    case UiIcon::ArrowRight:
        return QStringLiteral("arrowright_dark");
    case UiIcon::Offline:
        return QStringLiteral("offline_secondary");
    case UiIcon::Back:
        return QStringLiteral("back_secondary");
    case UiIcon::Keyboard:
        return QStringLiteral("keyboard_gray");
    case UiIcon::Backspace:
        return QStringLiteral("backspace_dark");
    case UiIcon::Check:
        return QStringLiteral("check_white");
    }
    return QString();
}

} // namespace

QIcon makeUiIcon(UiIcon::Type type, const QColor &color)
{
    const QString assetName = iconAssetName(type, color);
    if (assetName.isEmpty())
        return QIcon();

    const QString resourcePath = QStringLiteral(":/ui/icons/%1.png").arg(assetName);
    const QPixmap iconPixmap(resourcePath);
    if (iconPixmap.isNull()) {
        qWarning().noquote() << "UI icon resource is missing:" << resourcePath;
        return QIcon();
    }

    // 按传入的语义角色色重着色（保留 alpha，只替换 RGB）。图标素素材全是
    // 单色字形，这样一次染色即可在深/浅各主题下都保证对比度——不必为
    // 每套主题维护一套 PNG。
    QImage image = iconPixmap.toImage().convertToFormat(QImage::Format_ARGB32);
    const QRgb rgbMask = color.rgb() & 0x00FFFFFFu;
    for (int y = 0; y < image.height(); ++y) {
        QRgb *line = reinterpret_cast<QRgb *>(image.scanLine(y));
        for (int x = 0; x < image.width(); ++x) {
            const QRgb pixel = line[x];
            if (qAlpha(pixel) > 0)
                line[x] = (pixel & 0xFF000000u) | rgbMask;
        }
    }
    return QIcon(QPixmap::fromImage(image));
}

QColor iconTintColor(IconTint tint)
{
    switch (tint) {
    case IconTint::Hint:      return Theme::TextHint;
    case IconTint::Secondary: return Theme::TextSecondary;
    case IconTint::Primary:   return Theme::TextPrimary;
    case IconTint::Bright:    return Theme::TextBright;
    case IconTint::Accent:   return Theme::Accent;
    case IconTint::Success:   return Theme::Success;
    case IconTint::Danger:    return Theme::Danger;
    }
    return Theme::TextPrimary;
}
