#include "wificredentialstore.h"

#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QFileDevice>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QSaveFile>
#include <QSet>
#include <QStandardPaths>
#include <QtGlobal>

namespace {

QFileDevice::Permissions ownerOnlyPermissions()
{
    return QFileDevice::ReadOwner | QFileDevice::WriteOwner;
}

void setError(QString *error, const QString &message)
{
    if (error)
        *error = message;
}

bool validCredentials(const WifiCredentials &credentials, QString *error)
{
    // SSIDs are byte strings on the wire. Keep leading/trailing spaces intact.
    const int length = credentials.ssid.toUtf8().size();
    if (length < 1 || length > 32) {
        setError(error, QStringLiteral("Wi-Fi 名称长度必须为 1–32 字节。"));
        return false;
    }
    if (credentials.secured && credentials.password.isEmpty()) {
        setError(error, QStringLiteral("加密网络缺少密码，无法保存凭据。"));
        return false;
    }
    return true;
}

} // namespace

WifiCredentialStore::WifiCredentialStore()
    : m_filePath(QString::fromLocal8Bit(qgetenv("WIFI_CREDENTIALS_PATH"))),
      m_customPath(false)
{
    if (!m_filePath.isEmpty()) {
        m_customPath = true;
    } else {
        QString directory = QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation);
        if (directory.isEmpty())
            directory = QDir::home().filePath(QStringLiteral(".config/BoardLab/PeripheralTest"));
        m_filePath = QDir(directory).filePath(QStringLiteral("wifi_credentials.json"));
    }
    if (QFileInfo(m_filePath).isRelative())
        m_filePath = QDir::current().absoluteFilePath(m_filePath);
}

const QString &WifiCredentialStore::filePath() const
{
    return m_filePath;
}

bool WifiCredentialStore::loadAll(QList<WifiCredentials> *credentials, QString *error) const
{
    if (!credentials) {
        setError(error, QStringLiteral("Wi-Fi 凭据接收对象无效。"));
        return false;
    }
    credentials->clear();
    setError(error, QString());
    QFile file(m_filePath);
    if (!file.exists())
        return true; // A fresh installation is a valid, empty store.
#ifdef Q_OS_UNIX
    if (!QFile::setPermissions(m_filePath, ownerOnlyPermissions())) {
        setError(error, QStringLiteral("无法将 Wi-Fi 凭据文件权限限制为仅所有者可读写。"));
        return false;
    }
#endif
    if (!file.open(QIODevice::ReadOnly)) {
        setError(error, QStringLiteral("无法读取 Wi-Fi 凭据文件：%1").arg(file.errorString()));
        return false;
    }
    QJsonParseError parseError;
    const QByteArray json = file.read(1024 * 1024 + 1);
    if (json.size() > 1024 * 1024) {
        setError(error, QStringLiteral("Wi-Fi 凭据文件超过 1 MiB，拒绝读取。"));
        return false;
    }
    const QJsonDocument document = QJsonDocument::fromJson(json, &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        setError(error, QStringLiteral("Wi-Fi 凭据文件不是有效的 JSON 对象。"));
        return false;
    }
    const QJsonObject object = document.object();
    const int version = object.value(QStringLiteral("version")).toInt(1);
    QJsonArray records;
    if (version == 1) {
        records.append(object);
    } else if (version == 2 && object.value(QStringLiteral("networks")).isArray()) {
        records = object.value(QStringLiteral("networks")).toArray();
    } else {
        setError(error, QStringLiteral("Wi-Fi 凭据文件版本或 networks 字段无效。"));
        return false;
    }

    QList<WifiCredentials> loaded;
    QSet<QString> seen;
    for (const QJsonValue &record : records) {
        if (!record.isObject()) {
            setError(error, QStringLiteral("Wi-Fi 凭据列表中含无效记录。"));
            return false;
        }
        const QJsonObject profile = record.toObject();
        WifiCredentials entry;
        entry.ssid = profile.value(QStringLiteral("ssid")).toString();
        entry.password = profile.value(QStringLiteral("password")).toString();
        entry.secured = profile.value(QStringLiteral("secured")).toBool(!entry.password.isEmpty());
        if (!validCredentials(entry, error))
            return false;
        if (!entry.secured)
            entry.password.clear();
        if (seen.contains(entry.ssid)) {
            setError(error, QStringLiteral("Wi-Fi 凭据列表中 SSID 重复。"));
            return false;
        }
        seen.insert(entry.ssid);
        loaded.append(entry);
    }
    *credentials = loaded;
    return true;
}

bool WifiCredentialStore::saveAll(const QList<WifiCredentials> &credentials, QString *error) const
{
    setError(error, QString());
    if (credentials.isEmpty())
        return clear(error);
    QJsonArray records;
    QSet<QString> seen;
    for (const WifiCredentials &entry : credentials) {
        if (!validCredentials(entry, error))
            return false;
        if (seen.contains(entry.ssid)) {
            setError(error, QStringLiteral("不能保存重复的 Wi-Fi 名称。"));
            return false;
        }
        seen.insert(entry.ssid);
        QJsonObject profile;
        profile.insert(QStringLiteral("ssid"), entry.ssid);
        profile.insert(QStringLiteral("password"), entry.secured ? entry.password : QString());
        profile.insert(QStringLiteral("secured"), entry.secured);
        records.append(profile);
    }

    QDir directory = QFileInfo(m_filePath).absoluteDir();
    if (!directory.exists() && !directory.mkpath(QStringLiteral("."))) {
        setError(error, QStringLiteral("无法创建 Wi-Fi 凭据目录：%1").arg(directory.absolutePath()));
        return false;
    }
#ifdef Q_OS_UNIX
    if (!m_customPath) {
        QFile::setPermissions(directory.absolutePath(),
                             QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner);
    }
#endif
    QJsonObject object;
    object.insert(QStringLiteral("version"), 2);
    object.insert(QStringLiteral("networks"), records);
    const QByteArray data = QJsonDocument(object).toJson(QJsonDocument::Indented);
    if (data.size() > 1024 * 1024) {
        setError(error, QStringLiteral("Wi-Fi 凭据列表超过 1 MiB，无法保存。"));
        return false;
    }
    QSaveFile file(m_filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        setError(error, QStringLiteral("无法写入 Wi-Fi 凭据文件：%1").arg(file.errorString()));
        return false;
    }
    if (!file.setPermissions(ownerOnlyPermissions())) {
        file.cancelWriting();
        setError(error, QStringLiteral("无法限制 Wi-Fi 凭据文件权限。"));
        return false;
    }
    if (file.write(data) != data.size()) {
        file.cancelWriting();
        setError(error, QStringLiteral("写入 Wi-Fi 凭据文件失败。"));
        return false;
    }
    if (!file.commit()) {
        setError(error, QStringLiteral("保存 Wi-Fi 凭据文件失败：%1").arg(file.errorString()));
        return false;
    }
    if (!QFile::setPermissions(m_filePath, ownerOnlyPermissions())) {
        setError(error, QStringLiteral("凭据已写入，但无法设为仅所有者可读写。"));
        return false;
    }
    return true;
}

bool WifiCredentialStore::load(WifiCredentials *credentials, QString *error) const
{
    if (!credentials) {
        setError(error, QStringLiteral("Wi-Fi 凭据接收对象无效。"));
        return false;
    }
    QList<WifiCredentials> profiles;
    if (!loadAll(&profiles, error) || profiles.isEmpty())
        return false;
    *credentials = profiles.first();
    return true;
}

bool WifiCredentialStore::save(const WifiCredentials &credentials, QString *error) const
{
    QList<WifiCredentials> profiles;
    if (!loadAll(&profiles, error))
        return false; // Never silently overwrite an unreadable/corrupt file.
    for (int i = profiles.size() - 1; i >= 0; --i) {
        if (profiles.at(i).ssid == credentials.ssid)
            profiles.removeAt(i);
    }
    profiles.prepend(credentials);
    return saveAll(profiles, error);
}

bool WifiCredentialStore::remove(const QString &ssid, QString *error) const
{
    QList<WifiCredentials> profiles;
    if (!loadAll(&profiles, error))
        return false;
    for (int i = profiles.size() - 1; i >= 0; --i) {
        if (profiles.at(i).ssid == ssid)
            profiles.removeAt(i);
    }
    return saveAll(profiles, error);
}

bool WifiCredentialStore::clear(QString *error) const
{
    setError(error, QString());
    if (!QFileInfo::exists(m_filePath))
        return true;
    if (!QFile::remove(m_filePath)) {
        setError(error, QStringLiteral("无法删除 Wi-Fi 凭据文件。"));
        return false;
    }
    return true;
}
