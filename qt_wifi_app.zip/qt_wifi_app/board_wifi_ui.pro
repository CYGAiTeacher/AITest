QT += widgets network
CONFIG += c++11

TEMPLATE = app
TARGET = board_wifi_ui

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    cameraworker.cpp \
    canlinksession.cpp \
    modbusworker.cpp \
    ntpsynchronizer.cpp \
    xiaozhibridge.cpp \
    uiicons.cpp \
    uitheme.cpp \
    wifimanager.cpp \
    wifireconnectpolicy.cpp \
    wificredentialstore.cpp

HEADERS += \
    mainwindow.h \
    cameraworker.h \
    canlinksession.h \
    modbusworker.h \
    ntpsynchronizer.h \
    xiaozhibridge.h \
    uiicons.h \
    uitheme.h \
    wifimanager.h \
    wifireconnectpolicy.h \
    wificredentialstore.h

RESOURCES += ui_resources.qrc

# The CJK font is optional and is not included in the project ZIP.
exists($$PWD/fonts/NotoSansSC-Regular.otf) {
    DISTFILES += fonts/NotoSansSC-Regular.otf
    exists($$PWD/fonts/OFL.txt) {
        DISTFILES += fonts/OFL.txt
    }

    # For out-of-source qmake builds, copy an available optional font directory.
    unix:!equals(PWD, $$OUT_PWD) {
        QMAKE_POST_LINK += $$QMAKE_COPY_DIR $$PWD/fonts $$OUT_PWD
    }
}
