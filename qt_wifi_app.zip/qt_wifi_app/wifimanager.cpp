#include "wifimanager.h"

#include <QByteArray>
#include <QElapsedTimer>
#include <QFile>
#include <QFileInfo>
#include <QMap>
#include <QMutexLocker>
#include <QProcess>
#include <QRegularExpression>
#include <QSet>
#include <QThread>
#include <QTemporaryDir>
#include <QStringList>

#include <algorithm>
#include <cerrno>
#include <cstring>
#include <limits>

#ifdef Q_OS_UNIX
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <poll.h>
#include <unistd.h>
#include <stddef.h>
#endif

namespace {

class WpaControl
{
public:
    WpaControl(const QString &interfaceName, const QString &controlDirectory)
        : m_interfaceName(interfaceName),
          m_controlDirectory(controlDirectory),
          m_fd(-1)
    {
    }

    ~WpaControl() { closeSocket(); }

    bool openSocket(QString *error)
    {
#ifndef Q_OS_UNIX
        if (error)
            *error = QStringLiteral("wpa_supplicant 控制接口仅支持 Linux/Unix。");
        return false;
#else
        QStringList remotePaths;
        const QString explicitPath = QString::fromLocal8Bit(qgetenv("WPA_CTRL_PATH"));
        if (!explicitPath.isEmpty()) {
            remotePaths << explicitPath;
        } else {
            const QString envDir = QString::fromLocal8Bit(qgetenv("WPA_CTRL_DIR"));
            const QString primaryDir = envDir.isEmpty() ? m_controlDirectory : envDir;
            if (!primaryDir.isEmpty())
                remotePaths << primaryDir + QLatin1Char('/') + m_interfaceName;
            remotePaths << QStringLiteral("/run/wpa_supplicant/") + m_interfaceName;
            remotePaths << QStringLiteral("/var/run/wpa_supplicant/") + m_interfaceName;
        }
        remotePaths.removeDuplicates();

        QString lastError = QStringLiteral("找不到 wpa_supplicant 控制套接字。");
        for (const QString &remotePath : remotePaths) {
            const QByteArray remoteBytes = remotePath.toLocal8Bit();
            if (remoteBytes.size() >= int(sizeof(sockaddr_un::sun_path))) {
                lastError = QStringLiteral("控制套接字路径过长。");
                continue;
            }

            const int fd = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
            if (fd < 0) {
                lastError = QStringLiteral("无法创建 Wi-Fi 控制接口：%1")
                                .arg(QString::fromLocal8Bit(std::strerror(errno)));
                continue;
            }

            sockaddr_un localAddress;
            std::memset(&localAddress, 0, sizeof(localAddress));
            localAddress.sun_family = AF_UNIX;
            if (!m_localDirectory.isValid()) {
                ::close(fd);
                lastError = QStringLiteral("无法创建 Wi-Fi 私有控制目录。");
                continue;
            }
            const QString localPath = m_localDirectory.filePath(QStringLiteral("ctrl"));
            const QByteArray localBytes = localPath.toLocal8Bit();
            if (localBytes.size() >= int(sizeof(localAddress.sun_path))) {
                ::close(fd);
                lastError = QStringLiteral("本地控制套接字路径过长。");
                continue;
            }
            std::memcpy(localAddress.sun_path, localBytes.constData(), size_t(localBytes.size()));
            localAddress.sun_path[localBytes.size()] = '\0';
            ::unlink(localAddress.sun_path);
            const socklen_t localLength = socklen_t(offsetof(sockaddr_un, sun_path) + localBytes.size() + 1);
            if (::bind(fd, reinterpret_cast<sockaddr *>(&localAddress), localLength) < 0) {
                lastError = QStringLiteral("无法绑定本地控制套接字：%1")
                                .arg(QString::fromLocal8Bit(std::strerror(errno)));
                ::close(fd);
                continue;
            }

            sockaddr_un remoteAddress;
            std::memset(&remoteAddress, 0, sizeof(remoteAddress));
            remoteAddress.sun_family = AF_UNIX;
            std::memcpy(remoteAddress.sun_path, remoteBytes.constData(), size_t(remoteBytes.size()));
            remoteAddress.sun_path[remoteBytes.size()] = '\0';
            const socklen_t remoteLength = socklen_t(offsetof(sockaddr_un, sun_path) + remoteBytes.size() + 1);
            if (::connect(fd, reinterpret_cast<sockaddr *>(&remoteAddress), remoteLength) < 0) {
                lastError = QStringLiteral("无法连接 %1：%2")
                                .arg(remotePath, QString::fromLocal8Bit(std::strerror(errno)));
                ::close(fd);
                ::unlink(localPath.toLocal8Bit().constData());
                continue;
            }

            m_fd = fd;
            m_localPath = localPath;
            if (error)
                error->clear();
            return true;
        }

        if (error)
            *error = lastError + QStringLiteral(" 请检查 wpa_supplicant 是否运行、接口名和控制权限。");
        return false;
#endif
    }

    QString request(const QString &command, int timeoutMs, QString *error = nullptr)
    {
#ifndef Q_OS_UNIX
        Q_UNUSED(command)
        Q_UNUSED(timeoutMs)
        if (error)
            *error = QStringLiteral("当前平台不支持 wpa_supplicant 控制接口。");
        return QString();
#else
        if (m_fd < 0) {
            if (error)
                *error = QStringLiteral("Wi-Fi 控制接口尚未打开。");
            return QString();
        }
        const QByteArray bytes = command.toUtf8();
        const ssize_t sent = ::send(m_fd, bytes.constData(), size_t(bytes.size()), 0);
        if (sent != ssize_t(bytes.size())) {
            if (error)
                *error = QStringLiteral("发送 Wi-Fi 控制命令失败：%1")
                             .arg(QString::fromLocal8Bit(std::strerror(errno)));
            return QString();
        }

        QElapsedTimer elapsed;
        elapsed.start();
        while (elapsed.elapsed() < timeoutMs) {
            QByteArray message;
            const int remaining = qMax(1, timeoutMs - int(elapsed.elapsed()));
            if (!receiveMessage(remaining, &message, error))
                return QString();
            QString text = QString::fromUtf8(message.constData(), message.size());
            while (text.endsWith(QLatin1Char('\n')) || text.endsWith(QLatin1Char('\r')))
                text.chop(1);
            if (isUnsolicitedEvent(text)) {
                if (m_pendingEvents.size() >= 256) m_pendingEvents.removeFirst();
                m_pendingEvents << text;
                continue;
            }
            if (error)
                error->clear();
            return text;
        }
        if (error)
            *error = QStringLiteral("wpa_supplicant 响应超时。");
        return QString();
#endif
    }

    bool waitForScanEvent(int timeoutMs)
    {
#ifndef Q_OS_UNIX
        Q_UNUSED(timeoutMs)
        return false;
#else
        QElapsedTimer elapsed;
        elapsed.start();
        while (elapsed.elapsed() < timeoutMs && !QThread::currentThread()->isInterruptionRequested()) {
            for (int i = 0; i < m_pendingEvents.size(); ++i) {
                const QString event = m_pendingEvents.at(i);
                if (event.contains(QStringLiteral("CTRL-EVENT-SCAN-RESULTS"))) {
                    m_pendingEvents.removeAt(i);
                    return true;
                }
                if (event.contains(QStringLiteral("CTRL-EVENT-SCAN-FAILED"))) {
                    m_pendingEvents.removeAt(i);
                    return false;
                }
            }
            QByteArray message;
            QString ignored;
            const int remaining = qMax(1, qMin(500, timeoutMs - int(elapsed.elapsed())));
            if (!receiveMessage(remaining, &message, &ignored))
                continue;
            const QString text = QString::fromUtf8(message.constData(), message.size()).trimmed();
            if (text.contains(QStringLiteral("CTRL-EVENT-SCAN-RESULTS")))
                return true;
            if (text.contains(QStringLiteral("CTRL-EVENT-SCAN-FAILED")))
                return false;
            if (isUnsolicitedEvent(text)) {
                if (m_pendingEvents.size() >= 256) m_pendingEvents.removeFirst();
                m_pendingEvents << text;
            }
        }
        return false;
#endif
    }

    // Drain monitor events without blocking the UI (this object lives only
    // on the worker thread). Pending events may have arrived before a command
    // reply and must not be discarded when diagnosing WRONG_KEY.
    QStringList takeEvents(int waitMs = 0)
    {
        QStringList events = m_pendingEvents;
        m_pendingEvents.clear();
#ifdef Q_OS_UNIX
        for (int count = 0; count < 256; ++count) {
            QByteArray bytes;
            QString ignored;
            const int wait = count == 0 && events.isEmpty() ? waitMs : 0;
            if (!receiveMessage(wait, &bytes, &ignored))
                break;
            const QString event = QString::fromUtf8(bytes).trimmed();
            if (isUnsolicitedEvent(event))
                events.append(event);
        }
#else
        Q_UNUSED(waitMs)
#endif
        return events;
    }

    void closeSocket()
    {
#ifdef Q_OS_UNIX
        if (m_fd >= 0) {
            ::close(m_fd);
            m_fd = -1;
        }
        if (!m_localPath.isEmpty()) {
            ::unlink(m_localPath.toLocal8Bit().constData());
            m_localPath.clear();
        }
#endif
    }

private:
#ifdef Q_OS_UNIX
    static bool isUnsolicitedEvent(const QString &message)
    {
        // Events start with a numeric priority (or an IFNAME prefix).
        // Do not mistake "CTRL-EVENT-" / "<3>" inside an SSID or a multi-line
        // SCAN_RESULTS response for an unsolicited monitor event.
        QString payload = message;
        if (payload.startsWith(QStringLiteral("IFNAME="))) {
            const int separator = payload.indexOf(QLatin1Char(' '));
            if (separator >= 0)
                payload = payload.mid(separator + 1);
        }
        if (payload.startsWith(QLatin1Char('<'))) {
            const int end = payload.indexOf(QLatin1Char('>'), 1);
            bool numeric = end > 1;
            for (int i = 1; i < end; ++i)
                numeric = numeric && payload.at(i).isDigit();
            if (numeric)
                return true;
        }
        return payload.startsWith(QStringLiteral("CTRL-EVENT-")) ||
               payload.startsWith(QStringLiteral("WPS-")) ||
               payload.startsWith(QStringLiteral("P2P-")) ||
               payload.startsWith(QStringLiteral("WPA: Key negotiation"));
    }

    bool receiveMessage(int timeoutMs, QByteArray *message, QString *error)
    {
        pollfd descriptor;
        descriptor.fd = m_fd;
        descriptor.events = POLLIN;
        descriptor.revents = 0;
        int result = 0;
        QElapsedTimer elapsed;
        elapsed.start();
        do {
            if (QThread::currentThread()->isInterruptionRequested()) {
                if (error) *error = QStringLiteral("Wi-Fi 操作已取消。");
                return false;
            }
            result = ::poll(&descriptor, 1, qBound(0, timeoutMs - int(elapsed.elapsed()), 50));
            if (result < 0 && errno == EINTR) continue;
            if (result != 0) break;
        } while (elapsed.elapsed() < timeoutMs);

        if (result == 0) {
            if (error)
                *error = QStringLiteral("wpa_supplicant 响应超时。");
            return false;
        }
        if (result < 0 || (descriptor.revents & (POLLERR | POLLHUP | POLLNVAL))) {
            if (error)
                *error = QStringLiteral("读取 Wi-Fi 控制响应失败：%1")
                             .arg(QString::fromLocal8Bit(std::strerror(errno)));
            return false;
        }

        char buffer[16384];
        const ssize_t received = ::recv(m_fd, buffer, sizeof(buffer), 0);
        if (received < 0) {
            if (error)
                *error = QStringLiteral("读取 Wi-Fi 控制响应失败：%1")
                             .arg(QString::fromLocal8Bit(std::strerror(errno)));
            return false;
        }
        message->append(buffer, int(received));
        if (error)
            error->clear();
        return true;
    }
#endif

    QString m_interfaceName;
    QString m_controlDirectory;
    int m_fd;
    QTemporaryDir m_localDirectory;
    QString m_localPath;
    QStringList m_pendingEvents;
};

bool isHexPsk(const QByteArray &bytes)
{
    if (bytes.size() != 64)
        return false;
    for (char c : bytes) {
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
            return false;
    }
    return true;
}

QString quoteWpaConfigString(const QByteArray &value)
{
    // Match wpa_cli's SET_NETWORK psk "passphrase" syntax. Escape the two
    // characters that have special meaning inside a quoted config string.
    QByteArray quoted;
    quoted.reserve(value.size() + 2);
    quoted.append('"');
    for (char c : value) {
        if (c == '"' || c == '\\')
            quoted.append('\\');
        quoted.append(c);
    }
    quoted.append('"');
    return QString::fromLatin1(quoted);
}

QString wpaPskValue(const QString &password, QString *error)
{
    const QByteArray passphrase = password.toUtf8();
    if (isHexPsk(passphrase)) {
        if (error)
            error->clear();
        // A 64-digit hexadecimal value is already a raw 256-bit PSK.
        return QString::fromLatin1(passphrase.toLower());
    }

    if (passphrase.size() < 8 || passphrase.size() > 63) {
        if (error)
            *error = QStringLiteral("WPA/WPA2 密码需为 8–63 个 ASCII 字符，或 64 位十六进制 PSK。");
        return QString();
    }
    for (unsigned char c : passphrase) {
        if (c < 0x20 || c > 0x7e) {
            if (error)
                *error = QStringLiteral("WPA/WPA2 密码请使用可见 ASCII 字符。");
            return QString();
        }
    }

    if (error)
        error->clear();
    // Let wpa_supplicant derive the PMK from the quoted passphrase, exactly
    // as it does for: wpa_cli set_network <id> psk "passphrase".
    return quoteWpaConfigString(passphrase);
}

// wpa_supplicant escapes non-ASCII SSID bytes as \xNN. Decode scan and
// STATUS names identically so remembered Chinese/space-containing SSIDs match.
QString decodeWpaSsid(const QString &text)
{
    const QByteArray input = text.toUtf8();
    QByteArray output;
    for (int i = 0; i < input.size(); ++i) {
        if (input.at(i) != '\\' || i + 1 >= input.size()) {
            output.append(input.at(i));
            continue;
        }
        const char next = input.at(i + 1);
        if (next == 'x' && i + 3 < input.size()) {
            bool ok = false;
            const int value = input.mid(i + 2, 2).toInt(&ok, 16);
            if (ok) {
                output.append(static_cast<char>(value));
                i += 3;
                continue;
            }
        }
        if (next == '\\' || next == '"') {
            output.append(next);
            ++i;
        } else if (next == 'n' || next == 'r' || next == 't' || next == 'e') {
            output.append(next == 'n' ? '\n' : next == 'r' ? '\r' : next == 't' ? '\t' : char(27));
            ++i;
        } else {
            output.append(input.at(i));
        }
    }
    return QString::fromUtf8(output);
}

QString statusValue(const QString &status, const QString &key)
{
    const QStringList lines = status.split(QLatin1Char('\n'));
    const QString prefix = key + QLatin1Char('=');
    for (const QString &line : lines) {
        if (line.startsWith(prefix))
            return key == QStringLiteral("ssid") ? line.mid(prefix.size())
                                                  : line.mid(prefix.size()).trimmed();
    }
    return QString();
}

QString interfaceIpv4Address(const QString &interfaceName)
{
#ifdef Q_OS_UNIX
    struct ifaddrs *interfaces = nullptr;
    if (::getifaddrs(&interfaces) != 0)
        return QString();

    QString address;
    for (struct ifaddrs *entry = interfaces; entry; entry = entry->ifa_next) {
        if (!entry->ifa_addr || entry->ifa_addr->sa_family != AF_INET ||
            QString::fromLocal8Bit(entry->ifa_name) != interfaceName)
            continue;

        const struct sockaddr_in *ipv4 =
            reinterpret_cast<const struct sockaddr_in *>(entry->ifa_addr);
        char text[INET_ADDRSTRLEN] = {0};
        if (::inet_ntop(AF_INET, &ipv4->sin_addr, text, sizeof(text))) {
            const QString candidate = QString::fromLatin1(text);
            if (candidate != QStringLiteral("0.0.0.0")) {
                address = candidate;
                break;
            }
        }
    }
    ::freeifaddrs(interfaces);
    return address;
#else
    Q_UNUSED(interfaceName)
    return QString();
#endif
}

bool startUdhcpc(const QString &interfaceName, QString *error)
{
#ifdef Q_OS_UNIX
    QString program = QString::fromLocal8Bit(qgetenv("UDHCPC_PATH"));
    if (program.isEmpty()) {
        const QStringList candidates = QStringList()
            << QStringLiteral("/sbin/udhcpc")
            << QStringLiteral("/usr/sbin/udhcpc")
            << QStringLiteral("/bin/udhcpc")
            << QStringLiteral("/usr/bin/udhcpc");
        for (const QString &candidate : candidates) {
            if (QFileInfo(candidate).isExecutable()) {
                program = candidate;
                break;
            }
        }
        if (program.isEmpty())
            program = QStringLiteral("udhcpc");
    }

    if (!QRegularExpression(QStringLiteral("^[A-Za-z0-9_.:-]{1,15}$")).match(interfaceName).hasMatch()) {
        if (error) *error = QStringLiteral("无效的 DHCP 网络接口名。");
        return false;
    }
    const QString pidFilePath = QStringLiteral("/run/udhcpc-%1.pid").arg(interfaceName);
    QFile pidFile(pidFilePath);
    if (pidFile.open(QIODevice::ReadOnly)) {
        bool pidOk = false;
        const qint64 savedPid = QString::fromLatin1(pidFile.read(64).trimmed()).toLongLong(&pidOk);
        pidFile.close();
        if (pidOk && savedPid > 1 && savedPid <= std::numeric_limits<pid_t>::max() &&
            (::kill(static_cast<pid_t>(savedPid), 0) == 0 || errno == EPERM)) {
            QFile commandLine(QStringLiteral("/proc/%1/cmdline").arg(savedPid));
            if (commandLine.open(QIODevice::ReadOnly)) {
                const QList<QByteArray> arguments = commandLine.read(4096).split('\0');
                const QByteArray executable = arguments.value(0).split('/').last();
                const bool isUdhcpc = executable == "udhcpc" ||
                    (executable == "busybox" && arguments.value(1) == "udhcpc");
                bool sameInterface = false;
                for (int i = 1; i < arguments.size(); ++i) {
                    if ((arguments.at(i) == "-i" && arguments.value(i + 1) == interfaceName.toLocal8Bit()) ||
                        arguments.at(i) == QByteArray("-i") + interfaceName.toLocal8Bit()) sameInterface = true;
                }
                if (isUdhcpc && sameInterface) {
                    ::kill(static_cast<pid_t>(savedPid), SIGUSR1); // renew the current lease
                    if (error)
                        error->clear();
                    return true;
                }
            }
        }
        QFile::remove(pidFilePath);
    }

    const QStringList arguments = QStringList()
        << QStringLiteral("-i") << interfaceName
        << QStringLiteral("-p") << pidFilePath;
    qint64 processId = 0;
    if (!QProcess::startDetached(program, arguments, QString(), &processId)) {
        if (error)
            *error = QStringLiteral("无法启动 udhcpc（%1）。请确认 udhcpc 已安装、PATH 正确且有网络管理权限。")
                         .arg(program);
        return false;
    }
    if (error)
        error->clear();
    return true;
#else
    Q_UNUSED(interfaceName)
    if (error)
        *error = QStringLiteral("当前平台不支持 udhcpc。");
    return false;
#endif
}

bool runWpaCli(const QString &interfaceName,
               const QString &controlDirectory,
               const QStringList &commandArguments,
               int timeoutMs,
               QString *response,
               QString *error)
{
    QString program = QString::fromLocal8Bit(qgetenv("WPA_CLI_PATH"));
    if (program.isEmpty()) {
        const QStringList candidates = QStringList()
            << QStringLiteral("/usr/sbin/wpa_cli")
            << QStringLiteral("/sbin/wpa_cli")
            << QStringLiteral("/usr/bin/wpa_cli")
            << QStringLiteral("/bin/wpa_cli");
        for (const QString &candidate : candidates) {
            if (QFileInfo(candidate).isExecutable()) {
                program = candidate;
                break;
            }
        }
        if (program.isEmpty())
            program = QStringLiteral("wpa_cli"); // Let QProcess search PATH.
    }

    QString cliInterface = interfaceName;
    QString cliControlDirectory = QString::fromLocal8Bit(qgetenv("WPA_CTRL_DIR"));
    const QString explicitSocket = QString::fromLocal8Bit(qgetenv("WPA_CTRL_PATH"));
    if (!explicitSocket.isEmpty()) {
        const QFileInfo socketInfo(explicitSocket);
        cliControlDirectory = socketInfo.path();
        if (!socketInfo.fileName().isEmpty())
            cliInterface = socketInfo.fileName();
    } else if (cliControlDirectory.isEmpty()) {
        cliControlDirectory = controlDirectory;
    }
    if (cliControlDirectory.isEmpty())
        cliControlDirectory = QStringLiteral("/run/wpa_supplicant");

    QStringList arguments;
    arguments << QStringLiteral("-p") << cliControlDirectory
              << QStringLiteral("-i") << cliInterface;
    arguments << commandArguments;

    const bool cleanupCommand = commandArguments.value(0) == QLatin1String("remove_network");
    if (QThread::currentThread()->isInterruptionRequested() && !cleanupCommand) {
        if (error) *error = QStringLiteral("Wi-Fi 操作已取消。");
        return false;
    }
    QProcess process;
    process.start(program, arguments); // No shell: arguments are passed separately.
    if (!process.waitForStarted(2000)) {
        if (error) *error = QStringLiteral("无法启动 wpa_cli（%1）：%2").arg(program, process.errorString());
        return false;
    }
    QByteArray standardOutput, standardError;
    QElapsedTimer elapsed;
    elapsed.start();
    while (process.state() != QProcess::NotRunning) {
        process.waitForFinished(qBound(1, timeoutMs - int(elapsed.elapsed()), 50));
        standardOutput += process.readAllStandardOutput();
        standardError += process.readAllStandardError();
        if (standardOutput.size() > 262144 || standardError.size() > 65536 ||
            elapsed.elapsed() >= timeoutMs ||
            (QThread::currentThread()->isInterruptionRequested() && !cleanupCommand)) {
            process.kill();
            process.waitForFinished(1000);
            if (error) *error = QStringLiteral("wpa_cli 超时、已取消或输出过大：%1").arg(commandArguments.value(0));
            return false;
        }
    }
    standardOutput += process.readAllStandardOutput();
    standardError += process.readAllStandardError();
    const QString output = QString::fromUtf8(standardOutput).trimmed();
    if (response)
        *response = output;

    if (process.exitStatus() != QProcess::NormalExit || process.exitCode() != 0) {
        QString detail = QString::fromLocal8Bit(standardError).trimmed();
        if (detail.isEmpty())
            detail = output;
        if (detail.isEmpty())
            detail = process.errorString();
        if (error)
            *error = QStringLiteral("wpa_cli 命令失败（%1）：%2")
                         .arg(commandArguments.value(0), detail);
        return false;
    }

    if (error)
        error->clear();
    return true;
}

bool wpaCliCommandOk(const QString &interfaceName,
                     const QString &controlDirectory,
                     const QStringList &commandArguments,
                     QString *reason = nullptr)
{
    QString response;
    QString processError;
    if (!runWpaCli(interfaceName, controlDirectory, commandArguments,
                   3000, &response, &processError)) {
        if (reason)
            *reason = processError;
        return false;
    }
    if (response.trimmed() == QStringLiteral("OK"))
        return true;
    if (reason) {
        *reason = response.isEmpty()
                      ? QStringLiteral("wpa_supplicant 未接受网络配置。")
                      : QStringLiteral("wpa_supplicant 返回：%1").arg(response);
    }
    return false;
}

QList<WifiNetwork> parseScanResults(const QString &text)
{
    QMap<QString, WifiNetwork> bestBySsid;
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
    const QStringList lines = text.split(QLatin1Char('\n'), Qt::SkipEmptyParts);
#else
    const QStringList lines = text.split(QLatin1Char('\n'), QString::SkipEmptyParts);
#endif
    for (int i = 1; i < lines.size(); ++i) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
        const QStringList fields = lines.at(i).split(QLatin1Char('\t'), Qt::KeepEmptyParts);
#else
        const QStringList fields = lines.at(i).split(QLatin1Char('\t'), QString::KeepEmptyParts);
#endif
        if (fields.size() < 5)
            continue;
        const QString ssid = decodeWpaSsid(fields.mid(4).join(QStringLiteral("\t")));
        if (ssid.isEmpty())
            continue; // Hidden networks need a manually-entered SSID; not in this first version.

        WifiNetwork network;
        network.ssid = ssid;
        network.signalLevel = fields.at(2).toInt();
        network.flags = fields.at(3);
        const QString upperFlags = network.flags.toUpper();
        const bool hasPsk = upperFlags.contains(QStringLiteral("PSK"));
        const bool hasSecurity = upperFlags.contains(QStringLiteral("WPA")) ||
                                 upperFlags.contains(QStringLiteral("RSN")) ||
                                 upperFlags.contains(QStringLiteral("WEP")) ||
                                 upperFlags.contains(QStringLiteral("EAP")) ||
                                 upperFlags.contains(QStringLiteral("SAE")) ||
                                 upperFlags.contains(QStringLiteral("OWE"));
        network.secured = hasSecurity;
        network.supported = !hasSecurity || hasPsk;

        if (!bestBySsid.contains(ssid) ||
            bestBySsid.value(ssid).signalLevel < network.signalLevel) {
            bestBySsid.insert(ssid, network);
        }
    }

    QList<WifiNetwork> networks = bestBySsid.values();
    std::sort(networks.begin(), networks.end(), [](const WifiNetwork &a, const WifiNetwork &b) {
        return a.signalLevel > b.signalLevel;
    });
    return networks;
}

} // namespace

WifiWorker::WifiWorker(const QString &interfaceName,
                       const QString &controlDirectory,
                       QObject *parent)
    : QObject(parent),
      m_interfaceName(interfaceName),
      m_controlDirectory(controlDirectory),
      m_minimumRequestId(0)
{
}

void WifiWorker::cancelConnectionsBefore(quint64 minimumRequestId)
{
    const QMutexLocker locker(&m_cancelMutex);
    m_minimumRequestId = minimumRequestId;
}

bool WifiWorker::isCancelled(quint64 requestId) const
{
    if (QThread::currentThread()->isInterruptionRequested())
        return true;
    const QMutexLocker locker(&m_cancelMutex);
    return requestId < m_minimumRequestId;
}

bool WifiWorker::removeManagedNetworks(QString *error)
{
    QString response;
    if (!runWpaCli(m_interfaceName, m_controlDirectory,
                   QStringList() << QStringLiteral("list_networks"), 3000, &response, error))
        return false;
    if (!response.startsWith(QStringLiteral("network id"))) {
        if (error)
            *error = QStringLiteral("无法读取 wpa_supplicant 运行期网络列表。");
        return false;
    }
    // The id_str tag survives an application restart (but is never saved to
    // wpa_supplicant.conf). Do not delete another manager's/system's networks.
    const QStringList lines = response.split(QLatin1Char('\n'));
    for (int i = 1; i < lines.size(); ++i) {
        bool ok = false;
        const int number = lines.at(i).section(QLatin1Char('\t'), 0, 0).toInt(&ok);
        if (!ok || number < 0)
            continue;
        const QString id = QString::number(number);
        QString tag;
        QString ignored;
        if (!runWpaCli(m_interfaceName, m_controlDirectory,
                       QStringList() << QStringLiteral("get_network") << id << QStringLiteral("id_str"),
                       2000, &tag, &ignored) || tag != QStringLiteral("\"board_ui_managed\""))
            continue;
        if (!wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                             QStringList() << QStringLiteral("remove_network") << id, error))
            return false;
    }
    m_managedNetworkIds.clear();
    return true;
}

void WifiWorker::forgetManagedNetworks()
{
    QString error;
    if (!removeManagedNetworks(&error))
        emit statusCheckFailed(error);
    checkStatus();
}

void WifiWorker::scan(bool forReconnect)
{
    QString error;
    if (forReconnect) {
        // A native supplicant retry may already have succeeded while the UI
        // timer was waiting. Preserve that stable connection, never roam just
        // because another SSID is stronger.
        QString status;
        if (!runWpaCli(m_interfaceName, m_controlDirectory,
                       QStringList() << QStringLiteral("status"), 2500, &status, &error) ||
            statusValue(status, QStringLiteral("wpa_state")).isEmpty()) {
            emit scanFinished(QList<WifiNetwork>(),
                              error.isEmpty() ? QStringLiteral("Wi-Fi 状态不可用，稍后重试。") : error);
            return;
        }
        if (statusValue(status, QStringLiteral("wpa_state")) == QStringLiteral("COMPLETED")) {
            emit statusChanged(true, decodeWpaSsid(statusValue(status, QStringLiteral("ssid"))),
                               interfaceIpv4Address(m_interfaceName));
            emit scanFinished(QList<WifiNetwork>(), QString());
            return;
        }
        // Stop retrying a stale/weak application profile while choosing the
        // strongest remembered, currently visible network ourselves.
        if (!removeManagedNetworks(&error)) {
            emit scanFinished(QList<WifiNetwork>(), error);
            return;
        }
    }

    WpaControl control(m_interfaceName, m_controlDirectory);
    if (!control.openSocket(&error)) {
        emit scanFinished(QList<WifiNetwork>(), error);
        return;
    }
    const bool attached = control.request(QStringLiteral("ATTACH"), 1500, &error) == QStringLiteral("OK");
    const QString scanResponse = control.request(QStringLiteral("SCAN"), 2500, &error);
    if (scanResponse != QStringLiteral("OK") && !scanResponse.startsWith(QStringLiteral("FAIL-BUSY"))) {
        control.request(QStringLiteral("DETACH"), 500, nullptr);
        emit scanFinished(QList<WifiNetwork>(),
                          error.isEmpty() ? QStringLiteral("扫描命令失败：%1").arg(scanResponse) : error);
        return;
    }
    if (attached)
        control.waitForScanEvent(12000);
    else {
        for (int i = 0; i < 40 && !QThread::currentThread()->isInterruptionRequested(); ++i)
            QThread::msleep(100);
    }
    const QString response = control.request(QStringLiteral("SCAN_RESULTS"), 4000, &error);
    control.request(QStringLiteral("DETACH"), 500, nullptr);
    if (response.startsWith(QStringLiteral("FAIL")) || response.isEmpty()) {
        emit scanFinished(QList<WifiNetwork>(),
                          error.isEmpty() ? QStringLiteral("读取扫描结果失败。") : error);
        return;
    }
    // Deliver an up-to-date link state before scan results, closing the race
    // where a system/native retry connects while a background scan is running.
    checkStatus();
    emit scanFinished(parseScanResults(response), QString());
}

void WifiWorker::connectNetwork(quint64 requestId,
                                const QString &ssid,
                                const QString &password,
                                bool secured)
{
    QString id;
    WpaControl monitor(m_interfaceName, m_controlDirectory);
    bool attached = false;
    auto finishFailure = [&](WifiFailureReason reason, const QString &message) {
        if (!id.isEmpty()) {
            wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                             QStringList() << QStringLiteral("remove_network") << id, nullptr);
            m_managedNetworkIds.removeAll(id);
        }
        if (attached)
            monitor.request(QStringLiteral("DETACH"), 500, nullptr);
        emit connectFinished(requestId, false, ssid, QString(), reason, message);
    };
    if (isCancelled(requestId)) {
        finishFailure(WifiFailureReason::Cancelled, QStringLiteral("连接操作已取消。"));
        return;
    }
    const QByteArray ssidBytes = ssid.toUtf8();
    if (ssidBytes.isEmpty() || ssidBytes.size() > 32) {
        finishFailure(WifiFailureReason::InvalidCredentials, QStringLiteral("Wi-Fi 名称长度必须为 1–32 字节。"));
        return;
    }
    QString error;
    const QString pskValue = secured ? wpaPskValue(password, &error) : QString();
    if (secured && pskValue.isEmpty()) {
        finishFailure(WifiFailureReason::InvalidCredentials, error);
        return;
    }
    if (!removeManagedNetworks(&error)) {
        finishFailure(WifiFailureReason::ControlError, error);
        return;
    }
    // Attach BEFORE SELECT_NETWORK so even a fast WRONG_KEY/TEMP-DISABLED
    // event is captured. Polling STATUS alone cannot identify a bad password.
    if (monitor.openSocket(&error))
        attached = monitor.request(QStringLiteral("ATTACH"), 1500, nullptr) == QStringLiteral("OK");

    QString idText;
    if (!runWpaCli(m_interfaceName, m_controlDirectory,
                   QStringList() << QStringLiteral("add_network"), 3000, &idText, &error)) {
        finishFailure(WifiFailureReason::ControlError, error);
        return;
    }
    bool idOk = false;
    const int networkId = idText.toInt(&idOk);
    if (!idOk || networkId < 0) {
        finishFailure(WifiFailureReason::ControlError, QStringLiteral("wpa_cli 未返回有效网络 ID。"));
        return;
    }
    id = QString::number(networkId);
    m_managedNetworkIds.append(id);
    auto set = [&](const QString &key, const QString &value) {
        return !isCancelled(requestId) &&
               wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                                QStringList() << QStringLiteral("set_network") << id << key << value, &error);
    };
    const bool configured =
        set(QStringLiteral("id_str"), QStringLiteral("\"board_ui_managed\"")) &&
        set(QStringLiteral("ssid"), QString::fromLatin1(ssidBytes.toHex())) &&
        (!secured || set(QStringLiteral("psk"), pskValue)) &&
        set(QStringLiteral("key_mgmt"), secured ? QStringLiteral("WPA-PSK") : QStringLiteral("NONE")) &&
        set(QStringLiteral("priority"), QStringLiteral("10"));
    if (attached)
        monitor.takeEvents(); // Discard removal events from the OLD profile.
    if (!configured || isCancelled(requestId) ||
        !wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                         QStringList() << QStringLiteral("enable_network") << id, &error) ||
        !wpaCliCommandOk(m_interfaceName, m_controlDirectory,
                         QStringList() << QStringLiteral("select_network") << id, &error)) {
        finishFailure(isCancelled(requestId) ? WifiFailureReason::Cancelled : WifiFailureReason::ControlError,
                      error.isEmpty() ? QStringLiteral("配置 Wi-Fi 网络失败或已取消。") : error);
        return;
    }

    bool connected = false;
    QString lastState;
    QString lastError;
    bool gotStatus = false;
    QStringList events;
    WifiFailureReason failure = WifiFailureReason::None;
    const QRegularExpression eventId(QStringLiteral("\\bid=(\\d+)\\b"));
    QElapsedTimer elapsed;
    elapsed.start();
    while (elapsed.elapsed() < 18000 && !isCancelled(requestId)) {
        if (attached)
            events.append(monitor.takeEvents());
        for (const QString &event : events) {
            const QRegularExpressionMatch match = eventId.match(event);
            if (match.hasMatch() && match.captured(1) != id)
                continue; // An event for another network must not erase ours.
            if (event.contains(QStringLiteral("reason=WRONG_KEY")) ||
                event.contains(QStringLiteral("reason=AUTH_FAILED")) ||
                event.contains(QStringLiteral("pre-shared key may be incorrect"))) {
                failure = WifiFailureReason::InvalidCredentials;
                lastError = QStringLiteral("路由器拒绝密码（WRONG_KEY / AUTH_FAILED）。");
                break;
            }
            if (event.contains(QStringLiteral("CTRL-EVENT-ASSOC-REJECT")) ||
                event.contains(QStringLiteral("CTRL-EVENT-AUTH-REJECT"))) {
                failure = WifiFailureReason::ConnectionRejected;
                lastError = QStringLiteral("路由器拒绝关联/认证，请核对密码及路由器设置。");
                break;
            }
            if (event.contains(QStringLiteral("CTRL-EVENT-NETWORK-NOT-FOUND"))) {
                failure = WifiFailureReason::NetworkUnavailable;
                lastError = QStringLiteral("未探测到目标 Wi-Fi，保留密码，等待信号恢复。");
            }
        }
        events.clear();
        if (failure != WifiFailureReason::None)
            break;
        QString status;
        QString statusError;
        if (runWpaCli(m_interfaceName, m_controlDirectory,
                      QStringList() << QStringLiteral("status"), 2500, &status, &statusError)) {
            const QString state = statusValue(status, QStringLiteral("wpa_state"));
            if (!state.isEmpty()) {
                gotStatus = true;
                lastState = state;
            }
            const QString currentSsid = decodeWpaSsid(statusValue(status, QStringLiteral("ssid")));
            const QString currentId = statusValue(status, QStringLiteral("id"));
            if (state == QStringLiteral("COMPLETED") && currentSsid == ssid &&
                (currentId.isEmpty() || currentId == id)) {
                connected = true;
                break;
            }
        } else {
            lastError = statusError;
        }
        if (attached)
            events = monitor.takeEvents(500);
        else
            QThread::msleep(500);
    }

    if (isCancelled(requestId)) {
        finishFailure(WifiFailureReason::Cancelled, QStringLiteral("连接操作已取消。"));
        return;
    }
    if (!connected) {
        if (failure == WifiFailureReason::None) {
            failure = gotStatus ? WifiFailureReason::NetworkUnavailable : WifiFailureReason::ControlError;
            // Only discard credentials on a real failure with the AP STILL
            // visible. Never mistake an AP being powered off for a bad PSK.
            if (gotStatus) {
                WpaControl probe(m_interfaceName, m_controlDirectory);
                QString ignored;
                if (probe.openSocket(&ignored) &&
                    probe.request(QStringLiteral("ATTACH"), 1000) == QStringLiteral("OK")) {
                    const QString scanReply = probe.request(QStringLiteral("SCAN"), 1500);
                    const bool fresh = (scanReply == QStringLiteral("OK") ||
                                        scanReply.startsWith(QStringLiteral("FAIL-BUSY"))) &&
                                       probe.waitForScanEvent(6000);
                    if (fresh) {
                        const QList<WifiNetwork> visible = parseScanResults(
                            probe.request(QStringLiteral("SCAN_RESULTS"), 2000));
                        for (const WifiNetwork &network : visible) {
                            if (network.ssid == ssid) {
                                failure = WifiFailureReason::ConnectionRejected;
                                break;
                            }
                        }
                    }
                    probe.request(QStringLiteral("DETACH"), 500);
                }
            }
            lastError = QStringLiteral("连接超时（wpa_state=%1）。%2")
                            .arg(lastState.isEmpty() ? QStringLiteral("未知") : lastState,
                                 failure == WifiFailureReason::ConnectionRejected
                                     ? QStringLiteral("目标仍可见，请重新输入密码并核对路由器设置。")
                                     : QStringLiteral("信号消失或控制接口暂不可用，保留密码稍后重试。"));
        }
        // A slow association can complete during the diagnostic scan. Check
        // once more before discarding an otherwise valid profile.
        if (failure == WifiFailureReason::ConnectionRejected ||
            failure == WifiFailureReason::NetworkUnavailable) {
            QString finalStatus;
            QString ignored;
            if (runWpaCli(m_interfaceName, m_controlDirectory,
                           QStringList() << QStringLiteral("status"), 2500, &finalStatus, &ignored)) {
                connected = statusValue(finalStatus, QStringLiteral("wpa_state")) == QStringLiteral("COMPLETED") &&
                            decodeWpaSsid(statusValue(finalStatus, QStringLiteral("ssid"))) == ssid &&
                            statusValue(finalStatus, QStringLiteral("id")) == id;
            }
        }
        if (isCancelled(requestId)) {
            finishFailure(WifiFailureReason::Cancelled, QStringLiteral("连接操作已取消。"));
            return;
        }
        if (!connected) {
            finishFailure(failure, lastError);
            return;
        }
    }
    if (attached) {
        monitor.request(QStringLiteral("DETACH"), 500, nullptr);
        attached = false;
    }
    emit statusChanged(true, ssid, QString());
    QString dhcpError;
    const bool dhcpStarted = startUdhcpc(m_interfaceName, &dhcpError);
    QString ipAddress;
    QElapsedTimer dhcpWait;
    dhcpWait.start();
    while (dhcpWait.elapsed() < 20000 && !isCancelled(requestId)) {
        ipAddress = interfaceIpv4Address(m_interfaceName);
        if (!ipAddress.isEmpty() || !dhcpStarted)
            break;
        QThread::msleep(500);
    }
    if (isCancelled(requestId)) {
        finishFailure(WifiFailureReason::Cancelled, QStringLiteral("连接操作已取消。"));
        return;
    }
    const QString message = ipAddress.isEmpty()
        ? QStringLiteral("Wi-Fi 认证成功，但未获取 IPv4；密码已保留。%1")
              .arg(!dhcpStarted ? dhcpError : QStringLiteral("请检查 DHCP 服务和 udhcpc 脚本。"))
        : QStringLiteral("Wi-Fi 已连接，IP：%1。").arg(ipAddress);
    QString finalStatus;
    QString ignored;
    const bool haveFinalStatus = runWpaCli(m_interfaceName, m_controlDirectory,
        QStringList() << QStringLiteral("status"), 2500, &finalStatus, &ignored);
    const QString finalState = statusValue(finalStatus, QStringLiteral("wpa_state"));
    const bool linkLost = haveFinalStatus && !finalState.isEmpty() &&
        (finalState != QStringLiteral("COMPLETED") ||
         decodeWpaSsid(statusValue(finalStatus, QStringLiteral("ssid"))) != ssid);
    if (isCancelled(requestId)) {
        finishFailure(WifiFailureReason::Cancelled, QStringLiteral("连接操作已取消。"));
        return;
    }
    if (linkLost) {
        // Authentication DID succeed: save this valid credential first, then
        // report the later link loss so the UI schedules normal reconnection.
        emit connectFinished(requestId, true, ssid, QString(), WifiFailureReason::None,
                             QStringLiteral("Wi-Fi 认证后信号中断；保留密码并等待自动重连。"));
        emit statusChanged(false, QString(), QString());
        return;
    }
    emit statusChanged(true, ssid, ipAddress);
    emit connectFinished(requestId, true, ssid, ipAddress, WifiFailureReason::None, message);
}

void WifiWorker::checkStatus()
{
    QString response;
    QString error;
    if (!runWpaCli(m_interfaceName, m_controlDirectory,
                   QStringList() << QStringLiteral("status"), 2500, &response, &error)) {
        emit statusCheckFailed(error);
        return;
    }
    const QString state = statusValue(response, QStringLiteral("wpa_state"));
    if (state.isEmpty()) {
        emit statusCheckFailed(QStringLiteral("wpa_supplicant STATUS 无有效状态，稍后重试。"));
        return;
    }
    const bool connected = state == QStringLiteral("COMPLETED");
    emit statusChanged(connected,
                       connected ? decodeWpaSsid(statusValue(response, QStringLiteral("ssid"))) : QString(),
                       connected ? interfaceIpv4Address(m_interfaceName) : QString());
}
