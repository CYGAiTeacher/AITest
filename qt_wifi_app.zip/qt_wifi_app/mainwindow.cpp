#include "mainwindow.h"
#include "cameraworker.h"
#include "canlinksession.h"
#include "modbusworker.h"
#include "ntpsynchronizer.h"
#include "uiicons.h"
#include "uitheme.h"
#include "xiaozhibridge.h"

#include <QApplication>
#include <QAbstractButton>
#include <QAbstractItemView>
#include <QByteArray>
#include <QComboBox>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QDateTime>
#include <QDebug>
#include <QEvent>
#include <QFont>
#include <QFontMetrics>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMetaObject>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QPropertyAnimation>
#include <QResizeEvent>
#include <QSocketNotifier>
#include <QScrollArea>
#include <QScrollBar>
#include <QScroller>
#include <QScrollerProperties>
#include <QSettings>
#include <QSignalBlocker>
#include <QSizePolicy>
#include <QStackedWidget>
#include <QStyle>
#include <QStyledItemDelegate>
#include <QTextCursor>
#include <QStringList>
#include <QTimer>
#include <QtGlobal>
#include <QToolButton>
#include <QVBoxLayout>
#include <QVariant>
#include <QVector>

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <termios.h>
#include <unistd.h>
#include <linux/can.h>
#include <linux/can/raw.h>

namespace {

enum NetworkRoles {
    FlagsRole = Qt::UserRole + 1,
    SignalRole,
    SecuredRole,
    SupportedRole,
    SavedRole
};

bool isValidWpaPasswordFormat(const QString &password, QString *reason)
{
    const QByteArray bytes = password.toUtf8();
    if (bytes.size() == 64) {
        bool allHex = true;
        for (unsigned char c : bytes) {
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
                  (c >= 'A' && c <= 'F'))) {
                allHex = false;
                break;
            }
        }
        if (allHex) {
            if (reason)
                reason->clear();
            return true;
        }
    }

    if (bytes.size() < 8 || bytes.size() > 63) {
        if (reason)
            *reason = QStringLiteral("WPA/WPA2 密码需为 8–63 个 ASCII 字符，或 64 位十六进制 PSK。");
        return false;
    }
    for (unsigned char c : bytes) {
        if (c < 0x20 || c > 0x7e) {
            if (reason)
                *reason = QStringLiteral("WPA/WPA2 密码请使用可见 ASCII 字符。");
            return false;
        }
    }

    if (reason)
        reason->clear();
    return true;
}

QPixmap loadUiPixmap(const QString &resourcePath, const QSize &size)
{
    const QPixmap source(resourcePath);
    return source.isNull() ? QPixmap()
                           : source.scaled(size, Qt::KeepAspectRatio, Qt::SmoothTransformation);
}

class NetworkDelegate : public QStyledItemDelegate
{
public:
    explicit NetworkDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent),
          m_lockIcon(loadUiPixmap(QStringLiteral(":/ui/icons/lock_gray.png"), QSize(20, 20))),
          m_unsupportedLockIcon(loadUiPixmap(QStringLiteral(":/ui/icons/lock_red.png"), QSize(20, 20))),
          m_signal1(loadUiPixmap(QStringLiteral(":/ui/icons/signal_1.png"), QSize(28, 22))),
          m_signal2(loadUiPixmap(QStringLiteral(":/ui/icons/signal_2.png"), QSize(28, 22))),
          m_signal3(loadUiPixmap(QStringLiteral(":/ui/icons/signal_3.png"), QSize(28, 22))),
          m_signal4(loadUiPixmap(QStringLiteral(":/ui/icons/signal_4.png"), QSize(28, 22))),
          m_unsupportedIcon(loadUiPixmap(QStringLiteral(":/ui/icons/unsupported.png"), QSize(14, 14))),
          m_selectedIcon(loadUiPixmap(QStringLiteral(":/ui/icons/selected.png"), QSize(8, 8)))
    {
    }

    QSize sizeHint(const QStyleOptionViewItem &, const QModelIndex &) const override
    {
        return QSize(440, 28);
    }

    void paint(QPainter *painter,
               const QStyleOptionViewItem &option,
               const QModelIndex &index) const override
    {
        painter->save();
        painter->setRenderHint(QPainter::Antialiasing, true);
        painter->setRenderHint(QPainter::TextAntialiasing, true);
        painter->setRenderHint(QPainter::SmoothPixmapTransform, true);

        const QRect row = option.rect.adjusted(1, 1, -1, -1);
        const bool selected = (option.state & QStyle::State_Selected) != 0;
        const bool supported = index.data(SupportedRole).toBool();
        const QColor background = selected ? Theme::ControlBackgroundActive
                                           : Theme::CardBackground;
        const QColor border = selected ? Theme::Accent
                                       : Theme::BorderBase;
        painter->setPen(QPen(border, 1));
        painter->setBrush(background);
        painter->drawRoundedRect(row, 6, 6);

        const QString ssid = index.data(Qt::DisplayRole).toString();
        const bool secured = index.data(SecuredRole).toBool();
        const bool saved = index.data(SavedRole).toBool();
        const int signalLevel = index.data(SignalRole).toInt();
        const int bars = signalLevel >= -55 ? 4 : signalLevel >= -67 ? 3 : signalLevel >= -78 ? 2 : 1;

        int textLeft = row.left() + 10;
        if (secured) {
            const QPixmap &lock = supported ? m_lockIcon : m_unsupportedLockIcon;
            if (!lock.isNull())
                painter->drawPixmap(row.left() + 7, row.top() + 4, lock);
            textLeft = row.left() + 31;
        }

        QFont nameFont = option.font;
        nameFont.setPixelSize(13);
        nameFont.setWeight(QFont::DemiBold);
        painter->setFont(nameFont);
        painter->setPen(supported ? Theme::TextPrimary
                                  : Theme::TextHint);
        const QRect nameRect(textLeft, row.top(), row.right() - textLeft - (saved ? 120 : 70), row.height());
        painter->drawText(nameRect, Qt::AlignVCenter | Qt::AlignLeft,
                          painter->fontMetrics().elidedText(ssid, Qt::ElideRight, nameRect.width()));

        if (saved) {
            QFont badgeFont = option.font;
            badgeFont.setPixelSize(10);
            painter->setFont(badgeFont);
            painter->setPen(Theme::Success);
            painter->drawText(QRect(row.right() - 108, row.top(), 60, row.height()),
                              Qt::AlignCenter, QStringLiteral("已保存"));
        }

        const QPixmap *signal = bars == 4 ? &m_signal4
                                 : bars == 3 ? &m_signal3
                                 : bars == 2 ? &m_signal2
                                             : &m_signal1;
        if (!signal->isNull())
            painter->drawPixmap(row.right() - 39, row.top() + 3, *signal);

        if (!supported && !m_unsupportedIcon.isNull())
            painter->drawPixmap(row.right() - 55, row.top() + 7, m_unsupportedIcon);

        if (selected && !m_selectedIcon.isNull())
            painter->drawPixmap(row.right() - 10, row.center().y() - 4, m_selectedIcon);

        painter->restore();
    }

private:
    QPixmap m_lockIcon;
    QPixmap m_unsupportedLockIcon;
    QPixmap m_signal1;
    QPixmap m_signal2;
    QPixmap m_signal3;
    QPixmap m_signal4;
    QPixmap m_unsupportedIcon;
    QPixmap m_selectedIcon;
};

enum ChatBubbleRoles {
    ChatSideRole = Qt::UserRole + 101,
    ChatSystemRole
};

class ChatBubbleDelegate : public QStyledItemDelegate
{
public:
    explicit ChatBubbleDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent),
          m_assistantAvatar(loadUiPixmap(QStringLiteral(":/ui/icons/robot_blue.png"), QSize(24, 24))),
          m_userAvatar(loadUiPixmap(QStringLiteral(":/ui/icons/board_blue.png"), QSize(24, 24)))
    {
    }

    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const override
    {
        const QString text = index.data(Qt::DisplayRole).toString();
        if (index.data(ChatSystemRole).toBool())
            return QSize(option.rect.width(), 31);
        const int width = option.rect.width() > 0 ? option.rect.width() : 440;
        const int bubbleWidth = qMax(80, qMin(310, width - 64));
        const QFontMetrics metrics(option.font);
        const QRect textRect = metrics.boundingRect(QRect(0, 0, bubbleWidth - 20, 1000),
                                                    Qt::TextWordWrap, text);
        return QSize(width, qMax(42, textRect.height() + 18) + 4);
    }

    void paint(QPainter *painter,
               const QStyleOptionViewItem &option,
               const QModelIndex &index) const override
    {
        painter->save();
        painter->setRenderHint(QPainter::Antialiasing, true);
        painter->setRenderHint(QPainter::TextAntialiasing, true);
        painter->setRenderHint(QPainter::SmoothPixmapTransform, true);

        const QRect area = option.rect.adjusted(4, 2, -4, -2);
        const QString text = index.data(Qt::DisplayRole).toString();
        const QFontMetrics metrics(option.font);
        if (index.data(ChatSystemRole).toBool()) {
            const int textWidth = metrics.boundingRect(QRect(0, 0, area.width() - 24, 200),
                                                       Qt::TextWordWrap, text).width();
            const int bubbleWidth = qMin(area.width() - 12, qMax(80, textWidth + 20));
            const QRect bubble(area.center().x() - bubbleWidth / 2,
                               area.top() + 2, bubbleWidth, 25);
            painter->setPen(Qt::NoPen);
            painter->setBrush(Theme::ControlBackgroundActive);
            painter->drawRoundedRect(bubble, 10, 10);
            painter->setPen(Theme::TextSecondary);
            painter->drawText(bubble.adjusted(8, 0, -8, 0), Qt::AlignCenter | Qt::TextWordWrap, text);
            painter->restore();
            return;
        }

        const bool assistant = index.data(ChatSideRole).toInt() == 0;
        const int maxBubbleWidth = qMax(80, qMin(310, area.width() - 64));
        const QRect measured = metrics.boundingRect(QRect(0, 0, maxBubbleWidth - 20, 1000),
                                                    Qt::TextWordWrap, text);
        const int bubbleWidth = qMin(maxBubbleWidth, qMax(55, measured.width() + 20));
        const int bubbleHeight = qMax(30, measured.height() + 14);
        const int y = area.top() + qMax(2, (area.height() - bubbleHeight) / 2);
        const int avatarX = assistant ? area.left() : area.right() - 23;
        const QRect avatarRect(avatarX, y + 2, 22, 22);
        const int bubbleX = assistant ? area.left() + 30 : area.right() - 30 - bubbleWidth;
        const QRect bubble(bubbleX, y, bubbleWidth, bubbleHeight);

        const QPixmap &avatar = assistant ? m_assistantAvatar : m_userAvatar;
        if (!avatar.isNull())
            painter->drawPixmap(avatarRect, avatar);
        painter->setPen(QPen(Theme::BorderBase, 1));
        painter->setBrush(assistant ? Theme::CardBackground
                                   : Theme::ChatUserBubble);
        painter->drawRoundedRect(bubble, 9, 9);
        painter->setPen(Theme::TextPrimary);
        painter->drawText(bubble.adjusted(9, 6, -9, -6), Qt::AlignLeft | Qt::AlignVCenter |
                          Qt::TextWordWrap, text);
        painter->restore();
    }

private:
    QPixmap m_assistantAvatar;
    QPixmap m_userAvatar;
};

} // namespace

class SensorChart : public QWidget
{
public:
    explicit SensorChart(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        setMinimumHeight(98);
        setMaximumHeight(120);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    }

    QSize sizeHint() const override
    {
        return QSize(440, 108);
    }

    void appendReading(double temperature, double humidity)
    {
        m_temperatures.append(temperature);
        m_humidities.append(humidity);
        if (m_temperatures.size() > 60) {
            m_temperatures.remove(0);
            m_humidities.remove(0);
        }
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setRenderHint(QPainter::TextAntialiasing, true);
        const QRectF card = QRectF(rect()).adjusted(1, 1, -1, -1);
        painter.setPen(QPen(Theme::BorderBase, 1));
        painter.setBrush(Theme::CardBackground);
        painter.drawRoundedRect(card, 11, 11);

        QFont labelFont = font();
        labelFont.setPixelSize(9);
        painter.setFont(labelFont);
        const QColor temperatureColor = Theme::Danger;
        const QColor humidityColor = Theme::Accent;
        painter.setPen(temperatureColor);
        painter.drawText(QRect(12, 4, 86, 17), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("● 温度 °C"));
        painter.setPen(humidityColor);
        painter.drawText(QRect(98, 4, 98, 17), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("● 湿度 %RH"));

        const QRect plot = rect().adjusted(39, 23, -36, -15);
        if (plot.width() < 20 || plot.height() < 20)
            return;
        for (int i = 0; i <= 4; ++i) {
            const int y = plot.top() + i * plot.height() / 4;
            painter.setPen(QPen(Theme::BorderSoft, 1));
            painter.drawLine(plot.left(), y, plot.right(), y);
        }
        painter.setPen(Theme::TextHint);
        painter.drawText(QRect(1, plot.top() - 7, 35, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("60"));
        painter.drawText(QRect(1, plot.center().y() - 7, 35, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("25"));
        painter.drawText(QRect(1, plot.bottom() - 7, 35, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("-10"));
        painter.drawText(QRect(plot.right() + 3, plot.top() - 7, 31, 14), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("100"));
        painter.drawText(QRect(plot.right() + 3, plot.center().y() - 7, 31, 14), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("50"));
        painter.drawText(QRect(plot.right() + 3, plot.bottom() - 7, 31, 14), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("0"));

        if (m_temperatures.isEmpty()) {
            painter.setPen(Theme::TextHint);
            painter.drawText(plot, Qt::AlignCenter, QStringLiteral("等待温湿度数据…"));
            return;
        }

        QPainterPath temperaturePath;
        QPainterPath humidityPath;
        for (int i = 0; i < m_temperatures.size(); ++i) {
            const double x = m_temperatures.size() == 1
                                 ? plot.right()
                                 : plot.left() + static_cast<double>(i) * (plot.width() - 1) /
                                       static_cast<double>(m_temperatures.size() - 1);
            const double tempRatio = qBound(0.0, (m_temperatures.at(i) + 10.0) / 70.0, 1.0);
            const double humidityRatio = qBound(0.0, m_humidities.at(i) / 100.0, 1.0);
            const QPointF tempPoint(x, plot.bottom() - tempRatio * plot.height());
            const QPointF humidityPoint(x, plot.bottom() - humidityRatio * plot.height());
            if (i == 0) {
                temperaturePath.moveTo(tempPoint);
                humidityPath.moveTo(humidityPoint);
            } else {
                temperaturePath.lineTo(tempPoint);
                humidityPath.lineTo(humidityPoint);
            }
        }
        painter.setClipRect(plot.adjusted(-1, -1, 1, 1));
        painter.setPen(QPen(temperatureColor, 2));
        painter.drawPath(temperaturePath);
        painter.setPen(QPen(humidityColor, 2));
        painter.drawPath(humidityPath);
        if (m_temperatures.size() == 1) {
            const double tempY = plot.bottom() - qBound(0.0, (m_temperatures.first() + 10.0) / 70.0, 1.0) * plot.height();
            const double humidityY = plot.bottom() - qBound(0.0, m_humidities.first() / 100.0, 1.0) * plot.height();
            painter.setBrush(temperatureColor);
            painter.drawEllipse(QPointF(plot.right(), tempY), 3, 3);
            painter.setBrush(humidityColor);
            painter.drawEllipse(QPointF(plot.right(), humidityY), 3, 3);
        }
    }

private:
    QVector<double> m_temperatures;
    QVector<double> m_humidities;
};

// ---------------------------------------------------------------------------
// ThemeRowButton —— 主题选择行：整行即预览
// 卡片底色、文字色、左侧三色圆点（背景/强调/成功）全部取自目标主题的
// 调色板，切换前即可看到效果；选中态 = 强调描边 + 右侧对勾。
// ---------------------------------------------------------------------------
class ThemeRowButton : public QPushButton
{
public:
    explicit ThemeRowButton(int themeIndex, QWidget *parent = nullptr)
        : QPushButton(parent),
          m_themeIndex(themeIndex),
          m_selected(false)
    {
        setFixedHeight(40);
        setCursor(Qt::PointingHandCursor);
        setFocusPolicy(Qt::NoFocus);
    }

    void setSelected(bool on)
    {
        if (m_selected != on) {
            m_selected = on;
            update();
        }
    }

    int themeIndex() const { return m_themeIndex; }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setRenderHint(QPainter::TextAntialiasing, true);
        const QColor cardBg = Theme::themePreviewColor(m_themeIndex, Theme::PreviewCard);
        const QColor appBg = Theme::themePreviewColor(m_themeIndex, Theme::PreviewBackground);
        const QColor accent = Theme::themePreviewColor(m_themeIndex, Theme::PreviewAccent);
        const QColor text = Theme::themePreviewColor(m_themeIndex, Theme::PreviewText);
        const QColor success = Theme::themePreviewColor(m_themeIndex, Theme::PreviewSuccess);

        QColor border = text;
        border.setAlpha(70);
        const QRectF card = QRectF(rect()).adjusted(0.5, 0.5, -0.5, -0.5);
        painter.setBrush(cardBg);
        painter.setPen(QPen(m_selected ? accent : border, m_selected ? 2 : 1));
        painter.drawRoundedRect(card, 10, 10);

        // 左侧三色圆点：页面背景 / 强调 / 成功
        const int cy = height() / 2;
        const QColor dots[] = {appBg, accent, success};
        for (int i = 0; i < 3; ++i) {
            painter.setBrush(dots[i]);
            painter.setPen(QPen(border, 1));
            painter.drawEllipse(QPointF(19 + i * 14, cy), 4.5, 4.5);
        }

        QFont nameFont = font();
        nameFont.setPixelSize(12);
        nameFont.setBold(true);
        painter.setFont(nameFont);
        painter.setPen(text);
        painter.drawText(QRect(62, 5, width() - 130, 16), Qt::AlignVCenter | Qt::AlignLeft,
                         Theme::themeName(m_themeIndex));

        QColor sub = text;
        sub.setAlpha(160);
        QFont descFont = font();
        descFont.setPixelSize(9);
        painter.setFont(descFont);
        painter.setPen(sub);
        painter.drawText(QRect(62, 22, width() - 130, 14), Qt::AlignVCenter | Qt::AlignLeft,
                         Theme::themeDesc(m_themeIndex));

        if (m_selected) {
            painter.setBrush(success);
            painter.setPen(Qt::NoPen);
            painter.drawEllipse(QPointF(width() - 21, cy), 7.5, 7.5);
            painter.setPen(QPen(Qt::white, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.drawLine(QPointF(width() - 24.5, cy), QPointF(width() - 21.5, cy + 3));
            painter.drawLine(QPointF(width() - 21.5, cy + 3), QPointF(width() - 17, cy - 3));
        }
    }

private:
    int m_themeIndex;
    bool m_selected;
};

// ---------------------------------------------------------------------------
// LoadChart —— 主页 CPU / 内存使用率曲线（0~100% 双序列）
// 与 SensorChart 同风格：卡片背景 + 图例 + 网格 + 折线，60 个采样点滚动。
// ---------------------------------------------------------------------------
class LoadChart : public QWidget
{
public:
    explicit LoadChart(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        setFixedHeight(118);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    }

    void appendReading(double cpuPercent, double memPercent)
    {
        m_cpu.append(qBound(0.0, cpuPercent, 100.0));
        m_mem.append(qBound(0.0, memPercent, 100.0));
        if (m_cpu.size() > 60) {
            m_cpu.remove(0);
            m_mem.remove(0);
        }
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setRenderHint(QPainter::TextAntialiasing, true);
        const QRectF card = QRectF(rect()).adjusted(1, 1, -1, -1);
        painter.setPen(QPen(Theme::BorderBase, 1));
        painter.setBrush(Theme::CardBackground);
        painter.drawRoundedRect(card, 11, 11);

        const int labelFontPx = 9;
        QFont labelFont = font();
        labelFont.setPixelSize(labelFontPx);
        painter.setFont(labelFont);
        const QColor cpuColor = Theme::Danger;
        const QColor memColor = Theme::Accent;
        painter.setPen(cpuColor);
        painter.drawText(QRect(12, 4, 74, 17), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("● CPU %"));
        painter.setPen(memColor);
        painter.drawText(QRect(88, 4, 92, 17), Qt::AlignLeft | Qt::AlignVCenter,
                         QStringLiteral("● 内存 %"));

        // 右上角实时读数
        if (!m_cpu.isEmpty()) {
            QFont valueFont = font();
            valueFont.setPixelSize(10);
            valueFont.setBold(true);
            painter.setFont(valueFont);
            painter.setPen(Theme::TextPrimary);
            painter.drawText(QRect(width() - 150, 3, 138, 17), Qt::AlignRight | Qt::AlignVCenter,
                             QStringLiteral("CPU %1% · 内存 %2%")
                                 .arg(QString::number(m_cpu.last(), 'f', 0),
                                      QString::number(m_mem.last(), 'f', 0)));
            painter.setFont(labelFont);
        }

        const QRect plot = rect().adjusted(30, 23, -10, -10);
        if (plot.width() < 20 || plot.height() < 20)
            return;
        for (int i = 0; i <= 4; ++i) {
            const int y = plot.top() + i * plot.height() / 4;
            painter.setPen(QPen(Theme::BorderSoft, 1));
            painter.drawLine(plot.left(), y, plot.right(), y);
        }
        painter.setPen(Theme::TextHint);
        painter.drawText(QRect(0, plot.top() - 7, 26, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("100"));
        painter.drawText(QRect(0, plot.center().y() - 7, 26, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("50"));
        painter.drawText(QRect(0, plot.bottom() - 7, 26, 14), Qt::AlignRight | Qt::AlignVCenter,
                         QStringLiteral("0"));

        if (m_cpu.isEmpty()) {
            painter.setPen(Theme::TextHint);
            painter.drawText(plot, Qt::AlignCenter, QStringLiteral("采样中…"));
            return;
        }

        auto buildPath = [&](const QVector<double> &values) {
            QPainterPath path;
            for (int i = 0; i < values.size(); ++i) {
                const double x = values.size() == 1
                                     ? plot.right()
                                     : plot.left() + static_cast<double>(i) * (plot.width() - 1) /
                                           static_cast<double>(values.size() - 1);
                const double ratio = qBound(0.0, values.at(i) / 100.0, 1.0);
                const QPointF point(x, plot.bottom() - ratio * plot.height());
                if (i == 0)
                    path.moveTo(point);
                else
                    path.lineTo(point);
            }
            return path;
        };

        painter.setClipRect(plot.adjusted(-1, -1, 1, 1));
        painter.setPen(QPen(cpuColor, 2));
        painter.drawPath(buildPath(m_cpu));
        painter.setPen(QPen(memColor, 2));
        painter.drawPath(buildPath(m_mem));
        if (m_cpu.size() == 1) {
            painter.setBrush(cpuColor);
            painter.drawEllipse(QPointF(plot.right(),
                                        plot.bottom() - qBound(0.0, m_cpu.first() / 100.0, 1.0) * plot.height()),
                                3, 3);
            painter.setBrush(memColor);
            painter.drawEllipse(QPointF(plot.right(),
                                        plot.bottom() - qBound(0.0, m_mem.first() / 100.0, 1.0) * plot.height()),
                                3, 3);
        }
    }

private:
    QVector<double> m_cpu;
    QVector<double> m_mem;
};

// ---------------------------------------------------------------------------
// FeatureTilePager —— 横向滑动卡片分页器
// 每屏显示固定数量功能卡片，其余分页；手指左右滑动翻页，松手后自动
// 吸附到最近页，底部圆点指示当前页。QScroller 处理触摸/鼠标手势，
// 短按仍会正常触发卡片点击。
// ---------------------------------------------------------------------------
class FeatureTilePager : public QWidget
{
public:
    explicit FeatureTilePager(QWidget *parent = nullptr)
        : QWidget(parent),
          m_pageCount(0),
          m_currentPage(0)
    {
        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(2);

        m_scroll = new QScrollArea(this);
        m_scroll->setFrameShape(QFrame::NoFrame);
        m_scroll->setContentsMargins(0, 0, 0, 0);
        m_scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        m_scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        m_scroll->setWidgetResizable(false);

        m_strip = new QWidget;
        m_stripLayout = new QHBoxLayout(m_strip);
        m_stripLayout->setContentsMargins(0, 0, 0, 0);
        m_stripLayout->setSpacing(0);
        m_scroll->setWidget(m_strip);
        layout->addWidget(m_scroll, 1);
        // 视口自绘 + 不透明：拖动时不再反复混色重绘背景，跟手更顺
        m_scroll->viewport()->setAutoFillBackground(true);
        m_scroll->viewport()->setAttribute(Qt::WA_OpaquePaintEvent, true);

        QWidget *dotsRow = new QWidget(this);
        m_dotsLayout = new QHBoxLayout(dotsRow);
        m_dotsLayout->setContentsMargins(0, 0, 0, 0);
        m_dotsLayout->setSpacing(5);
        layout->addWidget(dotsRow, 0);
        dotsRow->setFixedHeight(10);

        QScroller *scroller = QScroller::scroller(m_scroll->viewport());
        QScroller::grabGesture(m_scroll->viewport(), QScroller::TouchGesture);
        QScroller::grabGesture(m_scroll->viewport(), QScroller::LeftMouseButtonGesture);
        QScrollerProperties props = scroller->scrollerProperties();
        props.setScrollMetric(QScrollerProperties::HorizontalOvershootPolicy,
                              QScrollerProperties::OvershootAlwaysOff);
        props.setScrollMetric(QScrollerProperties::VerticalOvershootPolicy,
                              QScrollerProperties::OvershootAlwaysOff);
        props.setScrollMetric(QScrollerProperties::OvershootDragDistanceFactor, 0.0);
        props.setScrollMetric(QScrollerProperties::OvershootScrollDistanceFactor, 0.0);
        // 关键：关闭惯性滑动。默认值下松手会先“漂”一段再由吸附弹回，
        // 两个动画叠在一起就是末尾一顿一顿的卡顿感。阈值调高后，
        // 松手立即进入下面的吸附翻页动画，干脆利落。
        props.setScrollMetric(QScrollerProperties::MinimumVelocity, 1000.0);
        props.setScrollMetric(QScrollerProperties::DecelerationFactor, 0.05);
        props.setScrollMetric(QScrollerProperties::DragStartDistance, 0.002);
        props.setScrollMetric(QScrollerProperties::MousePressEventDelay, 0.05);
        scroller->setScrollerProperties(props);

        m_snapAnimation = new QPropertyAnimation(m_scroll->horizontalScrollBar(), "value", this);
        m_snapAnimation->setEasingCurve(QEasingCurve::OutCubic);
        m_snapAnimation->setDuration(180);

        connect(scroller, &QScroller::stateChanged, this, [this](QScroller::State state) {
            if (state == QScroller::Pressed) {
                m_snapAnimation->stop();
                m_pressScrollValue = m_scroll->horizontalScrollBar()->value();
            } else if (state == QScroller::Dragging) {
                m_snapAnimation->stop();
            } else if (state == QScroller::Inactive) {
                QTimer::singleShot(0, this, [this]() { snapToNearestPage(); });
            }
        });
    }

    void setCards(const QList<QToolButton *> &cards, int cardsPerPage)
    {
        while (QLayoutItem *item = m_stripLayout->takeAt(0)) {
            if (QWidget *w = item->widget())
                delete w;
            delete item;
        }
        m_pageCount = cards.isEmpty() ? 0 : (cards.size() + cardsPerPage - 1) / cardsPerPage;
        m_currentPage = 0;

        for (int page = 0; page < m_pageCount; ++page) {
            QWidget *pageWidget = new QWidget(m_strip);
            QHBoxLayout *pageLayout = new QHBoxLayout(pageWidget);
            pageLayout->setContentsMargins(3, 2, 3, 2);
            pageLayout->setSpacing(8);
            const int begin = page * cardsPerPage;
            const int end = qMin(begin + cardsPerPage, cards.size());
            for (int i = begin; i < end; ++i) {
                cards.at(i)->setParent(pageWidget);
                pageLayout->addWidget(cards.at(i), 1);
            }
            // 末页不足整页时用空白填充，保持卡片尺寸与其他页一致
            for (int i = end - begin; i < cardsPerPage; ++i)
                pageLayout->addStretch(1);
            m_stripLayout->addWidget(pageWidget);
        }

        rebuildDots();
        relayoutStrip();
    }

    // 主题切换后，圆点高亮色取自 Theme（内联样式）——提供统一刷新入口
    void refreshColors()
    {
        updateDots();
    }

protected:
    void resizeEvent(QResizeEvent *event) override
    {
        QWidget::resizeEvent(event);
        relayoutStrip();
    }

    void showEvent(QShowEvent *event) override
    {
        QWidget::showEvent(event);
        relayoutStrip();
    }

private:
    int pageWidth() const
    {
        return m_scroll->viewport()->width();
    }

    void relayoutStrip()
    {
        const int w = pageWidth();
        if (w <= 0 || m_pageCount == 0)
            return;
        for (int i = 0; i < m_pageCount; ++i) {
            if (QWidget *page = m_stripLayout->itemAt(i) ? m_stripLayout->itemAt(i)->widget() : nullptr)
                page->setFixedWidth(w);
        }
        m_strip->setFixedSize(m_pageCount * w, m_scroll->viewport()->height());
        m_scroll->horizontalScrollBar()->setValue(m_currentPage * w);
    }

    void snapToNearestPage()
    {
        const int w = pageWidth();
        if (w <= 0 || m_pageCount == 0)
            return;
        QScrollBar *bar = m_scroll->horizontalScrollBar();
        // 按手势方向翻页：拖过阈值即翻向下一页，不再等滑动过半，
        // 也不会因为松手位置略偏而被弹回 —— 快速轻滑同样有效
        const int startPage = qBound(0, qRound(qreal(m_pressScrollValue) / qreal(w)),
                                     m_pageCount - 1);
        const int delta = bar->value() - m_pressScrollValue;
        const int threshold = qMax(18, w / 8);
        int target;
        if (delta > threshold)
            target = startPage + 1;
        else if (delta < -threshold)
            target = startPage - 1;
        else
            target = startPage;
        target = qBound(0, target, m_pageCount - 1);
        if (bar->value() != target * w) {
            m_snapAnimation->stop();
            m_snapAnimation->setStartValue(bar->value());
            m_snapAnimation->setEndValue(target * w);
            m_snapAnimation->start();
        }
        setCurrentPage(target);
    }

    void setCurrentPage(int page)
    {
        if (page == m_currentPage)
            return;
        m_currentPage = page;
        updateDots();
    }

    void rebuildDots()
    {
        while (QLayoutItem *item = m_dotsLayout->takeAt(0)) {
            if (QWidget *w = item->widget())
                delete w;
            delete item;
        }
        m_dots.clear();
        m_dotsLayout->addStretch(1);
        for (int i = 0; i < m_pageCount; ++i) {
            QLabel *dot = new QLabel(this);
            dot->setFixedSize(8, 8);
            m_dotsLayout->addWidget(dot);
            m_dots.append(dot);
        }
        m_dotsLayout->addStretch(1);
        updateDots();
    }

    void updateDots()
    {
        for (int i = 0; i < m_dots.size(); ++i) {
            m_dots.at(i)->setStyleSheet(QStringLiteral("background:%1; border-radius:4px;")
                                            .arg(i == m_currentPage ? Theme::AccentHex
                                                                    : Theme::BorderHoverHex));
        }
    }

    QScrollArea *m_scroll;
    QWidget *m_strip;
    QHBoxLayout *m_stripLayout;
    QHBoxLayout *m_dotsLayout;
    QList<QLabel *> m_dots;
    QPropertyAnimation *m_snapAnimation;
    int m_pressScrollValue = 0;
    int m_pageCount;
    int m_currentPage;
};

MainWindow::MainWindow(const QString &interfaceName,
                       const QString &controlDirectory,
                       QWidget *parent)
    : QWidget(parent),
      m_stack(nullptr),
      m_homePage(nullptr),
      m_wifiPage(nullptr),
      m_peripheralPage(nullptr),
      m_peripheralPageStack(nullptr),
      m_peripheralHubPage(nullptr),
      m_audioTestPage(nullptr),
      m_xiaozhiPage(nullptr),
      m_rs485Page(nullptr),
      m_cameraTestPage(nullptr),
      m_sensorPage(nullptr),
      m_wifiPageStack(nullptr),
      m_scanPage(nullptr),
      m_passwordPage(nullptr),
      m_wifiHeader(nullptr),
      m_actionBar(nullptr),
      m_passwordActionBar(nullptr),
      m_passwordFooterSpacer(nullptr),
      m_keyboardPanel(nullptr),
      m_keyboardSsid(nullptr),
      m_shiftButton(nullptr),
      m_modeButton(nullptr),
      m_backspaceButton(nullptr),
      m_doneButton(nullptr),
      m_keyboardVisible(false),
      m_keyboardMode(0),
      m_capsLock(false),
      m_clockDate(nullptr),
      m_clockTime(nullptr),
      m_wifiStatusButton(nullptr),
      m_wifiTopStatus(nullptr),
      m_wifiTopIp(nullptr),
      m_homeMessage(nullptr),
      m_scanButton(nullptr),
      m_networkList(nullptr),
      m_scanInfo(nullptr),
      m_passwordLabel(nullptr),
      m_passwordEdit(nullptr),
      m_passwordToggle(nullptr),
      m_keyboardButton(nullptr),
      m_wifiMessage(nullptr),
      m_passwordMessage(nullptr),
      m_skipButton(nullptr),
      m_connectButton(nullptr),
      m_passwordBackButton(nullptr),
      m_passwordConnectButton(nullptr),
      m_audioStatus(nullptr),
      m_recordButton(nullptr),
      m_musicButton(nullptr),
      m_xiaozhiStatus(nullptr),
      m_xiaozhiToggleButton(nullptr),
      m_xiaozhiActivationPanel(nullptr),
      m_xiaozhiActivationTitleLabel(nullptr),
      m_xiaozhiActivationCodeCaption(nullptr),
      m_xiaozhiActivationCodeLabel(nullptr),
      m_xiaozhiActivationInstructionsLabel(nullptr),
      m_xiaozhiActivationMessage(nullptr),
      m_xiaozhiActivationCode(),
      m_xiaozhiActivated(false),
      m_xiaozhiAudioReady(false),
      m_xiaozhiOnline(false),
      m_xiaozhiManualRestartHint(false),
      m_chatList(nullptr),
      m_streamingAssistantText(),
      m_streamingAssistantRow(-1),
      m_rs485Status(nullptr),
      m_temperatureValue(nullptr),
      m_humidityValue(nullptr),
      m_rs485RetryButton(nullptr),
      m_ledButton(nullptr),
      m_buzzerButton(nullptr),
      m_sensorChart(nullptr),
      m_cameraView(nullptr),
      m_cameraStatus(nullptr),
      m_cameraToggleButton(nullptr),
      m_cameraInfo(nullptr),
      m_cameraWorker(nullptr),
      m_cameraRunning(false),
      m_cameraStartPending(false),
      m_cameraStopPending(false),
      m_sensorStatus(nullptr),
      m_sensorGrid(nullptr),
      m_sensorGridHost(nullptr),
      m_sensorTimer(nullptr),
      m_sensorPollWorker(nullptr),
      m_sensorPollGeneration(0),
      m_sensorPollBusy(false),
      m_sensorInFlightGeneration(0),
      m_canTestPage(nullptr),
      m_canIfCombo(nullptr),
      m_canBitrateCombo(nullptr),
      m_canToggleButton(nullptr),
      m_canIdEdit(nullptr),
      m_canDataEdit(nullptr),
      m_canSendButton(nullptr),
      m_canLogView(nullptr),
      m_canStatusLabel(nullptr),
      m_canFd(-1),
      m_canNotifier(nullptr),
      m_canSession(nullptr),
      m_selfTestCanSession(nullptr),
      m_loadChart(nullptr),
      m_hubPager(nullptr),
      m_loadTimer(nullptr),
      m_prevCpuTotal(0),
      m_prevCpuIdle(0),
      m_selfTestPage(nullptr),
      m_selfTestButton(nullptr),
      m_selfTestSummary(nullptr),
      m_selfTestIndex(-1),
      m_selfTestPassed(0),
      m_selfTestRunning(false),
      m_selfTestGeneration(0),
      m_selfTestItemDone(true),
      m_selfTestTimeout(nullptr),
      m_selfTestCamera(nullptr),
      m_selfTestAudio(nullptr),
      m_selfTestSerialFd(-1),
      m_selfTestSerialNotifier(nullptr),
      m_selfTestSerialEcho(false),
      m_selfTestSerialTermiosSaved(false),
      m_selfTestCanFd(-1),
      m_selfTestCanNotifier(nullptr),
      m_themePage(nullptr),
      m_themeCurrentLabel(nullptr),
      m_factoryResetButton(nullptr),
      m_factoryResetStatus(nullptr),
      m_factoryResetTimer(nullptr),
      m_factoryResetArmed(false),
      m_audioTempDirectory(QDir::tempPath() + QStringLiteral("/board-ui-XXXXXX")),
      m_recordKillTimer(nullptr),
      m_playKillTimer(nullptr),
      m_recordStopRequested(false),
      m_recordForceKilled(false),
      m_recordProcess(nullptr),
      m_playProcess(nullptr),
      m_xiaozhiBridge(nullptr),
      m_modbusWorker(nullptr),
      m_musicFilePath(QStringLiteral("/music.wav")),
      m_recordingPath(),
      m_captureDevice(QStringLiteral("default")),
      m_playbackDevice(QStringLiteral("default")),
      m_arecordProgram(QStringLiteral("arecord")),
      m_aplayProgram(QStringLiteral("aplay")),
      m_playPurpose(),
      m_audioSampleRate(16000),
      m_autoPlayAfterRecord(false),
      m_playStopRequested(false),
      m_worker(nullptr),
      m_ntpWorker(nullptr),
      m_clockTimer(nullptr),
      m_statusTimer(nullptr),
      m_reconnectTimer(nullptr),
      m_timeSyncRetryTimer(nullptr),
      m_connectionAnimationTimer(nullptr),
      m_xiaozhiReadyHintTimer(nullptr),
      m_connectionAnimationFrame(0),
      m_connectionRequestId(0),
      m_interfaceName(interfaceName),
      m_controlDirectory(controlDirectory),
      m_ipAddress(),
      m_beijingUtcMilliseconds(0),
      m_timeSyncInProgress(false),
      m_timeSynchronized(false),
      m_setupComplete(false),
      m_hasCredentials(false),
      m_savePendingCredentials(false),
      m_autoConnection(false),
      m_wifiConnected(false),
      m_statusBusy(false),
      m_backgroundScan(false),
      m_autoReconnectSuspended(false),
      m_scanBusy(false),
      m_connectionBusy(false),
      m_showPassword(false)
{
    setObjectName(QStringLiteral("appRoot"));
    setWindowTitle(QStringLiteral("开发板 Wi-Fi 设置"));
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setFixedSize(480, 272);
    setAttribute(Qt::WA_StyledBackground, true);
    setAutoFillBackground(true);

    // 主页 CPU/内存曲线：每秒采样一次 /proc 统计
    m_loadTimer = new QTimer(this);
    m_loadTimer->setInterval(1000);
    connect(m_loadTimer, &QTimer::timeout, this, &MainWindow::sampleSystemLoad);
    m_loadTimer->start();
    sampleSystemLoad();

    setStyleSheet(Theme::styleSheet());

    m_stack = new QStackedWidget(this);
    m_stack->setFrameShape(QFrame::NoFrame);
    m_stack->setContentsMargins(0, 0, 0, 0);
    m_homePage = createHomePage();
    m_wifiPage = createWifiPage();
    m_peripheralPage = createPeripheralPage();
    m_stack->addWidget(m_homePage);
    m_stack->addWidget(m_wifiPage);
    m_stack->addWidget(m_peripheralPage);
    QVBoxLayout *rootLayout = new QVBoxLayout(this);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);
    rootLayout->addWidget(m_stack);

    for (QLabel *label : findChildren<QLabel *>()) label->setTextFormat(Qt::PlainText);
    qRegisterMetaType<QList<WifiNetwork> >("QList<WifiNetwork>");
    qRegisterMetaType<WifiFailureReason>("WifiFailureReason");
    m_worker = new WifiWorker(m_interfaceName, m_controlDirectory);
    m_worker->moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(this, &MainWindow::scanRequested, m_worker, &WifiWorker::scan, Qt::QueuedConnection);
    connect(this, &MainWindow::connectRequested, m_worker, &WifiWorker::connectNetwork, Qt::QueuedConnection);
    connect(this, &MainWindow::statusRequested, m_worker, &WifiWorker::checkStatus, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::scanFinished, this, &MainWindow::onScanFinished, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::connectFinished, this, &MainWindow::onConnectFinished, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::statusChanged, this, &MainWindow::onStatusChanged, Qt::QueuedConnection);
    connect(m_worker, &WifiWorker::statusCheckFailed, this, &MainWindow::onStatusCheckFailed, Qt::QueuedConnection);
    connect(this, &MainWindow::forgetWifiNetworksRequested,
            m_worker, &WifiWorker::forgetManagedNetworks, Qt::QueuedConnection);
    m_workerThread.setObjectName(QStringLiteral("wpa-control-worker"));
    m_workerThread.start();

    m_ntpWorker = new NtpSynchronizer;
    m_ntpWorker->moveToThread(&m_ntpThread);
    connect(&m_ntpThread, &QThread::finished, m_ntpWorker, &QObject::deleteLater);
    connect(this, &MainWindow::timeSyncRequested,
            m_ntpWorker, &NtpSynchronizer::synchronize, Qt::QueuedConnection);
    connect(m_ntpWorker, &NtpSynchronizer::synchronizationFinished,
            this, &MainWindow::onTimeSyncFinished, Qt::QueuedConnection);
    m_ntpThread.setObjectName(QStringLiteral("internet-time-sync"));
    m_ntpThread.start();

    m_recordingPath = m_audioTempDirectory.isValid()
        ? m_audioTempDirectory.filePath(QStringLiteral("recording.wav")) : QString();
    m_selfTestAudioPath = m_audioTempDirectory.isValid()
        ? m_audioTempDirectory.filePath(QStringLiteral("selftest.wav")) : QString();
    const QString captureDevice = QString::fromLocal8Bit(qgetenv("AUDIO_CAPTURE_DEVICE"));
    const QString playbackDevice = QString::fromLocal8Bit(qgetenv("AUDIO_PLAYBACK_DEVICE"));
    const QString arecordProgram = QString::fromLocal8Bit(qgetenv("ARECORD_PATH"));
    const QString aplayProgram = QString::fromLocal8Bit(qgetenv("APLAY_PATH"));
    const QString recordingFile = QString::fromLocal8Bit(qgetenv("AUDIO_RECORD_PATH"));
    const QString sampleRate = QString::fromLocal8Bit(qgetenv("AUDIO_SAMPLE_RATE"));
    if (!captureDevice.isEmpty()) m_captureDevice = captureDevice;
    if (!playbackDevice.isEmpty()) m_playbackDevice = playbackDevice;
    if (!arecordProgram.isEmpty()) m_arecordProgram = arecordProgram;
    if (!aplayProgram.isEmpty()) m_aplayProgram = aplayProgram;
    if (!recordingFile.isEmpty()) m_recordingPath = recordingFile;
    if (!sampleRate.isEmpty()) {
        bool ok = false;
        const int rate = sampleRate.toInt(&ok);
        if (ok && rate >= 8000 && rate <= 96000)
            m_audioSampleRate = rate;
    }

    m_recordKillTimer = new QTimer(this);
    m_recordKillTimer->setSingleShot(true);
    connect(m_recordKillTimer, &QTimer::timeout, this, [this]() {
        if (m_recordStopRequested && m_recordProcess->state() != QProcess::NotRunning) {
            m_recordForceKilled = true;
            m_recordProcess->kill();
        }
    });
    m_playKillTimer = new QTimer(this);
    m_playKillTimer->setSingleShot(true);
    connect(m_playKillTimer, &QTimer::timeout, this, [this]() {
        if (m_playStopRequested && m_playProcess->state() != QProcess::NotRunning)
            m_playProcess->kill();
    });
    m_recordProcess = new QProcess(this);
    m_recordProcess->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_recordProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        m_recordProcess->readAllStandardOutput();
    });
    connect(m_recordProcess, &QProcess::started, this, [this]() {
        m_audioStatus->setText(QStringLiteral("录音中 · 再按一次停止并自动回放"));
        updateAudioControls();
    });
    connect(m_recordProcess,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &MainWindow::onRecordProcessFinished);
    connect(m_recordProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            m_autoPlayAfterRecord = false;
            m_recordStopRequested = false;
            m_recordKillTimer->stop();
            m_audioStatus->setText(QStringLiteral("无法启动 arecord：请安装 ALSA 工具并检查路径"));
            updateAudioControls();
        }
    });

    m_playProcess = new QProcess(this);
    m_playProcess->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_playProcess, &QProcess::readyReadStandardOutput, this, [this]() {
        m_playProcess->readAllStandardOutput();
    });
    connect(m_playProcess,
            QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &MainWindow::onPlaybackProcessFinished);
    connect(m_playProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            m_playStopRequested = false;
            m_playKillTimer->stop();
            m_audioStatus->setText(QStringLiteral("无法启动 aplay：请安装 ALSA 工具并检查路径"));
            updateAudioControls();
        }
    });

    m_xiaozhiBridge = new XiaozhiBridge(this);
    connect(m_xiaozhiBridge, &XiaozhiBridge::statusChanged, this, [this](const QString &status) {
        const bool restarting = status.contains(QStringLiteral("自动恢复")) ||
                                status.contains(QStringLiteral("核心退出")) ||
                                status.contains(QStringLiteral("核心已退出")) ||
                                status.contains(QStringLiteral("无法启动小智核心")) ||
                                status.contains(QStringLiteral("连续启动失败"));
        if (restarting) {
            m_xiaozhiOnline = false;
            if (!m_xiaozhiActivated) {
                m_xiaozhiActivationCode.clear();
                if (m_xiaozhiActivationCodeLabel)
                    m_xiaozhiActivationCodeLabel->setText(QStringLiteral("等待激活码"));
            }
        }
        if (m_xiaozhiStatus)
            m_xiaozhiStatus->setText(status);
        if (m_xiaozhiToggleButton) {
            m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isActive()
                                               ? QStringLiteral("停止小智")
                                               : QStringLiteral("启动小智"));
        }
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::networkUnavailable, this, [this](const QString &detail) {
        resetXiaozhiSessionUi(XiaozhiBridge::networkUnavailableMessage());
        m_xiaozhiActivationMessage->setToolTip(detail);
        showHomeMessage(XiaozhiBridge::networkUnavailableMessage(), true);
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::activeChanged, this, [this](bool active) {
        m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isStopping() ? QStringLiteral("正在停止…")
            : active ? QStringLiteral("停止小智") : QStringLiteral("启动小智"));
        m_xiaozhiToggleButton->setEnabled(!m_xiaozhiBridge->isStopping());
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::chatTextReceived,
            this, &MainWindow::onXiaozhiTextReceived);
    connect(m_xiaozhiBridge, &XiaozhiBridge::userSpeechTextReceived, this, [this](const QString &text) {
        const QString userText = text.trimmed();
        if (!userText.isEmpty())
            addChatBubble(userText, false, false);
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::toastReceived, this, [this](const QString &text) {
        if (text.contains(QStringLiteral("设备已激活"))) {
            m_xiaozhiActivated = true;
            m_xiaozhiActivationCode.clear();
            if (m_xiaozhiActivationCodeLabel)
                m_xiaozhiActivationCodeLabel->setText(QStringLiteral("已完成绑定"));
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(QStringLiteral("设备已绑定 · 正在初始化音频并连接云端…"));
        } else if (m_xiaozhiStatus && !text.isEmpty()) {
            m_xiaozhiStatus->setText(text);
        }
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::activationCodeReceived, this, [this](const QString &code) {
        m_xiaozhiActivationCode = code.trimmed();
        m_xiaozhiActivated = false;
        m_xiaozhiOnline = false;
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(m_xiaozhiActivationCode.isEmpty()
                                                      ? QStringLiteral("等待激活码")
                                                      : m_xiaozhiActivationCode);
        if (m_xiaozhiStatus)
            m_xiaozhiStatus->setText(m_xiaozhiActivationCode.isEmpty()
                                         ? QStringLiteral("等待设备激活码")
                                         : QStringLiteral("设备激活码：%1").arg(m_xiaozhiActivationCode));
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::coreStateChanged, this, [this](int state) {
        if (state == 3) {
            m_xiaozhiActivated = true;
            m_xiaozhiOnline = true;
            m_xiaozhiActivationCode.clear();
            if (m_xiaozhiActivationCodeLabel)
                m_xiaozhiActivationCodeLabel->setText(QStringLiteral("已完成绑定"));
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(m_xiaozhiAudioReady
                                             ? QStringLiteral("小智已就绪 · 现在可以开始对话")
                                             : QStringLiteral("云端已连接 · 正在确认麦克风和扬声器就绪"));
        } else if (state == 4) {
            m_xiaozhiOnline = false;
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(m_xiaozhiActivated
                                             ? QStringLiteral("云端连接中断 · 小智核心正在尝试恢复")
                                             : QStringLiteral("小智网络断开"));
        } else if (state == 5) {
            m_xiaozhiActivated = true;
            m_xiaozhiOnline = true;
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(QStringLiteral("正在聆听本地麦克风…"));
        } else if (state == 6) {
            m_xiaozhiActivated = true;
            m_xiaozhiOnline = true;
            if (m_xiaozhiStatus)
                m_xiaozhiStatus->setText(QStringLiteral("小智正在说话…"));
        }
        updateXiaozhiActivationView();
    });
    connect(m_xiaozhiBridge, &XiaozhiBridge::audioReadyChanged, this, [this](bool ready) {
        m_xiaozhiAudioReady = ready;
        if (m_xiaozhiStatus && m_xiaozhiOnline) {
            const QString currentStatus = m_xiaozhiStatus->text();
            if (ready) {
                if (!currentStatus.contains(QStringLiteral("聆听")) &&
                    !currentStatus.contains(QStringLiteral("说话")))
                    m_xiaozhiStatus->setText(QStringLiteral("小智已就绪 · 现在可以开始对话"));
            } else {
                m_xiaozhiStatus->setText(QStringLiteral("云端已连接 · 正在初始化麦克风和扬声器"));
            }
        }
        updateXiaozhiActivationView();
    });

    QString modbusDevice = QString::fromLocal8Bit(qgetenv("MODBUS_DEVICE"));
    if (modbusDevice.isEmpty())
        modbusDevice = QStringLiteral("/dev/ttymxc2");
    int modbusBaud = 19200;
    const QString modbusBaudText = QString::fromLocal8Bit(qgetenv("MODBUS_BAUD"));
    if (!modbusBaudText.isEmpty()) {
        bool ok = false;
        const int value = modbusBaudText.toInt(&ok);
        if (ok) modbusBaud = value;
    }
    int modbusSlave = 1;
    const QString modbusSlaveText = QString::fromLocal8Bit(qgetenv("MODBUS_SLAVE_ID"));
    if (!modbusSlaveText.isEmpty()) {
        bool ok = false;
        const int value = modbusSlaveText.toInt(&ok);
        if (ok && value >= 1 && value <= 247) modbusSlave = value;
    }
    m_modbusWorker = new ModbusWorker(modbusDevice, modbusBaud, modbusSlave);
    m_modbusWorker->moveToThread(&m_modbusThread);
    connect(&m_modbusThread, &QThread::finished, m_modbusWorker, &QObject::deleteLater);
    connect(this, &MainWindow::modbusStartRequested,
            m_modbusWorker, &ModbusWorker::start, Qt::QueuedConnection);
    connect(this, &MainWindow::modbusStopRequested,
            m_modbusWorker, &ModbusWorker::stop, Qt::QueuedConnection);
    connect(this, &MainWindow::modbusLedRequested,
            m_modbusWorker, &ModbusWorker::setLed, Qt::QueuedConnection);
    connect(this, &MainWindow::modbusBuzzerRequested,
            m_modbusWorker, &ModbusWorker::setBuzzer, Qt::QueuedConnection);
    connect(m_modbusWorker, &ModbusWorker::statusChanged, this, [this](const QString &status) {
        if (m_rs485Status) {
            m_rs485Status->setToolTip(status);
            m_rs485Status->setText(QFontMetrics(m_rs485Status->font()).elidedText(
                status, Qt::ElideRight, qMax(40, m_rs485Status->width() - 4)));
        }
    }, Qt::QueuedConnection);
    connect(m_modbusWorker, &ModbusWorker::sensorReading, this,
            [this](double temperature, double humidity, bool ledOn, bool buzzerOn) {
        m_temperatureValue->setText(QStringLiteral("%1 °C").arg(temperature, 0, 'f', 2));
        m_humidityValue->setText(QStringLiteral("%1 %RH").arg(humidity, 0, 'f', 2));
        m_ledButton->blockSignals(true);
        m_buzzerButton->blockSignals(true);
        if (!m_ledButton->property("writePending").toBool()) {
            m_ledButton->setChecked(ledOn);
            m_ledButton->setText(ledOn ? QStringLiteral("LED 开") : QStringLiteral("LED 关"));
        }
        if (!m_buzzerButton->property("writePending").toBool()) {
            m_buzzerButton->setChecked(buzzerOn);
            m_buzzerButton->setText(buzzerOn ? QStringLiteral("蜂鸣器 开") : QStringLiteral("蜂鸣器 关"));
        }
        m_ledButton->blockSignals(false);
        m_buzzerButton->blockSignals(false);
        m_sensorChart->appendReading(temperature, humidity);
    }, Qt::QueuedConnection);
    connect(m_modbusWorker, &ModbusWorker::outputWriteFinished, this,
            [this](bool isLed, bool enabled, bool success, const QString &message) {
        QPushButton *button = isLed ? m_ledButton : m_buzzerButton;
        if (button) {
            button->blockSignals(true);
            const bool on = success ? enabled : !enabled;
            button->setProperty("writePending", false);
            button->setEnabled(true);
            button->setChecked(on);
            button->setText(isLed ? (on ? QStringLiteral("LED 开") : QStringLiteral("LED 关"))
                                 : (on ? QStringLiteral("蜂鸣器 开") : QStringLiteral("蜂鸣器 关")));
            button->blockSignals(false);
        }
        if (success) return;
        if (m_rs485Status) {
            m_rs485Status->setToolTip(message);
            m_rs485Status->setText(QFontMetrics(m_rs485Status->font()).elidedText(
                message, Qt::ElideRight, qMax(40, m_rs485Status->width() - 4)));
        }
    }, Qt::QueuedConnection);
    m_modbusThread.setObjectName(QStringLiteral("modbus-rtu-worker"));
    m_modbusThread.start();

    QString credentialError;
    m_credentialStore.loadAll(&m_savedNetworks, &credentialError);
    m_hasCredentials = !m_savedNetworks.isEmpty();
    m_setupComplete = m_hasCredentials;
    setWifiStatus(false, QString());
    m_skipButton->setText(QStringLiteral("返回"));
    registerThemedIcon(m_skipButton, UiIcon::Back, IconTint::Hint);
    m_stack->setCurrentWidget(m_hasCredentials ? m_homePage : m_wifiPage);

    m_clockTimer = new QTimer(this);
    connect(m_clockTimer, &QTimer::timeout, this, &MainWindow::updateClock);
    m_clockTimer->start(1000);
    updateClock();

    m_statusTimer = new QTimer(this);
    connect(m_statusTimer, &QTimer::timeout, this, &MainWindow::requestWifiStatus);
    m_statusTimer->start(5000);

    m_reconnectTimer = new QTimer(this);
    m_reconnectTimer->setSingleShot(true);
    connect(m_reconnectTimer, &QTimer::timeout, this, &MainWindow::tryAutoReconnect);

    m_timeSyncRetryTimer = new QTimer(this);
    m_timeSyncRetryTimer->setSingleShot(true);
    connect(m_timeSyncRetryTimer, &QTimer::timeout,
            this, &MainWindow::startInternetTimeSync);

    m_connectionAnimationTimer = new QTimer(this);
    m_connectionAnimationTimer->setInterval(350);
    connect(m_connectionAnimationTimer, &QTimer::timeout, this, [this]() {
        if (!m_connectionBusy || m_wifiPageStack->currentWidget() != m_scanPage) {
            m_connectionAnimationTimer->stop();
            return;
        }
        m_connectionAnimationFrame = (m_connectionAnimationFrame + 1) % 4;
        const QString dots(m_connectionAnimationFrame, QLatin1Char('.'));
        m_scanInfo->setText(QStringLiteral("连接中%1").arg(dots));
        m_wifiMessage->setText(QStringLiteral("正在连接 Wi-Fi%1").arg(dots));
        m_connectButton->setText(QStringLiteral("连接中%1").arg(dots));
    });

    m_xiaozhiReadyHintTimer = new QTimer(this);
    m_xiaozhiReadyHintTimer->setSingleShot(true);
    m_xiaozhiReadyHintTimer->setInterval(30000);
    connect(m_xiaozhiReadyHintTimer, &QTimer::timeout, this, [this]() {
        if (!m_xiaozhiActivated || (m_xiaozhiOnline && m_xiaozhiAudioReady))
            return;
        m_xiaozhiManualRestartHint = true;
        updateXiaozhiActivationView();
    });

    // Probe the current link first; an already-connected network is stable.
    QTimer::singleShot(250, this, &MainWindow::requestWifiStatus);
    if (m_hasCredentials) {
        scheduleAutoReconnect(500);
    } else {
        QTimer::singleShot(450, this, [this, credentialError]() {
            startScan();
            if (!credentialError.isEmpty()) {
                m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
                m_wifiMessage->setText(QStringLiteral("Wi-Fi 配置文件无效，请重新配置"));
                m_wifiMessage->setVisible(true);
                m_wifiMessage->setToolTip(credentialError);
            }
        });
    }
}

MainWindow::~MainWindow()
{
    for (QTimer *timer : findChildren<QTimer *>()) timer->stop();
    m_workerThread.requestInterruption();
    m_ntpThread.requestInterruption();
    m_modbusThread.requestInterruption();
    m_sensorPollThread.requestInterruption();
    m_cameraThread.requestInterruption();
    m_selfTestCameraThread.requestInterruption();
    cancelSelfTest();
    if (m_recordProcess) m_recordProcess->disconnect(this);
    if (m_playProcess) m_playProcess->disconnect(this);
    stopAudioProcesses();
    for (QProcess *process : {m_recordProcess, m_playProcess}) {
        if (process && process->state() != QProcess::NotRunning && !process->waitForFinished(500)) {
            process->kill();
            process->waitForFinished(1000);
        }
    }
    if (m_cameraWorker) m_cameraWorker->disconnect(this);
    stopCameraPreview();
    if (m_xiaozhiBridge) {
        m_xiaozhiBridge->disconnect(this);
        delete m_xiaozhiBridge;
        m_xiaozhiBridge = nullptr;
    }
    if (m_canSession) m_canSession->disconnect(this);
    if (m_selfTestCanSession) m_selfTestCanSession->disconnect(this);
    closeCanLink();
    delete m_canSession;
    delete m_selfTestCanSession;
    m_canSession = m_selfTestCanSession = nullptr;
    if (m_modbusThread.isRunning() && m_modbusWorker)
        QMetaObject::invokeMethod(m_modbusWorker, "stop", Qt::BlockingQueuedConnection);
    m_modbusThread.quit();
    m_sensorPollThread.quit();
    m_cameraThread.quit();
    m_selfTestCameraThread.quit();
    m_ntpThread.quit();
    m_workerThread.quit();
    m_modbusThread.wait();
    // A kernel sysfs read cannot safely be force-terminated. Interrupt checks
    // between files prevent serially waiting for every remaining DS18B20.
    m_sensorPollThread.wait();
    m_cameraThread.wait();
    m_selfTestCameraThread.wait();
    m_ntpThread.wait();
    m_workerThread.wait();
}

QWidget *MainWindow::createHomePage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("homePage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *pageLayout = new QVBoxLayout(page);
    pageLayout->setContentsMargins(0, 0, 0, 0);
    pageLayout->setSpacing(0);

    QFrame *topBar = new QFrame(page);
    topBar->setObjectName(QStringLiteral("topBar"));
    topBar->setLayoutDirection(Qt::LeftToRight);
    topBar->setFixedHeight(40);
    QGridLayout *barLayout = new QGridLayout(topBar);
    barLayout->setOriginCorner(Qt::TopLeftCorner);
    barLayout->setContentsMargins(2, 0, 2, 0);
    barLayout->setHorizontalSpacing(0);
    barLayout->setVerticalSpacing(0);
    barLayout->setColumnMinimumWidth(0, 154);
    barLayout->setColumnMinimumWidth(1, 154);
    barLayout->setColumnMinimumWidth(2, 154);
    barLayout->setColumnStretch(0, 1);
    barLayout->setColumnStretch(1, 1);
    barLayout->setColumnStretch(2, 1);

    QWidget *brandWidget = new QWidget(topBar);
    QHBoxLayout *brandLayout = new QHBoxLayout(brandWidget);
    brandLayout->setContentsMargins(0, 0, 0, 0);
    brandLayout->setSpacing(5);
    QLabel *brandMark = new QLabel(brandWidget);
    brandMark->setObjectName(QStringLiteral("brandMark"));
    brandMark->setAlignment(Qt::AlignCenter);
    brandMark->setFixedSize(24, 24);
    registerThemedIcon(brandMark, UiIcon::Board, IconTint::Accent, QSize(20, 20));
    QLabel *brandName = new QLabel(QStringLiteral("硬件测试"), brandWidget);
    brandName->setObjectName(QStringLiteral("brandName"));
    brandLayout->addWidget(brandMark);
    brandLayout->addWidget(brandName);

    QWidget *dateTimeWidget = new QWidget(topBar);
    QHBoxLayout *dateTimeLayout = new QHBoxLayout(dateTimeWidget);
    dateTimeLayout->setContentsMargins(0, 0, 0, 0);
    dateTimeLayout->setSpacing(5);
    dateTimeLayout->setAlignment(Qt::AlignCenter);
    m_clockDate = new QLabel(dateTimeWidget);
    m_clockDate->setObjectName(QStringLiteral("clockDate"));
    m_clockTime = new QLabel(dateTimeWidget);
    m_clockTime->setObjectName(QStringLiteral("clockTime"));
    dateTimeLayout->addWidget(m_clockDate);
    dateTimeLayout->addWidget(m_clockTime);
    dateTimeWidget->setFixedWidth(154);

    QWidget *wifiGroup = new QWidget(topBar);
    QHBoxLayout *wifiLayout = new QHBoxLayout(wifiGroup);
    wifiLayout->setContentsMargins(0, 0, 0, 0);
    wifiLayout->setSpacing(4);
    m_wifiStatusButton = new QPushButton(wifiGroup);
    m_wifiStatusButton->setObjectName(QStringLiteral("wifiStatusButton"));
    m_wifiStatusButton->setFixedSize(30, 30);
    m_wifiStatusButton->setIconSize(QSize(22, 22));
    m_wifiStatusButton->setToolTip(QStringLiteral("打开 Wi-Fi 设置"));
    connect(m_wifiStatusButton, &QPushButton::clicked, this, &MainWindow::openWifiSettings);

    QWidget *wifiInfoWidget = new QWidget(wifiGroup);
    wifiInfoWidget->setFixedWidth(115);
    QVBoxLayout *wifiInfoLayout = new QVBoxLayout(wifiInfoWidget);
    wifiInfoLayout->setContentsMargins(0, 0, 0, 0);
    wifiInfoLayout->setSpacing(0);
    m_wifiTopStatus = new QLabel(QStringLiteral("WIFI 未连接"), wifiInfoWidget);
    m_wifiTopStatus->setObjectName(QStringLiteral("wifiTopStatus"));
    m_wifiTopStatus->setProperty("connected", false);
    m_wifiTopStatus->setProperty("connecting", false);
    m_wifiTopIp = new QLabel(QStringLiteral("IP：--"), wifiInfoWidget);
    m_wifiTopIp->setObjectName(QStringLiteral("wifiTopIp"));
    wifiInfoLayout->addWidget(m_wifiTopStatus);
    wifiInfoLayout->addWidget(m_wifiTopIp);
    wifiLayout->addWidget(m_wifiStatusButton);
    wifiLayout->addWidget(wifiInfoWidget);

    // Forced LTR: hardware test stays far left, time stays centered, Wi-Fi status stays far right.
    barLayout->addWidget(brandWidget, 0, 0, Qt::AlignLeft | Qt::AlignVCenter);
    barLayout->addWidget(dateTimeWidget, 0, 1, Qt::AlignCenter);
    barLayout->addWidget(wifiGroup, 0, 2, Qt::AlignRight | Qt::AlignVCenter);
    pageLayout->addWidget(topBar);

    QWidget *body = new QWidget(page);
    QVBoxLayout *bodyLayout = new QVBoxLayout(body);
    bodyLayout->setContentsMargins(10, 10, 10, 7);
    bodyLayout->setSpacing(8);

    QFrame *hero = new QFrame(body);
    hero->setObjectName(QStringLiteral("heroCard"));
    hero->setFixedHeight(96);
    QHBoxLayout *heroLayout = new QHBoxLayout(hero);
    heroLayout->setContentsMargins(16, 10, 12, 10);
    heroLayout->setSpacing(12);

    QLabel *heroIcon = new QLabel(hero);
    heroIcon->setObjectName(QStringLiteral("heroIcon"));
    heroIcon->setAlignment(Qt::AlignCenter);
    heroIcon->setFixedSize(52, 52);
    registerThemedIcon(heroIcon, UiIcon::TestGrid, IconTint::Accent, QSize(40, 40));
    heroLayout->addWidget(heroIcon);

    QVBoxLayout *heroTextLayout = new QVBoxLayout;
    heroTextLayout->setContentsMargins(0, 0, 0, 0);
    heroTextLayout->setSpacing(4);
    QLabel *heroTitle = new QLabel(QStringLiteral("外设测试"), hero);
    heroTitle->setObjectName(QStringLiteral("heroTitle"));
    QLabel *heroSub = new QLabel(QStringLiteral("音频录放 · 小智语音 · RS485 · 摄像头 · CAN"), hero);
    heroSub->setObjectName(QStringLiteral("heroSub"));
    heroTextLayout->addWidget(heroTitle);
    heroTextLayout->addWidget(heroSub);
    heroLayout->addLayout(heroTextLayout, 1);

    QPushButton *futureButton = new QPushButton(hero);
    futureButton->setObjectName(QStringLiteral("heroArrow"));
    registerThemedIcon(futureButton, UiIcon::ArrowRight, IconTint::Primary);
    futureButton->setIconSize(QSize(25, 25));
    futureButton->setFixedSize(40, 40);
    heroLayout->addWidget(futureButton);
    connect(futureButton, &QPushButton::clicked, this, &MainWindow::openPeripheralHub);
    bodyLayout->addWidget(hero);

    // 原 RS485/CAN/LED/蜂鸣器快捷按钮区 → CPU/内存实时曲线
    m_loadChart = new LoadChart(body);
    bodyLayout->addWidget(m_loadChart);

    bodyLayout->addSpacing(2);
    m_homeMessage = new QLabel(QStringLiteral("点击主卡片进入外设测试"), body);
    m_homeMessage->setObjectName(QStringLiteral("smallNote"));
    m_homeMessage->setAlignment(Qt::AlignCenter);
    m_homeMessage->setFixedHeight(18);
    bodyLayout->addStretch(1);
    bodyLayout->addWidget(m_homeMessage);
    pageLayout->addWidget(body, 1);
    return page;
}

QWidget *MainWindow::createPeripheralPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("peripheralPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    m_peripheralPageStack = new QStackedWidget(page);
    m_peripheralPageStack->setFrameShape(QFrame::NoFrame);
    m_peripheralPageStack->setContentsMargins(0, 0, 0, 0);
    m_peripheralHubPage = createPeripheralHubPage();
    m_audioTestPage = createAudioTestPage();
    m_xiaozhiPage = createXiaozhiPage();
    m_rs485Page = createRs485Page();
    m_peripheralPageStack->addWidget(m_peripheralHubPage);
    m_peripheralPageStack->addWidget(m_audioTestPage);
    m_peripheralPageStack->addWidget(m_xiaozhiPage);
    m_peripheralPageStack->addWidget(m_rs485Page);
    m_cameraTestPage = createCameraTestPage();
    m_peripheralPageStack->addWidget(m_cameraTestPage);
    m_sensorPage = createSensorPage();
    m_peripheralPageStack->addWidget(m_sensorPage);
    m_canTestPage = createCanTestPage();
    m_peripheralPageStack->addWidget(m_canTestPage);
    m_selfTestPage = createSelfTestPage();
    m_peripheralPageStack->addWidget(m_selfTestPage);
    m_themePage = createThemePage();
    m_peripheralPageStack->addWidget(m_themePage);
    m_peripheralPageStack->setCurrentWidget(m_peripheralHubPage);
    layout->addWidget(m_peripheralPageStack);
    return page;
}

QWidget *MainWindow::createPeripheralHubPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("peripheralHubPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 5, 9, 6);
    layout->setSpacing(7);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("外设测试"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    QLabel *count = new QLabel(QStringLiteral("8 项"), header);
    count->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(count);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToHome);

    // 每屏 4 张功能卡，其余分页，左右滑动翻页（松手自动吸附）
    const QString iconPaths[] = {
        QStringLiteral(":/ui/icons/microphone_blue.png"),
        QStringLiteral(":/ui/icons/robot_blue.png"),
        QStringLiteral(":/ui/icons/rs485_secondary.png"),
        QStringLiteral(":/ui/icons/camera_blue.png"),
        QStringLiteral(":/ui/icons/sensor_blue.png"),
        QStringLiteral(":/ui/icons/can_secondary.png"),
        QStringLiteral(":/ui/icons/selftest_blue.png"),
        QStringLiteral(":/ui/icons/theme_blue.png")
    };
    const QString captions[] = {
        QStringLiteral("录音 / 播放"), QStringLiteral("小智语音"),
        QStringLiteral("RS485 / STM32"), QStringLiteral("摄像头"),
        QStringLiteral("传感器"), QStringLiteral("CAN 总线"),
        QStringLiteral("一键测试"), QStringLiteral("主题风格")
    };
    QList<QToolButton *> cards;
    for (int i = 0; i < 8; ++i) {
        QToolButton *button = new QToolButton;
        button->setObjectName(QStringLiteral("featureTile"));
        button->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        button->setIcon(QIcon(iconPaths[i]));
        button->setIconSize(QSize(38, 38));
        button->setText(captions[i]);
        button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        if (i == 0)
            connect(button, &QToolButton::clicked, this, &MainWindow::openAudioTestPage);
        else if (i == 1)
            connect(button, &QToolButton::clicked, this, &MainWindow::openXiaozhiPage);
        else if (i == 2)
            connect(button, &QToolButton::clicked, this, &MainWindow::openRs485Page);
        else if (i == 3)
            connect(button, &QToolButton::clicked, this, &MainWindow::openCameraTestPage);
        else if (i == 4)
            connect(button, &QToolButton::clicked, this, &MainWindow::openSensorPage);
        else if (i == 5)
            connect(button, &QToolButton::clicked, this, &MainWindow::openCanTestPage);
        else if (i == 6)
            connect(button, &QToolButton::clicked, this, &MainWindow::openSelfTestPage);
        else
            connect(button, &QToolButton::clicked, this, &MainWindow::openThemePage);
        cards.append(button);
    }
    FeatureTilePager *pager = new FeatureTilePager(page);
    pager->setCards(cards, 4);
    layout->addWidget(pager, 1);
    m_hubPager = pager;

    QLabel *note = new QLabel(QStringLiteral("LED 与蜂鸣器控制、温湿度曲线位于 RS485 页面"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(18);
    layout->addWidget(note);
    return page;
}

QWidget *MainWindow::createAudioTestPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("audioTestPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(4);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("音频测试"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    m_audioStatus = new QLabel(QStringLiteral("录音停止后自动回放 · 默认采样率 16000 Hz"), page);
    m_audioStatus->setObjectName(QStringLiteral("peripheralStatus"));
    m_audioStatus->setFixedHeight(18);
    layout->addWidget(m_audioStatus);

    QHBoxLayout *actions = new QHBoxLayout;
    actions->setContentsMargins(0, 0, 0, 0);
    actions->setSpacing(8);
    m_recordButton = new QPushButton(QStringLiteral("开始录音"), page);
    m_recordButton->setObjectName(QStringLiteral("largeAction"));
    m_recordButton->setIcon(QIcon(QStringLiteral(":/ui/icons/microphone_blue.png")));
    m_recordButton->setIconSize(QSize(34, 34));
    m_recordButton->setMinimumHeight(94);
    m_musicButton = new QPushButton(QStringLiteral("播放 /music.wav"), page);
    m_musicButton->setObjectName(QStringLiteral("largeAction"));
    m_musicButton->setIcon(QIcon(QStringLiteral(":/ui/icons/music_blue.png")));
    m_musicButton->setIconSize(QSize(34, 34));
    m_musicButton->setMinimumHeight(94);
    actions->addWidget(m_recordButton, 1);
    actions->addWidget(m_musicButton, 1);
    layout->addLayout(actions, 1);

    QLabel *note = new QLabel(QStringLiteral("第二次按录音键停止并回放；播放按钮读取 /music.wav"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(18);
    layout->addWidget(note);

    connect(m_recordButton, &QPushButton::clicked, this, [this]() {
        if (m_recordProcess && m_recordProcess->state() != QProcess::NotRunning)
            stopRecording(true);
        else
            startRecording();
    });
    connect(m_musicButton, &QPushButton::clicked, this, [this]() {
        if (m_playProcess && m_playProcess->state() != QProcess::NotRunning) {
            m_playStopRequested = true;
            m_playProcess->terminate();
            m_audioStatus->setText(QStringLiteral("正在停止播放…"));
            m_playKillTimer->start(1200);
            updateAudioControls();
            return;
        }
        playAudioFile(m_musicFilePath, QStringLiteral("音乐播放"));
    });
    updateAudioControls();
    return page;
}

QWidget *MainWindow::createXiaozhiPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("xiaozhiPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(8, 4, 8, 5);
    layout->setSpacing(3);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(6);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("小智语音对话"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    m_xiaozhiToggleButton = new QPushButton(QStringLiteral("启动小智"), header);
    m_xiaozhiToggleButton->setObjectName(QStringLiteral("primaryButton"));
    m_xiaozhiToggleButton->setFixedSize(92, 29);
    headerLayout->addWidget(m_xiaozhiToggleButton);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);
    connect(m_xiaozhiToggleButton, &QPushButton::clicked, this, [this]() {
        if (m_xiaozhiBridge->isActive()) {
            m_xiaozhiBridge->stop();
            resetXiaozhiSessionUi(QStringLiteral("小智已停止"));
            m_xiaozhiStatus->setText(QStringLiteral("小智已停止"));
        } else {
            requestXiaozhiStart();
        }
        m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isActive()
                                           ? QStringLiteral("停止小智")
                                           : QStringLiteral("启动小智"));
        updateXiaozhiActivationView();
    });

    m_xiaozhiStatus = new QLabel(QStringLiteral("未运行"), page);
    m_xiaozhiStatus->setObjectName(QStringLiteral("peripheralStatus"));
    m_xiaozhiStatus->setFixedHeight(17);
    layout->addWidget(m_xiaozhiStatus);

    m_xiaozhiActivationPanel = new QFrame(page);
    m_xiaozhiActivationPanel->setObjectName(QStringLiteral("activationCard"));
    m_xiaozhiActivationPanel->setMinimumHeight(130);
    QHBoxLayout *activationLayout = new QHBoxLayout(m_xiaozhiActivationPanel);
    activationLayout->setContentsMargins(7, 6, 8, 6);
    activationLayout->setSpacing(9);

    QVBoxLayout *qrLayout = new QVBoxLayout;
    qrLayout->setContentsMargins(0, 0, 0, 0);
    qrLayout->setSpacing(3);
    QLabel *qr = new QLabel(m_xiaozhiActivationPanel);
    qr->setObjectName(QStringLiteral("activationQr"));
    qr->setAlignment(Qt::AlignCenter);
    qr->setFixedSize(82, 82);
    const QPixmap qrPixmap(QStringLiteral(":/ui/activation_qr.png"));
    if (!qrPixmap.isNull())
        qr->setPixmap(qrPixmap);
    else
        qr->setText(QStringLiteral("二维码未加载"));
    QLabel *qrCaption = new QLabel(QStringLiteral("官方控制台\nxiaozhi.me/console"), m_xiaozhiActivationPanel);
    qrCaption->setObjectName(QStringLiteral("activationQrCaption"));
    qrCaption->setAlignment(Qt::AlignCenter);
    qrLayout->addWidget(qr, 0, Qt::AlignHCenter);
    qrLayout->addWidget(qrCaption, 0, Qt::AlignHCenter);
    activationLayout->addLayout(qrLayout, 0);

    QVBoxLayout *activationInfo = new QVBoxLayout;
    activationInfo->setContentsMargins(0, 0, 0, 0);
    activationInfo->setSpacing(2);
    m_xiaozhiActivationTitleLabel = new QLabel(QStringLiteral("首次使用 · 绑定小智设备"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationTitleLabel->setObjectName(QStringLiteral("activationTitle"));
    m_xiaozhiActivationCodeCaption = new QLabel(QStringLiteral("小智核心实时返回的 6 位激活码"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationCodeCaption->setObjectName(QStringLiteral("activationCodeCaption"));
    m_xiaozhiActivationCodeLabel = new QLabel(QStringLiteral("等待激活码"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationCodeLabel->setObjectName(QStringLiteral("activationCode"));
    m_xiaozhiActivationCodeLabel->setAlignment(Qt::AlignCenter);
    m_xiaozhiActivationCodeLabel->setMinimumHeight(31);
    m_xiaozhiActivationInstructionsLabel = new QLabel(
        QStringLiteral("扫码注册/登录 → 添加设备 → 输入上方六码并完成绑定。未激活前，语音对话不可用。"),
        m_xiaozhiActivationPanel);
    m_xiaozhiActivationInstructionsLabel->setObjectName(QStringLiteral("activationInstructions"));
    m_xiaozhiActivationInstructionsLabel->setWordWrap(true);
    m_xiaozhiActivationMessage = new QLabel(QStringLiteral("正在检查设备激活状态…"), m_xiaozhiActivationPanel);
    m_xiaozhiActivationMessage->setObjectName(QStringLiteral("activationMessage"));
    m_xiaozhiActivationMessage->setWordWrap(true);
    m_xiaozhiActivationMessage->setMinimumHeight(24);
    activationInfo->addWidget(m_xiaozhiActivationTitleLabel);
    activationInfo->addWidget(m_xiaozhiActivationCodeCaption);
    activationInfo->addWidget(m_xiaozhiActivationCodeLabel);
    activationInfo->addWidget(m_xiaozhiActivationInstructionsLabel, 1);
    activationInfo->addWidget(m_xiaozhiActivationMessage);
    activationLayout->addLayout(activationInfo, 1);
    layout->addWidget(m_xiaozhiActivationPanel, 1);

    m_chatList = new QListWidget(page);
    m_chatList->setItemDelegate(new ChatBubbleDelegate(m_chatList));
    m_chatList->setSelectionMode(QAbstractItemView::NoSelection);
    m_chatList->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_chatList->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    m_chatList->setSpacing(1);
    m_chatList->setWordWrap(true);
    layout->addWidget(m_chatList, 1);
    m_chatList->hide();

    QLabel *note = new QLabel(QStringLiteral("已就绪后开始说话 · 用户消息靠右，小智消息靠左"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setFixedHeight(16);
    note->setAlignment(Qt::AlignCenter);
    layout->addWidget(note);
    return page;
}

QWidget *MainWindow::createRs485Page()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("rs485Page"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(8, 4, 8, 4);
    layout->setSpacing(3);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(34);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(6);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(20, 20));
    back->setFixedSize(31, 30);
    QLabel *title = new QLabel(QStringLiteral("RS485 / STM32"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    m_rs485Status = new QLabel(QStringLiteral("Modbus RTU 未启动"), page);
    m_rs485Status->setObjectName(QStringLiteral("peripheralStatus"));
    m_rs485Status->setFixedHeight(16);
    layout->addWidget(m_rs485Status);

    QHBoxLayout *values = new QHBoxLayout;
    values->setContentsMargins(0, 0, 0, 0);
    values->setSpacing(7);
    QFrame *temperatureCard = new QFrame(page);
    temperatureCard->setObjectName(QStringLiteral("sensorValueCard"));
    QVBoxLayout *temperatureLayout = new QVBoxLayout(temperatureCard);
    temperatureLayout->setContentsMargins(9, 3, 9, 3);
    temperatureLayout->setSpacing(0);
    QLabel *temperatureCaption = new QLabel(QStringLiteral("温度"), temperatureCard);
    temperatureCaption->setObjectName(QStringLiteral("sensorCaption"));
    m_temperatureValue = new QLabel(QStringLiteral("-- °C"), temperatureCard);
    m_temperatureValue->setObjectName(QStringLiteral("sensorValue"));
    temperatureLayout->addWidget(temperatureCaption);
    temperatureLayout->addWidget(m_temperatureValue);
    QFrame *humidityCard = new QFrame(page);
    humidityCard->setObjectName(QStringLiteral("sensorValueCard"));
    QVBoxLayout *humidityLayout = new QVBoxLayout(humidityCard);
    humidityLayout->setContentsMargins(9, 3, 9, 3);
    humidityLayout->setSpacing(0);
    QLabel *humidityCaption = new QLabel(QStringLiteral("相对湿度"), humidityCard);
    humidityCaption->setObjectName(QStringLiteral("sensorCaption"));
    m_humidityValue = new QLabel(QStringLiteral("-- %RH"), humidityCard);
    m_humidityValue->setObjectName(QStringLiteral("sensorValue"));
    humidityLayout->addWidget(humidityCaption);
    humidityLayout->addWidget(m_humidityValue);
    values->addWidget(temperatureCard, 1);
    values->addWidget(humidityCard, 1);
    layout->addLayout(values);

    m_sensorChart = new SensorChart(page);
    layout->addWidget(m_sensorChart, 1);

    QHBoxLayout *controls = new QHBoxLayout;
    controls->setContentsMargins(0, 0, 0, 0);
    controls->setSpacing(7);
    m_ledButton = new QPushButton(QStringLiteral("LED 关"), page);
    m_ledButton->setObjectName(QStringLiteral("hardwareToggle"));
    registerThemedIcon(m_ledButton, UiIcon::Led, IconTint::Secondary);
    m_ledButton->setIconSize(QSize(20, 20));
    m_ledButton->setCheckable(true);
    m_ledButton->setFixedSize(120, 31);
    m_buzzerButton = new QPushButton(QStringLiteral("蜂鸣器 关"), page);
    m_buzzerButton->setObjectName(QStringLiteral("hardwareToggle"));
    registerThemedIcon(m_buzzerButton, UiIcon::Beep, IconTint::Secondary);
    m_buzzerButton->setIconSize(QSize(20, 20));
    m_buzzerButton->setCheckable(true);
    m_buzzerButton->setFixedSize(132, 31);
    m_rs485RetryButton = new QPushButton(QStringLiteral("重连"), page);
    m_rs485RetryButton->setObjectName(QStringLiteral("skipButton"));
    m_rs485RetryButton->setFixedSize(68, 30);
    controls->addWidget(m_ledButton);
    controls->addWidget(m_buzzerButton);
    controls->addStretch(1);
    controls->addWidget(m_rs485RetryButton);
    layout->addLayout(controls);

    connect(m_ledButton, &QPushButton::clicked, this, [this](bool enabled) {
        m_ledButton->setText(enabled ? QStringLiteral("LED 开") : QStringLiteral("LED 关"));
        m_ledButton->setProperty("writePending", true);
        m_ledButton->setEnabled(false);
        emit modbusLedRequested(enabled);
    });
    connect(m_buzzerButton, &QPushButton::clicked, this, [this](bool enabled) {
        m_buzzerButton->setText(enabled ? QStringLiteral("蜂鸣器 开") : QStringLiteral("蜂鸣器 关"));
        m_buzzerButton->setProperty("writePending", true);
        m_buzzerButton->setEnabled(false);
        emit modbusBuzzerRequested(enabled);
    });
    connect(m_rs485RetryButton, &QPushButton::clicked, this, [this]() {
        emit modbusStopRequested();
        emit modbusStartRequested(); // Queued after stop; leaving the page queues a final stop.
    });
    return page;
}

QWidget *MainWindow::createCameraTestPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("cameraTestPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(4);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("摄像头测试"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    m_cameraStatus = new QLabel(QStringLiteral("未打开"), header);
    m_cameraStatus->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(m_cameraStatus);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    m_cameraView = new QLabel(QStringLiteral("未打开摄像头"), page);
    m_cameraView->setObjectName(QStringLiteral("cameraView"));
    m_cameraView->setAlignment(Qt::AlignCenter);
    m_cameraView->setMinimumSize(100, 100);
    layout->addWidget(m_cameraView, 1);

    QHBoxLayout *bottomRow = new QHBoxLayout;
    bottomRow->setContentsMargins(0, 0, 0, 0);
    bottomRow->setSpacing(8);
    m_cameraInfo = new QLabel(QStringLiteral("设备 /dev/video0 · 可用 CAMERA_DEVICE 指定"), page);
    m_cameraInfo->setObjectName(QStringLiteral("peripheralStatus"));
    m_cameraInfo->setFixedHeight(26);
    m_cameraToggleButton = new QPushButton(QStringLiteral("打开摄像头"), page);
    m_cameraToggleButton->setObjectName(QStringLiteral("primaryButton"));
    m_cameraToggleButton->setFixedWidth(118);
    m_cameraToggleButton->setFixedHeight(30);
    bottomRow->addWidget(m_cameraInfo, 1);
    bottomRow->addWidget(m_cameraToggleButton);
    layout->addLayout(bottomRow);

    connect(m_cameraToggleButton, &QPushButton::clicked, this, [this]() {
        if (m_cameraRunning || m_cameraStartPending)
            stopCameraPreview();
        else
            startCameraPreview();
    });

    return page;
}

void MainWindow::openCameraTestPage()
{
    m_peripheralPageStack->setCurrentWidget(m_cameraTestPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    updateCameraControls();
}

void MainWindow::startCameraPreview()
{
    if (m_cameraRunning || m_cameraStartPending || m_cameraStopPending ||
        m_selfTestCameraThread.isRunning())
        return;

    if (!m_cameraWorker) {
        // 采集线程与信号连接只建立一次，重复打开复用同一套
        m_cameraWorker = new CameraWorker;
        m_cameraWorker->moveToThread(&m_cameraThread);
        connect(&m_cameraThread, &QThread::finished,
                m_cameraWorker, &QObject::deleteLater);
        connect(m_cameraWorker, &CameraWorker::frameReady,
                this, &MainWindow::onCameraFrame, Qt::QueuedConnection);
        connect(m_cameraWorker, &CameraWorker::captureFailed,
                this, &MainWindow::onCameraFailed, Qt::QueuedConnection);
        connect(m_cameraWorker, &CameraWorker::captureOpened,
                this, &MainWindow::onCameraOpened, Qt::QueuedConnection);
        connect(m_cameraWorker, &CameraWorker::captureClosed,
                this, &MainWindow::onCameraClosed, Qt::QueuedConnection);
        connect(m_cameraWorker, &CameraWorker::frameStats,
                this, &MainWindow::onCameraStats, Qt::QueuedConnection);
        m_cameraThread.start();
    }

    m_cameraWorker->prepareCapture();
    m_cameraStartPending = true;
    m_cameraStatus->setText(QStringLiteral("正在打开…"));
    updateCameraControls();
    QMetaObject::invokeMethod(m_cameraWorker, "startCapture", Qt::QueuedConnection);
}

void MainWindow::onCameraOpened(const QString &device, int width, int height,
                                const QString &formatName, int fps)
{
    if (m_cameraStopPending || m_peripheralPageStack->currentWidget() != m_cameraTestPage) {
        m_cameraWorker->stopCapture();
        return;
    }
    m_cameraRunning = true;
    m_cameraStartPending = false;
    m_cameraStatus->setText(QStringLiteral("运行中"));
    m_cameraInfo->setText(QStringLiteral("%1 · %2×%3 · %4 · %5")
                              .arg(device)
                              .arg(width)
                              .arg(height)
                              .arg(formatName)
                              .arg(fps > 0 ? QStringLiteral("%1 fps").arg(fps) : QStringLiteral("帧率待统计")));
    updateCameraControls();
}

void MainWindow::onCameraClosed()
{
    m_cameraStopPending = false;
    m_cameraRunning = false;
    m_cameraStartPending = false;
    m_cameraStatus->setText(QStringLiteral("已停止"));
    updateCameraControls();
}

void MainWindow::onCameraStats(int framesPerSecond)
{
    if (!m_cameraStopPending && m_cameraRunning)
        m_cameraStatus->setText(QStringLiteral("运行中 · %1 fps").arg(framesPerSecond));
}

void MainWindow::stopCameraPreview()
{
    if (!m_cameraWorker)
        return;
    // 仅置原子停止标志，采集循环在 poll 超时间隔内自行退出并释放设备
    m_cameraWorker->stopCapture();
    if (m_cameraRunning || m_cameraStartPending) {
        m_cameraStopPending = true;
        m_cameraStatus->setText(QStringLiteral("正在停止…"));
        updateCameraControls();
    }
}

void MainWindow::onCameraFrame(const QImage &image)
{
    if (m_cameraWorker) m_cameraWorker->acknowledgeFrame();
    if (m_cameraStopPending || m_peripheralPageStack->currentWidget() != m_cameraTestPage ||
        !m_cameraView || image.isNull())
        return;
    const QRect target = QRect(QPoint(0, 0), m_cameraView->size()).adjusted(3, 3, -3, -3);
    if (target.width() < 8 || target.height() < 8)
        return;
    // 先缩到显示尺寸再转 QPixmap：每帧只搬运 480x272 级别像素，
    // FastTransformation 在 i.MX6 上比 SmoothTransformation 快约一个数量级，
    // 画面也明显更跟手；清晰度损失在这块 LCD 上几乎不可见。
    m_cameraView->setPixmap(QPixmap::fromImage(image.scaled(target.size(),
                                                            Qt::KeepAspectRatio,
                                                            Qt::FastTransformation)));
}

void MainWindow::onCameraFailed(const QString &error)
{
    m_cameraStopPending = false;
    m_cameraRunning = false;
    m_cameraStartPending = false;
    m_cameraStatus->setText(QStringLiteral("打开失败"));
    m_cameraView->setPixmap(QPixmap());
    m_cameraView->setText(error);
    updateCameraControls();
}

void MainWindow::updateCameraControls()
{
    if (!m_cameraToggleButton)
        return;
    m_cameraToggleButton->setEnabled(!m_cameraStopPending);
    m_cameraToggleButton->setText(m_cameraStopPending ? QStringLiteral("正在关闭…") :
        (m_cameraRunning || m_cameraStartPending) ? QStringLiteral("关闭摄像头")
                                                  : QStringLiteral("打开摄像头"));
}

namespace {

// ---------------- 板载传感器 sysfs 扫描 ----------------
// 兼容节点：/sys/class/thermal/thermal_zoneN（i.MX6 SoC 温度常在此）、
// /sys/class/hwmon/hwmonN（温度/电压芯片）、/sys/bus/iio/devices（ADC/温感通道）。

QString readSysfsText(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return QString();
    return QString::fromLocal8Bit(file.read(4096)).trimmed();
}

struct SensorDef {
    QString caption;
    QString valuePath;     // 数值节点
    QString offsetPath;
    QString scalePath;     // 可选：IIO 比例系数节点（扫描时读一次）
    double divisor;        // 最终单位换算除数
    QString unit;
    int decimals;
    int sourceType = 0;    // 0=纯数值节点；1=1-wire w1_slave 两段文本（t= 字段）
};

// root 为空时从真实 sysfs 扫描；传入测试根目录可离线验证
QList<SensorDef> scanBoardSensors(const QString &root = QString())
{
    QList<SensorDef> defs;

    // 1) thermal zone：/temp 为毫摄氏度
    const QDir thermalRoot(root + QStringLiteral("/sys/class/thermal"));
    for (const QString &zone : thermalRoot.entryList(QStringList() << QStringLiteral("thermal_zone*"),
                                                     QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {
        const QString base = thermalRoot.filePath(zone);
        const QString tempPath = base + QStringLiteral("/temp");
        if (!QFile::exists(tempPath))
            continue;
        QString name = readSysfsText(base + QStringLiteral("/type"));
        if (name.isEmpty())
            name = zone;
        SensorDef def;
        def.caption = name;
        def.valuePath = tempPath;
        def.divisor = 1000.0;
        def.unit = QStringLiteral("°C");
        def.decimals = 1;
        defs.append(def);
    }

    // 2) hwmon：temp*_input（毫摄氏度）、in*_input（毫伏）
    const QDir hwmonRoot(root + QStringLiteral("/sys/class/hwmon"));
    for (const QString &chip : hwmonRoot.entryList(QStringList() << QStringLiteral("hwmon*"),
                                                   QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {
        const QString base = hwmonRoot.filePath(chip);
        QString chipName = readSysfsText(base + QStringLiteral("/name"));
        if (chipName.isEmpty())
            chipName = chip;
        const QDir dir(base);
        for (const QString &file : dir.entryList(QStringList() << QStringLiteral("temp*_input"),
                                                 QDir::Files, QDir::Name)) {
            const QString key = file.left(file.size() - 6); // 去掉 _input
            QString label = readSysfsText(base + QLatin1Char('/') + key + QStringLiteral("_label"));
            if (label.isEmpty())
                label = key;
            SensorDef def;
            def.caption = chipName + QStringLiteral(" ") + label;
            def.valuePath = base + QLatin1Char('/') + file;
            def.divisor = 1000.0;
            def.unit = QStringLiteral("°C");
            def.decimals = 1;
            defs.append(def);
        }
        for (const QString &file : dir.entryList(QStringList() << QStringLiteral("in*_input"),
                                                 QDir::Files, QDir::Name)) {
            const QString key = file.left(file.size() - 6);
            SensorDef def;
            def.caption = chipName + QStringLiteral(" ") + key;
            def.valuePath = base + QLatin1Char('/') + file;
            def.divisor = 1000.0;
            def.unit = QStringLiteral("V");
            def.decimals = 2;
            defs.append(def);
        }
    }

    // 3) IIO ADC/温感：in_voltage*_raw（raw*scale 为毫伏）、in_temp*_raw（毫摄氏度）
    const QDir iioRoot(root + QStringLiteral("/sys/bus/iio/devices"));
    for (const QString &dev : iioRoot.entryList(QStringList() << QStringLiteral("iio:device*"),
                                                QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {
        const QString base = iioRoot.filePath(dev);
        QString devName = readSysfsText(base + QStringLiteral("/name"));
        if (devName.isEmpty())
            devName = dev;
        const QDir dir(base);
        const QStringList channels = dir.entryList(QStringList() << QStringLiteral("in_voltage*_raw")
                                                                 << QStringLiteral("in_temp*_raw"),
                                                   QDir::Files, QDir::Name);
        for (const QString &file : channels) {
            const QString key = file.left(file.size() - 4); // 去掉 _raw
            const QString type = file.startsWith(QLatin1String("in_temp"))
                                     ? QStringLiteral("in_temp") : QStringLiteral("in_voltage");
            QString scalePath = base + QLatin1Char('/') + key + QStringLiteral("_scale");
            if (!QFile::exists(scalePath)) scalePath = base + QLatin1Char('/') + type + QStringLiteral("_scale");
            QString offsetPath = base + QLatin1Char('/') + key + QStringLiteral("_offset");
            if (!QFile::exists(offsetPath)) offsetPath = base + QLatin1Char('/') + type + QStringLiteral("_offset");
            const bool hasScale = QFile::exists(scalePath);
            SensorDef def;
            def.caption = devName + QStringLiteral(" ") + key;
            def.valuePath = base + QLatin1Char('/') + file;
            def.scalePath = hasScale ? scalePath : QString();
            def.offsetPath = hasScale && QFile::exists(offsetPath) ? offsetPath : QString();
            def.divisor = hasScale ? 1000.0 : 1.0;
            def.unit = hasScale ? (type == QLatin1String("in_temp") ? QStringLiteral("°C") : QStringLiteral("V"))
                                : QStringLiteral(" raw");
            def.decimals = hasScale ? (type == QLatin1String("in_temp") ? 1 : 2) : 0;
            defs.append(def);
        }
    }

    // 4) 1-wire 总线（内核 w1 子系统）：DS18B20/DS18S20 等温度从机。
    // 器件目录名 = 家族码-序列号；较新内核提供纯数值 temperature 节点，
    // 老内核用经典 w1_slave 两段文本（第一行 CRC 校验 + 第二行 t= 毫摄氏度）。
    const QDir w1Root(root + QStringLiteral("/sys/bus/w1/devices"));
    const QStringList w1Families =
        { QStringLiteral("28-*"), QStringLiteral("10-*"), QStringLiteral("22-*"),
          QStringLiteral("3B-*"), QStringLiteral("3b-*"), QStringLiteral("42-*") };
    for (const QString &dev : w1Root.entryList(w1Families, QDir::Dirs | QDir::NoDotAndDotDot,
                                               QDir::Name)) {
        const QString base = w1Root.filePath(dev);
        QString model = QStringLiteral("1-wire");
        if (dev.startsWith(QLatin1String("28-")))      model = QStringLiteral("DS18B20");
        else if (dev.startsWith(QLatin1String("10-"))) model = QStringLiteral("DS18S20");
        else if (dev.startsWith(QLatin1String("22-"))) model = QStringLiteral("DS1822");
        else if (dev.startsWith(QLatin1String("3B-"), Qt::CaseInsensitive)) model = QStringLiteral("DS1825");
        else if (dev.startsWith(QLatin1String("42-"))) model = QStringLiteral("DS28EA00");

        const QString tempNode = base + QStringLiteral("/temperature");
        const QString slaveNode = base + QStringLiteral("/w1_slave");
        SensorDef def;
        def.caption = model + QStringLiteral(" ") + dev;
        def.divisor = 1000.0;
        def.unit = QStringLiteral("°C");
        def.decimals = 1;
        if (QFile::exists(tempNode)) {
            def.valuePath = tempNode;
            def.sourceType = 0;
        } else if (QFile::exists(slaveNode)) {
            def.valuePath = slaveNode;
            def.sourceType = 1;
        } else {
            continue;
        }
        defs.append(def);
    }
    return defs;
}

// DS18B20 w1_slave 经典格式：
//   "50 05 ... : crc=1c YES\n50 05 ... t=23125\n"
// CRC 行含 YES 才有效；t= 为毫摄氏度（内核已对家族差异归一化）。
bool parseW1SlaveReading(const QByteArray &raw, double *milliCelsius)
{
    const int firstNewline = raw.indexOf('\n');
    if (firstNewline < 0 || !raw.left(firstNewline).trimmed().endsWith(" YES"))
        return false;
    const int tagIndex = raw.indexOf("t=", firstNewline + 1);
    if (tagIndex < 0)
        return false;
    const QByteArray tail = raw.mid(tagIndex + 2);
    const int end = tail.indexOf('\n');
    const QByteArray number = (end >= 0 ? tail.left(end) : tail).trimmed();
    bool ok = false;
    const qlonglong value = number.toLongLong(&ok);
    if (!ok || value < -55000 || value > 125000)
        return false;
    *milliCelsius = static_cast<double>(value);
    return true;
}

} // namespace

QWidget *MainWindow::createSensorPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("sensorPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(4);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("传感器"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    m_sensorStatus = new QLabel(QStringLiteral("打开后自动扫描"), header);
    m_sensorStatus->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(m_sensorStatus);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    QScrollArea *scroll = new QScrollArea(page);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setWidgetResizable(true);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scroll->setStyleSheet(QStringLiteral("QScrollArea { background:transparent; border:0; }"));
    m_sensorGridHost = new QWidget;
    m_sensorGridHost->setStyleSheet(QStringLiteral("background:transparent;"));
    m_sensorGrid = new QGridLayout(m_sensorGridHost);
    m_sensorGrid->setContentsMargins(0, 2, 0, 2);
    m_sensorGrid->setSpacing(6);
    scroll->setWidget(m_sensorGridHost);
    layout->addWidget(scroll, 1);

    QLabel *note = new QLabel(QStringLiteral("读取 thermal / hwmon / iio / 1-wire（DS18B20）；1.5 秒自动刷新"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(16);
    layout->addWidget(note);

    m_sensorTimer = new QTimer(page);
    m_sensorTimer->setInterval(1500);
    connect(m_sensorTimer, &QTimer::timeout, this, &MainWindow::updateSensorValues);

    // 读取线程：DS18B20 的 w1_slave 读取会同步等待一次温度转换（最长约 750ms
    // /12bit），放在工作线程执行，UI 仅收结果
    m_sensorPollWorker = new SensorPollWorker;
    m_sensorPollWorker->moveToThread(&m_sensorPollThread);
    connect(&m_sensorPollThread, &QThread::finished, m_sensorPollWorker, &QObject::deleteLater);
    connect(m_sensorPollWorker, &SensorPollWorker::polled, this, &MainWindow::onSensorPolled);
    m_sensorPollThread.start();
    return page;
}

void MainWindow::openSensorPage()
{
    m_peripheralPageStack->setCurrentWidget(m_sensorPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    refreshSensorList();
    if (m_sensorTimer)
        m_sensorTimer->start();
}

void MainWindow::refreshSensorList()
{
    if (!m_sensorGrid)
        return;
    ++m_sensorPollGeneration; // Invalidate old results even when the new list has the same size.
    while (QLayoutItem *item = m_sensorGrid->takeAt(0)) {
        if (QWidget *w = item->widget())
            delete w;
        delete item;
    }
    m_sensorEntries.clear();

    const QList<SensorDef> defs = scanBoardSensors();
    if (defs.isEmpty()) {
        QLabel *empty = new QLabel(QStringLiteral("未发现传感器 sysfs 节点"), m_sensorGridHost);
        empty->setObjectName(QStringLiteral("peripheralStatus"));
        empty->setAlignment(Qt::AlignCenter);
        m_sensorGrid->addWidget(empty, 0, 0, 1, 2);
        m_sensorStatus->setText(QStringLiteral("0 个通道"));
        return;
    }

    for (int i = 0; i < defs.size(); ++i) {
        const SensorDef &def = defs.at(i);
        QFrame *card = new QFrame(m_sensorGridHost);
        card->setObjectName(QStringLiteral("sensorValueCard"));
        QVBoxLayout *cardLayout = new QVBoxLayout(card);
        cardLayout->setContentsMargins(10, 4, 10, 5);
        cardLayout->setSpacing(1);
        QLabel *caption = new QLabel(def.caption, card);
        caption->setObjectName(QStringLiteral("sensorCaption"));
        QLabel *value = new QLabel(QStringLiteral("--"), card);
        value->setObjectName(QStringLiteral("sensorValue"));
        cardLayout->addWidget(caption);
        cardLayout->addWidget(value);
        m_sensorGrid->addWidget(card, i / 2, i % 2);

        SensorEntry entry;
        entry.valueLabel = value;
        entry.valuePath = def.valuePath;
        entry.scale = 1.0;
        entry.offset = 0.0;
        entry.divisor = def.divisor;
        entry.unit = def.unit;
        entry.decimals = def.decimals;
        bool metadataOk = true;
        if (!def.scalePath.isEmpty()) {
            entry.scale = readSysfsText(def.scalePath).toDouble(&metadataOk);
            metadataOk = metadataOk && std::isfinite(entry.scale) && entry.scale > 0.0;
        }
        if (!def.offsetPath.isEmpty()) {
            bool offsetOk = false;
            entry.offset = readSysfsText(def.offsetPath).toDouble(&offsetOk);
            metadataOk = metadataOk && offsetOk && std::isfinite(entry.offset);
        }
        if (!metadataOk) { // Never label unscaled ADC counts as volts/degrees.
            entry.scale = entry.divisor = 1.0;
            entry.offset = 0.0;
            entry.unit = QStringLiteral(" raw");
            entry.decimals = 0;
        }
        entry.sourceType = def.sourceType;
        m_sensorEntries.append(entry);
    }

    m_sensorStatus->setText(QStringLiteral("%1 个通道").arg(defs.size()));
    updateSensorValues();
}

void MainWindow::updateSensorValues()
{
    if (m_sensorEntries.isEmpty() || !m_sensorPollWorker)
        return;
    if (m_sensorPollBusy)
        return; // 上一轮（如 DS18B20 转换等待）还没返回，跳过本轮
    QStringList paths;
    paths.reserve(m_sensorEntries.size());
    for (const SensorEntry &entry : m_sensorEntries)
        paths.append(entry.valuePath);
    m_sensorPollBusy = true;
    m_sensorInFlightGeneration = ++m_sensorPollGeneration;
    QMetaObject::invokeMethod(m_sensorPollWorker, "pollNow", Qt::QueuedConnection,
                              Q_ARG(quint64, m_sensorInFlightGeneration),
                              Q_ARG(QStringList, paths));
}

void MainWindow::onSensorPolled(quint64 generation, const QByteArrayList &values)
{
    if (generation != m_sensorInFlightGeneration) return;
    m_sensorPollBusy = false;
    if (generation != m_sensorPollGeneration || values.size() != m_sensorEntries.size()) {
        if (m_peripheralPageStack->currentWidget() == m_sensorPage)
            updateSensorValues();
        return; // Rebuilt/left the page; do not write old values to new labels.
    }
    for (int i = 0; i < m_sensorEntries.size(); ++i) {
        const SensorEntry &entry = m_sensorEntries.at(i);
        double milliValue = 0.0;
        bool ok = false;
        if (entry.sourceType == 1) {
            ok = parseW1SlaveReading(values.at(i), &milliValue);
        } else {
            const double rawValue =
                QString::fromLocal8Bit(values.at(i)).trimmed().toDouble(&ok);
            milliValue = (rawValue + entry.offset) * entry.scale;
        }
        if (!ok || !std::isfinite(milliValue) || entry.divisor <= 0.0) {
            entry.valueLabel->setText(QStringLiteral("--"));
            continue;
        }
        const double value = milliValue / entry.divisor;
        entry.valueLabel->setText(QString::number(value, 'f', entry.decimals) + entry.unit);
    }
}

void SensorPollWorker::pollNow(quint64 generation, const QStringList &paths)
{
    QByteArrayList values;
    values.reserve(paths.size());
    for (const QString &path : paths) {
        if (QThread::currentThread()->isInterruptionRequested()) return;
        QFile file(path);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text))
            values.append(file.read(4096)); // w1_slave：内核在此同步等待一次温度转换
        else
            values.append(QByteArray());
    }
    emit polled(generation, values);
}

namespace {

// ---------------- CAN 总线（SocketCAN）辅助 ----------------

// 解析帧 ID：十六进制文本（可带 0x 前缀）；≤0x7FF 为标准帧，更大为扩展帧
bool parseCanIdText(const QString &text, quint32 *id, bool *extended)
{
    QString s = text.trimmed();
    if (s.startsWith(QLatin1String("0x"), Qt::CaseInsensitive))
        s = s.mid(2);
    bool ok = false;
    const quint32 value = s.toUInt(&ok, 16);
    if (!ok || s.isEmpty() || value > 0x1FFFFFFF)
        return false;
    *id = value;
    *extended = value > 0x7FF;
    return true;
}

// 解析数据：HEX 字节串，可含空格/逗号分隔；允许空（0 字节）；最多 8 字节
bool parseCanDataText(const QString &text, QByteArray *payload)
{
    payload->clear();
    QString filtered;
    const QString s = text.trimmed();
    for (const QChar &ch : s) {
        if (ch.isSpace() || ch == QLatin1Char(',') || ch == QLatin1Char('_'))
            continue;
        filtered.append(ch);
    }
    if (filtered.isEmpty())
        return true;
    if (filtered.size() % 2 != 0 || filtered.size() > 16)
        return false;
    for (int i = 0; i < filtered.size(); i += 2) {
        bool ok = false;
        const uint byte = filtered.mid(i, 2).toUInt(&ok, 16);
        if (!ok || byte > 0xFF)
            return false;
        payload->append(static_cast<char>(byte));
    }
    return true;
}

QString formatCanFrameText(const char *direction, const struct can_frame &frame)
{
    QStringList bytes;
    for (int i = 0; i < frame.can_dlc && i < 8; ++i)
        bytes << QStringLiteral("%1").arg(frame.data[i], 2, 16, QLatin1Char('0')).toUpper();
    const QString idText = (frame.can_id & CAN_EFF_FLAG)
                               ? QStringLiteral("X%1").arg(frame.can_id & CAN_EFF_MASK, 7, 16,
                                                           QLatin1Char('0')).toUpper()
                               : QStringLiteral("%1").arg(frame.can_id & CAN_SFF_MASK, 3, 16,
                                                          QLatin1Char('0')).toUpper();
    return QStringLiteral("%1 %2 [%3] %4")
        .arg(QString::fromLatin1(direction), idText)
        .arg(frame.can_dlc)
        .arg(bytes.join(QLatin1Char(' ')));
}

QStringList scanCanInterfaceNames()
{
    const QDir netRoot(QStringLiteral("/sys/class/net"));
    return netRoot.entryList(QStringList() << QStringLiteral("can*"),
                             QDir::Dirs | QDir::NoDotAndDotDot | QDir::System, QDir::Name);
}

} // namespace

QWidget *MainWindow::createCanTestPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("canTestPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(4);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(36);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("CAN 总线"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    m_canStatusLabel = new QLabel(QStringLiteral("未打开"), header);
    m_canStatusLabel->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(m_canStatusLabel);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    // 链路控制行：接口 + 波特率 + 开关
    QFrame *controls = new QFrame(page);
    controls->setObjectName(QStringLiteral("canCard"));
    QHBoxLayout *controlLayout = new QHBoxLayout(controls);
    controlLayout->setContentsMargins(9, 4, 9, 4);
    controlLayout->setSpacing(6);
    QLabel *ifLabel = new QLabel(QStringLiteral("接口"), controls);
    ifLabel->setObjectName(QStringLiteral("canFormLabel"));
    m_canIfCombo = new QComboBox(controls);
    m_canIfCombo->setFixedWidth(78);
    m_canIfCombo->setFixedHeight(28);
    QLabel *bitrateLabel = new QLabel(QStringLiteral("波特率"), controls);
    bitrateLabel->setObjectName(QStringLiteral("canFormLabel"));
    m_canBitrateCombo = new QComboBox(controls);
    m_canBitrateCombo->setFixedHeight(28);
    const int bitrates[] = {125, 250, 500, 800, 1000};
    for (int kbps : bitrates)
        m_canBitrateCombo->addItem(QStringLiteral("%1k").arg(kbps), kbps);
    m_canBitrateCombo->setCurrentIndex(2); // 默认 500k
    m_canToggleButton = new QPushButton(QStringLiteral("打开 CAN"), controls);
    m_canToggleButton->setFixedHeight(28);
    m_canToggleButton->setFixedWidth(76);
    controlLayout->addWidget(ifLabel);
    controlLayout->addWidget(m_canIfCombo);
    controlLayout->addWidget(bitrateLabel);
    controlLayout->addWidget(m_canBitrateCombo, 1);
    controlLayout->addWidget(m_canToggleButton);
    layout->addWidget(controls);
    connect(m_canToggleButton, &QPushButton::clicked, this, &MainWindow::toggleCanLink);

    // 发送行：ID + 数据 + 发送按钮
    QFrame *sendCard = new QFrame(page);
    sendCard->setObjectName(QStringLiteral("canCard"));
    QHBoxLayout *sendLayout = new QHBoxLayout(sendCard);
    sendLayout->setContentsMargins(9, 4, 9, 4);
    sendLayout->setSpacing(6);
    m_canIdEdit = new QLineEdit(sendCard);
    m_canIdEdit->setPlaceholderText(QStringLiteral("ID (HEX 如 123)"));
    m_canIdEdit->setFixedWidth(96);
    m_canIdEdit->setFixedHeight(28);
    m_canDataEdit = new QLineEdit(sendCard);
    m_canDataEdit->setPlaceholderText(QStringLiteral("数据 HEX（≤8 字节）如 11 22 AA"));
    m_canDataEdit->setFixedHeight(28);
    m_canSendButton = new QPushButton(QStringLiteral("发送"), sendCard);
    m_canSendButton->setFixedHeight(28);
    m_canSendButton->setFixedWidth(56);
    m_canIdEdit->setEnabled(false);
    m_canDataEdit->setEnabled(false);
    m_canSendButton->setEnabled(false);
    sendLayout->addWidget(m_canIdEdit);
    sendLayout->addWidget(m_canDataEdit, 1);
    sendLayout->addWidget(m_canSendButton);
    layout->addWidget(sendCard);
    connect(m_canSendButton, &QPushButton::clicked, this, &MainWindow::sendCanFrame);
    connect(m_canDataEdit, &QLineEdit::returnPressed, this, &MainWindow::sendCanFrame);

    // 收发日志
    m_canLogView = new QPlainTextEdit(page);
    m_canLogView->setObjectName(QStringLiteral("canLog"));
    m_canLogView->setReadOnly(true);
    m_canLogView->setMaximumBlockCount(120);
    m_canLogView->setPlaceholderText(QStringLiteral("收发帧日志…"));
    layout->addWidget(m_canLogView, 1);

    QLabel *note = new QLabel(QStringLiteral("SocketCAN · 用 ip 命令配置链路（需 root/iproute2）；数据支持空格分隔"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(14);
    layout->addWidget(note);
    m_canSession = new CanLinkSession(this);
    m_selfTestCanSession = new CanLinkSession(this);
    connect(m_canSession, &CanLinkSession::ready, this, [this](bool reused) {
        if (m_peripheralPageStack->currentWidget() != m_canTestPage) {
            m_canSession->close();
            return;
        }
        appendCanLog(reused ? QStringLiteral("⊙ 沿用已启用接口的现有配置，不修改/关闭外部链路")
                            : QStringLiteral("⊙ CAN 链路配置完成，控制器回环已关闭"));
        attachCanSocket();
    });
    connect(m_canSession, &CanLinkSession::failed, this, [this](const QString &message) {
        appendCanLog(message);
        m_canStatusLabel->setText(QStringLiteral("配置失败，正在清理"));
    });
    connect(m_canSession, &CanLinkSession::closed, this, [this](const QString &error) {
        closeCanLink();
        if (!error.isEmpty()) {
            appendCanLog(error + QStringLiteral("；请人工检查接口状态"));
            m_canStatusLabel->setText(QStringLiteral("接口恢复失败"));
        }
    });
    connect(m_selfTestCanSession, &CanLinkSession::closed, this, [this](const QString &error) {
        if (!error.isEmpty()) {
            if (m_selfTestRows.size() > 3) {
                if (m_selfTestRows.at(3).status->property("testState").toInt() == 2 && m_selfTestPassed > 0)
                    --m_selfTestPassed;
                setSelfTestRowState(3, 3, error + QStringLiteral("；请人工检查接口"));
            }
            m_selfTestSummary->setText(QStringLiteral("CAN 恢复失败，请人工检查"));
            m_selfTestSummary->setToolTip(error);
        }
    });
    return page;
}

void MainWindow::openCanTestPage()
{
    scanCanInterfaces();
    m_peripheralPageStack->setCurrentWidget(m_canTestPage);
    m_stack->setCurrentWidget(m_peripheralPage);
}

void MainWindow::scanCanInterfaces()
{
    if (!m_canIfCombo || (m_canSession && m_canSession->isActive()))
        return;
    const QString previous = m_canIfCombo->currentText();
    m_canIfCombo->clear();
    const QStringList names = scanCanInterfaceNames();
    m_canIfCombo->addItems(names.isEmpty() ? (QStringList() << QStringLiteral("can0")) : names);
    int index = m_canIfCombo->findText(previous);
    if (index < 0)
        index = m_canIfCombo->findText(QStringLiteral("can0"));
    if (index >= 0)
        m_canIfCombo->setCurrentIndex(index);
}

void MainWindow::appendCanLog(const QString &line)
{
    if (!m_canLogView)
        return;
    m_canLogView->appendPlainText(QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"))
                                  + QLatin1Char(' ') + line);
    QTextCursor cursor = m_canLogView->textCursor();
    cursor.movePosition(QTextCursor::End);
    m_canLogView->setTextCursor(cursor);
}

void MainWindow::toggleCanLink()
{
    if (m_canFd >= 0 || m_canSession->isActive()) {
        closeCanLink();
        return;
    }
    if (m_selfTestCanSession->isActive()) {
        appendCanLog(QStringLiteral("CAN 自检资源正在释放，请稍后重试"));
        return;
    }
    const QString iface = m_canIfCombo->currentText().trimmed();
    // Combo data are in kbps; iproute2 requires bits/s.
    const int bitrateBps = m_canBitrateCombo->currentData().toInt() * 1000;
    if (!m_canSession->begin(iface, bitrateBps, false)) {
        appendCanLog(QStringLiteral("无法打开 CAN：接口/速率无效，或上次接口恢复失败"));
        return;
    }
    m_canIfCombo->setEnabled(false);
    m_canBitrateCombo->setEnabled(false);
    m_canStatusLabel->setText(QStringLiteral("正在配置 CAN…"));
    m_canToggleButton->setText(QStringLiteral("取消打开"));
}

void MainWindow::attachCanSocket()
{
    const QString iface = m_canSession->interfaceName();
    const int fd = ::socket(PF_CAN, SOCK_RAW | SOCK_NONBLOCK | SOCK_CLOEXEC, CAN_RAW);
    if (fd < 0) {
        appendCanLog(QStringLiteral("✗ 创建 CAN socket 失败：%1")
                         .arg(QString::fromLocal8Bit(strerror(errno))));
        closeCanLink();
        m_canStatusLabel->setText(QStringLiteral("打开失败"));
        return;
    }
    const QByteArray nameBytes = iface.toLocal8Bit();
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, nameBytes.constData(), IFNAMSIZ - 1);
    if (::ioctl(fd, SIOCGIFINDEX, &ifr) < 0) {
        appendCanLog(QStringLiteral("✗ 查询接口索引失败：%1")
                         .arg(QString::fromLocal8Bit(strerror(errno))));
        ::close(fd);
        closeCanLink();
        m_canStatusLabel->setText(QStringLiteral("打开失败"));
        return;
    }
    struct sockaddr_can addr;
    memset(&addr, 0, sizeof(addr));
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    if (::bind(fd, reinterpret_cast<struct sockaddr *>(&addr), sizeof(addr)) < 0) {
        appendCanLog(QStringLiteral("✗ 绑定 %1 失败：%2")
                         .arg(iface, QString::fromLocal8Bit(strerror(errno))));
        ::close(fd);
        closeCanLink();
        m_canStatusLabel->setText(QStringLiteral("打开失败"));
        return;
    }
    m_canFd = fd;
    m_canNotifier = new QSocketNotifier(fd, QSocketNotifier::Read, this);
    connect(m_canNotifier, &QSocketNotifier::activated, this, &MainWindow::readCanFrames);

    const int bitrate = m_canSession->effectiveBitrate();
    m_canStatusLabel->setText(bitrate > 0 ? QStringLiteral("%1 @ %2k 已打开").arg(iface).arg(bitrate / 1000)
                                         : QStringLiteral("%1 已打开（现有配置）").arg(iface));
    m_canToggleButton->setText(QStringLiteral("关闭 CAN"));
    m_canIfCombo->setEnabled(false);
    m_canBitrateCombo->setEnabled(false);
    m_canIdEdit->setEnabled(true);
    m_canDataEdit->setEnabled(true);
    m_canSendButton->setEnabled(true);
    appendCanLog(QStringLiteral("● 已连接 %1，开始接收帧").arg(iface));
}

void MainWindow::closeCanLink()
{
    if (m_canFd >= 0) {
        delete m_canNotifier;
        m_canNotifier = nullptr;
        ::close(m_canFd);
        m_canFd = -1;
        appendCanLog(QStringLiteral("● CAN 会话已关闭"));
    }
    if (m_canSession) m_canSession->close();
    const bool closing = m_canSession && m_canSession->isActive();
    if (m_canToggleButton)
        m_canToggleButton->setText(closing ? QStringLiteral("正在关闭…") : QStringLiteral("打开 CAN"));
    if (m_canToggleButton) m_canToggleButton->setEnabled(!closing);
    if (m_canIfCombo)
        m_canIfCombo->setEnabled(!closing);
    if (m_canBitrateCombo)
        m_canBitrateCombo->setEnabled(!closing);
    if (m_canIdEdit)
        m_canIdEdit->setEnabled(false);
    if (m_canDataEdit)
        m_canDataEdit->setEnabled(false);
    if (m_canSendButton)
        m_canSendButton->setEnabled(false);
    if (m_canStatusLabel && m_canStatusLabel->text() != QStringLiteral("配置失败"))
        m_canStatusLabel->setText(closing ? QStringLiteral("正在恢复接口…") : QStringLiteral("未打开"));
}

void MainWindow::sendCanFrame()
{
    if (m_canFd < 0) {
        appendCanLog(QStringLiteral("✗ CAN 未打开，无法发送"));
        return;
    }
    quint32 id = 0;
    bool extended = false;
    if (!parseCanIdText(m_canIdEdit->text(), &id, &extended)) {
        appendCanLog(QStringLiteral("✗ ID 无效：HEX 如 123；>7FF 自动按扩展帧发送"));
        return;
    }
    QByteArray payload;
    if (!parseCanDataText(m_canDataEdit->text(), &payload)) {
        appendCanLog(QStringLiteral("✗ 数据无效：HEX 字节串（≤8 字节），如 11 22 AA"));
        return;
    }

    struct can_frame frame;
    memset(&frame, 0, sizeof(frame));
    frame.can_id = id | (extended ? CAN_EFF_FLAG : 0u);
    frame.can_dlc = static_cast<__u8>(payload.size());
    if (!payload.isEmpty())
        memcpy(frame.data, payload.constData(), static_cast<size_t>(payload.size()));
    const ssize_t written = ::write(m_canFd, &frame, sizeof(frame));
    if (written != static_cast<ssize_t>(sizeof(frame))) {
        appendCanLog(QStringLiteral("✗ 发送失败：%1")
                         .arg(QString::fromLocal8Bit(strerror(errno))));
        return;
    }
    appendCanLog(formatCanFrameText("TX", frame));
}

void MainWindow::readCanFrames()
{
    if (m_canFd < 0)
        return;
    for (int budget = 0; budget < 32; ++budget) {
        struct can_frame frame;
        const ssize_t n = ::read(m_canFd, &frame, sizeof(frame));
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            if (errno == EINTR) continue;
            appendCanLog(QStringLiteral("✗ 读取失败：%1")
                             .arg(QString::fromLocal8Bit(strerror(errno))));
            closeCanLink();
            return;
        }
        if (n != static_cast<ssize_t>(sizeof(frame)))
            break;
        if (frame.can_id & CAN_ERR_FLAG)
            continue; // 忽略错误帧，保持日志干净
        appendCanLog(formatCanFrameText("RX", frame));
    }
}

namespace {
double memoryUsagePercent(const QByteArray &contents)
{
    QHash<QByteArray, quint64> fields;
    for (const QByteArray &line : contents.split('\n')) {
        const QList<QByteArray> parts = line.simplified().split(' ');
        if (parts.size() >= 2) fields.insert(parts.at(0), parts.at(1).toULongLong());
    }
    const quint64 total = fields.value("MemTotal:");
    if (!total) return 0.0;
    quint64 available = fields.value("MemAvailable:");
    if (!fields.contains("MemAvailable:")) { // Older i.MX6 BSP kernels.
        const quint64 reclaimable = fields.value("MemFree:") + fields.value("Buffers:") +
            fields.value("Cached:") + fields.value("SReclaimable:");
        available = reclaimable - qMin(reclaimable, fields.value("Shmem:"));
    }
    available = qMin(total, available);
    return 100.0 * static_cast<double>(total - available) / static_cast<double>(total);
}
} // namespace

void MainWindow::sampleSystemLoad()
{
    // CPU：/proc/stat 首行（user nice system idle iowait irq softirq steal ...）
    double cpuPercent = 0.0;
    QFile statFile(QStringLiteral("/proc/stat"));
    if (statFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        const QByteArray line = statFile.readLine().simplified();
        const QList<QByteArray> parts = line.split(' ');
        if (parts.size() >= 5 && parts.at(0) == "cpu") {
            quint64 fields[8] = {0};
            const int count = qMin(parts.size() - 1, 8);
            for (int i = 0; i < count; ++i)
                fields[i] = parts.at(i + 1).toULongLong();
            const quint64 idle = fields[3] + fields[4]; // idle + iowait
            quint64 total = 0;
            for (int i = 0; i < count; ++i)
                total += fields[i];
            if (m_prevCpuTotal > 0 && total > m_prevCpuTotal) {
                const quint64 totalDelta = total - m_prevCpuTotal;
                const quint64 idleDelta = idle >= m_prevCpuIdle ? qMin(totalDelta, idle - m_prevCpuIdle) : 0;
                cpuPercent = 100.0 * static_cast<double>(totalDelta - idleDelta) /
                             static_cast<double>(totalDelta);
            }
            m_prevCpuTotal = total;
            m_prevCpuIdle = idle;
        }
    }

    // procfs reports size=0, so QFile::atEnd() can be true before the first
    // read. Read first, then parse; zero MemAvailable is also a valid reading.
    double memPercent = 0.0;
    QFile memFile(QStringLiteral("/proc/meminfo"));
    if (memFile.open(QIODevice::ReadOnly | QIODevice::Text))
        memPercent = memoryUsagePercent(memFile.read(65536));

    if (m_loadChart)
        m_loadChart->appendReading(cpuPercent, memPercent);
}

namespace {

// 一键测试：行状态 0=待测 1=检测中 2=通过 3=失败
QString selfTestBaudText(speed_t speed)
{
    switch (speed) {
#ifdef B9600
    case B9600: return QStringLiteral("9600");
#endif
#ifdef B19200
    case B19200: return QStringLiteral("19200");
#endif
#ifdef B38400
    case B38400: return QStringLiteral("38400");
#endif
#ifdef B57600
    case B57600: return QStringLiteral("57600");
#endif
#ifdef B115200
    case B115200: return QStringLiteral("115200");
#endif
#ifdef B230400
    case B230400: return QStringLiteral("230400");
#endif
    default: break;
    }
    return QStringLiteral("?");
}

} // namespace

QWidget *MainWindow::createSelfTestPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("selfTestPage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(3);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(34);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("一键测试"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    m_selfTestSummary = new QLabel(QStringLiteral("未运行"), header);
    m_selfTestSummary->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(m_selfTestSummary);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    QFrame *controls = new QFrame(page);
    controls->setObjectName(QStringLiteral("canCard"));
    QHBoxLayout *controlLayout = new QHBoxLayout(controls);
    controlLayout->setContentsMargins(9, 4, 9, 4);
    controlLayout->setSpacing(8);
    m_selfTestButton = new QPushButton(QStringLiteral("开始测试"), controls);
    m_selfTestButton->setFixedHeight(30);
    QLabel *hint = new QLabel(QStringLiteral("逐项自检，单项超时保护"), controls);
    hint->setObjectName(QStringLiteral("peripheralStatus"));
    controlLayout->addWidget(m_selfTestButton);
    controlLayout->addWidget(hint, 1);
    layout->addWidget(controls);
    connect(m_selfTestButton, &QPushButton::clicked, this, &MainWindow::startSelfTest);

    const QString names[] = {
        QStringLiteral("摄像头"), QStringLiteral("音频采集"), QStringLiteral("RS485 串口"),
        QStringLiteral("CAN 总线"), QStringLiteral("板载传感器")
    };
    m_selfTestRows.clear();
    for (const QString &name : names) {
        QFrame *row = new QFrame(page);
        row->setObjectName(QStringLiteral("selfTestRow"));
        row->setFixedHeight(30);
        QHBoxLayout *rowLayout = new QHBoxLayout(row);
        rowLayout->setContentsMargins(9, 2, 9, 2);
        rowLayout->setSpacing(7);
        QLabel *status = new QLabel(QStringLiteral("○"), row);
        status->setObjectName(QStringLiteral("selfTestRowStatus"));
        status->setAlignment(Qt::AlignCenter);
        status->setFixedWidth(20);
        QLabel *nameLabel = new QLabel(name, row);
        nameLabel->setObjectName(QStringLiteral("selfTestRowName"));
        nameLabel->setFixedWidth(84);
        QLabel *detail = new QLabel(QStringLiteral("待测"), row);
        detail->setObjectName(QStringLiteral("selfTestRowDetail"));
        rowLayout->addWidget(status);
        rowLayout->addWidget(nameLabel);
        rowLayout->addWidget(detail, 1);
        layout->addWidget(row);
        m_selfTestRows.append(SelfTestRow{status, detail});
    }

    QLabel *note = new QLabel(QStringLiteral("串口：打开/写入，非对端验证；CAN：内部回环；传感器：节点扫描"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(14);
    layout->addWidget(note);

    // 单项超时保护（时长由各测试项设定）
    m_selfTestTimeout = new QTimer(page);
    m_selfTestTimeout->setSingleShot(true);
    return page;
}

void MainWindow::openSelfTestPage()
{
    m_peripheralPageStack->setCurrentWidget(m_selfTestPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    if (!m_selfTestRunning && m_selfTestIndex == -1)
        m_selfTestSummary->setText(QStringLiteral("就绪"));
}

void MainWindow::setSelfTestRowState(int row, int state, const QString &detail)
{
    if (row < 0 || row >= m_selfTestRows.size())
        return;
    const SelfTestRow &r = m_selfTestRows.at(row);
    r.status->setProperty("testState", state);
    switch (state) {
    case 1: // 检测中
        r.status->setText(QStringLiteral("…"));
        r.status->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::AccentBright.name()));
        r.detail->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::TextHint.name()));
        break;
    case 2: // 通过
        r.status->setPixmap(makeUiIcon(UiIcon::Check, Theme::Success).pixmap(16, 16));
        r.status->setStyleSheet(QString());
        r.detail->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::SuccessBright.name()));
        break;
    case 3: // 失败
        r.status->setText(QStringLiteral("✗"));
        r.status->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::Danger.name()));
        r.detail->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::Danger.name()));
        break;
    default: // 0 待测
        r.status->setText(QStringLiteral("○"));
        r.status->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::TextHint.name()));
        r.detail->setStyleSheet(QStringLiteral("color:%1;").arg(Theme::TextHint.name()));
        break;
    }
    r.detail->setText(detail);
}

void MainWindow::startSelfTest()
{
    if (m_selfTestRunning) return;
    if (m_selfTestCameraThread.isRunning() || m_cameraRunning || m_cameraStartPending || m_cameraStopPending ||
        m_canSession->isActive() || m_selfTestCanSession->isActive() ||
        m_recordProcess->state() != QProcess::NotRunning || m_playProcess->state() != QProcess::NotRunning ||
        m_xiaozhiBridge->isActive()) {
        m_selfTestSummary->setText(QStringLiteral("设备忙或正在释放，请稍后重试"));
        return;
    }
    ++m_selfTestGeneration;
    m_selfTestRunning = true;
    m_selfTestIndex = -1;
    m_selfTestPassed = 0;
    m_selfTestItemDone = true;
    m_selfTestSummary->setStyleSheet(QString());
    for (int i = 0; i < m_selfTestRows.size(); ++i)
        setSelfTestRowState(i, 0, QStringLiteral("待测"));
    m_selfTestButton->setEnabled(false);
    m_selfTestButton->setText(QStringLiteral("测试中…"));
    m_selfTestSummary->setText(QStringLiteral("进行中 0/%1").arg(m_selfTestRows.size()));
    runSelfTestItem();
}

void MainWindow::runSelfTestItem()
{
    if (!m_selfTestRunning) return;
    ++m_selfTestIndex;
    if (m_selfTestIndex >= m_selfTestRows.size()) {
        m_selfTestRunning = false;
        m_selfTestIndex = -1;
        m_selfTestButton->setEnabled(true);
        m_selfTestButton->setText(QStringLiteral("重新测试"));
        const int total = m_selfTestRows.size();
        const bool allPass = m_selfTestPassed == total;
        m_selfTestSummary->setText(QStringLiteral("通过 %1/%2").arg(m_selfTestPassed).arg(total));
        m_selfTestSummary->setStyleSheet(QStringLiteral("color:%1; font-weight:700;")
            .arg((allPass ? Theme::SuccessBright : Theme::Danger).name()));
        return;
    }
    const quint64 generation = ++m_selfTestGeneration;
    const int row = m_selfTestIndex;
    const auto current = [this, generation, row]() {
        return m_selfTestRunning && !m_selfTestItemDone &&
               m_selfTestGeneration == generation && m_selfTestIndex == row;
    };
    m_selfTestItemDone = false;
    m_selfTestSummary->setText(QStringLiteral("进行中 %1/%2").arg(row + 1).arg(m_selfTestRows.size()));
    setSelfTestRowState(row, 1, QStringLiteral("检测中…"));
    m_selfTestTimeout->disconnect(this);
    connect(m_selfTestTimeout, &QTimer::timeout, this, [this, current, row]() {
        if (!current()) return;
        finishSelfTestItem(false, row == 0 ? QStringLiteral("摄像头打开/采集超时")
            : row == 1 ? QStringLiteral("音频采集超时")
            : row == 3 ? QStringLiteral("CAN 配置或回环收发超时") : QStringLiteral("超时未响应"));
    });

    if (row == 0) {
        if (m_selfTestCameraThread.isRunning()) {
            finishSelfTestItem(false, QStringLiteral("上次摄像头采集仍在释放，请稍后重试"));
            return;
        }
        m_selfTestCamInfo = QStringLiteral("V4L2");
        m_selfTestCamera = new CameraWorker;
        m_selfTestCamera->prepareCapture();
        m_selfTestCamera->moveToThread(&m_selfTestCameraThread);
        connect(&m_selfTestCameraThread, &QThread::finished, m_selfTestCamera, &QObject::deleteLater);
        connect(&m_selfTestCameraThread, &QThread::started, m_selfTestCamera, &CameraWorker::startCapture);
        connect(m_selfTestCamera, &CameraWorker::captureOpened, this,
            [this, current](const QString &, int w, int h, const QString &, int) {
                if (current()) m_selfTestCamInfo = QStringLiteral("%1×%2").arg(w).arg(h);
            });
        connect(m_selfTestCamera, &CameraWorker::frameReady, this, [this, current](const QImage &) {
            if (current()) finishSelfTestItem(true, QStringLiteral("%1 采集正常").arg(m_selfTestCamInfo));
        });
        connect(m_selfTestCamera, &CameraWorker::captureFailed, this, [this, current](const QString &error) {
            if (current()) finishSelfTestItem(false, error);
        });
        m_selfTestTimeout->start(4500);
        m_selfTestCameraThread.start();
    } else if (row == 1) {
        if (m_selfTestAudioPath.isEmpty()) {
            finishSelfTestItem(false, QStringLiteral("无法创建私有录音临时目录"));
            return;
        }
        m_selfTestAudio = new QProcess(this);
        m_selfTestAudio->setProcessChannelMode(QProcess::MergedChannels);
        QProcess *audio = m_selfTestAudio;
        connect(audio, &QProcess::readyReadStandardOutput, audio,
            [audio]() { audio->readAllStandardOutput(); });
        connect(m_selfTestAudio, &QProcess::errorOccurred, this, [this, current](QProcess::ProcessError error) {
            if (current() && error == QProcess::FailedToStart)
                finishSelfTestItem(false, QStringLiteral("无法启动 %1").arg(m_arecordProgram));
        });
        connect(m_selfTestAudio, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
            [this, current](int code, QProcess::ExitStatus status) {
                if (!current()) return;
                const bool passed = status == QProcess::NormalExit && code == 0 &&
                                    QFileInfo(m_selfTestAudioPath).size() > 44;
                finishSelfTestItem(passed, passed ? QStringLiteral("采集 1 秒正常（%1）").arg(m_captureDevice)
                    : QStringLiteral("采集失败或 WAV 为空（代码 %1）").arg(code));
            });
        m_selfTestAudio->start(m_arecordProgram,
            {QStringLiteral("-D"), m_captureDevice, QStringLiteral("-f"), QStringLiteral("S16_LE"),
             QStringLiteral("-r"), QStringLiteral("16000"), QStringLiteral("-c"), QStringLiteral("1"),
             QStringLiteral("-t"), QStringLiteral("wav"), QStringLiteral("-d"), QStringLiteral("1"), m_selfTestAudioPath});
        m_selfTestTimeout->start(4500);
    } else if (row == 2) {
        QString device = QString::fromLocal8Bit(qgetenv("MODBUS_DEVICE"));
        if (device.isEmpty()) device = QStringLiteral("/dev/ttymxc2");
        m_selfTestSerialEcho = false;
        m_selfTestSerialFd = ::open(device.toLocal8Bit().constData(), O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
        if (m_selfTestSerialFd < 0) {
            finishSelfTestItem(false, QStringLiteral("无法打开 %1：%2")
                .arg(device, QString::fromLocal8Bit(strerror(errno))));
            return;
        }
        if (::tcgetattr(m_selfTestSerialFd, &m_selfTestOriginalTermios) != 0) {
            finishSelfTestItem(false, QStringLiteral("无法读取串口参数"));
            return;
        }
        m_selfTestSerialTermiosSaved = true;
        struct termios raw = m_selfTestOriginalTermios;
        ::cfmakeraw(&raw);
        if (::tcsetattr(m_selfTestSerialFd, TCSANOW, &raw) != 0) {
            finishSelfTestItem(false, QStringLiteral("无法设置串口测试模式"));
            return;
        }
        ::tcflush(m_selfTestSerialFd, TCIFLUSH);
        m_selfTestSerialInfo = QStringLiteral("可打开/写入（%1 波特）")
            .arg(selfTestBaudText(::cfgetispeed(&raw)));
        const char probe = 0x55;
        if (::write(m_selfTestSerialFd, &probe, 1) != 1) {
            finishSelfTestItem(false, QStringLiteral("串口测试字节写入失败"));
            return;
        }
        m_selfTestSerialNotifier = new QSocketNotifier(m_selfTestSerialFd, QSocketNotifier::Read, this);
        connect(m_selfTestSerialNotifier, &QSocketNotifier::activated, this, [this, current]() {
            if (!current()) return;
            char buffer[64];
            const ssize_t count = ::read(m_selfTestSerialFd, buffer, sizeof(buffer));
            if (count > 0 && QByteArray(buffer, static_cast<int>(count)).contains(char(0x55)))
                m_selfTestSerialEcho = true;
        });
        QTimer::singleShot(300, this, [this, current]() {
            if (current()) finishSelfTestItem(true, m_selfTestSerialInfo +
                (m_selfTestSerialEcho ? QStringLiteral("，55 回显正常") : QStringLiteral("，未验证对端")));
        });
        m_selfTestTimeout->start(1200);
    } else if (row == 3) {
        const QStringList interfaces = scanCanInterfaceNames();
        if (interfaces.isEmpty()) {
            finishSelfTestItem(false, QStringLiteral("未发现 canX 接口"));
            return;
        }
        m_selfTestCanIf = interfaces.first();
        m_selfTestCanReadyConnection = connect(m_selfTestCanSession, &CanLinkSession::ready, this,
            [this, current, generation](bool) { if (current()) startSelfTestCanSocket(generation); });
        m_selfTestCanFailureConnection = connect(m_selfTestCanSession, &CanLinkSession::failed, this,
            [this, current](const QString &error) { if (current()) finishSelfTestItem(false, error); });
        if (!m_selfTestCanSession->begin(m_selfTestCanIf, 500000, true)) {
            finishSelfTestItem(false, QStringLiteral("CAN 正在释放或上次恢复失败"));
            return;
        }
        m_selfTestTimeout->start(6500);
    } else {
        const QList<SensorDef> defs = scanBoardSensors();
        finishSelfTestItem(!defs.isEmpty(), defs.isEmpty()
            ? QStringLiteral("未发现 thermal/hwmon/iio/1-wire 节点")
            : QStringLiteral("发现 %1 个通道（仅扫描）").arg(defs.size()));
    }
}

void MainWindow::startSelfTestCanSocket(quint64 generation)
{
    const auto current = [this, generation]() {
        return m_selfTestRunning && !m_selfTestItemDone && m_selfTestIndex == 3 &&
               m_selfTestGeneration == generation;
    };
    if (!current()) return;
    const int fd = ::socket(PF_CAN, SOCK_RAW | SOCK_NONBLOCK | SOCK_CLOEXEC, CAN_RAW);
    if (fd < 0) {
        finishSelfTestItem(false, QStringLiteral("创建 CAN socket 失败"));
        return;
    }
    m_selfTestCanFd = fd;
    const int one = 1;
    struct can_filter filter;
    filter.can_id = 0x123;
    filter.can_mask = CAN_SFF_MASK | CAN_EFF_FLAG | CAN_RTR_FLAG;
    if (::setsockopt(fd, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS, &one, sizeof(one)) != 0 ||
        ::setsockopt(fd, SOL_CAN_RAW, CAN_RAW_LOOPBACK, &one, sizeof(one)) != 0 ||
        ::setsockopt(fd, SOL_CAN_RAW, CAN_RAW_FILTER, &filter, sizeof(filter)) != 0) {
        finishSelfTestItem(false, QStringLiteral("CAN 回环选项设置失败"));
        return;
    }
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    const QByteArray name = m_selfTestCanIf.toLocal8Bit();
    strncpy(ifr.ifr_name, name.constData(), IFNAMSIZ - 1);
    if (::ioctl(fd, SIOCGIFINDEX, &ifr) < 0) {
        finishSelfTestItem(false, QStringLiteral("CAN 接口索引查询失败"));
        return;
    }
    struct sockaddr_can address;
    memset(&address, 0, sizeof(address));
    address.can_family = AF_CAN;
    address.can_ifindex = ifr.ifr_ifindex;
    if (::bind(fd, reinterpret_cast<struct sockaddr *>(&address), sizeof(address)) < 0) {
        finishSelfTestItem(false, QStringLiteral("CAN socket 绑定失败"));
        return;
    }
    const QByteArray pattern = QByteArray::fromHex("deadbeef01020304");
    m_selfTestCanNotifier = new QSocketNotifier(fd, QSocketNotifier::Read, this);
    connect(m_selfTestCanNotifier, &QSocketNotifier::activated, this, [this, current, pattern]() {
        if (!current()) return;
        for (int budget = 0; budget < 32; ++budget) {
            struct can_frame frame;
            const ssize_t count = ::read(m_selfTestCanFd, &frame, sizeof(frame));
            if (count < 0 && errno == EINTR) continue;
            if (count != static_cast<ssize_t>(sizeof(frame))) return;
            if (frame.can_id == 0x123 && frame.can_dlc == 8 && memcmp(frame.data, pattern.constData(), 8) == 0) {
                finishSelfTestItem(true, QStringLiteral("内部回环 ID/长度/8 字节数据匹配（500k）"));
                return; // Cleanup closes the fd; do not keep reading it.
            }
        }
    });
    struct can_frame frame;
    memset(&frame, 0, sizeof(frame));
    frame.can_id = 0x123;
    frame.can_dlc = 8;
    memcpy(frame.data, pattern.constData(), 8);
    if (::write(fd, &frame, sizeof(frame)) != static_cast<ssize_t>(sizeof(frame))) {
        finishSelfTestItem(false, QStringLiteral("CAN 测试帧发送失败"));
        return;
    }
    m_selfTestTimeout->start(1800);
}

void MainWindow::finishSelfTestItem(bool passed, const QString &detail)
{
    if (!m_selfTestRunning || m_selfTestIndex < 0 || m_selfTestIndex >= m_selfTestRows.size() || m_selfTestItemDone)
        return;
    m_selfTestItemDone = true;
    if (m_selfTestTimeout)
        m_selfTestTimeout->stop();
    cleanupSelfTestItem();
    setSelfTestRowState(m_selfTestIndex, passed ? 2 : 3, detail);
    if (passed)
        ++m_selfTestPassed;
    const quint64 generation = m_selfTestGeneration;
    QTimer::singleShot(150, this, [this, generation]() {
        if (m_selfTestRunning && generation == m_selfTestGeneration) runSelfTestItem();
    });
}

void MainWindow::cleanupSelfTestItem()
{
    if (m_selfTestTimeout)
        m_selfTestTimeout->stop();
    if (m_selfTestCamera) {
        m_selfTestCamera->disconnect(this);
        m_selfTestCamera->stopCapture();
        m_selfTestCameraThread.quit();
        // finished -> deleteLater owns deletion. Never delete a worker whose
        // capture loop may still be using its mmap buffers.
        m_selfTestCamera = nullptr;
    }
    if (m_selfTestAudio) {
        QProcess *audio = m_selfTestAudio;
        m_selfTestAudio = nullptr;
        audio->disconnect(this);
        const QString path = m_selfTestAudioPath;
        if (audio->state() != QProcess::NotRunning) {
            connect(audio, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), audio,
                [audio, path](int, QProcess::ExitStatus) { QFile::remove(path); audio->deleteLater(); });
            audio->kill();
        } else {
            QFile::remove(path);
            audio->deleteLater();
        }
    }
    if (m_selfTestSerialNotifier) {
        delete m_selfTestSerialNotifier;
        m_selfTestSerialNotifier = nullptr;
    }
    if (m_selfTestSerialFd >= 0) {
        if (m_selfTestSerialTermiosSaved)
            ::tcsetattr(m_selfTestSerialFd, TCSANOW, &m_selfTestOriginalTermios);
        m_selfTestSerialTermiosSaved = false;
        ::close(m_selfTestSerialFd);
        m_selfTestSerialFd = -1;
    }
    if (m_selfTestCanNotifier) {
        delete m_selfTestCanNotifier;
        m_selfTestCanNotifier = nullptr;
    }
    if (m_selfTestCanFd >= 0) {
        ::close(m_selfTestCanFd);
        m_selfTestCanFd = -1;
    }
    QObject::disconnect(m_selfTestCanReadyConnection);
    QObject::disconnect(m_selfTestCanFailureConnection);
    if (m_selfTestCanSession) m_selfTestCanSession->close();
}

void MainWindow::cancelSelfTest()
{
    ++m_selfTestGeneration; // Invalidate serial, camera, audio and next-item timers.
    if (!m_selfTestRunning && m_selfTestIndex < 0)
        return;
    m_selfTestRunning = false;
    m_selfTestItemDone = true;
    cleanupSelfTestItem();
    m_selfTestIndex = -1;
    if (m_selfTestButton) {
        m_selfTestButton->setEnabled(true);
        m_selfTestButton->setText(QStringLiteral("开始测试"));
    }
    if (m_selfTestSummary) {
        m_selfTestSummary->setText(QStringLiteral("已取消"));
        m_selfTestSummary->setStyleSheet(QString());
    }
}

// ---------------------------------------------------------------------------
// 主题切换
// ---------------------------------------------------------------------------

void MainWindow::registerThemedIcon(QAbstractButton *button, UiIcon::Type type, IconTint tint)
{
    if (!button)
        return;
    bool found = false;
    for (ThemedIconEntry &entry : m_themedIconRegistry) {
        if (entry.widget == button) {
            entry.type = type;
            entry.tint = tint;
            entry.pixmapSize = QSize();
            found = true;
            break;
        }
    }
    if (!found)
        m_themedIconRegistry.append(ThemedIconEntry{QPointer<QWidget>(button), type, tint, QSize()});
    button->setIcon(makeUiIcon(type, iconTintColor(tint)));
}

void MainWindow::registerThemedIcon(QLabel *label, UiIcon::Type type, IconTint tint,
                                    const QSize &pixmapSize)
{
    if (!label)
        return;
    bool found = false;
    for (ThemedIconEntry &entry : m_themedIconRegistry) {
        if (entry.widget == label && entry.pixmapSize == pixmapSize) {
            entry.type = type;
            entry.tint = tint;
            found = true;
            break;
        }
    }
    if (!found)
        m_themedIconRegistry.append(
            ThemedIconEntry{QPointer<QWidget>(label), type, tint, pixmapSize});
    label->setPixmap(makeUiIcon(type, iconTintColor(tint)).pixmap(pixmapSize));
}

void MainWindow::refreshThemedIcons()
{
    for (const ThemedIconEntry &entry : m_themedIconRegistry) {
        QWidget *widget = entry.widget.data();
        if (!widget)
            continue;
        const QIcon icon = makeUiIcon(entry.type, iconTintColor(entry.tint));
        if (entry.pixmapSize.isValid()) {
            if (QLabel *label = qobject_cast<QLabel *>(widget))
                label->setPixmap(icon.pixmap(entry.pixmapSize));
        } else if (QAbstractButton *button = qobject_cast<QAbstractButton *>(widget)) {
            button->setIcon(icon);
        }
    }
}

QWidget *MainWindow::createThemePage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("themePage"));
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);
    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(9, 4, 9, 5);
    layout->setSpacing(6);

    QFrame *header = new QFrame(page);
    header->setObjectName(QStringLiteral("subPageHeader"));
    header->setFixedHeight(34);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(7);
    QPushButton *back = new QPushButton(header);
    back->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(back, UiIcon::Back, IconTint::Hint);
    back->setIconSize(QSize(21, 21));
    back->setFixedSize(32, 32);
    QLabel *title = new QLabel(QStringLiteral("主题风格"), header);
    title->setObjectName(QStringLiteral("subPageTitle"));
    m_themeCurrentLabel = new QLabel(header);
    m_themeCurrentLabel->setObjectName(QStringLiteral("peripheralStatus"));
    headerLayout->addWidget(back);
    headerLayout->addWidget(title);
    headerLayout->addStretch(1);
    headerLayout->addWidget(m_themeCurrentLabel);
    layout->addWidget(header);
    connect(back, &QPushButton::clicked, this, &MainWindow::returnToPeripheralHub);

    for (int i = 0; i < Theme::themeCount(); ++i) {
        ThemeRowButton *row = new ThemeRowButton(i, page);
        layout->addWidget(row);
        m_themeRows.append(row);
        connect(row, &QPushButton::clicked, this, [this, i]() { applyThemeIndex(i); });
    }

    layout->addStretch(1);
    QLabel *note = new QLabel(QStringLiteral("切换立即生效并自动保存，重启后保持"), page);
    note->setObjectName(QStringLiteral("peripheralStatus"));
    note->setAlignment(Qt::AlignCenter);
    note->setFixedHeight(12);
    layout->addWidget(note);

    // 危险区：恢复出厂设置（两步确认，4 秒无操作自动取消）
    QHBoxLayout *resetRow = new QHBoxLayout;
    resetRow->setContentsMargins(0, 1, 0, 0);
    resetRow->setSpacing(8);
    m_factoryResetButton = new QPushButton(QStringLiteral("恢复出厂设置"), page);
    m_factoryResetButton->setObjectName(QStringLiteral("dangerButton"));
    m_factoryResetButton->setFixedSize(110, 28);
    m_factoryResetStatus = new QLabel(QStringLiteral("清除 Wi-Fi 凭据与主题设置"), page);
    m_factoryResetStatus->setObjectName(QStringLiteral("peripheralStatus"));
    resetRow->addWidget(m_factoryResetButton);
    resetRow->addWidget(m_factoryResetStatus, 1);
    layout->addLayout(resetRow);
    m_factoryResetTimer = new QTimer(page);
    m_factoryResetTimer->setSingleShot(true);
    connect(m_factoryResetTimer, &QTimer::timeout, this, &MainWindow::disarmFactoryReset);
    connect(m_factoryResetButton, &QPushButton::clicked, this,
            &MainWindow::handleFactoryResetRequested);
    refreshThemeRows();
    return page;
}

void MainWindow::disarmFactoryReset()
{
    m_factoryResetArmed = false;
    if (m_factoryResetButton)
        m_factoryResetButton->setText(QStringLiteral("恢复出厂设置"));
    if (m_factoryResetStatus)
        m_factoryResetStatus->setText(QStringLiteral("清除 Wi-Fi 凭据与主题设置"));
}

void MainWindow::handleFactoryResetRequested()
{
    if (!m_factoryResetArmed) {
        // 第一步：进入待确认状态
        m_factoryResetArmed = true;
        m_factoryResetButton->setText(QStringLiteral("确认恢复？"));
        m_factoryResetStatus->setText(QStringLiteral("再按一次确认，4 秒后自动取消"));
        m_factoryResetTimer->start(4000);
        return;
    }

    // 第二步：执行恢复
    m_factoryResetTimer->stop();
    m_factoryResetArmed = false;

    if (m_reconnectTimer)
        m_reconnectTimer->stop();
    m_savedNetworks.clear();
    m_reconnectPolicy.reset();
    m_pendingCredentials = WifiCredentials();
    m_savePendingCredentials = false;
    m_autoConnection = false;
    ++m_connectionRequestId;
    if (m_worker)
        m_worker->cancelConnectionsBefore(m_connectionRequestId);
    setBusy(false);
    refreshSavedNetworkMarkers();
    emit forgetWifiNetworksRequested(); // Only our tagged runtime profiles.

    // 1) 删除 Wi-Fi 凭据文件（不存在视为成功）
    QString credError;
    const bool credCleared = m_credentialStore.clear(&credError);

    // 2) 主题回默认：先应用（其中会回写设置项），随后清空持久化配置文件
    applyThemeIndex(0);
    QSettings(QStringLiteral("imx6ull"), QStringLiteral("board_ui")).clear();

    // 3) 内存态同步：首页按无凭据处理，Wi-Fi 页输入框清空
    m_hasCredentials = false;
    if (m_passwordEdit)
        m_passwordEdit->clear();

    m_factoryResetButton->setText(QStringLiteral("恢复出厂设置"));
    if (credCleared)
        m_factoryResetStatus->setText(QStringLiteral("已恢复出厂设置（Wi-Fi 凭据 / 主题已清空）"));
    else
        m_factoryResetStatus->setText(QStringLiteral("凭据删除失败：%1").arg(credError));
}



void MainWindow::openThemePage()
{
    refreshThemeRows();
    m_peripheralPageStack->setCurrentWidget(m_themePage);
    m_stack->setCurrentWidget(m_peripheralPage);
}

void MainWindow::refreshThemeRows()
{
    const int current = Theme::currentThemeIndex();
    for (int i = 0; i < m_themeRows.size(); ++i)
        m_themeRows.at(i)->setSelected(i == current);
    if (m_themeCurrentLabel)
        m_themeCurrentLabel->setText(QStringLiteral("当前：") + Theme::themeName(current));
}

void MainWindow::applyThemeIndex(int index)
{
    Theme::setTheme(index);
    Theme::saveThemeIndex(index);

    Theme::applyPalette(*qApp);
    setStyleSheet(Theme::styleSheet());
    refreshThemedIcons();
    // 分页器圆点 + CPU/内存曲线等自绘元素读取的是内联色/画笔色，逐一触发重绘
    if (m_hubPager)
        m_hubPager->refreshColors();
    if (m_loadChart)
        m_loadChart->update();
    refreshThemeRows();
    update(); // 全窗重绘，温湿度曲线/聊天气泡等随主题刷新
}

QWidget *MainWindow::createWifiPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("wifiPage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);

    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    m_wifiPageStack = new QStackedWidget(page);
    m_wifiPageStack->setFrameShape(QFrame::NoFrame);
    m_wifiPageStack->setContentsMargins(0, 0, 0, 0);
    m_scanPage = createWifiScanPage();
    m_passwordPage = createPasswordEntryPage();
    m_wifiPageStack->addWidget(m_scanPage);
    m_wifiPageStack->addWidget(m_passwordPage);
    m_wifiPageStack->setCurrentWidget(m_scanPage);
    layout->addWidget(m_wifiPageStack);
    return page;
}

QWidget *MainWindow::createWifiScanPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("wifiScanPage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);

    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(10, 6, 10, 2);
    layout->setSpacing(3);

    m_wifiHeader = new QWidget(page);
    QHBoxLayout *header = new QHBoxLayout(m_wifiHeader);
    header->setContentsMargins(0, 0, 0, 0);
    header->setSpacing(6);

    QLabel *wifiIcon = new QLabel(m_wifiHeader);
    wifiIcon->setFixedSize(27, 27);
    wifiIcon->setAlignment(Qt::AlignCenter);
    registerThemedIcon(wifiIcon, UiIcon::Wifi, IconTint::Accent, QSize(24, 24));
    QLabel *title = new QLabel(QStringLiteral("Wi-Fi"), m_wifiHeader);
    title->setObjectName(QStringLiteral("pageTitle"));
    header->addWidget(wifiIcon);
    header->addWidget(title);
    header->addStretch(1);

    m_scanInfo = new QLabel(QString(), m_wifiHeader);
    m_scanInfo->setObjectName(QStringLiteral("scanInfo"));
    header->addWidget(m_scanInfo);

    m_scanButton = new QPushButton(m_wifiHeader);
    m_scanButton->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(m_scanButton, UiIcon::Search, IconTint::Secondary);
    m_scanButton->setIconSize(QSize(20, 20));
    m_scanButton->setFixedSize(34, 32);
    m_scanButton->setToolTip(QStringLiteral("扫描网络"));
    header->addWidget(m_scanButton);
    layout->addWidget(m_wifiHeader);

    m_networkList = new QListWidget(page);
    m_networkList->setItemDelegate(new NetworkDelegate(m_networkList));
    m_networkList->setSelectionMode(QAbstractItemView::SingleSelection);
    m_networkList->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_networkList->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    m_networkList->setMinimumHeight(84);
    m_networkList->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    layout->addWidget(m_networkList, 1);

    m_wifiMessage = new QLabel(QString(), page);
    m_wifiMessage->setObjectName(QStringLiteral("message"));
    m_wifiMessage->setFixedHeight(18);
    m_wifiMessage->setToolTip(QString());
    m_wifiMessage->hide();
    layout->addWidget(m_wifiMessage);

    m_actionBar = new QWidget(page);
    QHBoxLayout *actionRow = new QHBoxLayout(m_actionBar);
    actionRow->setContentsMargins(0, 0, 0, 0);
    actionRow->setSpacing(7);

    m_skipButton = new QPushButton(QStringLiteral("返回"), m_actionBar);
    m_skipButton->setObjectName(QStringLiteral("skipButton"));
    registerThemedIcon(m_skipButton, UiIcon::Back, IconTint::Hint);
    m_skipButton->setIconSize(QSize(18, 18));
    m_skipButton->setFixedHeight(30);

    m_connectButton = new QPushButton(QStringLiteral("连接"), m_actionBar);
    m_connectButton->setObjectName(QStringLiteral("primaryButton"));
    registerThemedIcon(m_connectButton, UiIcon::Check, IconTint::Bright);
    m_connectButton->setIconSize(QSize(18, 18));
    m_connectButton->setFixedSize(100, 30);

    actionRow->addWidget(m_skipButton);
    actionRow->addStretch(1);
    actionRow->addWidget(m_connectButton);
    layout->addWidget(m_actionBar);

    connect(m_scanButton, &QPushButton::clicked, this, &MainWindow::startScan);
    connect(m_networkList, &QListWidget::itemSelectionChanged, this, &MainWindow::updateSelection);
    connect(m_connectButton, &QPushButton::clicked, this, &MainWindow::onWifiScanConnectClicked);
    connect(m_skipButton, &QPushButton::clicked, this, &MainWindow::leaveWifiPage);
    return page;
}

QWidget *MainWindow::createPasswordEntryPage()
{
    QWidget *page = new QWidget;
    page->setObjectName(QStringLiteral("passwordPage"));
    page->setLayoutDirection(Qt::LeftToRight);
    page->setAttribute(Qt::WA_StyledBackground, true);
    page->setAutoFillBackground(true);

    QVBoxLayout *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 6, 0, 2);
    layout->setSpacing(8);

    QHBoxLayout *passwordRow = new QHBoxLayout;
    passwordRow->setContentsMargins(10, 0, 10, 0);
    passwordRow->setSpacing(6);

    m_passwordLabel = new QLabel(page);
    m_passwordLabel->setFixedSize(22, 22);
    m_passwordLabel->setAlignment(Qt::AlignCenter);
    registerThemedIcon(m_passwordLabel, UiIcon::Lock, IconTint::Secondary, QSize(18, 18));

    m_passwordEdit = new QLineEdit(page);
    m_passwordEdit->setPlaceholderText(QStringLiteral("密码"));
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_passwordEdit->setMaxLength(64);
    m_passwordEdit->setReadOnly(true);
    m_passwordEdit->setAttribute(Qt::WA_InputMethodEnabled, false);
    m_passwordEdit->setAttribute(Qt::WA_AcceptTouchEvents, true);
    m_passwordEdit->installEventFilter(this);
    m_passwordEdit->setFixedHeight(31);

    m_keyboardButton = new QPushButton(page);
    m_keyboardButton->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(m_keyboardButton, UiIcon::Keyboard, IconTint::Secondary);
    m_keyboardButton->setIconSize(QSize(20, 20));
    m_keyboardButton->setFixedSize(34, 32);
    m_keyboardButton->setToolTip(QStringLiteral("打开软键盘"));
    m_keyboardButton->setEnabled(false);

    m_passwordToggle = new QPushButton(page);
    m_passwordToggle->setObjectName(QStringLiteral("iconButton"));
    registerThemedIcon(m_passwordToggle, UiIcon::Eye, IconTint::Secondary);
    m_passwordToggle->setIconSize(QSize(20, 20));
    m_passwordToggle->setFixedSize(34, 32);
    m_passwordToggle->setToolTip(QStringLiteral("显示 / 隐藏密码"));

    passwordRow->addWidget(m_passwordLabel);
    passwordRow->addWidget(m_passwordEdit, 1);
    passwordRow->addWidget(m_keyboardButton);
    passwordRow->addWidget(m_passwordToggle);
    layout->addLayout(passwordRow);

    m_passwordMessage = new QLabel(QString(), page);
    m_passwordMessage->setObjectName(QStringLiteral("message"));
    m_passwordMessage->setFixedHeight(18);
    m_passwordMessage->hide();
    layout->addWidget(m_passwordMessage);

    m_keyboardPanel = createPasswordKeyboard(page);
    m_keyboardPanel->hide();
    layout->addWidget(m_keyboardPanel, 1);

    m_passwordFooterSpacer = new QWidget(page);
    m_passwordFooterSpacer->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
    layout->addWidget(m_passwordFooterSpacer, 1);

    m_passwordActionBar = new QWidget(page);
    QHBoxLayout *actionRow = new QHBoxLayout(m_passwordActionBar);
    actionRow->setContentsMargins(10, 0, 10, 0);
    actionRow->setSpacing(7);

    m_passwordBackButton = new QPushButton(QStringLiteral("返回"), m_passwordActionBar);
    m_passwordBackButton->setObjectName(QStringLiteral("skipButton"));
    registerThemedIcon(m_passwordBackButton, UiIcon::Back, IconTint::Hint);
    m_passwordBackButton->setIconSize(QSize(18, 18));
    m_passwordBackButton->setFixedHeight(30);

    m_passwordConnectButton = new QPushButton(QStringLiteral("连接"), m_passwordActionBar);
    m_passwordConnectButton->setObjectName(QStringLiteral("primaryButton"));
    registerThemedIcon(m_passwordConnectButton, UiIcon::Check, IconTint::Bright);
    m_passwordConnectButton->setIconSize(QSize(18, 18));
    m_passwordConnectButton->setFixedSize(100, 30);

    actionRow->addWidget(m_passwordBackButton);
    actionRow->addStretch(1);
    actionRow->addWidget(m_passwordConnectButton);
    layout->addWidget(m_passwordActionBar);

    connect(m_keyboardButton, &QPushButton::clicked, this, &MainWindow::showPasswordKeyboard);
    connect(m_passwordEdit, &QLineEdit::returnPressed, this, &MainWindow::onConnectClicked);
    connect(m_passwordBackButton, &QPushButton::clicked, this, &MainWindow::onPasswordBackClicked);
    connect(m_passwordConnectButton, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    connect(m_passwordToggle, &QPushButton::clicked, this, [this]() {
        m_showPassword = !m_showPassword;
        m_passwordEdit->setEchoMode(m_showPassword ? QLineEdit::Normal : QLineEdit::Password);
        registerThemedIcon(m_passwordToggle, UiIcon::Eye,
                           m_showPassword ? IconTint::Accent : IconTint::Hint);
        m_passwordToggle->setToolTip(m_showPassword ? QStringLiteral("隐藏密码") : QStringLiteral("显示密码"));
    });
    return page;
}

QWidget *MainWindow::createPasswordKeyboard(QWidget *parent)
{
    QWidget *panel = new QWidget(parent);
    panel->setObjectName(QStringLiteral("keyboardPanel"));
    panel->setMinimumHeight(160);
    panel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    QVBoxLayout *panelLayout = new QVBoxLayout(panel);
    panelLayout->setContentsMargins(6, 0, 6, 0);
    panelLayout->setSpacing(2);

    m_keyboardSsid = new QLabel(panel);
    m_keyboardSsid->setObjectName(QStringLiteral("keyboardSsid"));
    m_keyboardSsid->setFixedHeight(20);
    panelLayout->addWidget(m_keyboardSsid);

    auto makeKey = [panel](const QString &text, bool special, int width) {
        QPushButton *key = new QPushButton(text, panel);
        key->setObjectName(special ? QStringLiteral("softKeySpecial") : QStringLiteral("softKey"));
        key->setFocusPolicy(Qt::NoFocus);
        key->setMinimumHeight(32);
        key->setMaximumHeight(50);
        key->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        if (width > 0)
            key->setMinimumWidth(width);
        return key;
    };

    QHBoxLayout *row1 = new QHBoxLayout;
    row1->setContentsMargins(0, 0, 0, 0);
    row1->setSpacing(3);
    const QString row1Chars = QStringLiteral("qwertyuiop");
    for (int i = 0; i < row1Chars.size(); ++i) {
        QPushButton *key = makeKey(row1Chars.mid(i, 1), false, 43);
        m_alphaButtons << key;
        row1->addWidget(key, 1);
        connect(key, &QPushButton::clicked, this, [this, key]() {
            insertPasswordText(key->text());
        });
    }
    panelLayout->addLayout(row1, 1);

    QHBoxLayout *row2 = new QHBoxLayout;
    row2->setContentsMargins(0, 0, 0, 0);
    row2->setSpacing(3);
    row2->addStretch(1);
    const QString row2Chars = QStringLiteral("asdfghjkl");
    for (int i = 0; i < row2Chars.size(); ++i) {
        QPushButton *key = makeKey(row2Chars.mid(i, 1), false, 43);
        m_alphaButtons << key;
        row2->addWidget(key, 1);
        connect(key, &QPushButton::clicked, this, [this, key]() {
            insertPasswordText(key->text());
        });
    }
    row2->addStretch(1);
    panelLayout->addLayout(row2, 1);

    QHBoxLayout *row3 = new QHBoxLayout;
    row3->setContentsMargins(0, 0, 0, 0);
    row3->setSpacing(3);
    m_shiftButton = makeKey(QStringLiteral("⇧"), true, 42);
    row3->addWidget(m_shiftButton, 1);
    connect(m_shiftButton, &QPushButton::clicked, this, [this]() {
        if (m_keyboardMode == 0) {
            m_capsLock = !m_capsLock;
            updateKeyboardLabels();
        } else {
            insertPasswordText(m_shiftButton->text());
        }
    });
    const QString row3Chars = QStringLiteral("zxcvbnm");
    for (int i = 0; i < row3Chars.size(); ++i) {
        QPushButton *key = makeKey(row3Chars.mid(i, 1), false, 43);
        m_alphaButtons << key;
        row3->addWidget(key, 1);
        connect(key, &QPushButton::clicked, this, [this, key]() {
            insertPasswordText(key->text());
        });
    }
    m_backspaceButton = makeKey(QString(), true, 44);
    registerThemedIcon(m_backspaceButton, UiIcon::Backspace, IconTint::Primary);
    m_backspaceButton->setIconSize(QSize(20, 20));
    m_backspaceButton->setToolTip(QStringLiteral("删除"));
    row3->addWidget(m_backspaceButton, 1);
    connect(m_backspaceButton, &QPushButton::clicked, this, &MainWindow::backspacePassword);
    panelLayout->addLayout(row3, 1);

    QHBoxLayout *row4 = new QHBoxLayout;
    row4->setContentsMargins(0, 0, 0, 0);
    row4->setSpacing(3);
    m_modeButton = makeKey(QStringLiteral("ABC"), true, 54);
    m_modeButton->setObjectName(QStringLiteral("softKeyMode"));
    row4->addWidget(m_modeButton);
    connect(m_modeButton, &QPushButton::clicked, this, [this]() {
        m_keyboardMode = (m_keyboardMode + 1) % 3;
        m_capsLock = false;
        updateKeyboardLabels();
    });

    QPushButton *commaKey = makeKey(QStringLiteral(","), true, 36);
    row4->addWidget(commaKey);
    connect(commaKey, &QPushButton::clicked, this, [this]() { insertPasswordText(QStringLiteral(",")); });

    QPushButton *spaceKey = makeKey(QStringLiteral("空格"), true, 0);
    row4->addWidget(spaceKey, 1);
    connect(spaceKey, &QPushButton::clicked, this, [this]() { insertPasswordText(QStringLiteral(" ")); });

    QPushButton *periodKey = makeKey(QStringLiteral("."), true, 36);
    row4->addWidget(periodKey);
    connect(periodKey, &QPushButton::clicked, this, [this]() { insertPasswordText(QStringLiteral(".")); });

    m_doneButton = makeKey(QStringLiteral("完成"), true, 58);
    m_doneButton->setObjectName(QStringLiteral("softKeyDone"));
    registerThemedIcon(m_doneButton, UiIcon::Check, IconTint::Bright);
    m_doneButton->setIconSize(QSize(17, 17));
    row4->addWidget(m_doneButton);
    connect(m_doneButton, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    row4->setStretch(0, 0);
    row4->setStretch(1, 0);
    row4->setStretch(2, 1);
    row4->setStretch(3, 0);
    row4->setStretch(4, 0);
    panelLayout->addLayout(row4, 1);

    updateKeyboardLabels();
    return panel;
}

void MainWindow::showPasswordKeyboard()
{
    if (!m_passwordEdit || !m_passwordEdit->isEnabled() || m_connectionBusy)
        return;
    QString ssid;
    selectedNetwork(&ssid, nullptr, nullptr);
    m_keyboardSsid->setText(QFontMetrics(m_keyboardSsid->font()).elidedText(ssid, Qt::ElideMiddle, 450));
    if (!m_keyboardVisible) {
        m_keyboardMode = 0;
        m_capsLock = false;
    }
    m_wifiPageStack->setCurrentWidget(m_passwordPage);
    m_keyboardVisible = true;
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->setStyleSheet(QString());
    m_passwordMessage->hide();
    m_passwordFooterSpacer->hide();
    m_passwordActionBar->hide();
    m_keyboardPanel->show();
    m_passwordEdit->setCursorPosition(m_passwordEdit->text().size());
    updateKeyboardLabels();
}

void MainWindow::hidePasswordKeyboard()
{
    if (!m_keyboardVisible)
        return;
    m_keyboardVisible = false;
    m_keyboardPanel->hide();
    m_passwordMessage->setVisible(!m_passwordMessage->text().isEmpty());
    m_passwordFooterSpacer->show();
    m_passwordActionBar->show();
}

void MainWindow::updateKeyboardLabels()
{
    QStringList labels;
    QString shiftLabel;
    if (m_keyboardMode == 0) {
        labels = QStringList() << QStringLiteral("q") << QStringLiteral("w") << QStringLiteral("e")
                               << QStringLiteral("r") << QStringLiteral("t") << QStringLiteral("y")
                               << QStringLiteral("u") << QStringLiteral("i") << QStringLiteral("o")
                               << QStringLiteral("p") << QStringLiteral("a") << QStringLiteral("s")
                               << QStringLiteral("d") << QStringLiteral("f") << QStringLiteral("g")
                               << QStringLiteral("h") << QStringLiteral("j") << QStringLiteral("k")
                               << QStringLiteral("l") << QStringLiteral("z") << QStringLiteral("x")
                               << QStringLiteral("c") << QStringLiteral("v") << QStringLiteral("b")
                               << QStringLiteral("n") << QStringLiteral("m");
        if (m_capsLock) {
            for (QString &label : labels)
                label = label.toUpper();
        }
        shiftLabel = QStringLiteral("⇧");
        m_modeButton->setText(QStringLiteral("ABC"));
        m_modeButton->setToolTip(QStringLiteral("字母键盘"));
    } else if (m_keyboardMode == 1) {
        labels = QStringList() << QStringLiteral("1") << QStringLiteral("2") << QStringLiteral("3")
                               << QStringLiteral("4") << QStringLiteral("5") << QStringLiteral("6")
                               << QStringLiteral("7") << QStringLiteral("8") << QStringLiteral("9")
                               << QStringLiteral("0") << QStringLiteral("@") << QStringLiteral("#")
                               << QStringLiteral("$") << QStringLiteral("%") << QStringLiteral("&")
                               << QStringLiteral("-") << QStringLiteral("+") << QStringLiteral("(")
                               << QStringLiteral(")") << QStringLiteral("*") << QStringLiteral("/")
                               << QStringLiteral(":") << QStringLiteral("\"") << QStringLiteral("'")
                               << QStringLiteral("!") << QStringLiteral("?");
        shiftLabel = QStringLiteral("=");
        m_modeButton->setText(QStringLiteral("123"));
        m_modeButton->setToolTip(QStringLiteral("数字键盘"));
    } else {
        labels = QStringList() << QStringLiteral("!") << QStringLiteral("@") << QStringLiteral("#")
                               << QStringLiteral("$") << QStringLiteral("%") << QStringLiteral("^")
                               << QStringLiteral("&") << QStringLiteral("*") << QStringLiteral("(")
                               << QStringLiteral(")") << QStringLiteral("-") << QStringLiteral("_")
                               << QStringLiteral("+") << QStringLiteral("[") << QStringLiteral("]")
                               << QStringLiteral("{") << QStringLiteral("}") << QStringLiteral("\\")
                               << QStringLiteral("|") << QStringLiteral(";") << QStringLiteral(":")
                               << QStringLiteral("\"") << QStringLiteral("'") << QStringLiteral("<")
                               << QStringLiteral(">") << QStringLiteral("?");
        shiftLabel = QStringLiteral("~");
        m_modeButton->setText(QStringLiteral("#+="));
        m_modeButton->setToolTip(QStringLiteral("符号键盘"));
    }

    const int count = qMin(labels.size(), m_alphaButtons.size());
    for (int i = 0; i < count; ++i)
        m_alphaButtons.at(i)->setText(labels.at(i));
    m_shiftButton->setText(shiftLabel);
    m_shiftButton->setProperty("active", m_keyboardMode == 0 && m_capsLock);
    m_shiftButton->style()->unpolish(m_shiftButton);
    m_shiftButton->style()->polish(m_shiftButton);
    m_modeButton->setProperty("active", m_keyboardMode != 0);
    m_modeButton->style()->unpolish(m_modeButton);
    m_modeButton->style()->polish(m_modeButton);
}

void MainWindow::insertPasswordText(const QString &text)
{
    if (text.isEmpty() || !m_passwordEdit)
        return;
    QString value = m_passwordEdit->text();
    const int room = 64 - value.size();
    if (room <= 0)
        return;
    value.append(text.left(room));
    m_passwordEdit->setText(value);
    m_passwordEdit->setCursorPosition(value.size());
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    if (m_keyboardVisible)
        m_passwordMessage->hide();
}

void MainWindow::backspacePassword()
{
    QString value = m_passwordEdit->text();
    if (value.isEmpty()) {
        m_passwordMessage->clear();
        m_passwordMessage->setToolTip(QString());
        if (m_keyboardVisible)
            m_passwordMessage->hide();
        return;
    }
    value.chop(1);
    m_passwordEdit->setText(value);
    m_passwordEdit->setCursorPosition(value.size());
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    if (m_keyboardVisible)
        m_passwordMessage->hide();
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == m_passwordEdit &&
        (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::TouchBegin)) {
        showPasswordKeyboard();
        event->accept();
        return true;
    }
    return QWidget::eventFilter(watched, event);
}

void MainWindow::startScan()
{
    if (m_scanBusy || m_connectionBusy)
        return;
    hidePasswordKeyboard();
    m_backgroundScan = false;
    m_scanBusy = true;
    m_scanButton->setEnabled(false);
    m_networkList->setEnabled(false);
    m_connectButton->setEnabled(false);
    m_passwordConnectButton->setEnabled(false);
    m_passwordEdit->setEnabled(false);
    m_passwordToggle->setEnabled(false);
    m_keyboardButton->setEnabled(false);
    m_scanButton->setText(QString());
    m_scanInfo->setText(QStringLiteral("扫描…"));
    m_wifiMessage->setStyleSheet(QString());
    m_wifiMessage->clear();
    m_wifiMessage->hide();
    m_wifiMessage->setToolTip(QString());
    emit scanRequested(false);
}

void MainWindow::onScanFinished(const QList<WifiNetwork> &networks, const QString &error)
{
    const bool background = m_backgroundScan;
    m_backgroundScan = false;
    m_scanBusy = false;
    m_scanButton->setEnabled(!m_connectionBusy);
    m_networkList->setEnabled(!m_connectionBusy);
    m_scanButton->setText(QString());

    // A background result must never destroy a password the user is typing.
    if (m_wifiPageStack->currentWidget() != m_passwordPage) {
        const QString previous = m_networkList->currentItem()
                                     ? m_networkList->currentItem()->text() : QString();
        QList<WifiNetwork> sorted = networks;
        std::sort(sorted.begin(), sorted.end(), [](const WifiNetwork &a, const WifiNetwork &b) {
            return a.signalLevel == b.signalLevel ? a.ssid < b.ssid : a.signalLevel > b.signalLevel;
        });
        {
            const QSignalBlocker blocker(m_networkList);
            m_networkList->clear();
            int preferred = -1;
            int previousIndex = -1;
            for (const WifiNetwork &network : sorted) {
                QListWidgetItem *item = new QListWidgetItem(network.ssid, m_networkList);
                item->setData(FlagsRole, network.flags);
                item->setData(SignalRole, network.signalLevel);
                item->setData(SecuredRole, network.secured);
                item->setData(SupportedRole, network.supported);
                item->setSizeHint(QSize(440, 28));
                const int row = m_networkList->count() - 1;
                if (preferred < 0 && network.supported)
                    preferred = row;
                if (network.ssid == previous)
                    previousIndex = row;
            }
            if (!sorted.isEmpty())
                m_networkList->setCurrentRow(previousIndex >= 0 ? previousIndex : qMax(0, preferred));
        }
        refreshSavedNetworkMarkers();
        updateSelection();
        m_scanInfo->setText(error.isEmpty() ? QStringLiteral("%1 个").arg(networks.size())
                                           : QStringLiteral("扫描失败"));
        if (!error.isEmpty() || networks.isEmpty()) {
            m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
            m_wifiMessage->setText(error.isEmpty() ? QStringLiteral("未发现网络")
                : QFontMetrics(m_wifiMessage->font()).elidedText(error, Qt::ElideRight, 445));
            m_wifiMessage->setVisible(true);
            m_wifiMessage->setToolTip(error);
        }
    }

    if (!background || m_wifiConnected || m_savedNetworks.isEmpty() || m_autoReconnectSuspended || m_connectionBusy)
        return;
    WifiCredentials candidate;
    if (error.isEmpty() && m_reconnectPolicy.choose(networks, m_savedNetworks, &candidate)) {
        beginWifiConnection(candidate, true);
    } else {
        showHomeMessage(error.isEmpty() ? QStringLiteral("等待已保存 Wi-Fi 信号，自动重连中…")
                                        : QStringLiteral("Wi-Fi 扫描暂不可用，稍后自动重试"), true);
        scheduleAutoReconnect(5000);
    }
}

void MainWindow::updateSelection()
{
    const QListWidgetItem *item = m_networkList->currentItem();
    if (!item) {
        m_passwordEdit->clear();
        m_passwordEdit->setEnabled(false);
        m_passwordToggle->setEnabled(false);
        m_keyboardButton->setEnabled(false);
        m_passwordLabel->clear();
        m_connectButton->setEnabled(false);
        m_passwordConnectButton->setEnabled(false);
        return;
    }

    const bool secured = item->data(SecuredRole).toBool();
    const bool supported = item->data(SupportedRole).toBool();
    m_passwordEdit->clear();
    m_showPassword = false;
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    registerThemedIcon(m_passwordToggle, UiIcon::Eye, IconTint::Hint);
    m_passwordEdit->setEnabled(secured && supported && !m_connectionBusy);
    m_passwordToggle->setEnabled(secured && supported && !m_connectionBusy);
    m_keyboardButton->setEnabled(secured && supported && !m_connectionBusy);
    m_passwordEdit->setPlaceholderText(!supported ? QStringLiteral("暂不支持")
                                               : (secured ? QStringLiteral("密码")
                                                          : QStringLiteral("无需密码")));
    if (secured) {
        registerThemedIcon(m_passwordLabel, UiIcon::Lock,
                           supported ? IconTint::Secondary : IconTint::Danger, QSize(18, 18));
    } else {
        m_passwordLabel->clear();
    }
    m_connectButton->setText(savedCredentialsFor(item->text(), secured)
                                 ? QStringLiteral("直接连接") : QStringLiteral("连接"));
    m_connectButton->setEnabled(supported && !m_connectionBusy && !m_scanBusy);
    m_passwordConnectButton->setEnabled(supported && !m_connectionBusy && !m_scanBusy);
    if (!supported) {
        m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
        m_wifiMessage->setText(QStringLiteral("暂不支持此网络"));
        m_wifiMessage->setVisible(true);
        m_wifiMessage->setToolTip(QString());
    } else {
        m_wifiMessage->setStyleSheet(QString());
        m_wifiMessage->clear();
        m_wifiMessage->hide();
        m_wifiMessage->setToolTip(QString());
    }
}

bool MainWindow::selectedNetwork(QString *ssid,
                                 bool *secured,
                                 bool *supported) const
{
    const QListWidgetItem *item = m_networkList->currentItem();
    if (!item)
        return false;
    if (ssid)
        *ssid = item->text();
    if (secured)
        *secured = item->data(SecuredRole).toBool();
    if (supported)
        *supported = item->data(SupportedRole).toBool();
    return true;
}

void MainWindow::onWifiScanConnectClicked()
{
    if (m_scanBusy || m_connectionBusy)
        return;

    QString ssid;
    bool secured = false;
    bool supported = false;
    if (!selectedNetwork(&ssid, &secured, &supported)) {
        m_wifiMessage->setText(QStringLiteral("请选择网络"));
        m_wifiMessage->setVisible(true);
        return;
    }
    if (!supported) {
        m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
        m_wifiMessage->setText(QStringLiteral("暂不支持此网络"));
        m_wifiMessage->setVisible(true);
        return;
    }

    WifiCredentials saved;
    if (savedCredentialsFor(ssid, secured, &saved)) {
        beginWifiConnection(saved, false);
        return;
    }
    if (!secured) {
        m_passwordEdit->clear();
        onConnectClicked();
        return;
    }

    m_passwordEdit->clear();
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_showPassword = false;
    registerThemedIcon(m_passwordToggle, UiIcon::Eye, IconTint::Secondary);
    m_passwordToggle->setToolTip(QStringLiteral("显示 / 隐藏密码"));
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();
    m_wifiPageStack->setCurrentWidget(m_passwordPage);
    showPasswordKeyboard();
}

void MainWindow::onPasswordBackClicked()
{
    hidePasswordKeyboard();
    m_passwordEdit->clear();
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();
    m_wifiPageStack->setCurrentWidget(m_scanPage);
}

void MainWindow::onConnectClicked()
{
    if (m_connectionBusy || m_scanBusy)
        return;
    QLabel *statusMessage = m_wifiPageStack->currentWidget() == m_passwordPage
                                ? m_passwordMessage
                                : m_wifiMessage;
    QString ssid;
    bool secured = false;
    bool supported = false;
    if (!selectedNetwork(&ssid, &secured, &supported)) {
        statusMessage->setText(QStringLiteral("请选择网络"));
        statusMessage->setVisible(true);
        return;
    }
    if (!supported) {
        statusMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
        statusMessage->setText(QStringLiteral("暂不支持此网络"));
        statusMessage->setVisible(true);
        return;
    }

    const QString password = m_passwordEdit->text();
    QString passwordFormatError;
    if (secured && !isValidWpaPasswordFormat(password, &passwordFormatError)) {
        hidePasswordKeyboard();
        m_wifiPageStack->setCurrentWidget(m_scanPage);
        m_passwordEdit->clear();
        m_passwordMessage->clear();
        m_passwordMessage->setToolTip(QString());
        m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
        m_wifiMessage->setText(password.isEmpty()
                                   ? QStringLiteral("密码不能为空，请点击“连接”重新输入密码。")
                                   : QStringLiteral("密码格式不合法，请点击“连接”重新输入密码。"));
        m_wifiMessage->setVisible(true);
        m_wifiMessage->setToolTip(passwordFormatError);
        return;
    }

    WifiCredentials credentials;
    credentials.ssid = ssid;
    credentials.password = secured ? password : QString();
    credentials.secured = secured;
    beginWifiConnection(credentials, false);
}

void MainWindow::beginWifiConnection(const WifiCredentials &credentials, bool automatic)
{
    if (m_connectionBusy || m_scanBusy)
        return;
    if (m_reconnectTimer)
        m_reconnectTimer->stop();
    hidePasswordKeyboard();
    m_wifiPageStack->setCurrentWidget(m_scanPage);
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Info));
    m_wifiMessage->setText(automatic ? QStringLiteral("正在自动重连 Wi-Fi") : QStringLiteral("正在连接 Wi-Fi"));
    m_wifiMessage->setVisible(true);
    m_wifiMessage->setToolTip(QString());
    m_ipAddress.clear();
    m_wifiConnected = false;
    m_connectedSsid.clear();
    if (m_timeSyncRetryTimer)
        m_timeSyncRetryTimer->stop();
    m_pendingCredentials = credentials;
    m_savePendingCredentials = true;
    m_autoConnection = automatic;
    setWifiConnecting();
    setBusy(true);
    m_connectionAnimationFrame = 0;
    m_scanInfo->setText(QStringLiteral("连接中"));
    m_connectionAnimationTimer->start();
    emit connectRequested(++m_connectionRequestId, credentials.ssid, credentials.password, credentials.secured);
}

bool MainWindow::savedCredentialsFor(const QString &ssid, bool secured, WifiCredentials *credentials) const
{
    for (const WifiCredentials &profile : m_savedNetworks) {
        if (profile.ssid == ssid && profile.secured == secured &&
            (!secured || !profile.password.isEmpty())) {
            if (credentials)
                *credentials = profile;
            return true;
        }
    }
    return false;
}

bool MainWindow::forgetCredentialsFor(const QString &ssid, QString *error)
{
    bool removed = false;
    for (int i = m_savedNetworks.size() - 1; i >= 0; --i) {
        if (m_savedNetworks.at(i).ssid == ssid) {
            m_savedNetworks.removeAt(i);
            removed = true;
        }
    }
    m_hasCredentials = !m_savedNetworks.isEmpty();
    refreshSavedNetworkMarkers();
    // Even if storage is read-only, the rejected password is disabled in
    // memory for this session and will not be retried in a loop.
    return !removed || m_credentialStore.saveAll(m_savedNetworks, error);
}

void MainWindow::refreshSavedNetworkMarkers()
{
    for (int i = 0; i < m_networkList->count(); ++i) {
        QListWidgetItem *item = m_networkList->item(i);
        const bool saved = item->data(SupportedRole).toBool() &&
                           savedCredentialsFor(item->text(), item->data(SecuredRole).toBool());
        item->setData(SavedRole, saved);
        item->setToolTip(QStringLiteral("%1 dBm%2").arg(item->data(SignalRole).toInt())
                             .arg(saved ? QStringLiteral(" · 已保存，连接无需再次输入密码") : QString()));
    }
    m_networkList->viewport()->update();
}

void MainWindow::requestWifiStatus()
{
    if (m_connectionBusy || m_scanBusy || m_statusBusy)
        return; // Do not accumulate queued STATUS requests behind a long scan.
    m_statusBusy = true;
    emit statusRequested();
}

void MainWindow::scheduleAutoReconnect(int delayMs)
{
    if (!m_reconnectTimer)
        return;
    if (m_wifiConnected || m_savedNetworks.isEmpty() || m_autoReconnectSuspended) {
        m_reconnectTimer->stop();
        return;
    }
    if (m_connectionBusy)
        return;
    if (!m_reconnectTimer->isActive() || m_reconnectTimer->remainingTime() > delayMs)
        m_reconnectTimer->start(qMax(0, delayMs));
}

void MainWindow::tryAutoReconnect()
{
    if (m_wifiConnected || m_savedNetworks.isEmpty() || m_autoReconnectSuspended)
        return;
    if (m_connectionBusy || m_scanBusy || m_statusBusy) {
        scheduleAutoReconnect(1000);
        return;
    }
    m_backgroundScan = true;
    m_scanBusy = true;
    m_scanButton->setEnabled(false);
    m_networkList->setEnabled(false);
    m_connectButton->setEnabled(false);
    m_passwordConnectButton->setEnabled(false);
    showHomeMessage(QStringLiteral("Wi-Fi 未连接，正在搜索已保存网络…"), true);
    emit scanRequested(true);
}

void MainWindow::setBusy(bool busy)
{
    m_connectionBusy = busy;
    if (!busy && m_connectionAnimationTimer && m_connectionAnimationTimer->isActive()) {
        m_connectionAnimationTimer->stop();
        if (m_wifiPageStack->currentWidget() == m_scanPage)
            m_scanInfo->setText(QStringLiteral("%1 个").arg(m_networkList->count()));
    }
    m_scanButton->setEnabled(!busy && !m_scanBusy);
    m_networkList->setEnabled(!busy && !m_scanBusy);
    m_skipButton->setEnabled(!busy);
    m_passwordBackButton->setEnabled(!busy);
    m_connectButton->setText(busy ? QStringLiteral("连接中…") : QStringLiteral("连接"));
    m_passwordConnectButton->setText(busy ? QStringLiteral("连接中…") : QStringLiteral("连接"));

    if (busy) {
        m_connectButton->setEnabled(false);
        m_passwordConnectButton->setEnabled(false);
        m_passwordEdit->setEnabled(false);
        m_passwordToggle->setEnabled(false);
        m_keyboardButton->setEnabled(false);
    } else {
        const QListWidgetItem *item = m_networkList->currentItem();
        const bool secured = item && item->data(SecuredRole).toBool();
        const bool supported = item && item->data(SupportedRole).toBool();
        m_passwordEdit->setEnabled(secured && supported);
        m_passwordToggle->setEnabled(secured && supported);
        m_keyboardButton->setEnabled(secured && supported);
        m_connectButton->setEnabled(supported && !m_scanBusy);
        m_passwordConnectButton->setEnabled(supported && !m_scanBusy);
    }
}

void MainWindow::onConnectFinished(quint64 requestId,
                                   bool success,
                                   const QString &ssid,
                                   const QString &ipAddress,
                                   WifiFailureReason reason,
                                   const QString &message)
{
    if (requestId != m_connectionRequestId)
        return; // Factory reset/cancellation invalidated this result.
    const bool automatic = m_autoConnection;
    const WifiCredentials attempted = m_pendingCredentials;
    const bool savePending = m_savePendingCredentials;
    m_pendingCredentials = WifiCredentials();
    m_savePendingCredentials = false;
    setBusy(false);
    m_autoConnection = false;
    m_passwordEdit->clear();

    if (!success) {
        m_ipAddress.clear();
        m_wifiConnected = false;
        m_connectedSsid.clear();
        if (m_timeSyncRetryTimer)
            m_timeSyncRetryTimer->stop();
        setWifiStatus(false, QString());
        if (reason == WifiFailureReason::Cancelled)
            return;
        m_reconnectPolicy.failed(ssid);
        const bool reject = reason == WifiFailureReason::InvalidCredentials ||
                            reason == WifiFailureReason::ConnectionRejected;
        QString removalError;
        const bool removed = !reject || forgetCredentialsFor(ssid, &removalError);
        QString prompt;
        if (!removed)
            prompt = QStringLiteral("密码已停用，但配置文件删除失败，请检查存储权限");
        else if (reject && attempted.secured)
            prompt = QStringLiteral("连接失败，已清除该网络密码，请点击“连接”重新输入");
        else if (reject)
            prompt = QStringLiteral("连接失败，已移除此网络记录，请检查路由器后重试");
        else if (reason == WifiFailureReason::NetworkUnavailable)
            prompt = QStringLiteral("目标信号暂不可用，保留已保存密码，稍后重试");
        else
            prompt = QStringLiteral("Wi-Fi 控制接口暂不可用，保留密码，稍后重试");

        if (!automatic) {
            hidePasswordKeyboard();
            m_wifiPageStack->setCurrentWidget(m_scanPage);
            updateSelection();
            m_wifiMessage->setStyleSheet(Theme::messageStyleSheet(Theme::Tone::Warning));
            m_wifiMessage->setText(QFontMetrics(m_wifiMessage->font()).elidedText(prompt, Qt::ElideRight, 445));
            m_wifiMessage->setVisible(true);
            m_wifiMessage->setToolTip(message + (removalError.isEmpty() ? QString() : QLatin1Char('\n') + removalError));
        }
        showHomeMessage(reject ? QStringLiteral("Wi-Fi 连接失败，点击顶栏 Wi-Fi 重新输入密码") : prompt, true);
        if (m_homeMessage)
            m_homeMessage->setToolTip(QStringLiteral("%1：%2\n%3").arg(ssid, prompt, message));
        // A bad strongest profile is gone (or on cooldown); a fresh scan can
        // now fall back to the next strongest remembered network.
        scheduleAutoReconnect(1000);
        return;
    }

    m_ipAddress = ipAddress;
    m_wifiConnected = true;
    m_connectedSsid = ssid;
    m_reconnectPolicy.reset();
    if (m_reconnectTimer)
        m_reconnectTimer->stop();
    QString saveError;
    bool saved = true;
    if (savePending) {
        for (int i = m_savedNetworks.size() - 1; i >= 0; --i) {
            if (m_savedNetworks.at(i).ssid == attempted.ssid)
                m_savedNetworks.removeAt(i);
        }
        m_savedNetworks.prepend(attempted);
        saved = m_credentialStore.saveAll(m_savedNetworks, &saveError);
        m_hasCredentials = !m_savedNetworks.isEmpty();
    }
    refreshSavedNetworkMarkers();
    m_wifiMessage->clear();
    m_wifiMessage->hide();
    m_passwordMessage->clear();
    m_passwordMessage->hide();
    m_setupComplete = true;
    setWifiStatus(true, ssid);
    if (!automatic) {
        m_autoReconnectSuspended = false;
        m_stack->setCurrentWidget(m_homePage);
    }
    // Background recovery must not pull the user out of an external test page.
    if (!saved) {
        showHomeMessage(QStringLiteral("Wi-Fi 已连接，但凭据未写入磁盘"), true);
        m_homeMessage->setToolTip(saveError);
    } else if (ipAddress.isEmpty()) {
        showHomeMessage(QStringLiteral("Wi-Fi 已连接，等待 DHCP 分配 IP（密码已保留）"), true);
        m_homeMessage->setToolTip(message);
    } else {
        showHomeMessage(automatic ? QStringLiteral("Wi-Fi 已自动重连") : QStringLiteral("RS485  ↔  STM32"));
    }
    if (!ipAddress.isEmpty())
        startInternetTimeSync();
}

void MainWindow::onStatusChanged(bool connected,
                                 const QString &ssid,
                                 const QString &ipAddress)
{
    const bool wasConnected = m_wifiConnected;
    m_statusBusy = false;
    m_wifiConnected = connected;
    m_connectedSsid = connected ? ssid : QString();
    m_ipAddress = connected ? ipAddress : QString();
    setWifiStatus(connected, ssid);
    if (connected) {
        if (m_reconnectTimer)
            m_reconnectTimer->stop();
        m_reconnectPolicy.reset();
        if (!ipAddress.isEmpty())
            startInternetTimeSync();
        if (!m_connectionBusy && !wasConnected)
            showHomeMessage(QStringLiteral("Wi-Fi 已恢复连接"));
    } else {
        if (m_timeSyncRetryTimer)
            m_timeSyncRetryTimer->stop();
        if (wasConnected)
            showHomeMessage(QStringLiteral("Wi-Fi 已断开，等待信号后自动重连…"), true);
        scheduleAutoReconnect(wasConnected ? 1000 : 5000);
    }
}

void MainWindow::onStatusCheckFailed(const QString &message)
{
    m_statusBusy = false;
    // A missing/busy control socket is not proof that WPA authentication
    // failed, and must never erase credentials or flicker a healthy link down.
    if (m_wifiStatusButton)
        m_wifiStatusButton->setToolTip(message);
    scheduleAutoReconnect(5000);
}

void MainWindow::setWifiStatus(bool connected, const QString &ssid)
{
    if (m_xiaozhiBridge)
        m_xiaozhiBridge->setNetworkAvailable(connected && !m_ipAddress.isEmpty());
    if (!m_wifiStatusButton)
        return;
    m_wifiStatusButton->setProperty("connected", connected);
    m_wifiStatusButton->setText(QString());
    registerThemedIcon(m_wifiStatusButton,
                       connected ? UiIcon::WifiConnected : UiIcon::Wifi,
                       connected ? IconTint::Success : IconTint::Hint);

    if (m_wifiTopStatus) {
        m_wifiTopStatus->setProperty("connected", connected);
        m_wifiTopStatus->setProperty("connecting", false);
        m_wifiTopStatus->setText(connected ? QStringLiteral("WIFI 已连接")
                                           : QStringLiteral("WIFI 未连接"));
        m_wifiTopStatus->style()->unpolish(m_wifiTopStatus);
        m_wifiTopStatus->style()->polish(m_wifiTopStatus);
    }
    if (m_wifiTopIp) {
        m_wifiTopIp->setText(connected
                                 ? (m_ipAddress.isEmpty()
                                        ? QStringLiteral("IP：未获取")
                                        : QStringLiteral("IP：%1").arg(m_ipAddress))
                                 : QStringLiteral("IP：--"));
    }

    QString tooltip = connected && !ssid.isEmpty()
                          ? QStringLiteral("Wi-Fi 已连接：%1").arg(ssid)
                          : QStringLiteral("Wi-Fi 未连接");
    if (connected && !m_ipAddress.isEmpty())
        tooltip += QStringLiteral("\nIP：%1").arg(m_ipAddress);
    m_wifiStatusButton->setToolTip(tooltip);
    m_wifiStatusButton->style()->unpolish(m_wifiStatusButton);
    m_wifiStatusButton->style()->polish(m_wifiStatusButton);
}

void MainWindow::setWifiConnecting()
{
    if (m_wifiTopStatus) {
        m_wifiTopStatus->setProperty("connected", false);
        m_wifiTopStatus->setProperty("connecting", true);
        m_wifiTopStatus->setText(QStringLiteral("WIFI 连接中…"));
        m_wifiTopStatus->style()->unpolish(m_wifiTopStatus);
        m_wifiTopStatus->style()->polish(m_wifiTopStatus);
    }
    if (m_wifiTopIp)
        m_wifiTopIp->setText(QStringLiteral("IP：获取中…"));
    if (m_wifiStatusButton) {
        m_wifiStatusButton->setProperty("connected", false);
        registerThemedIcon(m_wifiStatusButton, UiIcon::Wifi, IconTint::Accent);
        m_wifiStatusButton->setToolTip(QStringLiteral("Wi-Fi 连接中…"));
        m_wifiStatusButton->style()->unpolish(m_wifiStatusButton);
        m_wifiStatusButton->style()->polish(m_wifiStatusButton);
    }
}

void MainWindow::startInternetTimeSync()
{
    if (m_ipAddress.isEmpty() || m_timeSynchronized || m_timeSyncInProgress ||
        (m_timeSyncRetryTimer && m_timeSyncRetryTimer->isActive()))
        return;

    if (m_timeSyncRetryTimer)
        m_timeSyncRetryTimer->stop();
    m_timeSyncInProgress = true;
    if (m_clockTime)
        m_clockTime->setToolTip(QStringLiteral("Wi-Fi 已联网，正在获取北京时间…"));
    emit timeSyncRequested();
}

void MainWindow::onTimeSyncFinished(bool success,
                                    qint64 utcMilliseconds,
                                    bool systemClockSet,
                                    bool rtcWritten,
                                    const QString &message)
{
    m_timeSyncInProgress = false;
    if (success && utcMilliseconds > 0) {
        m_beijingUtcMilliseconds = utcMilliseconds;
        m_beijingClockElapsed.start();
        m_timeSynchronized = true;
        if (m_timeSyncRetryTimer)
            m_timeSyncRetryTimer->stop();

        QString clockTooltip = systemClockSet
                                   ? QStringLiteral("北京时间 · 系统时钟已同步")
                                   : QStringLiteral("北京时间 · 系统时钟未修改");
        clockTooltip += rtcWritten
                            ? QStringLiteral(" · 已写入 RTC（UTC）")
                            : QStringLiteral(" · RTC 写入失败");
        if (m_clockDate)
            m_clockDate->setToolTip(clockTooltip);
        if (m_clockTime)
            m_clockTime->setToolTip(clockTooltip);
        qInfo().noquote() << message;
        updateClock();
        return;
    }

    if (m_clockDate)
        m_clockDate->setToolTip(QStringLiteral("北京时间校时失败，网络可用后重试"));
    if (m_clockTime)
        m_clockTime->setToolTip(QStringLiteral("北京时间校时失败，网络可用后重试"));
    qWarning().noquote() << message;
    if (!m_ipAddress.isEmpty() && m_timeSyncRetryTimer)
        m_timeSyncRetryTimer->start(30000);
}

void MainWindow::showHomeMessage(const QString &text, bool warning)
{
    if (!m_homeMessage)
        return;
    m_homeMessage->setText(text);
    m_homeMessage->setToolTip(text);
    m_homeMessage->setStyleSheet(Theme::messageStyleSheet(warning ? Theme::Tone::Warning
                                                                  : Theme::Tone::Neutral));
}

void MainWindow::updateClock()
{
    const qint64 utcMilliseconds = m_timeSynchronized && m_beijingClockElapsed.isValid()
                                      ? m_beijingUtcMilliseconds + m_beijingClockElapsed.elapsed()
                                      : QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    const QDateTime beijingTime = QDateTime::fromMSecsSinceEpoch(utcMilliseconds, Qt::UTC)
                                      .addSecs(8 * 60 * 60);
    if (m_clockDate)
        m_clockDate->setText(beijingTime.toString(QStringLiteral("yyyy-MM-dd")));
    if (m_clockTime)
        m_clockTime->setText(beijingTime.toString(QStringLiteral("HH:mm:ss")));
}

void MainWindow::openWifiSettings()
{
    m_autoReconnectSuspended = true;
    if (m_reconnectTimer)
        m_reconnectTimer->stop();
    hidePasswordKeyboard();
    m_wifiPageStack->setCurrentWidget(m_scanPage);
    m_skipButton->setText(QStringLiteral("返回"));
    registerThemedIcon(m_skipButton, UiIcon::Back, IconTint::Hint);
    m_passwordEdit->clear();
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    m_showPassword = false;
    registerThemedIcon(m_passwordToggle, UiIcon::Eye, IconTint::Secondary);
    m_passwordMessage->clear();
    m_passwordMessage->setToolTip(QString());
    m_passwordMessage->hide();
    m_wifiMessage->setStyleSheet(QString());
    m_wifiMessage->clear();
    m_wifiMessage->hide();
    m_wifiMessage->setToolTip(QString());
    m_stack->setCurrentWidget(m_wifiPage);
    startScan();
}

void MainWindow::leaveWifiPage()
{
    hidePasswordKeyboard();
    if (!m_setupComplete) {
        // Keep the user in the home screen for this run; without a credential
        // file the next launch will return to Wi-Fi setup.
        m_setupComplete = true;
    }
    m_stack->setCurrentWidget(m_homePage);
    m_autoReconnectSuspended = false;
    scheduleAutoReconnect(250);
}

void MainWindow::openPeripheralHub()
{
    m_peripheralPageStack->setCurrentWidget(m_peripheralHubPage);
    m_stack->setCurrentWidget(m_peripheralPage);
}

void MainWindow::openAudioTestPage()
{
    m_peripheralPageStack->setCurrentWidget(m_audioTestPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    updateAudioControls();
}

void MainWindow::openXiaozhiPage()
{
    m_peripheralPageStack->setCurrentWidget(m_xiaozhiPage);
    m_stack->setCurrentWidget(m_peripheralPage);
    if (!m_xiaozhiBridge->isActive()) requestXiaozhiStart();
    m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isActive()
                                       ? QStringLiteral("停止小智")
                                       : QStringLiteral("启动小智"));
    updateXiaozhiActivationView();
}

void MainWindow::requestXiaozhiStart()
{
    resetXiaozhiSessionUi(QStringLiteral("正在检查小智网络连接…"));
    m_xiaozhiBridge->setNetworkAvailable(m_wifiConnected && !m_ipAddress.isEmpty());
    if (m_wifiConnected && !m_ipAddress.isEmpty() &&
        ((m_recordProcess && m_recordProcess->state() != QProcess::NotRunning) ||
         (m_playProcess && m_playProcess->state() != QProcess::NotRunning) || m_selfTestAudio)) {
        m_xiaozhiStatus->setText(QStringLiteral("音频设备正在释放，请稍后再次尝试"));
        updateXiaozhiActivationView();
        return;
    }
    QString error;
    if (!m_xiaozhiBridge->start(&error)) {
        m_xiaozhiStatus->setText(error);
        m_xiaozhiActivationMessage->setText(error);
    }
    updateXiaozhiActivationView();
}

void MainWindow::openRs485Page()
{
    m_peripheralPageStack->setCurrentWidget(m_rs485Page);
    m_stack->setCurrentWidget(m_peripheralPage);
    emit modbusStartRequested();
}

void MainWindow::returnToHome()
{
    returnToPeripheralHub();
    m_stack->setCurrentWidget(m_homePage);
}

void MainWindow::returnToPeripheralHub()
{
    QWidget *current = m_peripheralPageStack->currentWidget();
    if (current == m_audioTestPage) {
        stopAudioProcesses();
    } else if (current == m_xiaozhiPage) {
        if (m_xiaozhiBridge)
            m_xiaozhiBridge->stop();
        resetXiaozhiSessionUi(QStringLiteral("小智已停止"));
    } else if (current == m_rs485Page) {
        emit modbusStopRequested();
        if (m_rs485Status)
            m_rs485Status->setText(QStringLiteral("正在关闭 RS485…"));
    } else if (current == m_cameraTestPage) {
        stopCameraPreview();
    } else if (current == m_sensorPage) {
        ++m_sensorPollGeneration;
        if (m_sensorTimer)
            m_sensorTimer->stop();
    } else if (current == m_canTestPage) {
        closeCanLink();
    } else if (current == m_selfTestPage) {
        cancelSelfTest();
    } else if (current == m_themePage) {
        disarmFactoryReset();
    }
    m_peripheralPageStack->setCurrentWidget(m_peripheralHubPage);
}

void MainWindow::startRecording()
{
    if (!m_recordProcess || !m_playProcess ||
        m_recordProcess->state() != QProcess::NotRunning ||
        m_playProcess->state() != QProcess::NotRunning)
        return;

    if (m_recordingPath.isEmpty()) {
        m_audioStatus->setText(QStringLiteral("无法创建私有录音临时目录"));
        return;
    }
    if (m_xiaozhiBridge->isActive()) {
        m_audioStatus->setText(QStringLiteral("小智仍在使用音频设备，请先停止小智"));
        return;
    }
    const QFileInfo outputInfo(m_recordingPath);
    if (!QDir().mkpath(outputInfo.absolutePath())) {
        m_audioStatus->setText(QStringLiteral("无法创建录音目录：%1").arg(outputInfo.absolutePath()));
        return;
    }
    QFile::remove(m_recordingPath);
    m_autoPlayAfterRecord = false;
    m_recordStopRequested = false;
    m_recordForceKilled = false;
    m_recordKillTimer->stop();
    m_recordProcess->setProgram(m_arecordProgram);
    QStringList arguments;
    arguments << QStringLiteral("-D") << m_captureDevice
              << QStringLiteral("-f") << QStringLiteral("S16_LE")
              << QStringLiteral("-r") << QString::number(m_audioSampleRate)
              << QStringLiteral("-c") << QStringLiteral("1")
              << QStringLiteral("-t") << QStringLiteral("wav")
              << m_recordingPath;
    m_recordProcess->setArguments(arguments);
    m_recordProcess->start();
    m_audioStatus->setText(QStringLiteral("正在启动录音…"));
    updateAudioControls();
}

void MainWindow::stopRecording(bool playWhenFinished)
{
    if (!m_recordProcess || m_recordProcess->state() == QProcess::NotRunning || m_recordStopRequested)
        return;
    m_autoPlayAfterRecord = playWhenFinished;
    m_recordStopRequested = true;
    m_audioStatus->setText(playWhenFinished
                               ? QStringLiteral("正在结束录音并准备回放…")
                               : QStringLiteral("正在结束录音…"));
    m_recordProcess->terminate();
    updateAudioControls();
    m_recordKillTimer->start(1800);
}

void MainWindow::playAudioFile(const QString &path, const QString &purpose)
{
    if (!m_playProcess || !m_recordProcess)
        return;
    if (m_recordProcess->state() != QProcess::NotRunning) {
        m_audioStatus->setText(QStringLiteral("录音进行中，请先停止录音"));
        return;
    }
    if (m_playProcess->state() != QProcess::NotRunning) {
        m_audioStatus->setText(QStringLiteral("当前已有音频正在播放"));
        return;
    }
    const QFileInfo fileInfo(path);
    if (!fileInfo.exists() || !fileInfo.isFile()) {
        m_audioStatus->setText(QStringLiteral("音频文件不存在：%1").arg(path));
        updateAudioControls();
        return;
    }

    m_playStopRequested = false;
    m_playKillTimer->stop();
    m_playPurpose = purpose;
    m_playProcess->setProgram(m_aplayProgram);
    m_playProcess->setArguments(QStringList() << QStringLiteral("-D") << m_playbackDevice << path);
    m_playProcess->start();
    m_audioStatus->setText(QStringLiteral("正在播放：%1").arg(path));
    updateAudioControls();
}

void MainWindow::stopAudioProcesses()
{
    m_autoPlayAfterRecord = false;
    if (m_recordProcess && m_recordProcess->state() != QProcess::NotRunning) {
        m_recordStopRequested = true;
        m_recordProcess->terminate();
        m_recordKillTimer->start(1500);
    }
    if (m_playProcess && m_playProcess->state() != QProcess::NotRunning) {
        m_playStopRequested = true;
        m_playProcess->terminate();
        m_playKillTimer->start(1500);
    }
    updateAudioControls();
}

void MainWindow::updateAudioControls()
{
    if (!m_recordButton || !m_musicButton)
        return;
    const bool recording = m_recordProcess && m_recordProcess->state() != QProcess::NotRunning;
    const bool playing = m_playProcess && m_playProcess->state() != QProcess::NotRunning;
    const bool stoppingRecord = recording && m_recordStopRequested;
    m_recordButton->setText(recording
                                ? (stoppingRecord ? QStringLiteral("正在结束录音…")
                                                  : QStringLiteral("停止录音并回放"))
                                : QStringLiteral("开始录音"));
    m_recordButton->setEnabled(recording ? !stoppingRecord : !playing);
    m_musicButton->setText(playing ? QStringLiteral("停止播放")
                                   : QStringLiteral("播放 /music.wav"));
    m_musicButton->setEnabled(!m_playStopRequested && (playing || !recording));
}

void MainWindow::onRecordProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    const bool playAfterStop = m_autoPlayAfterRecord && !m_recordForceKilled &&
                               exitStatus == QProcess::NormalExit;
    const bool wantedPlayback = m_autoPlayAfterRecord;
    m_recordKillTimer->stop();
    m_recordStopRequested = false;
    m_autoPlayAfterRecord = false;
    updateAudioControls();

    const QFileInfo recording(m_recordingPath);
    if (playAfterStop && recording.exists() && recording.isFile() && recording.size() > 44) {
        m_audioStatus->setText(QStringLiteral("录音完成，正在自动回放…"));
        playAudioFile(m_recordingPath, QStringLiteral("录音回放"));
        return;
    }
    if (wantedPlayback) {
        m_audioStatus->setText(QStringLiteral("录音文件无效、为空或录音异常（代码 %1），不自动回放").arg(exitCode));
    } else if (recording.exists() && recording.size() > 44) {
        m_audioStatus->setText(QStringLiteral("录音已保存：%1").arg(m_recordingPath));
    } else {
        m_audioStatus->setText(QStringLiteral("录音结束；请检查麦克风、arecord 和 ALSA 设备"));
    }
    updateAudioControls();
}

void MainWindow::onPlaybackProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    m_playKillTimer->stop();
    const QString purpose = m_playPurpose;
    m_playPurpose.clear();
    const bool stoppedByUser = m_playStopRequested;
    m_playStopRequested = false;
    if (stoppedByUser)
        m_audioStatus->setText(QStringLiteral("播放已停止"));
    else if (exitStatus == QProcess::NormalExit && exitCode == 0)
        m_audioStatus->setText(QStringLiteral("%1完成").arg(purpose));
    else
        m_audioStatus->setText(QStringLiteral("%1失败或异常结束（代码 %2）").arg(purpose).arg(exitCode));
    updateAudioControls();
}

void MainWindow::onXiaozhiTextReceived(const QString &text, const QString &sentenceState)
{
    if (text.trimmed().isEmpty() || !m_chatList)
        return;

    if (sentenceState == QLatin1String("sentence_start")) {
        addChatBubble(text, true, false);
        m_streamingAssistantRow = m_chatList->count() - 1;
        m_streamingAssistantText = text;
        return;
    }
    if (sentenceState == QLatin1String("sentence_end")) {
        if (m_streamingAssistantRow >= 0 && m_streamingAssistantRow < m_chatList->count()) {
            QListWidgetItem *item = m_chatList->item(m_streamingAssistantRow);
            if (text != m_streamingAssistantText && !text.startsWith(m_streamingAssistantText))
                item->setText(text);
            else if (text.startsWith(m_streamingAssistantText))
                item->setText(text);
            m_streamingAssistantRow = -1;
            m_streamingAssistantText.clear();
            m_chatList->scrollToBottom();
        } else {
            addChatBubble(text, true, false);
        }
        return;
    }
    addChatBubble(text, true, false);
}

void MainWindow::resetXiaozhiSessionUi(const QString &status)
{
    m_xiaozhiActivationCode.clear();
    m_xiaozhiActivated = false;
    m_xiaozhiAudioReady = false;
    m_xiaozhiOnline = false;
    m_xiaozhiManualRestartHint = false;
    if (m_xiaozhiReadyHintTimer)
        m_xiaozhiReadyHintTimer->stop();
    m_streamingAssistantText.clear();
    m_streamingAssistantRow = -1;
    if (m_xiaozhiActivationCodeLabel)
        m_xiaozhiActivationCodeLabel->setText(QStringLiteral("等待激活码"));
    if (m_xiaozhiStatus && !status.isEmpty())
        m_xiaozhiStatus->setText(status);
    updateXiaozhiActivationView();
}

void MainWindow::updateXiaozhiActivationView()
{
    if (!m_xiaozhiActivationPanel || !m_chatList)
        return;
    if (m_xiaozhiBridge && m_xiaozhiToggleButton) {
        m_xiaozhiToggleButton->setText(m_xiaozhiBridge->isStopping() ? QStringLiteral("正在停止…")
            : m_xiaozhiBridge->isActive() ? QStringLiteral("停止小智") : QStringLiteral("启动小智"));
        m_xiaozhiToggleButton->setEnabled(!m_xiaozhiBridge->isStopping());
    }

    if (m_xiaozhiBridge && m_xiaozhiBridge->networkBlocked()) {
        if (m_xiaozhiReadyHintTimer) m_xiaozhiReadyHintTimer->stop();
        m_xiaozhiActivationPanel->show();
        m_chatList->hide();
        m_xiaozhiStatus->setText(XiaozhiBridge::networkUnavailableMessage());
        m_xiaozhiActivationTitleLabel->setText(QStringLiteral("网络不可用"));
        m_xiaozhiActivationCodeCaption->setText(QStringLiteral("请检查 Wi-Fi 和路由器联网状态"));
        m_xiaozhiActivationCodeLabel->setText(QStringLiteral("请先联网"));
        m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("正确连接 Wi-Fi 并确认网络可用后，点击右上角“启动小智”重试。"));
        m_xiaozhiActivationMessage->setText(XiaozhiBridge::networkUnavailableMessage());
        return;
    }
    const bool conversationReady = m_xiaozhiOnline && m_xiaozhiAudioReady;
    if (m_xiaozhiReadyHintTimer) {
        if (conversationReady) {
            m_xiaozhiReadyHintTimer->stop();
            m_xiaozhiManualRestartHint = false;
        } else if (m_xiaozhiActivated) {
            if (!m_xiaozhiManualRestartHint && !m_xiaozhiReadyHintTimer->isActive())
                m_xiaozhiReadyHintTimer->start();
        } else {
            m_xiaozhiReadyHintTimer->stop();
            m_xiaozhiManualRestartHint = false;
        }
    }

    m_xiaozhiActivationPanel->setVisible(!conversationReady);
    m_chatList->setVisible(conversationReady);
    if (!m_xiaozhiActivationMessage)
        return;

    if (conversationReady) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("小智服务、麦克风和扬声器均已就绪。现在可以开始说话。"));
        return;
    }

    if (m_xiaozhiManualRestartHint) {
        if (m_xiaozhiStatus)
            m_xiaozhiStatus->setText(QStringLiteral("连接未就绪 · 请停止小智后重新启动"));
        if (m_xiaozhiActivationTitleLabel)
            m_xiaozhiActivationTitleLabel->setText(QStringLiteral("小智连接长时间未就绪"));
        if (m_xiaozhiActivationCodeCaption)
            m_xiaozhiActivationCodeCaption->setText(QStringLiteral("建议手动重新启动"));
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(QStringLiteral("连接未就绪"));
        if (m_xiaozhiActivationInstructionsLabel)
            m_xiaozhiActivationInstructionsLabel->setText(
                QStringLiteral("若右上角显示“停止小智”，请先点击停止；按钮变为“启动小智”后，再点击一次。"));
        m_xiaozhiActivationMessage->setText(
            QStringLiteral("等待 30 秒仍未显示“已就绪”。重启后请等状态恢复再开始说话。"));
        return;
    }

    const QString status = m_xiaozhiStatus ? m_xiaozhiStatus->text() : QString();
    if (m_xiaozhiActivated) {
        if (m_xiaozhiActivationTitleLabel)
            m_xiaozhiActivationTitleLabel->setText(m_xiaozhiOnline && !m_xiaozhiAudioReady
                                                       ? QStringLiteral("云端已连接 · 正在准备音频设备")
                                                       : QStringLiteral("设备已绑定 · 正在连接小智服务"));
        if (m_xiaozhiActivationCodeCaption)
            m_xiaozhiActivationCodeCaption->setText(QStringLiteral("设备激活状态"));
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(QStringLiteral("已完成绑定"));
        if (m_xiaozhiActivationInstructionsLabel) {
            if (status.contains(QStringLiteral("中断")) || status.contains(QStringLiteral("网络断开")))
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("云端连接暂时中断，请检查 Wi-Fi；小智核心会自动尝试恢复。"));
            else if (status.contains(QStringLiteral("自动恢复")) || status.contains(QStringLiteral("音频线程初始化失败")))
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("核心正在自动恢复音频与云端连接，无需手动停止或重启。"));
            else if (m_xiaozhiOnline && !m_xiaozhiAudioReady)
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("核心正在确认麦克风录音和扬声器播放均可用；完成后会提示“已就绪”。"));
            else
                m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("核心正在初始化麦克风并连接云端；显示“已就绪”后再开始说话。"));
        }
    } else {
        if (m_xiaozhiActivationTitleLabel)
            m_xiaozhiActivationTitleLabel->setText(QStringLiteral("首次使用 · 绑定小智设备"));
        if (m_xiaozhiActivationCodeCaption)
            m_xiaozhiActivationCodeCaption->setText(QStringLiteral("小智核心实时返回的 6 位激活码"));
        if (m_xiaozhiActivationCodeLabel)
            m_xiaozhiActivationCodeLabel->setText(m_xiaozhiActivationCode.isEmpty()
                                                      ? QStringLiteral("等待激活码")
                                                      : m_xiaozhiActivationCode);
        if (m_xiaozhiActivationInstructionsLabel)
            m_xiaozhiActivationInstructionsLabel->setText(QStringLiteral("扫码注册/登录 → 添加设备 → 输入上方六码并完成绑定。未激活前，语音对话不可用。"));
    }

    if (status.contains(QStringLiteral("自动恢复")) ||
        status.contains(QStringLiteral("音频线程初始化失败"))) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("检测到核心音频初始化异常，正在自动重启恢复；无需手动操作。"));
    } else if (!m_xiaozhiBridge || !m_xiaozhiBridge->isActive()) {
        if (status == QLatin1String("小智已停止")) {
            m_xiaozhiActivationMessage->setText(QStringLiteral("小智核心已停止；如需使用，请点击右上角启动。"));
        } else if (status.contains(QStringLiteral("未找到")) ||
                   status.contains(QStringLiteral("执行权限")) ||
                   status.contains(QStringLiteral("无法监听")) ||
                   status.contains(QStringLiteral("连续启动失败")) ||
                   status.contains(QStringLiteral("异常退出"))) {
            m_xiaozhiActivationMessage->setText(status);
        } else {
            m_xiaozhiActivationMessage->setText(status.isEmpty()
                ? QStringLiteral("请点击右上角启动小智。") : status);
        }
    } else if (!m_xiaozhiBridge->isRunning()) {
        m_xiaozhiActivationMessage->setText(status.contains(QStringLiteral("网络")) ? status
            : QStringLiteral("小智核心正在自动恢复；恢复连接后会提示“已就绪”。"));
    } else if (m_xiaozhiActivated) {
        if (status.contains(QStringLiteral("中断")) || status.contains(QStringLiteral("网络断开")))
            m_xiaozhiActivationMessage->setText(QStringLiteral("云端网络暂不可用；小智核心正在自动恢复连接，请检查 Wi-Fi。"));
        else
            m_xiaozhiActivationMessage->setText(QStringLiteral("设备已绑定；核心正在初始化麦克风并连接云端。请等状态显示“已就绪”后再说话。"));
    } else if (!m_xiaozhiActivationCode.isEmpty()) {
        m_xiaozhiActivationMessage->setText(QStringLiteral("请按步骤完成设备绑定；激活确认前不会开启正常语音对话。"));
    } else {
        m_xiaozhiActivationMessage->setText(QStringLiteral("正在检查设备激活状态；如需绑定，将显示核心实际返回的六码。"));
    }
}

void MainWindow::addChatBubble(const QString &text, bool assistant, bool systemMessage)
{
    if (!m_chatList)
        return;
    while (m_chatList->count() >= 100) {
        delete m_chatList->takeItem(0);
        if (m_streamingAssistantRow > 0)
            --m_streamingAssistantRow;
        else if (m_streamingAssistantRow == 0)
            m_streamingAssistantRow = -1;
    }
    QListWidgetItem *item = new QListWidgetItem(text, m_chatList);
    item->setData(ChatSideRole, assistant ? 0 : 1);
    item->setData(ChatSystemRole, systemMessage);
    m_chatList->scrollToBottom();
}
