#include "uitheme.h"

#include <QApplication>
#include <QPalette>
#include <QSettings>
#include <QStyle>
#include <QtGlobal>

// ---------------------------------------------------------------------------
// 配色唯一出处：调整任一颜色的取值，整个界面（样式表、绘制、图标、调色板）
// 同步生效。颜色常量与同名 Hex 字符串由 THEME_DEFINE 一并生成。
// ---------------------------------------------------------------------------

// 颜色为可变全局量：setTheme() 一次性重载全部取值并刷新同名 Hex 字符串，
// styleSheet()/messageStyleSheet()/绘制/图标着色引用它们即可随主题变化。
#define THEME_STORAGE(Name, DefaultHex)                         \
    QColor Name = QColor(QStringLiteral(DefaultHex));           \
    QString Name##Hex = QStringLiteral(DefaultHex);

namespace Theme {

// ---------- 基础表面层级（由深到浅） ----------
THEME_STORAGE(AppBackground, "#0B1727")
THEME_STORAGE(TopBarBackground, "#102036")
THEME_STORAGE(CardBackground, "#12253B")
THEME_STORAGE(ControlBackground, "#172B43")
THEME_STORAGE(ControlBackgroundHover, "#203850")
THEME_STORAGE(ControlBackgroundPressed, "#254A6A")
THEME_STORAGE(ControlBackgroundDisabled, "#142337")
THEME_STORAGE(ControlBackgroundActive, "#1A3450")
THEME_STORAGE(ControlBackgroundActivePressed, "#2D4F70")
THEME_STORAGE(SunkenBackground, "#0F1C2C")
THEME_STORAGE(InputBackground, "#101F32")
THEME_STORAGE(TooltipBackground, "#1B2D43")

// ---------- 描边层级 ----------
THEME_STORAGE(BorderBase, "#2A405A")
THEME_STORAGE(BorderSoft, "#263C55")
THEME_STORAGE(BorderInput, "#354D68")
THEME_STORAGE(BorderHover, "#365574")
THEME_STORAGE(TooltipBorder, "#365270")
THEME_STORAGE(ScrollbarHandle, "#35506D")

// ---------- 文字层级 ----------
THEME_STORAGE(TextPrimary, "#E8F0FA")
THEME_STORAGE(TextSecondary, "#ADBED2")
THEME_STORAGE(TextHint, "#8296AF")
THEME_STORAGE(TextBright, "#F3F7FD")
THEME_STORAGE(TextNote, "#D1DEEC")

// ---------- 品牌强调（蓝） ----------
THEME_STORAGE(Accent, "#5AAAF2")
THEME_STORAGE(AccentBright, "#75BEFF")
THEME_STORAGE(Primary, "#2169A5")
THEME_STORAGE(PrimaryHover, "#2C7DC0")
THEME_STORAGE(PrimaryPressed, "#1A568C")
THEME_STORAGE(PrimaryBorder, "#3A8BD0")
THEME_STORAGE(PrimaryPressedBorder, "#153F68")

// ---------- 成功绿 ----------
THEME_STORAGE(Success, "#35A978")
THEME_STORAGE(SuccessBright, "#55D49A")
THEME_STORAGE(SuccessText, "#8DE0B6")
THEME_STORAGE(SuccessBackground, "#153C32")
THEME_STORAGE(SuccessBorder, "#2B6654")
THEME_STORAGE(SuccessPressed, "#1E5143")
THEME_STORAGE(DoneKeyBackground, "#25855F")
THEME_STORAGE(DoneKeyBorder, "#287D59")
THEME_STORAGE(DoneKeyPressed, "#1C6147")
THEME_STORAGE(DoneKeyPressedBorder, "#174D3A")
THEME_STORAGE(ChatUserBubble, "#1B4036")

// ---------- 告警红 ----------
THEME_STORAGE(Danger, "#FF8C95")

// ---------- 软键盘功能键 ----------
THEME_STORAGE(SoftKeyBackground, "#233B54")
THEME_STORAGE(SoftKeyBorder, "#3F5874")
THEME_STORAGE(SoftKeyPressed, "#435B75")

// ---------- 二维码 ----------
THEME_STORAGE(QrBackground, "#FFFFFF")
THEME_STORAGE(QrBorder, "#CBD5E1")

// ---------- 仅 QPalette 使用的中间调 ----------
THEME_STORAGE(PaletteButtonText, "#D5E2F1")
THEME_STORAGE(PaletteAlternateBase, "#14263D")
THEME_STORAGE(PaletteLight, "#29425F")
THEME_STORAGE(PaletteMidlight, "#233A53")
THEME_STORAGE(PaletteMid, "#1B2F45")
THEME_STORAGE(PaletteDark, "#081321")
THEME_STORAGE(PaletteShadow, "#040A12")

// ---------------------------------------------------------------------------
// 调色板表：每个字段顺序与上面的 THEME_STORAGE 声明一一对应
// ---------------------------------------------------------------------------
struct PaletteDef {
    const char *name;
    const char *desc;
    const char *AppBackground;
    const char *TopBarBackground;
    const char *CardBackground;
    const char *ControlBackground;
    const char *ControlBackgroundHover;
    const char *ControlBackgroundPressed;
    const char *ControlBackgroundDisabled;
    const char *ControlBackgroundActive;
    const char *ControlBackgroundActivePressed;
    const char *SunkenBackground;
    const char *InputBackground;
    const char *TooltipBackground;
    const char *BorderBase;
    const char *BorderSoft;
    const char *BorderInput;
    const char *BorderHover;
    const char *TooltipBorder;
    const char *ScrollbarHandle;
    const char *TextPrimary;
    const char *TextSecondary;
    const char *TextHint;
    const char *TextBright;
    const char *TextNote;
    const char *Accent;
    const char *AccentBright;
    const char *Primary;
    const char *PrimaryHover;
    const char *PrimaryPressed;
    const char *PrimaryBorder;
    const char *PrimaryPressedBorder;
    const char *Success;
    const char *SuccessBright;
    const char *SuccessText;
    const char *SuccessBackground;
    const char *SuccessBorder;
    const char *SuccessPressed;
    const char *DoneKeyBackground;
    const char *DoneKeyBorder;
    const char *DoneKeyPressed;
    const char *DoneKeyPressedBorder;
    const char *ChatUserBubble;
    const char *Danger;
    const char *SoftKeyBackground;
    const char *SoftKeyBorder;
    const char *SoftKeyPressed;
    const char *QrBackground;
    const char *QrBorder;
    const char *PaletteButtonText;
    const char *PaletteAlternateBase;
    const char *PaletteLight;
    const char *PaletteMidlight;
    const char *PaletteMid;
    const char *PaletteDark;
    const char *PaletteShadow;
};

static const PaletteDef kThemes[] = {
    { "午夜蓝", "深色护眼 · 默认主题",
        "#0B1727",
        "#102036",
        "#12253B",
        "#172B43",
        "#203850",
        "#254A6A",
        "#142337",
        "#1A3450",
        "#2D4F70",
        "#0F1C2C",
        "#101F32",
        "#1B2D43",
        "#2A405A",
        "#263C55",
        "#354D68",
        "#365574",
        "#365270",
        "#35506D",
        "#E8F0FA",
        "#ADBED2",
        "#8296AF",
        "#F3F7FD",
        "#D1DEEC",
        "#5AAAF2",
        "#75BEFF",
        "#2169A5",
        "#2C7DC0",
        "#1A568C",
        "#3A8BD0",
        "#153F68",
        "#35A978",
        "#55D49A",
        "#8DE0B6",
        "#153C32",
        "#2B6654",
        "#1E5143",
        "#25855F",
        "#287D59",
        "#1C6147",
        "#174D3A",
        "#1B4036",
        "#FF8C95",
        "#233B54",
        "#3F5874",
        "#435B75",
        "#FFFFFF",
        "#CBD5E1",
        "#D5E2F1",
        "#14263D",
        "#29425F",
        "#233A53",
        "#1B2F45",
        "#081321",
        "#040A12" },
    { "曜石黑", "纯黑省电 · AMOLED 友好",
        "#05080E",
        "#080D15",
        "#0A1019",
        "#0F1724",
        "#16202F",
        "#1D2B40",
        "#090F18",
        "#122036",
        "#1E3050",
        "#060B12",
        "#081019",
        "#111A26",
        "#1D2A3C",
        "#1A2636",
        "#26374C",
        "#2C4360",
        "#29435E",
        "#28405C",
        "#E8F0FA",
        "#ADBED2",
        "#8296AF",
        "#F3F7FD",
        "#D1DEEC",
        "#4FA3E8",
        "#6CB8FF",
        "#1D6096",
        "#2774AC",
        "#174C77",
        "#347EBC",
        "#123A5E",
        "#35A978",
        "#55D49A",
        "#8DE0B6",
        "#11302A",
        "#24564A",
        "#1A4239",
        "#217558",
        "#23704F",
        "#1A5440",
        "#143F31",
        "#15322B",
        "#FF8088",
        "#1B2C40",
        "#34506E",
        "#3A5474",
        "#FFFFFF",
        "#CBD5E1",
        "#D5E2F1",
        "#0C1420",
        "#1F3045",
        "#1B2A3E",
        "#162536",
        "#050B14",
        "#000000" },
    { "护眼墨绿", "暗绿低蓝光 · 长时间观测",
        "#0A1812",
        "#0E221A",
        "#122A22",
        "#173428",
        "#1E4434",
        "#275644",
        "#0F2620",
        "#1B3E30",
        "#2A5544",
        "#0C1F17",
        "#0F241C",
        "#1A362B",
        "#2A4A3C",
        "#264236",
        "#36584A",
        "#3E6B56",
        "#366052",
        "#355848",
        "#E6F4EC",
        "#ADCABD",
        "#7FA08F",
        "#F2FBF6",
        "#CFE5D8",
        "#46C488",
        "#61DEA3",
        "#1E7A56",
        "#249268",
        "#186044",
        "#36A87A",
        "#144B36",
        "#35B383",
        "#55D49A",
        "#8DE0B6",
        "#14402F",
        "#2B6654",
        "#1E5143",
        "#25855F",
        "#287D59",
        "#1C6147",
        "#174D3A",
        "#174237",
        "#FF8C95",
        "#224636",
        "#3E6352",
        "#40614E",
        "#FFFFFF",
        "#CBD5E1",
        "#D3E8DC",
        "#12291F",
        "#274A3B",
        "#234236",
        "#1B352A",
        "#07140E",
        "#020805" },
    { "清爽白", "浅色高亮 · 强光环境可视",
        "#E9EEF5",
        "#FFFFFF",
        "#FFFFFF",
        "#EDF2F8",
        "#DCE6F2",
        "#C9D9EC",
        "#E3E9F1",
        "#D6E4F5",
        "#B9CFE9",
        "#DFE7F1",
        "#FFFFFF",
        "#FFFFFF",
        "#C6D3E2",
        "#D6DEE9",
        "#AAC0D6",
        "#84B4E8",
        "#C6D3E2",
        "#B4C3D4",
        "#1C2836",
        "#4A5C72",
        "#7C8DA2",
        "#FFFFFF",
        "#34465C",
        "#2E8BDE",
        "#1774C4",
        "#2F8FDB",
        "#4AA3E8",
        "#2270B4",
        "#2179C0",
        "#1A5E92",
        "#2EA26E",
        "#238A5C",
        "#FFFFFF",
        "#DFF3E9",
        "#A4D8BE",
        "#C6E9D8",
        "#2E9E6C",
        "#288B5F",
        "#237A53",
        "#1C6743",
        "#D9EEE4",
        "#D64550",
        "#F4F7FB",
        "#CBD8E6",
        "#DBE5F0",
        "#FFFFFF",
        "#CBD5E1",
        "#22303F",
        "#F2F6FA",
        "#FFFFFF",
        "#DDE4EC",
        "#C3CFDC",
        "#8CA0B4",
        "#5B6C7F" }
};

static const int kThemeCount = int(sizeof(kThemes) / sizeof(kThemes[0]));
static int g_themeIndex = 0;

int themeCount()
{
    return kThemeCount;
}

QString themeName(int index)
{
    return QString::fromUtf8(kThemes[qBound(0, index, kThemeCount - 1)].name);
}

QString themeDesc(int index)
{
    return QString::fromUtf8(kThemes[qBound(0, index, kThemeCount - 1)].desc);
}

QColor themePreviewColor(int index, PreviewSlot slot)
{
    const PaletteDef &def = kThemes[qBound(0, index, kThemeCount - 1)];
    switch (slot) {
    case PreviewBackground: return QColor(QLatin1String(def.AppBackground));
    case PreviewCard:       return QColor(QLatin1String(def.CardBackground));
    case PreviewAccent:     return QColor(QLatin1String(def.Accent));
    case PreviewText:       return QColor(QLatin1String(def.TextPrimary));
    case PreviewSuccess:    return QColor(QLatin1String(def.Success));
    }
    return QColor();
}

int currentThemeIndex()
{
    return g_themeIndex;
}

void setTheme(int index)
{
    g_themeIndex = qBound(0, index, kThemeCount - 1);
    const PaletteDef &def = kThemes[g_themeIndex];
#define APPLY_THEME_FIELD(F)                        \
    F = QColor(QLatin1String(def.F));               \
    F##Hex = QLatin1String(def.F);
    APPLY_THEME_FIELD(AppBackground)
    APPLY_THEME_FIELD(TopBarBackground)
    APPLY_THEME_FIELD(CardBackground)
    APPLY_THEME_FIELD(ControlBackground)
    APPLY_THEME_FIELD(ControlBackgroundHover)
    APPLY_THEME_FIELD(ControlBackgroundPressed)
    APPLY_THEME_FIELD(ControlBackgroundDisabled)
    APPLY_THEME_FIELD(ControlBackgroundActive)
    APPLY_THEME_FIELD(ControlBackgroundActivePressed)
    APPLY_THEME_FIELD(SunkenBackground)
    APPLY_THEME_FIELD(InputBackground)
    APPLY_THEME_FIELD(TooltipBackground)
    APPLY_THEME_FIELD(BorderBase)
    APPLY_THEME_FIELD(BorderSoft)
    APPLY_THEME_FIELD(BorderInput)
    APPLY_THEME_FIELD(BorderHover)
    APPLY_THEME_FIELD(TooltipBorder)
    APPLY_THEME_FIELD(ScrollbarHandle)
    APPLY_THEME_FIELD(TextPrimary)
    APPLY_THEME_FIELD(TextSecondary)
    APPLY_THEME_FIELD(TextHint)
    APPLY_THEME_FIELD(TextBright)
    APPLY_THEME_FIELD(TextNote)
    APPLY_THEME_FIELD(Accent)
    APPLY_THEME_FIELD(AccentBright)
    APPLY_THEME_FIELD(Primary)
    APPLY_THEME_FIELD(PrimaryHover)
    APPLY_THEME_FIELD(PrimaryPressed)
    APPLY_THEME_FIELD(PrimaryBorder)
    APPLY_THEME_FIELD(PrimaryPressedBorder)
    APPLY_THEME_FIELD(Success)
    APPLY_THEME_FIELD(SuccessBright)
    APPLY_THEME_FIELD(SuccessText)
    APPLY_THEME_FIELD(SuccessBackground)
    APPLY_THEME_FIELD(SuccessBorder)
    APPLY_THEME_FIELD(SuccessPressed)
    APPLY_THEME_FIELD(DoneKeyBackground)
    APPLY_THEME_FIELD(DoneKeyBorder)
    APPLY_THEME_FIELD(DoneKeyPressed)
    APPLY_THEME_FIELD(DoneKeyPressedBorder)
    APPLY_THEME_FIELD(ChatUserBubble)
    APPLY_THEME_FIELD(Danger)
    APPLY_THEME_FIELD(SoftKeyBackground)
    APPLY_THEME_FIELD(SoftKeyBorder)
    APPLY_THEME_FIELD(SoftKeyPressed)
    APPLY_THEME_FIELD(QrBackground)
    APPLY_THEME_FIELD(QrBorder)
    APPLY_THEME_FIELD(PaletteButtonText)
    APPLY_THEME_FIELD(PaletteAlternateBase)
    APPLY_THEME_FIELD(PaletteLight)
    APPLY_THEME_FIELD(PaletteMidlight)
    APPLY_THEME_FIELD(PaletteMid)
    APPLY_THEME_FIELD(PaletteDark)
    APPLY_THEME_FIELD(PaletteShadow)
#undef APPLY_THEME_FIELD
}

int loadSavedThemeIndex()
{
    const QSettings settings(QStringLiteral("imx6ull"), QStringLiteral("board_ui"));
    return qBound(0, settings.value(QStringLiteral("ui/theme"), 0).toInt(), kThemeCount - 1);
}

void saveThemeIndex(int index)
{
    QSettings settings(QStringLiteral("imx6ull"), QStringLiteral("board_ui"));
    settings.setValue(QStringLiteral("ui/theme"), qBound(0, index, kThemeCount - 1));
    settings.sync();
}

void applyPalette(QApplication &app)
{
    QPalette palette(app.style()->standardPalette());
    palette.setColor(QPalette::Window, AppBackground);
    palette.setColor(QPalette::WindowText, TextPrimary);
    palette.setColor(QPalette::Base, InputBackground);
    palette.setColor(QPalette::AlternateBase, PaletteAlternateBase);
    palette.setColor(QPalette::ToolTipBase, TooltipBackground);
    palette.setColor(QPalette::ToolTipText, TextPrimary);
    palette.setColor(QPalette::Text, TextPrimary);
    palette.setColor(QPalette::Button, ControlBackground);
    palette.setColor(QPalette::ButtonText, PaletteButtonText);
    palette.setColor(QPalette::Light, PaletteLight);
    palette.setColor(QPalette::Midlight, PaletteMidlight);
    palette.setColor(QPalette::Mid, PaletteMid);
    palette.setColor(QPalette::Dark, PaletteDark);
    palette.setColor(QPalette::Shadow, PaletteShadow);
    palette.setColor(QPalette::Link, AccentBright);
    palette.setColor(QPalette::Highlight, Primary);
    palette.setColor(QPalette::HighlightedText, TextBright);
    palette.setColor(QPalette::Disabled, QPalette::WindowText, TextHint);
    palette.setColor(QPalette::Disabled, QPalette::Text, TextHint);
    palette.setColor(QPalette::Disabled, QPalette::ButtonText, TextHint);
    app.setPalette(palette);
}

// 规则 { ... } 片段
static QString rule(const QString &selector, const QString &body)
{
    return selector + QLatin1String(" { ") + body + QLatin1String(" }");
}

QString styleSheet()
{
    QString sheet;
    sheet.reserve(8192);

    sheet += rule(QLatin1String("QWidget#appRoot, QWidget#homePage, QWidget#wifiPage, QWidget#wifiScanPage, QWidget#passwordPage, QWidget#peripheralPage, QWidget#peripheralHubPage, QWidget#audioTestPage, QWidget#xiaozhiPage, QWidget#rs485Page, QWidget#cameraTestPage, QWidget#sensorPage, QWidget#canTestPage, QWidget#selfTestPage, QWidget#themePage"),
                  QLatin1String("background:") + AppBackgroundHex + QLatin1String("; color:") + TextPrimaryHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QStackedWidget"), QLatin1String("background:transparent; border:0;"));
    sheet += rule(QLatin1String("QWidget"), QLatin1String("font-size:13px;"));
    sheet += rule(QLatin1String("QToolTip"),
                  QLatin1String("background:") + TooltipBackgroundHex + QLatin1String("; color:") + TextPrimaryHex
                  + QLatin1String("; border:1px solid ") + TooltipBorderHex + QLatin1String("; padding:3px;"));
    sheet += rule(QLatin1String("QScrollBar:vertical"),
                  QLatin1String("background:") + SunkenBackgroundHex + QLatin1String("; width:7px; margin:2px 1px; border:0;"));
    sheet += rule(QLatin1String("QScrollBar::handle:vertical"),
                  QLatin1String("background:") + ScrollbarHandleHex + QLatin1String("; min-height:22px; border-radius:3px;"));
    sheet += rule(QLatin1String("QScrollBar::handle:vertical:hover"),
                  QLatin1String("background:") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical"),
                  QLatin1String("height:0; border:0;"));
    sheet += rule(QLatin1String("QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical"),
                  QLatin1String("background:transparent;"));
    sheet += rule(QLatin1String("QFrame#topBar"),
                  QLatin1String("background:") + TopBarBackgroundHex
                  + QLatin1String("; border-bottom:1px solid ") + BorderBaseHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#brandMark"),
                  QLatin1String("background:") + ControlBackgroundActiveHex + QLatin1String("; border-radius:8px;"));
    sheet += rule(QLatin1String("QLabel#brandName"),
                  QLatin1String("color:") + TextPrimaryHex + QLatin1String("; font-size:14px; font-weight:750;"));
    sheet += rule(QLatin1String("QLabel#clockDate"),
                  QLatin1String("color:") + AccentHex + QLatin1String("; font-size:12px; font-weight:700;"));
    sheet += rule(QLatin1String("QLabel#clockTime"),
                  QLatin1String("color:") + TextPrimaryHex + QLatin1String("; font-size:12px; font-weight:750;"));
    sheet += rule(QLatin1String("QLabel#wifiTopStatus"),
                  QLatin1String("color:") + DangerHex + QLatin1String("; font-size:11px; font-weight:700;"));
    sheet += rule(QLatin1String("QLabel#wifiTopStatus[connected=\"true\"]"),
                  QLatin1String("color:") + SuccessBrightHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#wifiTopStatus[connecting=\"true\"]"),
                  QLatin1String("color:") + AccentBrightHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#wifiTopIp"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:11px;"));
    sheet += rule(QLatin1String("QPushButton"),
                  QLatin1String("background:") + ControlBackgroundHex + QLatin1String("; color:") + TextPrimaryHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex
                  + QLatin1String("; border-radius:10px; padding:4px 8px; font-size:13px;"));
    sheet += rule(QLatin1String("QPushButton:hover"),
                  QLatin1String("border-color:") + AccentHex
                  + QLatin1String("; background:") + ControlBackgroundHoverHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton:pressed"),
                  QLatin1String("background:") + ControlBackgroundPressedHex + QLatin1String("; color:") + TextPrimaryHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String("; padding-top:6px;"));
    sheet += rule(QLatin1String("QPushButton:disabled"),
                  QLatin1String("color:") + TextHintHex
                  + QLatin1String("; background:") + ControlBackgroundDisabledHex
                  + QLatin1String("; border-color:") + BorderSoftHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#primaryButton"),
                  QLatin1String("background:") + PrimaryHex
                  + QLatin1String("; border:1px solid ") + PrimaryBorderHex
                  + QLatin1String("; color:") + TextBrightHex
                  + QLatin1String("; font-weight:700; padding:3px 10px;"));
    sheet += rule(QLatin1String("QPushButton#primaryButton:hover"),
                  QLatin1String("background:") + PrimaryHoverHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#primaryButton:pressed"),
                  QLatin1String("background:") + PrimaryPressedHex
                  + QLatin1String("; border:2px solid ") + PrimaryPressedBorderHex
                  + QLatin1String("; padding-top:3px;"));
    sheet += rule(QLatin1String("QPushButton#skipButton:pressed"),
                  QLatin1String("background:") + ControlBackgroundPressedHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String("; padding:2px 10px;"));
    sheet += rule(QLatin1String("QPushButton#wifiStatusButton"),
                  QLatin1String("min-width:30px; max-width:30px; min-height:30px; max-height:30px; padding:0; background:transparent; border:1px solid transparent;"));
    sheet += rule(QLatin1String("QPushButton#wifiStatusButton:hover"),
                  QLatin1String("background:") + ControlBackgroundActiveHex
                  + QLatin1String("; border-color:") + BorderHoverHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#wifiStatusButton:pressed"),
                  QLatin1String("background:") + ControlBackgroundPressedHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#wifiStatusButton[connected=\"true\"]"),
                  QLatin1String("background:") + SuccessBackgroundHex
                  + QLatin1String("; border-color:") + SuccessBorderHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#wifiStatusButton[connected=\"true\"]:pressed"),
                  QLatin1String("background:") + SuccessPressedHex
                  + QLatin1String("; border:2px solid ") + SuccessHex + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#iconButton"),
                  QLatin1String("background:transparent; border:1px solid transparent; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#iconButton:hover"),
                  QLatin1String("background:") + ControlBackgroundActiveHex
                  + QLatin1String("; border-color:") + BorderHoverHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#iconButton:pressed"),
                  QLatin1String("background:") + ControlBackgroundPressedHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#skipButton"), QLatin1String("font-size:12px; padding:3px 11px;"));
    sheet += rule(QLatin1String("QLabel#pageTitle"),
                  QLatin1String("font-size:17px; font-weight:750; color:") + TextPrimaryHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#scanInfo"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:11px;"));
    sheet += rule(QLatin1String("QLabel#message"),
                  QLatin1String("color:") + DangerHex + QLatin1String("; font-size:11px;"));
    sheet += rule(QLatin1String("QLineEdit"),
                  QLatin1String("min-height:28px; border:1px solid ") + BorderInputHex
                  + QLatin1String("; border-radius:10px; background:") + InputBackgroundHex
                  + QLatin1String("; padding:3px 9px; color:") + TextPrimaryHex
                  + QLatin1String("; selection-background-color:") + PrimaryHex + QLatin1String("; font-size:12px;"));
    sheet += rule(QLatin1String("QLineEdit:focus"),
                  QLatin1String("border-color:") + AccentHex + QLatin1String(";"));
    // CAN 页表单控件
    sheet += rule(QLatin1String("QComboBox"),
                  QLatin1String("min-height:24px; border:1px solid ") + BorderInputHex
                  + QLatin1String("; border-radius:8px; background:") + InputBackgroundHex
                  + QLatin1String("; padding:1px 6px; color:") + TextPrimaryHex + QLatin1String("; font-size:11px;"));
    sheet += rule(QLatin1String("QComboBox:focus"), QLatin1String("border-color:") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QComboBox:disabled"),
                  QLatin1String("color:") + TextHintHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QComboBox::drop-down"),
                  QLatin1String("border:0; width:20px; subcontrol-origin:padding;"));
    sheet += rule(QLatin1String("QComboBox::down-arrow"),
                  QLatin1String("width:0; height:0; border-left:4px solid transparent; border-right:4px solid transparent; border-top:5px solid ") + TextSecondaryHex + QLatin1String("; margin-right:6px;"));
    sheet += rule(QLatin1String("QComboBox QAbstractItemView"),
                  QLatin1String("background:") + InputBackgroundHex + QLatin1String("; border:1px solid ")
                  + BorderBaseHex + QLatin1String("; color:") + TextPrimaryHex
                  + QLatin1String("; selection-background-color:") + PrimaryHex
                  + QLatin1String("; selection-color:") + TextBrightHex + QLatin1String("; outline:0; font-size:11px;"));
    sheet += rule(QLatin1String("QPlainTextEdit#canLog"),
                  QLatin1String("background:") + InputBackgroundHex + QLatin1String("; border:1px solid ")
                  + BorderBaseHex + QLatin1String("; border-radius:10px; padding:4px 8px; color:")
                  + TextSecondaryHex + QLatin1String("; font-size:10px;"));
    sheet += rule(QLatin1String("QFrame#canCard"),
                  QLatin1String("background:") + CardBackgroundHex + QLatin1String("; border:1px solid ")
                  + BorderBaseHex + QLatin1String("; border-radius:11px;"));
    sheet += rule(QLatin1String("QLabel#canFormLabel"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:11px; font-weight:600;"));
    // 恢复出厂设置（危险区）按钮
    sheet += rule(QLatin1String("QPushButton#dangerButton"),
                  QLatin1String("background:transparent; border:1px solid ") + DangerHex
                  + QLatin1String("; color:") + DangerHex
                  + QLatin1String("; border-radius:9px; min-height:24px; padding:2px 10px; font-size:11px;"));
    sheet += rule(QLatin1String("QPushButton#dangerButton:pressed"),
                  QLatin1String("background:") + DangerHex + QLatin1String("; color:")
                  + TextBrightHex + QLatin1String(";"));
    // 一键测试页结果行
    sheet += rule(QLatin1String("QFrame#selfTestRow"),
                  QLatin1String("background:") + CardBackgroundHex + QLatin1String("; border:1px solid ")
                  + BorderBaseHex + QLatin1String("; border-radius:9px;"));
    sheet += rule(QLatin1String("QLabel#selfTestRowStatus"),
                  QLatin1String("font-size:13px; font-weight:700; color:") + TextHintHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#selfTestRowName"),
                  QLatin1String("font-size:12px; font-weight:700; color:") + TextPrimaryHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#selfTestRowDetail"),
                  QLatin1String("font-size:9px; color:") + TextHintHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QListWidget"), QLatin1String("background:transparent; border:0; outline:0; padding:0;"));
    sheet += rule(QLatin1String("QListWidget::item"), QLatin1String("border:0; padding:0; margin:0 0 2px 0;"));
    sheet += rule(QLatin1String("QFrame#heroCard"),
                  QLatin1String("background:") + CardBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex + QLatin1String("; border-radius:15px;"));
    sheet += rule(QLatin1String("QLabel#heroIcon"),
                  QLatin1String("background:") + ControlBackgroundActiveHex + QLatin1String("; border-radius:12px;"));
    sheet += rule(QLatin1String("QLabel#heroTitle"),
                  QLatin1String("font-size:18px; font-weight:750; color:") + TextPrimaryHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#heroSub"),
                  QLatin1String("font-size:11px; color:") + TextSecondaryHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#heroArrow"),
                  QLatin1String("background:") + ControlBackgroundActiveHex
                  + QLatin1String("; border:0; border-radius:12px; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#heroArrow:hover"),
                  QLatin1String("background:") + ControlBackgroundPressedHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#heroArrow:pressed"),
                  QLatin1String("background:") + ControlBackgroundActivePressedHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QToolButton#quickTile"),
                  QLatin1String("background:") + CardBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex
                  + QLatin1String("; border-radius:12px; color:") + TextPrimaryHex
                  + QLatin1String("; font-size:11px; padding:4px;"));
    sheet += rule(QLatin1String("QToolButton#quickTile:disabled"),
                  QLatin1String("background:") + CardBackgroundHex + QLatin1String("; color:") + TextHintHex
                  + QLatin1String("; border-color:") + BorderSoftHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QToolButton#quickTile:pressed"),
                  QLatin1String("background:") + ControlBackgroundActiveHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QFrame#subPageHeader"),
                  QLatin1String("background:") + TopBarBackgroundHex
                  + QLatin1String("; border-bottom:1px solid ") + BorderBaseHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#subPageTitle"),
                  QLatin1String("color:") + TextPrimaryHex + QLatin1String("; font-size:16px; font-weight:750;"));
    sheet += rule(QLatin1String("QLabel#peripheralStatus"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:11px;"));
    sheet += rule(QLatin1String("QToolButton#featureTile"),
                  QLatin1String("background:") + CardBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex
                  + QLatin1String("; border-radius:13px; color:") + TextPrimaryHex
                  + QLatin1String("; font-size:13px; font-weight:650; padding:8px;"));
    sheet += rule(QLatin1String("QToolButton#featureTile:pressed"),
                  QLatin1String("background:") + ControlBackgroundActiveHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QToolButton#featureTile:disabled"),
                  QLatin1String("background:") + CardBackgroundHex + QLatin1String("; color:") + TextHintHex
                  + QLatin1String("; border-color:") + BorderSoftHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#largeAction"),
                  QLatin1String("background:") + CardBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex
                  + QLatin1String("; border-radius:14px; color:") + TextPrimaryHex
                  + QLatin1String("; font-size:14px; font-weight:700; padding:8px;"));
    sheet += rule(QLatin1String("QPushButton#largeAction:pressed"),
                  QLatin1String("background:") + ControlBackgroundActiveHex
                  + QLatin1String("; border:2px solid ") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#hardwareToggle"),
                  QLatin1String("background:") + ControlBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex
                  + QLatin1String("; border-radius:10px; color:") + TextPrimaryHex
                  + QLatin1String("; font-weight:700; padding:5px 12px;"));
    sheet += rule(QLatin1String("QPushButton#hardwareToggle:checked"),
                  QLatin1String("background:") + SuccessBackgroundHex
                  + QLatin1String("; border-color:") + SuccessHex
                  + QLatin1String("; color:") + SuccessTextHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#hardwareToggle:pressed"),
                  QLatin1String("border:2px solid ") + AccentHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QFrame#sensorValueCard"),
                  QLatin1String("background:") + CardBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex + QLatin1String("; border-radius:10px;"));
    sheet += rule(QLatin1String("QLabel#sensorCaption"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:10px;"));
    sheet += rule(QLatin1String("QLabel#sensorValue"),
                  QLatin1String("color:") + TextPrimaryHex + QLatin1String("; font-size:17px; font-weight:750;"));
    sheet += rule(QLatin1String("QWidget#keyboardPanel"),
                  QLatin1String("background:") + SunkenBackgroundHex + QLatin1String("; border:0; border-radius:0;"));
    sheet += rule(QLatin1String("QLabel#cameraView"),
                  QLatin1String("background:") + SunkenBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderBaseHex
                  + QLatin1String("; border-radius:10px; color:") + TextHintHex
                  + QLatin1String("; font-size:12px;"));
    sheet += rule(QLatin1String("QLabel#keyboardSsid"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:12px; font-weight:700;"));
    sheet += rule(QLatin1String("QPushButton#softKey"),
                  QLatin1String("min-height:32px; max-height:50px; padding:0; border:1px solid ") + BorderInputHex
                  + QLatin1String("; border-radius:6px; background:") + ControlBackgroundHex
                  + QLatin1String("; color:") + TextPrimaryHex
                  + QLatin1String("; font-size:15px; font-weight:600;"));
    sheet += rule(QLatin1String("QPushButton#softKey:pressed"),
                  QLatin1String("background:") + ControlBackgroundPressedHex
                  + QLatin1String("; border:1px solid ") + AccentHex
                  + QLatin1String("; color:") + TextBrightHex + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#softKeySpecial"),
                  QLatin1String("min-height:32px; max-height:50px; padding:0 3px; border:1px solid ") + SoftKeyBorderHex
                  + QLatin1String("; border-radius:6px; background:") + SoftKeyBackgroundHex
                  + QLatin1String("; color:") + TextPrimaryHex
                  + QLatin1String("; font-size:13px; font-weight:700;"));
    sheet += rule(QLatin1String("QPushButton#softKeySpecial:pressed"),
                  QLatin1String("background:") + SoftKeyPressedHex
                  + QLatin1String("; border:1px solid ") + TextHintHex
                  + QLatin1String("; color:") + TextBrightHex + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#softKeyDone"),
                  QLatin1String("min-height:32px; max-height:50px; padding:0 3px; border:1px solid ") + DoneKeyBorderHex
                  + QLatin1String("; border-radius:6px; background:") + DoneKeyBackgroundHex
                  + QLatin1String("; color:") + TextBrightHex
                  + QLatin1String("; font-size:13px; font-weight:700;"));
    sheet += rule(QLatin1String("QPushButton#softKeyDone:pressed"),
                  QLatin1String("background:") + DoneKeyPressedHex
                  + QLatin1String("; border:1px solid ") + DoneKeyPressedBorderHex
                  + QLatin1String("; color:") + TextBrightHex + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#softKeySpecial[active=\"true\"]"),
                  QLatin1String("background:") + PrimaryHex + QLatin1String("; color:") + TextBrightHex
                  + QLatin1String("; border-color:") + PrimaryHoverHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#softKeySpecial[active=\"true\"]:pressed"),
                  QLatin1String("background:") + PrimaryPressedHex
                  + QLatin1String("; border:1px solid ") + PrimaryPressedBorderHex
                  + QLatin1String("; padding:0;"));
    sheet += rule(QLatin1String("QPushButton#softKeyMode"),
                  QLatin1String("min-height:32px; max-height:50px; padding:0 3px; border:1px solid ") + PrimaryHoverHex
                  + QLatin1String("; border-radius:6px; background:") + PrimaryHex
                  + QLatin1String("; color:") + TextBrightHex
                  + QLatin1String("; font-size:13px; font-weight:700;"));
    sheet += rule(QLatin1String("QPushButton#softKeyMode:hover"),
                  QLatin1String("background:") + PrimaryHoverHex
                  + QLatin1String("; border-color:") + PrimaryPressedHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#softKeyMode:pressed"),
                  QLatin1String("background:") + PrimaryPressedHex
                  + QLatin1String("; border-color:") + PrimaryPressedBorderHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QPushButton#softKeyMode[active=\"true\"]"),
                  QLatin1String("background:") + PrimaryPressedHex
                  + QLatin1String("; border-color:") + PrimaryPressedBorderHex + QLatin1String(";"));
    sheet += rule(QLatin1String("QLabel#smallNote"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:11px;"));
    sheet += rule(QLatin1String("QFrame#activationCard"),
                  QLatin1String("background:") + CardBackgroundHex
                  + QLatin1String("; border:1px solid ") + BorderHoverHex + QLatin1String("; border-radius:12px;"));
    sheet += rule(QLatin1String("QLabel#activationTitle"),
                  QLatin1String("color:") + TextPrimaryHex + QLatin1String("; font-size:13px; font-weight:750;"));
    sheet += rule(QLatin1String("QLabel#activationCodeCaption"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:10px;"));
    sheet += rule(QLatin1String("QLabel#activationCode"),
                  QLatin1String("background:") + SunkenBackgroundHex + QLatin1String("; color:") + AccentBrightHex
                  + QLatin1String("; border:1px solid ") + BorderHoverHex
                  + QLatin1String("; border-radius:7px; padding:2px 8px; font-size:21px; font-weight:800;"));
    sheet += rule(QLatin1String("QLabel#activationInstructions"),
                  QLatin1String("color:") + TextNoteHex + QLatin1String("; font-size:10px;"));
    sheet += rule(QLatin1String("QLabel#activationMessage"),
                  QLatin1String("color:") + AccentBrightHex + QLatin1String("; font-size:10px; font-weight:650;"));
    sheet += rule(QLatin1String("QLabel#activationQr"),
                  QLatin1String("background:") + QrBackgroundHex
                  + QLatin1String("; border:1px solid ") + QrBorderHex + QLatin1String("; border-radius:4px;"));
    sheet += rule(QLatin1String("QLabel#activationQrCaption"),
                  QLatin1String("color:") + TextSecondaryHex + QLatin1String("; font-size:9px;"));

    return sheet;
}

QString messageStyleSheet(Tone tone)
{
    switch (tone) {
    case Tone::Info:
        return QLatin1String("color:") + AccentHex + QLatin1String(";font-size:11px;");
    case Tone::Warning:
        return QLatin1String("color:") + DangerHex + QLatin1String(";font-size:11px;");
    case Tone::Neutral:
    default:
        return QLatin1String("color:") + TextSecondaryHex + QLatin1String(";font-size:11px;");
    }
}

} // namespace Theme

#undef THEME_DEFINE
