#ifndef XIAOZHIBRIDGE_H
#define XIAOZHIBRIDGE_H

#include <QObject>
#include <QHostAddress>
#include <QProcess>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QByteArray>
#include <QList>
#include <QUrl>

class QTimer;

class XiaozhiBridge : public QObject
{
    Q_OBJECT
public:
    explicit XiaozhiBridge(QObject *parent = nullptr);
    ~XiaozhiBridge() override;

    // Returns whether the request was accepted. The asynchronous DNS/TCP
    // preflight must succeed before a Core process is actually launched.
    bool start(QString *error = nullptr);
    void stop(); // Non-blocking; terminate, then a bounded kill timer.
    void setNetworkAvailable(bool available);
    bool isRunning() const;
    bool isActive() const;
    bool isStopping() const;
    bool networkBlocked() const;
    const QString &executablePath() const;
    static QString networkUnavailableMessage();

signals:
    void statusChanged(const QString &status);
    void activeChanged(bool active);
    void networkUnavailable(const QString &detail);
    void chatTextReceived(const QString &text, const QString &sentenceState);
    void userSpeechTextReceived(const QString &text);
    void toastReceived(const QString &text);
    void activationCodeReceived(const QString &code);
    void coreStateChanged(int state);
    void audioReadyChanged(bool ready);

private slots:
    void readDatagrams();

private:
    bool bindGuiSocket(QString *error);
    bool launchCore(QString *error);
    bool validateExecutable(QString *error) const;
    void scheduleRestart();
    bool loadRuntimeConfig(QString *error);
    void beginNetworkProbe();
    void finishNetworkProbe(bool success, const QString &detail = QString());
    void blockForNetwork(const QString &detail);
    void stopInternal(bool networkBlocked);
    void resetAudioReadiness();
    void readCoreOutput();

    QProcess m_process;
    QUdpSocket m_socket;
    QTcpSocket m_probeSocket;
    QTimer *m_restartTimer;
    QTimer *m_probeTimer;
    QTimer *m_killTimer;
    int m_restartAttempts;
    bool m_wantsRunning;
    bool m_networkAvailable;
    bool m_networkBlocked;
    bool m_probeActive;
    bool m_udpDrainScheduled;
    bool m_audioRecoveryRequested;
    bool m_captureReady;
    bool m_playbackReady;
    QByteArray m_logLineBuffer;
    QString m_executablePath;
    QString m_workingDirectory;
    QHostAddress m_guiBindAddress;
    QList<QHostAddress> m_localAddresses;
    quint16 m_guiPort;
    bool m_ttsDisplayEnabled;
    QUrl m_checkUrl;
};

#endif // XIAOZHIBRIDGE_H
