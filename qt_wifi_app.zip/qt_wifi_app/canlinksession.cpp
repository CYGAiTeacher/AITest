#include "canlinksession.h"

#include <QDebug>
#include <QRegularExpression>
#include <QStringList>

CanLinkSession::CanLinkSession(QObject *parent)
    : QObject(parent), m_state(Idle),
      m_program(QString::fromLocal8Bit(qgetenv("IP_PROGRAM"))),
      m_bitrate(0), m_oldBitrate(0), m_loopback(false), m_oldLoopback(false),
      m_modified(false), m_closing(false), m_commandHandled(true), m_timedOut(false)
{
    if (m_program.isEmpty()) m_program = QStringLiteral("ip");
    m_process.setProcessChannelMode(QProcess::MergedChannels);
    m_timeout.setSingleShot(true);
    m_timeout.setInterval(1500);
    connect(&m_timeout, &QTimer::timeout, this, [this]() {
        m_timedOut = true;
        m_process.kill();
    });
    connect(&m_process, &QProcess::readyReadStandardOutput, this, [this]() {
        m_output += m_process.readAllStandardOutput();
        if (m_output.size() > 32768) m_output = m_output.right(32768);
    });
    connect(&m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this](int code, QProcess::ExitStatus status) {
        m_output += m_process.readAllStandardOutput();
        commandFinished(!m_timedOut && status == QProcess::NormalExit && code == 0,
                        m_timedOut ? QStringLiteral("ip 命令超时") : QString::fromLocal8Bit(m_output).trimmed());
    });
    connect(&m_process, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart)
            commandFinished(false, QStringLiteral("无法启动 iproute2：%1").arg(m_process.errorString()));
    });
}

CanLinkSession::~CanLinkSession()
{
    // UI close() is asynchronous. Final application destruction still performs
    // bounded best-effort cleanup, rather than killing a configuring command
    // and silently leaving the controller in internal-loopback mode.
    m_process.disconnect(this);
    m_timeout.stop();
    if (m_process.state() != QProcess::NotRunning) {
        m_process.kill();
        m_process.waitForFinished(500);
    }
    if (!m_modified) return;
    const QList<QStringList> commands = {
        {QStringLiteral("link"), QStringLiteral("set"), m_interface, QStringLiteral("down")},
        restoreArguments()
    };
    for (const QStringList &arguments : commands) {
        QProcess process;
        process.start(m_program, arguments);
        if (!process.waitForFinished(1500)) {
            process.kill();
            process.waitForFinished(500);
            qWarning() << "CAN cleanup timed out:" << m_interface;
        } else if (process.exitStatus() != QProcess::NormalExit || process.exitCode() != 0) {
            qWarning() << "CAN cleanup failed:" << process.readAllStandardError();
        }
    }
}

bool CanLinkSession::isActive() const { return m_state != Idle; }
bool CanLinkSession::isReady() const { return m_state == Ready; }
const QString &CanLinkSession::interfaceName() const { return m_interface; }
int CanLinkSession::effectiveBitrate() const { return m_bitrate; }

bool CanLinkSession::begin(const QString &interfaceName, int bitrate, bool loopback)
{
    if (isActive() || m_modified || !QRegularExpression(QStringLiteral("^can[0-9]+$")).match(interfaceName).hasMatch() ||
        bitrate < 10000 || bitrate > 1000000)
        return false;
    m_interface = interfaceName;
    m_bitrate = bitrate;
    m_loopback = loopback;
    m_oldBitrate = 0;
    m_oldLoopback = false;
    m_modified = false;
    m_closing = false;
    m_cleanupError.clear();
    command(Inspecting, {QStringLiteral("-details"), QStringLiteral("link"), QStringLiteral("show"),
                         QStringLiteral("dev"), m_interface});
    return true;
}

void CanLinkSession::command(State state, const QStringList &arguments)
{
    m_state = state;
    m_output.clear();
    m_commandHandled = false;
    m_timedOut = false;
    m_timeout.start();
    m_process.start(m_program, arguments);
}

void CanLinkSession::commandFinished(bool success, const QString &detail)
{
    if (m_commandHandled) return;
    m_commandHandled = true;
    m_timeout.stop();
    const State finished = m_state;
    if (finished == Disabling || finished == Restoring) {
        if (!success) {
            if (!m_cleanupError.isEmpty()) m_cleanupError += QLatin1String("；");
            m_cleanupError += QStringLiteral("CAN 恢复失败：%1").arg(detail.left(512));
        }
        if (finished == Disabling)
            command(Restoring, restoreArguments());
        else {
            // Retain modified=true on failure so destruction may retry cleanup.
            if (m_cleanupError.isEmpty()) m_modified = false;
            complete();
        }
        return;
    }
    if (m_closing) { cleanup(); return; }
    if (!success) {
        const QString error = QStringLiteral("CAN 配置失败：%1").arg(detail.left(512));
        m_closing = true;
        emit failed(error);
        cleanup();
        return;
    }
    if (finished == Inspecting) {
        const QString text = QString::fromLocal8Bit(m_output);
        const QRegularExpressionMatch flags = QRegularExpression(QStringLiteral("<([^>]+)>")).match(text);
        if (!flags.hasMatch() || !text.contains(QLatin1String("link/can"))) {
            m_closing = true;
            emit failed(QStringLiteral("无法识别 CAN 接口状态，请安装支持 -details 的 iproute2"));
            cleanup();
            return;
        }
        const bool wasUp = flags.captured(1).split(QLatin1Char(',')).contains(QStringLiteral("UP"));
        const QRegularExpressionMatch bitrate =
            QRegularExpression(QStringLiteral("\\bbitrate\\s+(\\d+)")).match(text);
        m_oldBitrate = bitrate.hasMatch() ? bitrate.captured(1).toInt() : 0;
        // This is the controller mode, not the generic netdevice IFF_LOOPBACK.
        const QRegularExpressionMatch mode =
            QRegularExpression(QStringLiteral("\\bcan\\s+<([^>]+)>")).match(text);
        m_oldLoopback = mode.hasMatch() && mode.captured(1).split(QLatin1Char(',')).contains(QStringLiteral("LOOPBACK"));
        if (wasUp) {
            if (m_loopback || m_oldLoopback) {
                m_closing = true;
                emit failed(QStringLiteral("CAN 接口已启用，不能安全改变控制器回环；请先由原管理程序关闭接口"));
                cleanup();
            } else {
                m_bitrate = m_oldBitrate; // Display actual bitrate, never claim the combo value.
                m_state = Ready;
                emit ready(true);
            }
            return;
        }
        m_modified = true; // Even a partial/failed command requires cleanup.
        command(Configuring, {QStringLiteral("link"), QStringLiteral("set"), m_interface,
                              QStringLiteral("type"), QStringLiteral("can"), QStringLiteral("bitrate"),
                              QString::number(m_bitrate), QStringLiteral("loopback"),
                              m_loopback ? QStringLiteral("on") : QStringLiteral("off")});
    } else if (finished == Configuring) {
        command(Enabling, {QStringLiteral("link"), QStringLiteral("set"), m_interface, QStringLiteral("up")});
    } else if (finished == Enabling) {
        m_state = Ready;
        emit ready(false);
    }
}

QStringList CanLinkSession::restoreArguments() const
{
    QStringList arguments = {QStringLiteral("link"), QStringLiteral("set"), m_interface,
                             QStringLiteral("type"), QStringLiteral("can")};
    if (m_oldBitrate > 0)
        arguments << QStringLiteral("bitrate") << QString::number(m_oldBitrate);
    arguments << QStringLiteral("loopback") << (m_oldLoopback ? QStringLiteral("on") : QStringLiteral("off"));
    return arguments;
}

void CanLinkSession::close()
{
    if (!isActive()) return;
    m_closing = true;
    if (m_state == Ready) cleanup();
    // An in-flight command is allowed to finish (or hit its timeout), then the
    // completion handler restores the interface. Never run ip commands in parallel.
}

void CanLinkSession::cleanup()
{
    if (m_modified)
        command(Disabling, {QStringLiteral("link"), QStringLiteral("set"), m_interface, QStringLiteral("down")});
    else
        complete();
}

void CanLinkSession::complete()
{
    m_state = Idle;
    m_closing = false;
    emit closed(m_cleanupError);
}
