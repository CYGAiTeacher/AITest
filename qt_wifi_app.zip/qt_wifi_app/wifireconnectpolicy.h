#ifndef WIFI_RECONNECT_POLICY_H
#define WIFI_RECONNECT_POLICY_H

#include "wificredentialstore.h"
#include "wifimanager.h"
#include <QElapsedTimer>
#include <QHash>

// UI-independent selection/backoff policy; all deadlines use monotonic time
// so NTP/system-clock corrections cannot break reconnection scheduling.
class WifiReconnectPolicy
{
public:
    WifiReconnectPolicy();
    bool choose(const QList<WifiNetwork> &visible,
                const QList<WifiCredentials> &saved,
                WifiCredentials *credentials,
                int *signalLevel = nullptr) const;
    void failed(const QString &ssid);
    void reset();

private:
    QElapsedTimer m_clock;
    QHash<QString, int> m_failures;
    QHash<QString, qint64> m_retryAfter;
};

#endif // WIFI_RECONNECT_POLICY_H
