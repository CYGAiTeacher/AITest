#include "cameraworker.h"

#include <QDebug>
#include <QThread>
#include <QVector>

#include <cerrno>
#include <cstring>

#include <fcntl.h>
#include <linux/videodev2.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

// ---------------------------------------------------------------------------
// V4L2 采集流程：open → QUERYCAP → S_FMT（YUYV/UYVY）→ REQBUFS(mmap)
// → QBUF ×N → STREAMON → poll + DQBUF 循环 → STREAMOFF → munmap → close
// 转换采用定点整数运算，适合没有 NEON 优化的 i.MX6 场景。
// ---------------------------------------------------------------------------

namespace {

const int kBufferCount = 3;
const int kPollTimeoutMs = 500;

inline unsigned char clampByte(int value)
{
    return static_cast<unsigned char>(value < 0 ? 0 : (value > 255 ? 255 : value));
}

// BT.601 查表法：转换系数预计算一次，每个像素只剩几次查表 + 加法，
// 比逐像素乘加减少约一半运算量（i.MX6 单核上 VGA 全帧约省 30-40% 耗时）。
struct YuvToRgb32Lut {
    short rt[256];        // R 通道 V 分量贡献
    short gu[256];        // G 通道 U 分量贡献
    short gv[256];        // G 通道 V 分量贡献
    short bu[256];        // B 通道 U 分量贡献
    unsigned char clamp[1024]; // 下标 = 值 + 384

    static int divide256Floor(int value)
    {
        // C++11 right shift of a negative signed value is implementation-defined.
        return value >= 0 ? value / 256 : -((-value + 255) / 256);
    }

    YuvToRgb32Lut()
    {
        for (int i = 0; i < 256; ++i) {
            rt[i] = static_cast<short>(divide256Floor(359 * (i - 128)));
            gu[i] = static_cast<short>(divide256Floor(88 * (i - 128)));
            gv[i] = static_cast<short>(divide256Floor(183 * (i - 128)));
            bu[i] = static_cast<short>(divide256Floor(454 * (i - 128)));
        }
        for (int i = 0; i < 1024; ++i) {
            const int v = i - 384;
            clamp[i] = static_cast<unsigned char>(v < 0 ? 0 : (v > 255 ? 255 : v));
        }
    }

    // 目标为 QImage::Format_RGB32（小端内存序 B,G,R,255）
    inline void convert(int y, int u, int v, unsigned char *bgrx) const
    {
        bgrx[2] = clamp[y + rt[v] + 384];              // R
        bgrx[1] = clamp[y - gu[u] - gv[v] + 384];      // G
        bgrx[0] = clamp[y + bu[u] + 384];              // B
        bgrx[3] = 255;
    }
};

const YuvToRgb32Lut &yuvLut()
{
    static const YuvToRgb32Lut lut; // 函数内静态对象：首次使用时初始化，线程内安全
    return lut;
}

} // namespace

CameraWorker::CameraWorker(QObject *parent)
    : QObject(parent),
      m_fd(-1),
      m_width(0),
      m_height(0),
      m_sourceBytesPerLine(0),
      m_pixelFormat(0),
      m_statFrames(0)
{
    const QByteArray deviceEnv = qgetenv("CAMERA_DEVICE");
    m_devicePath = deviceEnv.isEmpty()
                       ? QStringLiteral("/dev/video0")
                       : QString::fromLocal8Bit(deviceEnv);
}

CameraWorker::~CameraWorker()
{
    for (const MmapBuffer &buffer : m_buffers) {
        if (buffer.start && buffer.start != MAP_FAILED)
            ::munmap(buffer.start, buffer.length);
    }
    m_buffers.clear();
    if (m_fd >= 0) {
        ::close(m_fd);
        m_fd = -1;
    }
}

QString CameraWorker::pixelFormatName(unsigned int fourcc)
{
    char text[5] = {static_cast<char>(fourcc & 0xFF),
                    static_cast<char>((fourcc >> 8) & 0xFF),
                    static_cast<char>((fourcc >> 16) & 0xFF),
                    static_cast<char>((fourcc >> 24) & 0xFF),
                    0};
    return QString::fromLatin1(text);
}

void CameraWorker::prepareCapture()
{
    m_framePending.store(false);
    m_stopRequested.store(false);
}

void CameraWorker::acknowledgeFrame()
{
    m_framePending.store(false);
}

void CameraWorker::startCapture()
{
    if (m_stopRequested.load() || QThread::currentThread()->isInterruptionRequested()) {
        closeDevice(QStringLiteral("已停止"), false);
        return;
    }
    if (!openDevice() || !configureFormat())
        return;
    const int fps = negotiateFrameRate(); // Negotiate before STREAMON.
    if (!requestBuffers() || !streamOn()) {
        // 具体原因已由各步骤输出，这里统一走关闭路径
        return;
    }
    m_statFrames = 0;
    m_statElapsed.start();
    emit captureOpened(m_devicePath, m_width, m_height, pixelFormatName(m_pixelFormat), fps);
    captureLoop();
}

void CameraWorker::stopCapture()
{
    m_stopRequested = true;
}

bool CameraWorker::openDevice()
{
    m_fd = ::open(m_devicePath.toLocal8Bit().constData(), O_RDWR | O_NONBLOCK | O_CLOEXEC, 0);
    if (m_fd < 0) {
        closeDevice(QStringLiteral("无法打开摄像头 %1：%2")
                        .arg(m_devicePath, QString::fromLocal8Bit(std::strerror(errno))),
                    true);
        return false;
    }

    struct v4l2_capability cap;
    std::memset(&cap, 0, sizeof(cap));
    if (::ioctl(m_fd, VIDIOC_QUERYCAP, &cap) < 0) {
        closeDevice(QStringLiteral("查询设备能力失败：%1")
                        .arg(QString::fromLocal8Bit(std::strerror(errno))),
                    true);
        return false;
    }
    const unsigned int capabilities = (cap.capabilities & V4L2_CAP_DEVICE_CAPS)
                                          ? cap.device_caps : cap.capabilities;
    if (!(capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
        closeDevice(QStringLiteral("%1 不是视频采集设备").arg(m_devicePath), true);
        return false;
    }
    if (!(capabilities & V4L2_CAP_STREAMING)) {
        closeDevice(QStringLiteral("%1 不支持流媒体（mmap）采集").arg(m_devicePath), true);
        return false;
    }
    return true;
}

bool CameraWorker::configureFormat()
{
    // 优先 YUYV，其次 UYVY；分辨率优先 640x480，退回 320x240，最终以驱动返回值为准
    const unsigned int formats[] = {V4L2_PIX_FMT_YUYV, V4L2_PIX_FMT_UYVY};
    const int sizes[][2] = {{640, 480}, {320, 240}};

    for (unsigned int wantedFormat : formats) {
        for (const auto &size : sizes) {
            struct v4l2_format fmt;
            std::memset(&fmt, 0, sizeof(fmt));
            fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            fmt.fmt.pix.width = static_cast<unsigned int>(size[0]);
            fmt.fmt.pix.height = static_cast<unsigned int>(size[1]);
            fmt.fmt.pix.pixelformat = wantedFormat;
            fmt.fmt.pix.field = V4L2_FIELD_ANY;
            if (::ioctl(m_fd, VIDIOC_S_FMT, &fmt) < 0)
                continue;
            if (fmt.fmt.pix.pixelformat != wantedFormat)
                continue; // 驱动给了别的格式，继续尝试

            const quint64 width = fmt.fmt.pix.width;
            const quint64 height = fmt.fmt.pix.height;
            const quint64 stride = qMax<quint64>(fmt.fmt.pix.bytesperline, width * 2);
            if (!width || (width & 1) || !height || width > 4096 || height > 4096 ||
                stride * height > 32ULL * 1024 * 1024) {
                closeDevice(QStringLiteral("驱动返回的分辨率/行跨度无效或过大"), true);
                return false;
            }
            m_sourceBytesPerLine = static_cast<int>(stride);
            m_width = static_cast<int>(fmt.fmt.pix.width);
            m_height = static_cast<int>(fmt.fmt.pix.height);
            m_pixelFormat = wantedFormat;
            return true;
        }
    }

    closeDevice(QStringLiteral("设置像素格式失败：摄像头不提供 YUYV/UYVY 输出"
                               "（仅 MJPEG 的设备暂不支持）"),
                true);
    return false;
}

int CameraWorker::negotiateFrameRate()
{
    // 主动请求 30 fps：部分驱动（尤其 UVC 摄像头）默认只有 10/15 fps，
    // 不设置会感觉画面明显卡顿。不支持的驱动静默忽略，返回当前值。
    struct v4l2_streamparm parm;
    std::memset(&parm, 0, sizeof(parm));
    parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (::ioctl(m_fd, VIDIOC_G_PARM, &parm) < 0)
        return 0;
    if (!(parm.parm.capture.capability & V4L2_CAP_TIMEPERFRAME)) {
        struct v4l2_fract t = parm.parm.capture.timeperframe;
        return (t.denominator > 0 && t.numerator > 0)
                   ? static_cast<int>(t.denominator / t.numerator)
                   : 0;
    }
    parm.parm.capture.timeperframe.numerator = 1;
    parm.parm.capture.timeperframe.denominator = 30;
    if (::ioctl(m_fd, VIDIOC_S_PARM, &parm) < 0)
        return 0;
    if (::ioctl(m_fd, VIDIOC_G_PARM, &parm) < 0)
        return 0;
    const struct v4l2_fract t = parm.parm.capture.timeperframe;
    return (t.denominator > 0 && t.numerator > 0)
               ? static_cast<int>(t.denominator / t.numerator)
               : 0;
}

bool CameraWorker::requestBuffers()
{
    struct v4l2_requestbuffers req;
    std::memset(&req, 0, sizeof(req));
    req.count = kBufferCount;
    req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    req.memory = V4L2_MEMORY_MMAP;
    if (::ioctl(m_fd, VIDIOC_REQBUFS, &req) < 0 || req.count == 0 || req.count > 32) {
        closeDevice(QStringLiteral("申请帧缓冲失败：%1")
                        .arg(QString::fromLocal8Bit(std::strerror(errno))),
                    true);
        return false;
    }

    m_buffers.fill(MmapBuffer{nullptr, 0}, static_cast<int>(req.count));
    for (unsigned int i = 0; i < req.count; ++i) {
        struct v4l2_buffer buf;
        std::memset(&buf, 0, sizeof(buf));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;
        buf.index = i;
        if (::ioctl(m_fd, VIDIOC_QUERYBUF, &buf) < 0) {
            closeDevice(QStringLiteral("查询帧缓冲失败：%1")
                            .arg(QString::fromLocal8Bit(std::strerror(errno))),
                        true);
            return false;
        }
        const quint64 needed = static_cast<quint64>(m_height - 1) * m_sourceBytesPerLine + m_width * 2;
        if (buf.length < needed || buf.length > 32U * 1024 * 1024) {
            closeDevice(QStringLiteral("驱动返回的帧缓冲长度无效"), true);
            return false;
        }
        void *start = ::mmap(nullptr, buf.length, PROT_READ | PROT_WRITE,
                             MAP_SHARED, m_fd, buf.m.offset);
        if (start == MAP_FAILED) {
            closeDevice(QStringLiteral("映射帧缓冲失败：%1")
                            .arg(QString::fromLocal8Bit(std::strerror(errno))),
                        true);
            return false;
        }
        m_buffers[static_cast<int>(i)] = MmapBuffer{start, buf.length};
    }
    return true;
}

bool CameraWorker::streamOn()
{
    if (m_stopRequested.load()) {
        closeDevice(QStringLiteral("已停止"), false);
        return false;
    }
    m_frameImage = QImage(m_width, m_height, QImage::Format_RGB32);
    if (m_frameImage.isNull()) {
        closeDevice(QStringLiteral("无法分配摄像头图像内存"), true);
        return false;
    }
    for (int i = 0; i < m_buffers.size(); ++i) {
        struct v4l2_buffer buf;
        std::memset(&buf, 0, sizeof(buf));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;
        buf.index = static_cast<unsigned int>(i);
        if (::ioctl(m_fd, VIDIOC_QBUF, &buf) < 0) {
            closeDevice(QStringLiteral("帧缓冲入队失败：%1")
                            .arg(QString::fromLocal8Bit(std::strerror(errno))),
                        true);
            return false;
        }
    }

    enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (::ioctl(m_fd, VIDIOC_STREAMON, &type) < 0) {
        closeDevice(QStringLiteral("启动视频流失败：%1")
                        .arg(QString::fromLocal8Bit(std::strerror(errno))),
                    true);
        return false;
    }

    return true;
}

void CameraWorker::captureLoop()
{
    while (!m_stopRequested.load() && !QThread::currentThread()->isInterruptionRequested()) {
        struct pollfd pfd;
        pfd.fd = m_fd;
        pfd.events = POLLIN;
        pfd.revents = 0;
        const int pollResult = ::poll(&pfd, 1, kPollTimeoutMs);
        if (pollResult < 0) {
            if (errno == EINTR)
                continue;
            closeDevice(QStringLiteral("等待帧数据失败：%1")
                            .arg(QString::fromLocal8Bit(std::strerror(errno))),
                        true);
            return;
        }
        if (pollResult == 0)
            continue; // 超时仅用于检查停止标志
        if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) {
            closeDevice(QStringLiteral("摄像头已断开或报告 I/O 错误"), true);
            return;
        }
        if (!(pfd.revents & POLLIN))
            continue;

        struct v4l2_buffer buf;
        std::memset(&buf, 0, sizeof(buf));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;
        if (::ioctl(m_fd, VIDIOC_DQBUF, &buf) < 0) {
            if (errno == EAGAIN || errno == EINTR)
                continue;
            closeDevice(QStringLiteral("取出帧失败：%1")
                            .arg(QString::fromLocal8Bit(std::strerror(errno))),
                        true);
            return;
        }

        if (buf.index >= static_cast<unsigned int>(m_buffers.size()) ||
            buf.bytesused > m_buffers.at(static_cast<int>(buf.index)).length) {
            closeDevice(QStringLiteral("摄像头帧索引/长度超出 mmap 缓冲区"), true);
            return;
        }
        if (!(buf.flags & V4L2_BUF_FLAG_ERROR) && !m_stopRequested.load())
            convertFrame(static_cast<const unsigned char *>(m_buffers.at(static_cast<int>(buf.index)).start),
                         buf.bytesused);

        if (::ioctl(m_fd, VIDIOC_QBUF, &buf) < 0) {
            closeDevice(QStringLiteral("帧缓冲重新入队失败：%1")
                            .arg(QString::fromLocal8Bit(std::strerror(errno))),
                        true);
            return;
        }

        ++m_statFrames;
        const qint64 elapsed = m_statElapsed.elapsed();
        if (elapsed >= 1000) {
            emit frameStats(static_cast<int>((m_statFrames * 1000LL) / elapsed));
            m_statFrames = 0;
            m_statElapsed.restart();
        }
    }

    closeDevice(QStringLiteral("已停止"), false);
}

void CameraWorker::convertFrame(const unsigned char *data, unsigned int bytesUsed)
{
    const quint64 expected = m_height > 0
        ? static_cast<quint64>(m_height - 1) * m_sourceBytesPerLine + m_width * 2 : 0;
    if (!data || m_frameImage.isNull() || m_width <= 0 || (m_width & 1) || m_height <= 0 ||
        m_sourceBytesPerLine < m_width * 2 || bytesUsed < expected || m_framePending.load())
        return; // Drop incomplete/late frames, never call a bad frame a successful self-test.
    m_frameImage.detach();
    unsigned char *dst = m_frameImage.bits();
    const int stride = m_frameImage.bytesPerLine();

    const YuvToRgb32Lut &lut = yuvLut();
    for (int y = 0; y < m_height; ++y) {
        const unsigned char *src = data + y * m_sourceBytesPerLine;
        unsigned char *row = dst + y * stride;
        if (m_pixelFormat == V4L2_PIX_FMT_YUYV) {
            for (int x = 0; x < m_width; x += 2) {
                lut.convert(src[0], src[1], src[3], row);
                lut.convert(src[2], src[1], src[3], row + 4);
                src += 4;
                row += 8;
            }
        } else { // UYVY
            for (int x = 0; x < m_width; x += 2) {
                lut.convert(src[1], src[0], src[2], row);
                lut.convert(src[3], src[0], src[2], row + 4);
                src += 4;
                row += 8;
            }
        }
    }
    if (!m_stopRequested.load() && !m_framePending.exchange(true))
        emit frameReady(m_frameImage);
}

void CameraWorker::closeDevice(const QString &reason, bool failed)
{
    if (m_fd >= 0) {
        enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        ::ioctl(m_fd, VIDIOC_STREAMOFF, &type); // 忽略返回值：可能本来就没开流
        ::close(m_fd);
        m_fd = -1;
    }
    for (const MmapBuffer &buffer : m_buffers) {
        if (buffer.start && buffer.start != MAP_FAILED)
            ::munmap(buffer.start, buffer.length);
    }
    m_buffers.clear();
    m_frameImage = QImage();

    if (failed)
        emit captureFailed(reason);
    else
        emit captureClosed(reason);
}
