#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QElapsedTimer>
#include <QImage>
#include <QList>
#include <QProcess>
#include <QThread>
#include <QTemporaryDir>
#include <termios.h>
#include <QWidget>

#include "wificredentialstore.h"
#include "wifimanager.h"
#include "wifireconnectpolicy.h"

#include "uiicons.h"

#include <QPointer>
#include <QSize>
#include <QVector>

class QAbstractButton;
class CameraWorker;
class CanLinkSession;
class LoadChart;
class FeatureTilePager;
class ModbusWorker;
class NtpSynchronizer;
class QComboBox;
class QEvent;
class QGridLayout;
class QLabel;
class QLineEdit;
class QListWidget;
class QPlainTextEdit;
class QPushButton;
class QSocketNotifier;
class QStackedWidget;
class QTimer;
class XiaozhiBridge;
class SensorChart;

// 传感器数值读取工作线程对象：
// DS18B20 等 1-wire 器件的 w1_slave 读取会同步等待一次温度转换（最长约 750ms），
// 所有 sysfs 读文件统一移到此线程执行，UI 线程只收结果，避免界面卡顿。
class SensorPollWorker : public QObject
{
    Q_OBJECT

public slots:
    void pollNow(quint64 generation, const QStringList &paths);

signals:
    void polled(quint64 generation, const QByteArrayList &values);
};

class MainWindow : public QWidget
{
    Q_OBJECT
public:
    explicit MainWindow(const QString &interfaceName,
                        const QString &controlDirectory,
                        QWidget *parent = nullptr);
    ~MainWindow() override;

signals:
    void scanRequested(bool forReconnect);
    void forgetWifiNetworksRequested();
    void connectRequested(quint64 requestId,
                          const QString &ssid,
                          const QString &password,
                          bool secured);
    void statusRequested();
    void timeSyncRequested();
    void modbusStartRequested();
    void modbusStopRequested();
    void modbusLedRequested(bool enabled);
    void modbusBuzzerRequested(bool enabled);

private slots:
    void startScan();
    void onScanFinished(const QList<WifiNetwork> &networks, const QString &error);
    void onConnectFinished(quint64 requestId,
                           bool success,
                           const QString &ssid,
                           const QString &ipAddress,
                           WifiFailureReason reason,
                           const QString &message);
    void onStatusChanged(bool connected, const QString &ssid, const QString &ipAddress);
    void onStatusCheckFailed(const QString &message);
    void onTimeSyncFinished(bool success,
                            qint64 utcMilliseconds,
                            bool systemClockSet,
                            bool rtcWritten,
                            const QString &message);
    void updateClock();
    void updateSelection();
    void onConnectClicked();
    void onWifiScanConnectClicked();
    void onPasswordBackClicked();
    void openWifiSettings();
    void leaveWifiPage();
    void onRecordProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);
    void onPlaybackProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    QWidget *createHomePage();
    QWidget *createWifiPage();
    QWidget *createWifiScanPage();
    QWidget *createPasswordEntryPage();
    QWidget *createPasswordKeyboard(QWidget *parent);
    QWidget *createPeripheralPage();
    QWidget *createPeripheralHubPage();
    QWidget *createAudioTestPage();
    QWidget *createXiaozhiPage();
    QWidget *createRs485Page();
    QWidget *createCameraTestPage();
    QWidget *createSensorPage();
    QWidget *createCanTestPage();
    QWidget *createSelfTestPage();
    QWidget *createThemePage();
    void openThemePage();
    void applyThemeIndex(int index);
    void refreshThemeRows();
    void handleFactoryResetRequested();
    void disarmFactoryReset();
    // 图标主题登记：切换主题时对全部登记图标重新按角色取色
    void registerThemedIcon(QAbstractButton *button, UiIcon::Type type, IconTint tint);
    void registerThemedIcon(QLabel *label, UiIcon::Type type, IconTint tint,
                            const QSize &pixmapSize);
    void refreshThemedIcons();
    void showPasswordKeyboard();
    void hidePasswordKeyboard();
    void updateKeyboardLabels();
    void insertPasswordText(const QString &text);
    void backspacePassword();
    void requestWifiStatus();
    void scheduleAutoReconnect(int delayMs = 5000);
    void tryAutoReconnect();
    void beginWifiConnection(const WifiCredentials &credentials, bool automatic);
    bool savedCredentialsFor(const QString &ssid, bool secured, WifiCredentials *credentials = nullptr) const;
    bool forgetCredentialsFor(const QString &ssid, QString *error);
    void refreshSavedNetworkMarkers();
    void setBusy(bool busy);
    void setWifiStatus(bool connected, const QString &ssid);
    void setWifiConnecting();
    void startInternetTimeSync();
    void showHomeMessage(const QString &text, bool warning = false);
    bool selectedNetwork(QString *ssid, bool *secured, bool *supported) const;

    void openPeripheralHub();
    void openAudioTestPage();
    void openXiaozhiPage();
    void requestXiaozhiStart();
    void openRs485Page();
    void openCameraTestPage();
    void openSensorPage();
    void refreshSensorList();
    void updateSensorValues();
    void onSensorPolled(quint64 generation, const QByteArrayList &values);
    void openCanTestPage();
    void toggleCanLink();
    void attachCanSocket();
    void startSelfTestCanSocket(quint64 generation);
    void sendCanFrame();
    void readCanFrames();
    void closeCanLink();
    void appendCanLog(const QString &line);
    void scanCanInterfaces();
    void sampleSystemLoad();
    void openSelfTestPage();
    void startSelfTest();
    void cancelSelfTest();
    void runSelfTestItem();
    void finishSelfTestItem(bool passed, const QString &detail);
    void cleanupSelfTestItem();
    void setSelfTestRowState(int row, int state, const QString &detail);
    void startCameraPreview();
    void stopCameraPreview();
    void onCameraFrame(const QImage &image);
    void onCameraOpened(const QString &device, int width, int height,
                        const QString &formatName, int fps);
    void onCameraClosed();
    void onCameraFailed(const QString &error);
    void onCameraStats(int framesPerSecond);
    void updateCameraControls();
    void returnToHome();
    void returnToPeripheralHub();
    void startRecording();
    void stopRecording(bool playWhenFinished);
    void playAudioFile(const QString &path, const QString &purpose);
    void stopAudioProcesses();
    void updateAudioControls();
    void onXiaozhiTextReceived(const QString &text, const QString &sentenceState);
    void addChatBubble(const QString &text, bool assistant, bool systemMessage = false);
    void resetXiaozhiSessionUi(const QString &status);
    void updateXiaozhiActivationView();

    QStackedWidget *m_stack;
    QWidget *m_homePage;
    QWidget *m_wifiPage;
    QWidget *m_peripheralPage;
    QStackedWidget *m_peripheralPageStack;
    QWidget *m_peripheralHubPage;
    QWidget *m_audioTestPage;
    QWidget *m_xiaozhiPage;
    QWidget *m_rs485Page;
    QWidget *m_cameraTestPage;
    QWidget *m_sensorPage;
    QStackedWidget *m_wifiPageStack;
    QWidget *m_scanPage;
    QWidget *m_passwordPage;
    QWidget *m_wifiHeader;
    QWidget *m_actionBar;
    QWidget *m_passwordActionBar;
    QWidget *m_passwordFooterSpacer;
    QWidget *m_keyboardPanel;
    QLabel *m_keyboardSsid;
    QPushButton *m_shiftButton;
    QPushButton *m_modeButton;
    QPushButton *m_backspaceButton;
    QPushButton *m_doneButton;
    QList<QPushButton *> m_alphaButtons;
    bool m_keyboardVisible;
    int m_keyboardMode;
    bool m_capsLock;

    QLabel *m_clockDate;
    QLabel *m_clockTime;
    QPushButton *m_wifiStatusButton;
    QLabel *m_wifiTopStatus;
    QLabel *m_wifiTopIp;
    QLabel *m_homeMessage;

    QPushButton *m_scanButton;
    QListWidget *m_networkList;
    QLabel *m_scanInfo;
    QLabel *m_passwordLabel;
    QLineEdit *m_passwordEdit;
    QPushButton *m_passwordToggle;
    QPushButton *m_keyboardButton;
    QLabel *m_wifiMessage;
    QLabel *m_passwordMessage;
    QPushButton *m_skipButton;
    QPushButton *m_connectButton;
    QPushButton *m_passwordBackButton;
    QPushButton *m_passwordConnectButton;

    QLabel *m_audioStatus;
    QPushButton *m_recordButton;
    QPushButton *m_musicButton;
    QLabel *m_xiaozhiStatus;
    QPushButton *m_xiaozhiToggleButton;
    QWidget *m_xiaozhiActivationPanel;
    QLabel *m_xiaozhiActivationTitleLabel;
    QLabel *m_xiaozhiActivationCodeCaption;
    QLabel *m_xiaozhiActivationCodeLabel;
    QLabel *m_xiaozhiActivationInstructionsLabel;
    QLabel *m_xiaozhiActivationMessage;
    QString m_xiaozhiActivationCode;
    bool m_xiaozhiActivated;
    bool m_xiaozhiAudioReady;
    bool m_xiaozhiOnline;
    bool m_xiaozhiManualRestartHint;
    QListWidget *m_chatList;
    QString m_streamingAssistantText;
    int m_streamingAssistantRow;
    QLabel *m_rs485Status;
    QLabel *m_temperatureValue;
    QLabel *m_humidityValue;
    QPushButton *m_rs485RetryButton;
    QPushButton *m_ledButton;
    QPushButton *m_buzzerButton;
    SensorChart *m_sensorChart;
    QLabel *m_cameraView;
    QLabel *m_cameraStatus;
    QPushButton *m_cameraToggleButton;
    QLabel *m_cameraInfo;
    CameraWorker *m_cameraWorker;
    QThread m_cameraThread;
    bool m_cameraRunning;
    bool m_cameraStartPending;
    bool m_cameraStopPending;
    // 传感器页：动态扫描 sysfs（thermal/hwmon/iio）后一行一个数值卡
    struct SensorEntry {
        QLabel *valueLabel;
        QString valuePath;  // 数值 sysfs 节点
        double offset = 0.0;
        double scale;       // 扫描时读取的 IIO *_scale（其余为 1.0）
        double divisor;     // 单位换算除数（如 m°C→°C 为 1000）
        QString unit;
        int decimals;
        int sourceType;     // 0=纯数值节点；1=DS18B20 w1_slave 两段文本（取 t= 字段）
    };
    QList<SensorEntry> m_sensorEntries;
    QLabel *m_sensorStatus;
    QGridLayout *m_sensorGrid;
    QWidget *m_sensorGridHost;
    QTimer *m_sensorTimer;
    SensorPollWorker *m_sensorPollWorker;
    QThread m_sensorPollThread;
    quint64 m_sensorPollGeneration;
    bool m_sensorPollBusy;
    quint64 m_sensorInFlightGeneration;
    // CAN 总线测试页（SocketCAN）
    QWidget *m_canTestPage;
    QComboBox *m_canIfCombo;
    QComboBox *m_canBitrateCombo;
    QPushButton *m_canToggleButton;
    QLineEdit *m_canIdEdit;
    QLineEdit *m_canDataEdit;
    QPushButton *m_canSendButton;
    QPlainTextEdit *m_canLogView;
    QLabel *m_canStatusLabel;
    int m_canFd;
    QSocketNotifier *m_canNotifier;
    CanLinkSession *m_canSession;
    CanLinkSession *m_selfTestCanSession;
    // 主页 CPU/内存曲线
    LoadChart *m_loadChart;
    FeatureTilePager *m_hubPager; // 枢纽页分页器（类型无 Q_OBJECT，存成员而非 findChild）
    QTimer *m_loadTimer;
    quint64 m_prevCpuTotal;
    quint64 m_prevCpuIdle;
    // 一键测试页（顺序执行，单项超时防卡死）
    QWidget *m_selfTestPage;
    QPushButton *m_selfTestButton;
    QLabel *m_selfTestSummary;
    struct SelfTestRow {
        QLabel *status;
        QLabel *detail;
    };
    QVector<SelfTestRow> m_selfTestRows;
    int m_selfTestIndex;
    int m_selfTestPassed;
    bool m_selfTestRunning;
    quint64 m_selfTestGeneration;
    bool m_selfTestItemDone;
    QString m_selfTestCamInfo;
    QTimer *m_selfTestTimeout;
    CameraWorker *m_selfTestCamera;
    QThread m_selfTestCameraThread;
    QProcess *m_selfTestAudio;
    QMetaObject::Connection m_selfTestCanReadyConnection;
    QMetaObject::Connection m_selfTestCanFailureConnection;
    int m_selfTestSerialFd;
    QSocketNotifier *m_selfTestSerialNotifier;
    bool m_selfTestSerialEcho;
    bool m_selfTestSerialTermiosSaved;
    struct termios m_selfTestOriginalTermios;
    QString m_selfTestSerialInfo;
    int m_selfTestCanFd;
    QSocketNotifier *m_selfTestCanNotifier;
    QString m_selfTestCanIf;
    QString m_selfTestAudioPath;
    // 主题切换页 + 图标登记表
    QWidget *m_themePage;
    QLabel *m_themeCurrentLabel;
    QVector<class ThemeRowButton *> m_themeRows;
    QPushButton *m_factoryResetButton;
    QLabel *m_factoryResetStatus;
    QTimer *m_factoryResetTimer;
    bool m_factoryResetArmed;
    struct ThemedIconEntry {
        QPointer<QWidget> widget;
        UiIcon::Type type;
        IconTint tint;
        QSize pixmapSize; // 有效尺寸 → QLabel::setPixmap；无效 → QAbstractButton::setIcon
    };
    QVector<ThemedIconEntry> m_themedIconRegistry;

    QTemporaryDir m_audioTempDirectory;
    QTimer *m_recordKillTimer;
    QTimer *m_playKillTimer;
    bool m_recordStopRequested;
    bool m_recordForceKilled;
    QProcess *m_recordProcess;
    QProcess *m_playProcess;
    XiaozhiBridge *m_xiaozhiBridge;
    ModbusWorker *m_modbusWorker;
    QThread m_modbusThread;
    QString m_musicFilePath;
    QString m_recordingPath;
    QString m_captureDevice;
    QString m_playbackDevice;
    QString m_arecordProgram;
    QString m_aplayProgram;
    QString m_playPurpose;
    int m_audioSampleRate;
    bool m_autoPlayAfterRecord;
    bool m_playStopRequested;

    QThread m_workerThread;
    WifiWorker *m_worker;
    QThread m_ntpThread;
    NtpSynchronizer *m_ntpWorker;
    QTimer *m_clockTimer;
    QTimer *m_statusTimer;
    QTimer *m_reconnectTimer;
    QTimer *m_timeSyncRetryTimer;
    QTimer *m_connectionAnimationTimer;
    QTimer *m_xiaozhiReadyHintTimer;
    int m_connectionAnimationFrame;
    WifiCredentialStore m_credentialStore;
    WifiCredentials m_pendingCredentials;
    QList<WifiCredentials> m_savedNetworks;
    WifiReconnectPolicy m_reconnectPolicy;
    quint64 m_connectionRequestId;
    QString m_connectedSsid;
    QString m_interfaceName;
    QString m_controlDirectory;
    QString m_ipAddress;
    QElapsedTimer m_beijingClockElapsed;
    qint64 m_beijingUtcMilliseconds;
    bool m_timeSyncInProgress;
    bool m_timeSynchronized;
    bool m_setupComplete;
    bool m_hasCredentials;
    bool m_savePendingCredentials;
    bool m_autoConnection;
    bool m_wifiConnected;
    bool m_statusBusy;
    bool m_backgroundScan;
    bool m_autoReconnectSuspended;
    bool m_scanBusy;
    bool m_connectionBusy;
    bool m_showPassword;
};

#endif // MAINWINDOW_H
