#include "xiaozhibridge.h"

#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkInterface>
#include <QStringList>
#include <QTimer>

XiaozhiBridge::XiaozhiBridge(QObject *parent)
    : QObject(parent),
      m_socket(this),
      m_probeSocket(this),
      m_restartTimer(new QTimer(this)),
      m_probeTimer(new QTimer(this)),
      m_killTimer(new QTimer(this)),
      m_restartAttempts(0),
      m_wantsRunning(false),
      m_networkAvailable(false),
      m_networkBlocked(false),
      m_probeActive(false),
      m_udpDrainScheduled(false),
      m_audioRecoveryRequested(false),
      m_captureReady(false),
      m_playbackReady(false),
      m_executablePath(QString::fromLocal8Bit(qgetenv("XIAOZHI_EXECUTABLE"))),
      m_workingDirectory(QString::fromLocal8Bit(qgetenv("XIAOZHI_WORKDIR"))),
      m_guiBindAddress(QHostAddress::LocalHost),
      m_guiPort(5679),
      m_ttsDisplayEnabled(true)
{
    if (m_executablePath.isEmpty())
        m_executablePath = QStringLiteral("/xiaozhi_linux_rs-armv7-gnueabihf");
    m_executablePath = QFileInfo(m_executablePath).absoluteFilePath();
    if (m_workingDirectory.isEmpty())
        m_workingDirectory = QFileInfo(m_executablePath).absolutePath();
    m_workingDirectory = QDir(m_workingDirectory).absolutePath();
    m_restartTimer->setSingleShot(true);
    m_probeTimer->setSingleShot(true);
    m_killTimer->setSingleShot(true);
    m_killTimer->setInterval(1500);

    connect(m_restartTimer, &QTimer::timeout, this, [this]() {
        if (m_wantsRunning && m_process.state() == QProcess::NotRunning)
            beginNetworkProbe(); // Every automatic restart also checks the network.
    });
    connect(m_probeTimer, &QTimer::timeout, this, [this]() {
        finishNetworkProbe(false, QStringLiteral("小智服务 DNS/TCP 连接检查超时"));
    });
    connect(&m_probeSocket, &QTcpSocket::connected, this, [this]() { finishNetworkProbe(true); });
    connect(&m_probeSocket,
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
            &QAbstractSocket::errorOccurred,
#else
            QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),
#endif
            this, [this](QAbstractSocket::SocketError) {
        finishNetworkProbe(false, m_probeSocket.errorString());
    });
    connect(m_killTimer, &QTimer::timeout, this, [this]() {
        if (m_process.state() != QProcess::NotRunning &&
            (!m_wantsRunning || m_audioRecoveryRequested))
            m_process.kill();
    });
    connect(&m_socket, &QUdpSocket::readyRead, this, &XiaozhiBridge::readDatagrams);
    connect(&m_process, &QProcess::started, this, [this]() {
        if (!m_wantsRunning) {
            m_process.terminate();
            m_killTimer->start();
            return;
        }
        emit statusChanged(QStringLiteral("小智核心已启动，正在检查激活与云端连接"));
        emit activeChanged(true);
    });
    connect(&m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this](int exitCode, QProcess::ExitStatus exitStatus) {
        m_killTimer->stop();
        resetAudioReadiness();
        m_audioRecoveryRequested = false;
        if (!m_wantsRunning) {
            m_socket.close();
            emit statusChanged(m_networkBlocked ? networkUnavailableMessage() : QStringLiteral("小智已停止"));
        } else {
            emit statusChanged(exitStatus == QProcess::CrashExit
                ? QStringLiteral("小智核心异常退出（代码 %1）").arg(exitCode)
                : QStringLiteral("小智核心已退出（代码 %1）").arg(exitCode));
            scheduleRestart();
        }
        emit activeChanged(isActive());
    });
    connect(&m_process, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
        if (error != QProcess::FailedToStart)
            return;
        resetAudioReadiness();
        if (m_wantsRunning) {
            emit statusChanged(QStringLiteral("无法启动小智核心：请检查 ABI、工作目录和执行权限"));
            scheduleRestart();
        }
        emit activeChanged(isActive());
    });
    connect(&m_process, &QProcess::readyReadStandardOutput, this, &XiaozhiBridge::readCoreOutput);
}

XiaozhiBridge::~XiaozhiBridge()
{
    // Only final destruction waits; normal page navigation must stay responsive.
    m_process.disconnect(this);
    m_socket.disconnect(this);
    m_probeSocket.disconnect(this);
    m_restartTimer->stop();
    m_probeTimer->stop();
    m_killTimer->stop();
    m_wantsRunning = false;
    m_probeActive = false;
    m_probeSocket.abort();
    if (m_process.state() != QProcess::NotRunning) {
        m_process.terminate();
        if (!m_process.waitForFinished(1200)) {
            m_process.kill();
            m_process.waitForFinished(1000);
        }
    }
    m_socket.close();
}

QString XiaozhiBridge::networkUnavailableMessage()
{
    return QStringLiteral("网络不可用，请正确连接wifi后再次尝试。");
}

const QString &XiaozhiBridge::executablePath() const { return m_executablePath; }
bool XiaozhiBridge::isRunning() const { return m_process.state() != QProcess::NotRunning; }
bool XiaozhiBridge::isActive() const { return m_wantsRunning || isRunning() || m_probeActive || m_restartTimer->isActive(); }
bool XiaozhiBridge::isStopping() const { return isRunning() && !m_wantsRunning; }
bool XiaozhiBridge::networkBlocked() const { return m_networkBlocked; }

void XiaozhiBridge::setNetworkAvailable(bool available)
{
    m_networkAvailable = available;
    if (!available && isActive())
        blockForNetwork(QStringLiteral("Wi-Fi 已断开或尚未取得可用 IP"));
}

bool XiaozhiBridge::bindGuiSocket(QString *error)
{
    if (m_socket.state() == QAbstractSocket::BoundState)
        return true;
    if (!m_socket.bind(m_guiBindAddress, m_guiPort)) {
        if (error)
            *error = QStringLiteral("无法监听小智 GUI UDP 端口 %1：%2").arg(m_guiPort).arg(m_socket.errorString());
        return false;
    }
    m_localAddresses = QNetworkInterface::allAddresses();
    return true;
}

bool XiaozhiBridge::loadRuntimeConfig(QString *error)
{
    const QString configuredPath = QString::fromLocal8Bit(qgetenv("XIAOZHI_CONFIG_PATH"));
    const bool explicitWorkdir = !qgetenv("XIAOZHI_WORKDIR").isEmpty();
    QStringList candidates;
    if (!configuredPath.isEmpty()) {
        const QFileInfo config(configuredPath);
        if (config.fileName() != QLatin1String("xiaozhi_config.json") ||
            (explicitWorkdir && config.absolutePath() != QDir(m_workingDirectory).absolutePath())) {
            if (error)
                *error = QStringLiteral("小智 Core 从工作目录读取 xiaozhi_config.json，请统一 XIAOZHI_CONFIG_PATH 与 XIAOZHI_WORKDIR");
            return false;
        }
        candidates << config.absoluteFilePath();
    } else if (explicitWorkdir) {
        candidates << QDir(m_workingDirectory).filePath(QStringLiteral("xiaozhi_config.json"));
    } else {
        candidates << QDir(m_workingDirectory).filePath(QStringLiteral("xiaozhi_config.json"))
                   << QDir::current().filePath(QStringLiteral("xiaozhi_config.json"))
                   << QStringLiteral("/xiaozhi_config.json");
    }
    candidates.removeDuplicates();
    m_guiBindAddress = QHostAddress::LocalHost;
    m_guiPort = 5679;
    m_ttsDisplayEnabled = true;
    QString serviceUrl = QStringLiteral("wss://api.tenclass.net/xiaozhi/v1/");
    for (const QString &path : candidates) {
        QFile file(path);
        if (!file.exists() && configuredPath.isEmpty())
            continue;
        if (!file.open(QIODevice::ReadOnly)) {
            if (error)
                *error = QStringLiteral("无法读取小智配置：%1").arg(path);
            return false;
        }
        QJsonParseError parseError;
        const QByteArray bytes = file.read(1024 * 1024 + 1);
        const QJsonDocument doc = QJsonDocument::fromJson(bytes, &parseError);
        if (bytes.size() > 1024 * 1024 || parseError.error != QJsonParseError::NoError || !doc.isObject()) {
            if (error)
                *error = QStringLiteral("小智配置不是有效 JSON 对象或超过 1 MiB：%1").arg(path);
            return false;
        }
        const QJsonObject object = doc.object();
        if (object.contains(QStringLiteral("gui_remote_port"))) {
            const int port = object.value(QStringLiteral("gui_remote_port")).toInt();
            if (port < 1 || port > 65535) {
                if (error) *error = QStringLiteral("小智 gui_remote_port 必须为 1–65535");
                return false;
            }
            m_guiPort = static_cast<quint16>(port);
        }
        const QString ip = object.value(QStringLiteral("gui_remote_ip")).toString();
        if (!ip.isEmpty() && !m_guiBindAddress.setAddress(ip)) {
            if (error) *error = QStringLiteral("小智 gui_remote_ip 不是有效 IP 地址");
            return false;
        }
        if (object.value(QStringLiteral("enable_tts_display")).isBool())
            m_ttsDisplayEnabled = object.value(QStringLiteral("enable_tts_display")).toBool();
        if (!object.value(QStringLiteral("ws_url")).toString().isEmpty())
            serviceUrl = object.value(QStringLiteral("ws_url")).toString();
        else if (!object.value(QStringLiteral("ota_url")).toString().isEmpty())
            serviceUrl = object.value(QStringLiteral("ota_url")).toString();
        if (!explicitWorkdir)
            m_workingDirectory = QFileInfo(path).absolutePath();
        break;
    }
    const QString overrideUrl = QString::fromLocal8Bit(qgetenv("XIAOZHI_NETWORK_CHECK_URL"));
    m_checkUrl = QUrl(overrideUrl.isEmpty() ? serviceUrl : overrideUrl);
    const QString scheme = m_checkUrl.scheme().toLower();
    const int port = m_checkUrl.port(scheme == QLatin1String("http") || scheme == QLatin1String("ws") ? 80 : 443);
    if (!m_checkUrl.isValid() || m_checkUrl.host().isEmpty() || port < 1 || port > 65535 ||
        (scheme != QLatin1String("https") && scheme != QLatin1String("http") &&
         scheme != QLatin1String("wss") && scheme != QLatin1String("ws") && scheme != QLatin1String("tcp"))) {
        if (error) *error = QStringLiteral("小智服务网络检查地址无效，请核对 ws_url / XIAOZHI_NETWORK_CHECK_URL");
        return false;
    }
    return true;
}

bool XiaozhiBridge::validateExecutable(QString *error) const
{
    const QFileInfo executable(m_executablePath);
    if (!executable.isFile() || !executable.isExecutable() || !QDir(m_workingDirectory).exists()) {
        if (error)
            *error = QStringLiteral("未找到可执行的小智程序或工作目录无效：%1；请核对执行权限与部署路径").arg(m_executablePath);
        return false;
    }
    return true;
}

bool XiaozhiBridge::start(QString *error)
{
    if (error) error->clear();
    if (!m_networkAvailable) {
        blockForNetwork(QStringLiteral("Wi-Fi 未连接或没有 IP 地址"));
        if (error) *error = networkUnavailableMessage();
        return false;
    }
    if (isStopping()) {
        if (error) *error = QStringLiteral("小智正在停止，请稍后再次尝试");
        return false;
    }
    if (isActive())
        return true;
    m_networkBlocked = false;
    if (!loadRuntimeConfig(error))
        return false;
    m_restartAttempts = 0;
    m_wantsRunning = true;
    beginNetworkProbe();
    return true;
}

void XiaozhiBridge::beginNetworkProbe()
{
    if (!m_wantsRunning)
        return;
    if (!m_networkAvailable) {
        blockForNetwork(QStringLiteral("Wi-Fi 连接已断开"));
        return;
    }
    m_probeActive = false;
    m_probeSocket.abort();
    m_probeActive = true;
    m_restartTimer->stop();
    bool ok = false;
    const int configuredTimeout = QString::fromLocal8Bit(qgetenv("XIAOZHI_NETWORK_TIMEOUT_MS")).toInt(&ok);
    m_probeTimer->start(ok ? qBound(500, configuredTimeout, 10000) : 4000);
    emit statusChanged(QStringLiteral("正在检查小智网络连接…"));
    emit activeChanged(true);
    const QString scheme = m_checkUrl.scheme().toLower();
    m_probeSocket.connectToHost(m_checkUrl.host(), static_cast<quint16>(
        m_checkUrl.port(scheme == QLatin1String("http") || scheme == QLatin1String("ws") ? 80 : 443)));
}

void XiaozhiBridge::finishNetworkProbe(bool success, const QString &detail)
{
    if (!m_probeActive)
        return;
    m_probeActive = false;
    m_probeTimer->stop();
    m_probeSocket.abort();
    if (!m_wantsRunning)
        return;
    if (!success || !m_networkAvailable) {
        blockForNetwork(detail);
        return;
    }
    QString error;
    if (!launchCore(&error)) {
        m_wantsRunning = false;
        emit statusChanged(error);
        emit activeChanged(false);
    }
}

bool XiaozhiBridge::launchCore(QString *error)
{
    if (!m_networkAvailable || !m_wantsRunning)
        return false;
    if (!validateExecutable(error) || !bindGuiSocket(error))
        return false;
    m_audioRecoveryRequested = false;
    resetAudioReadiness();
    m_logLineBuffer.clear();
    m_process.setProgram(m_executablePath);
    m_process.setArguments(QStringList());
    m_process.setWorkingDirectory(m_workingDirectory);
    m_process.setProcessChannelMode(QProcess::MergedChannels);
    m_process.start();
    emit statusChanged(m_ttsDisplayEnabled ? QStringLiteral("网络检查通过，正在启动小智核心…")
        : QStringLiteral("网络检查通过，正在启动；请启用 enable_tts_display=true 显示字幕"));
    return true;
}

void XiaozhiBridge::scheduleRestart()
{
    if (!m_wantsRunning || m_restartTimer->isActive())
        return;
    if (!m_networkAvailable) {
        blockForNetwork(QStringLiteral("Wi-Fi 连接不可用"));
        return;
    }
    if (m_restartAttempts >= 3) {
        m_wantsRunning = false;
        m_socket.close();
        emit statusChanged(QStringLiteral("小智核心连续启动失败 3 次，已停止自动重试；请检查配置、ABI 和音频设备"));
        return;
    }
    const int delayMs[] = {2000, 5000, 12000};
    m_restartTimer->start(delayMs[m_restartAttempts++]);
    emit statusChanged(QStringLiteral("小智核心正在自动恢复，%1 秒后重试（%2/3）")
                           .arg((delayMs[m_restartAttempts - 1] + 999) / 1000).arg(m_restartAttempts));
}

void XiaozhiBridge::resetAudioReadiness()
{
    m_captureReady = false;
    m_playbackReady = false;
    emit audioReadyChanged(false);
}

void XiaozhiBridge::stopInternal(bool blocked)
{
    m_wantsRunning = false;
    m_networkBlocked = blocked;
    m_audioRecoveryRequested = false;
    m_restartTimer->stop();
    m_probeTimer->stop();
    m_probeActive = false;
    m_probeSocket.abort();
    m_socket.close();
    resetAudioReadiness();
    if (isRunning()) {
        m_process.terminate();
        m_killTimer->start();
    } else {
        m_killTimer->stop();
    }
    emit activeChanged(isActive());
}

void XiaozhiBridge::blockForNetwork(const QString &detail)
{
    stopInternal(true);
    emit statusChanged(networkUnavailableMessage());
    emit networkUnavailable(detail);
}

void XiaozhiBridge::stop()
{
    stopInternal(false);
    emit statusChanged(isRunning() ? QStringLiteral("正在停止小智…") : QStringLiteral("小智已停止"));
}

void XiaozhiBridge::readCoreOutput()
{
    m_logLineBuffer.append(m_process.readAllStandardOutput());
    int newline = -1;
    while ((newline = m_logLineBuffer.indexOf('\n')) >= 0) {
        const QByteArray rawLine = m_logLineBuffer.left(qMin(newline, 8192)).trimmed();
        m_logLineBuffer.remove(0, newline + 1);
        if (rawLine.isEmpty()) continue;
        const QString line = QString::fromUtf8(rawLine);
        qInfo().noquote() << "[XiaoZhi Core]" << line;
        if (!m_wantsRunning) continue;
        const QString marker = QStringLiteral("STT Result:");
        const int at = line.indexOf(marker);
        if (at >= 0) {
            const QString text = line.mid(at + marker.size()).trimmed();
            if (!text.isEmpty()) emit userSpeechTextReceived(text);
        }
        const bool wasReady = m_captureReady && m_playbackReady;
        if (line.contains(QStringLiteral("Recording started:"))) m_captureReady = true;
        if (line.contains(QStringLiteral("Playback started:"))) m_playbackReady = true;
        if (line.contains(QStringLiteral("Recording thread error:")) || line.contains(QStringLiteral("Playback thread error:"))) {
            resetAudioReadiness();
            if (!m_audioRecoveryRequested && isRunning()) {
                m_audioRecoveryRequested = true;
                emit statusChanged(QStringLiteral("小智音频线程初始化失败，正在自动恢复核心…"));
                m_process.terminate();
                m_killTimer->start();
            }
        } else if (!wasReady && m_captureReady && m_playbackReady) {
            emit audioReadyChanged(true);
        }
    }
    // A faulty Core without newlines must not grow the UI process indefinitely.
    if (m_logLineBuffer.size() > 65536)
        m_logLineBuffer = m_logLineBuffer.right(65536);
}

void XiaozhiBridge::readDatagrams()
{
    for (int budget = 0; budget < 32 && m_socket.hasPendingDatagrams(); ++budget) {
        const qint64 size = m_socket.pendingDatagramSize();
        QHostAddress sender;
        QByteArray bytes(static_cast<int>(qBound<qint64>(0, size, 16384)), '\0');
        const qint64 read = m_socket.readDatagram(bytes.data(), bytes.size(), &sender);
        if (read < 0 || size < 1 || size > 16384 || !m_wantsRunning || !isRunning() ||
            (!sender.isLoopback() && !m_localAddresses.contains(sender)))
            continue;
        bytes.resize(static_cast<int>(read));
        const QJsonDocument doc = QJsonDocument::fromJson(bytes);
        if (!doc.isObject()) continue;
        const QJsonObject object = doc.object();
        const QString type = object.value(QStringLiteral("type")).toString();
        if (type == QLatin1String("tts")) {
            const QString text = object.value(QStringLiteral("text")).toString().trimmed();
            if (!text.isEmpty()) emit chatTextReceived(text, object.value(QStringLiteral("state")).toString());
        } else if (type == QLatin1String("toast")) {
            emit toastReceived(object.value(QStringLiteral("text")).toString());
        } else if (type == QLatin1String("activation")) {
            emit activationCodeReceived(object.value(QStringLiteral("code")).toString());
        }
        if (object.value(QStringLiteral("state")).isDouble())
            emit coreStateChanged(object.value(QStringLiteral("state")).toInt());
    }
    if (m_socket.hasPendingDatagrams() && !m_udpDrainScheduled) {
        m_udpDrainScheduled = true;
        QTimer::singleShot(0, this, [this]() { m_udpDrainScheduled = false; readDatagrams(); });
    }
}
