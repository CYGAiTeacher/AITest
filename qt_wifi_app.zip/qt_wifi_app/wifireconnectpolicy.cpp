#include "wifireconnectpolicy.h"

#include <algorithm>
#include <limits>

WifiReconnectPolicy::WifiReconnectPolicy()
{
    m_clock.start();
}

bool WifiReconnectPolicy::choose(const QList<WifiNetwork> &visible,
                                 const QList<WifiCredentials> &saved,
                                 WifiCredentials *credentials,
                                 int *signalLevel) const
{
    if (!credentials)
        return false;
    const qint64 now = m_clock.elapsed();
    bool found = false;
    int strongest = std::numeric_limits<int>::min();
    for (const WifiNetwork &network : visible) {
        if (!network.supported || m_retryAfter.value(network.ssid, 0) > now)
            continue;
        for (const WifiCredentials &profile : saved) {
            if (profile.ssid != network.ssid || profile.secured != network.secured ||
                (profile.secured && profile.password.isEmpty()))
                continue;
            if (!found || network.signalLevel > strongest ||
                (network.signalLevel == strongest && profile.ssid < credentials->ssid)) {
                *credentials = profile;
                strongest = network.signalLevel;
                found = true;
            }
            break;
        }
    }
    if (found && signalLevel)
        *signalLevel = strongest;
    return found;
}

void WifiReconnectPolicy::failed(const QString &ssid)
{
    const int count = qMin(m_failures.value(ssid, 0) + 1, 5);
    m_failures.insert(ssid, count);
    const int delayMs = qMin(60000, 5000 * (1 << (count - 1)));
    m_retryAfter.insert(ssid, m_clock.elapsed() + delayMs);
}

void WifiReconnectPolicy::reset()
{
    m_failures.clear();
    m_retryAfter.clear();
}
