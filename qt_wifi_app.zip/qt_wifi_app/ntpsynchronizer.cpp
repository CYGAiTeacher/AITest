#include "ntpsynchronizer.h"

#include <QByteArray>
#include <QStringList>
#include <QDateTime>
#include <QEventLoop>
#include <QHostInfo>
#include <QThread>
#include <QScopedValueRollback>
#include <QTimer>
#include <QUdpSocket>
#include <cmath>
#include <limits>

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <linux/rtc.h>
#include <netdb.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

namespace {

const quint32 kNtpUnixEpochDelta = 2208988800U;
const int kNtpPacketSize = 48;
const int kNtpTimeoutMs = 1600;

void writeNetworkUInt32(char *bytes, quint32 value)
{
    bytes[0] = static_cast<char>((value >> 24) & 0xff);
    bytes[1] = static_cast<char>((value >> 16) & 0xff);
    bytes[2] = static_cast<char>((value >> 8) & 0xff);
    bytes[3] = static_cast<char>(value & 0xff);
}

quint32 readNetworkUInt32(const char *bytes)
{
    return (quint32(static_cast<unsigned char>(bytes[0])) << 24)
         | (quint32(static_cast<unsigned char>(bytes[1])) << 16)
         | (quint32(static_cast<unsigned char>(bytes[2])) << 8)
         | quint32(static_cast<unsigned char>(bytes[3]));
}

double timevalSeconds(const timeval &value)
{
    return double(value.tv_sec) + double(value.tv_usec) / 1000000.0;
}

void writeNtpTimestamp(char *bytes, const timeval &value)
{
    const quint32 seconds = quint32(quint64(value.tv_sec) + kNtpUnixEpochDelta);
    const quint32 fraction = quint32((quint64(value.tv_usec) << 32) / 1000000ULL);
    writeNetworkUInt32(bytes, seconds);
    writeNetworkUInt32(bytes + 4, fraction);
}

bool ntpCancelled()
{
    return QThread::currentThread()->isInterruptionRequested();
}

double readNtpTimestamp(const char *bytes, double referenceUnixSeconds)
{
    const double base = double(qint64(readNetworkUInt32(bytes)) - qint64(kNtpUnixEpochDelta));
    // NTP seconds wrap in 2036. Unfold the era nearest the current/reference
    // clock, using 2020 as a floor for boards booting with an unset RTC.
    const double reference = qMax(referenceUnixSeconds, 1577836800.0);
    const double era = std::floor((reference - base) / 4294967296.0 + 0.5);
    return base + era * 4294967296.0 + double(readNetworkUInt32(bytes + 4)) / 4294967296.0;
}

bool parseNtpReply(const QByteArray &response, const QByteArray &request,
                   const timeval &requestTime, const timeval &receiveTime,
                   qint64 *utcMilliseconds, QString *error)
{
    const auto fail = [error](const QString &message) { if (error) *error = message; return false; };
    if (response.size() < kNtpPacketSize || request.size() < kNtpPacketSize)
        return fail(QStringLiteral("Invalid NTP packet length"));
    const unsigned char header = static_cast<unsigned char>(response.at(0));
    const int stratum = static_cast<unsigned char>(response.at(1));
    if ((header & 7) != 4 || ((header >> 3) & 7) < 3 || ((header >> 3) & 7) > 4 ||
        (header >> 6) == 3 || stratum < 1 || stratum > 15)
        return fail(QStringLiteral("Unsynchronized/invalid NTP server packet"));
    if (std::memcmp(response.constData() + 24, request.constData() + 40, 8) != 0)
        return fail(QStringLiteral("NTP response did not match the request"));
    if (response.mid(32, 8) == QByteArray(8, char(0)) || response.mid(40, 8) == QByteArray(8, char(0)))
        return fail(QStringLiteral("NTP server returned an empty timestamp"));
    const double t1 = timevalSeconds(requestTime);
    const double t4 = timevalSeconds(receiveTime);
    const double t2 = readNtpTimestamp(response.constData() + 32, t4);
    const double t3 = readNtpTimestamp(response.constData() + 40, t4);
    const double correctedUtc = t4 + ((t2 - t1) + (t3 - t4)) / 2.0;
    if (!std::isfinite(correctedUtc) || correctedUtc < 1577836800.0 || correctedUtc >= 4102444800.0 ||
        t3 < t2 || t4 < t1 || t4 - t1 > 10.0 || t3 - t2 > 10.0)
        return fail(QStringLiteral("NTP timestamp out of range or local clock changed"));
    *utcMilliseconds = qint64(correctedUtc * 1000.0 + 0.5);
    return true;
}

QList<QHostAddress> resolveNtpHost(const QString &host, QString *error)
{
    QHostAddress numeric;
    if (numeric.setAddress(host)) return {numeric};
    QList<QHostAddress> addresses;
    QEventLoop loop;
    QTimer deadline;
    QTimer cancellation;
    deadline.setSingleShot(true);
    cancellation.setInterval(50);
    QObject::connect(&deadline, &QTimer::timeout, &loop, &QEventLoop::quit);
    QObject::connect(&cancellation, &QTimer::timeout, &loop, [&loop]() { if (ntpCancelled()) loop.quit(); });
    const int lookupId = QHostInfo::lookupHost(host, &loop, [&addresses, &loop, error](const QHostInfo &info) {
        addresses = info.addresses();
        if (info.error() != QHostInfo::NoError && error) *error = info.errorString();
        loop.quit();
    });
    deadline.start(1300);
    cancellation.start();
    if (!ntpCancelled()) loop.exec();
    QHostInfo::abortHostLookup(lookupId);
    if (addresses.isEmpty() && error && error->isEmpty()) *error = QStringLiteral("NTP DNS lookup timed out/cancelled");
    return addresses;
}

bool queryServer(const QString &host, qint64 *utcMilliseconds, QString *error)
{
    if (ntpCancelled()) return false;
    const QList<QHostAddress> addresses = resolveNtpHost(host, error);
    int attempted = 0;
    for (const QHostAddress &address : addresses) {
        if (ntpCancelled()) return false;
        if (++attempted > 2) break; // Bound a multi-address DNS answer.
        QUdpSocket socket;
        socket.connectToHost(address, 123); // Numeric address: no blocking resolver.
        timeval requestTime;
        if (::gettimeofday(&requestTime, nullptr) != 0) continue;
        QByteArray request(kNtpPacketSize, char(0));
        request[0] = char(0x23);
        writeNtpTimestamp(request.data() + 40, requestTime);
        if (socket.write(request) != request.size()) {
            if (error) *error = socket.errorString();
            continue;
        }
        QEventLoop loop;
        QTimer deadline;
        QTimer cancellation;
        deadline.setSingleShot(true);
        cancellation.setInterval(50);
        QObject::connect(&socket, &QUdpSocket::readyRead, &loop, &QEventLoop::quit);
        QObject::connect(&deadline, &QTimer::timeout, &loop, &QEventLoop::quit);
        QObject::connect(&cancellation, &QTimer::timeout, &loop, [&loop]() { if (ntpCancelled()) loop.quit(); });
        deadline.start(kNtpTimeoutMs);
        cancellation.start();
        if (!socket.hasPendingDatagrams() && !ntpCancelled()) loop.exec();
        if (ntpCancelled()) return false;
        if (!socket.hasPendingDatagrams()) {
            if (error) *error = QStringLiteral("NTP response timed out");
            continue;
        }
        QByteArray response(512, char(0));
        const qint64 length = socket.readDatagram(response.data(), response.size());
        if (length < 0) continue;
        response.resize(static_cast<int>(length));
        timeval receiveTime;
        if (::gettimeofday(&receiveTime, nullptr) != 0) continue;
        if (parseNtpReply(response, request, requestTime, receiveTime, utcMilliseconds, error)) return true;
    }
    return false;
}

bool setSystemClock(qint64 utcMilliseconds, QString *error)
{
    const qint64 seconds = utcMilliseconds / 1000;
    if (seconds > static_cast<qint64>(std::numeric_limits<time_t>::max())) {
        if (error) *error = QStringLiteral("System time_t cannot represent this date");
        return false;
    }
    struct timeval value;
    value.tv_sec = time_t(seconds);
    value.tv_usec = suseconds_t(utcMilliseconds % 1000) * 1000;
    if (::settimeofday(&value, nullptr) == 0)
        return true;
    if (error)
        *error = QString::fromLocal8Bit(std::strerror(errno));
    return false;
}

bool writeRtcClock(qint64 utcMilliseconds, QString *deviceUsed, QString *error)
{
    if ((utcMilliseconds + 500) / 1000 > static_cast<qint64>(std::numeric_limits<time_t>::max())) {
        if (error) *error = QStringLiteral("RTC conversion time_t cannot represent this date");
        return false;
    }
    const time_t utcSeconds = time_t((utcMilliseconds + 500) / 1000);
    struct tm utcFields;
    if (!::gmtime_r(&utcSeconds, &utcFields)) {
        if (error)
            *error = QStringLiteral("Unable to convert NTP time for RTC");
        return false;
    }

    struct rtc_time rtcValue;
    std::memset(&rtcValue, 0, sizeof(rtcValue));
    rtcValue.tm_sec = utcFields.tm_sec;
    rtcValue.tm_min = utcFields.tm_min;
    rtcValue.tm_hour = utcFields.tm_hour;
    rtcValue.tm_mday = utcFields.tm_mday;
    rtcValue.tm_mon = utcFields.tm_mon;
    rtcValue.tm_year = utcFields.tm_year;
    rtcValue.tm_wday = utcFields.tm_wday;
    rtcValue.tm_yday = utcFields.tm_yday;
    rtcValue.tm_isdst = 0;

    QStringList devices;
    const QByteArray overrideDevice = qgetenv("RTC_DEVICE");
    if (!overrideDevice.isEmpty())
        devices << QString::fromLocal8Bit(overrideDevice);
    devices << QStringLiteral("/dev/rtc0")
            << QStringLiteral("/dev/rtc")
            << QStringLiteral("/dev/rtc1");

    devices.removeDuplicates();
    QString lastError = QStringLiteral("No usable RTC device found");
    for (const QString &device : devices) {
        const QByteArray devicePath = device.toLocal8Bit();
        const int fd = ::open(devicePath.constData(), O_RDWR | O_CLOEXEC);
        if (fd < 0) {
            lastError = QStringLiteral("%1: %2")
                            .arg(device, QString::fromLocal8Bit(std::strerror(errno)));
            continue;
        }

        const int result = ::ioctl(fd, RTC_SET_TIME, &rtcValue);
        const int ioctlError = errno;
        ::close(fd);
        if (result == 0) {
            if (deviceUsed)
                *deviceUsed = device;
            return true;
        }
        lastError = QStringLiteral("%1: %2")
                        .arg(device, QString::fromLocal8Bit(std::strerror(ioctlError)));
    }

    if (error)
        *error = lastError;
    return false;
}

} // namespace

NtpSynchronizer::NtpSynchronizer(QObject *parent)
    : QObject(parent), m_syncInProgress(false)
{
}

void NtpSynchronizer::synchronize()
{
    if (m_syncInProgress || ntpCancelled()) return;
    const QScopedValueRollback<bool> running(m_syncInProgress, true);
    const QStringList servers = QStringList()
        << QStringLiteral("ntp.aliyun.com")
        << QStringLiteral("ntp.tencent.com")
        << QStringLiteral("cn.pool.ntp.org")
        << QStringLiteral("ntp.ntsc.ac.cn");

    qint64 utcMilliseconds = 0;
    QString lastError;
    QString usedServer;
    for (const QString &server : servers) {
        if (ntpCancelled()) return;
        if (queryServer(server, &utcMilliseconds, &lastError)) {
            usedServer = server;
            break;
        }
    }

    if (ntpCancelled()) return;
    if (usedServer.isEmpty()) {
        emit synchronizationFinished(false, 0, false, false,
                                     QStringLiteral("无法从互联网获取北京时间：%1").arg(lastError));
        return;
    }

    QString clockError;
    const bool clockSet = setSystemClock(utcMilliseconds, &clockError);
    QString rtcDevice;
    QString rtcError;
    const bool rtcWritten = writeRtcClock(utcMilliseconds, &rtcDevice, &rtcError);

    QString message = QStringLiteral("北京时间已从 %1 同步").arg(usedServer);
    message += clockSet ? QStringLiteral("；系统时钟已校准")
                        : QStringLiteral("；系统时钟校准失败（%1）").arg(clockError);
    message += rtcWritten ? QStringLiteral("；已写入 RTC %1（UTC）").arg(rtcDevice)
                          : QStringLiteral("；RTC 写入失败（%1）").arg(rtcError);
    emit synchronizationFinished(true, utcMilliseconds, clockSet, rtcWritten, message);
}
