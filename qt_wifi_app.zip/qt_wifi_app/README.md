# 开发板 Wi‑Fi 与外设测试程序（Qt 5 Widgets）

目标：Linux 开发板，4.3 英寸 480 × 272 横屏 LCD。首页顶栏强制 LTR：左侧为“硬件测试”图标/标题，中间居中显示北京时间，最右侧为 Wi-Fi 图标、连接状态和 IP；日期使用亮蓝、时分秒使用浅色正文分别显示，合起来为 `yyyy-MM-dd HH:mm:ss`。首页底部不重复显示 IP。首次联网取得 IP 后，程序通过互联网 NTP 自动同步北京时间（UTC+8），并尝试校准系统时钟及写入 RTC。首页外设入口可打开录音/播放、小智 AI 对话、RS485/STM32 温湿度曲线及 LED/蜂鸣器控制、V4L2 摄像头预览、板载传感器（sysfs 温度/电压 + 1-wire DS18B20）通道监测和 SocketCAN 总线收发测试。首页外设入口下方为 CPU/内存使用率实时曲线。支持四套配色主题运行时自由切换（午夜蓝/曜石黑/护眼墨绿/清爽白，外设菜单「主题风格」页点选即生效并持久化保存，重启保持；图标也按主题角色色实时重着色）。主题风格页底部提供两步确认的「恢复出厂设置」按钮（删除 Wi-Fi 凭据 JSON 与主题配置并即时回默认主题）。外设菜单含「一键测试」页：自动顺序执行摄像头/音频采集/RS485 串口/CAN/传感器五项自检（逐项超时保护），通过显示 ✓、失败显示 ✗ 及原因；串口检查可打开/配置/成功写入，回显仅为附注，不代表验证 STM32 对端；CAN 使用控制器内部 loopback 模式并匹配帧 ID、长度和全部数据，无需外部总线对端；传感器自检仅验证节点发现。Wi-Fi 凭据独立持久化（可记住多个网络），支持启动/断线自动重连、按信号强度选取已保存网络、已保存网络免重复输入密码；认证被拒绝或目标仍可见的连接超时会清除该网络密码，再次选择时要求重新输入。支持 WPA/WPA2-Personal 与开放网络。详细页面设计、寄存器表和部署边界见 [`UI_DESIGN.md`](UI_DESIGN.md)。

## v12 更新：断网拦截与程序检查

- 小智两个手动启动入口及自动重启统一检查 Wi-Fi/IP 和小智服务 DNS/TCP 可达性。网络不可用时不执行 Core，页面明确显示 **“网络不可用，请正确连接wifi后再次尝试。”**；联网后点击启动重试。
- 修复已复现的摄像头颜色表越界、/proc 内存读取错误，以及 CAN kbps→bits/s 单位错误；收紧线程退出、设备清理、旧异步回调隔离和进程停止定时器。
- 完整变更、检测范围及不能保证的硬件边界见 [`AUDIT_REPORT.md`](AUDIT_REPORT.md)。

## 功能

- 没有有效已保存网络时，首次启动进入 Wi-Fi 设置页；有已保存网络时先进入首页，检查当前连接，未连接则扫描并优先连接信号最强的已保存网络。断线后持续自动扫描，信号恢复即可自动重连。
- Wi-Fi 扫描子页不显示密码输入框；网络列表按信号强度排序并纵向扩展，占据页面主要区域，用图片锁图标区分加密网络、标记暂不支持的加密类型。底部只保留紧凑的“返回”和“连接”按钮。已保存且安全类型匹配的网络标注“已保存”，选中后显示“直接连接”，跳过密码页；只有未保存的加密网络进入独立密码页。开放网络直接连接。扫描使用 wpa_supplicant 控制接口；连接时由 `wpa_cli add_network/set_network/enable_network/select_network` 动态配置，**不会执行 `SAVE_CONFIG`，不会把新输入的 SSID/密码写入 `wpa_supplicant.conf`**。
- 多个网络的 SSID、密码和安全类型保存在独立 JSON 文件 `wifi_credentials.json` 的 `networks` 数组中；新增成功连接不会覆盖其他网络，旧版单网络 JSON 可直接读取、下次保存时迁移。Linux 下文件权限为 `0600`。WPA 成功后运行 `udhcpc -i <接口>` 获取 IPv4。
- 首页顶栏强制从左到右排列：“硬件测试”固定最左、北京时间居中、Wi-Fi 图标/状态/IP 固定最右；点击右侧 Wi-Fi 图标打开设置。主界面底部不重复显示 IP。整体采用深蓝主题：窗口底色 `#0B1727`，顶栏 `#102036`，卡片 `#12253B`，控件 `#172B43`；以亮蓝 `#5AAAF2`、浅色正文和清晰描边分层，不用大面积纯白填充。所有 UI 图标均为适配深色背景的 PNG 图片资源。
- 触屏运行时隐藏 Qt 鼠标指针；按钮在按住期间使用高亮边框和明显的底色变化反馈触摸。部分较小的操作图标已加大。
- DHCP 获取到 IP 后自动通过 NTP 获取北京时间（UTC+8），依次尝试 `ntp.aliyun.com`、`ntp.tencent.com`、`cn.pool.ntp.org` 和 `ntp.ntsc.ac.cn`。成功后尝试用 `settimeofday()` 校准系统时钟，并通过 Linux `RTC_SET_TIME` 将 NTP 时间写入 RTC；RTC 按 Linux 常规约定写入 UTC，界面显示 UTC+8。默认依次尝试 `/dev/rtc0`、`/dev/rtc`、`/dev/rtc1`，可用 `RTC_DEVICE=/dev/rtcX` 指定设备。设置系统时钟/RTC 通常需要 root 或 `CAP_SYS_TIME` 及 RTC 设备写权限；权限不足时会记录失败原因，但顶栏仍使用获取到的网络时间显示。请确保 DNS 可用且出站 UDP 123 未被拦截；NTP 获取失败时每 30 秒重试；DNS/UDP 等待支持退出中断，并拒绝未同步的 LI=3 报文，处理 2036 年时间戳回绕。
- WPA/WPA2-Personal 普通密码按 `wpa_cli` 的方式以带引号的 `SET_NETWORK <id> psk "passphrase"` 命令传给 wpa_supplicant，由它派生 PSK；64 位十六进制输入仍按原始 PSK 设置。
- 凭据文件是明文，应用会尽量设为 `0600`，默认保存在当前运行用户的应用配置目录；可用 `WIFI_CREDENTIALS_PATH` 指定可写分区上的路径。密码也会短暂作为参数传给 `wpa_cli`，有权限查看进程参数的本机用户可能看到它。请以专用低权限用户运行并保护凭据文件。

## 外设测试面板

首页主卡片进入外设测试菜单，主卡片下方为 CPU/内存使用率实时曲线（每秒采样 /proc/stat 与 /proc/meminfo，双序列折线滚动约一分钟窗口）。音频、小智、RS485、摄像头、传感器、CAN 均为独立子页。

### 摄像头预览（V4L2）

- 直接通过 Linux V4L2 接口（`ioctl` + `mmap` 流式缓冲）捕获画面，不依赖 Qt Multimedia；支持 `YUYV` / `UYVY` 打包格式，软件经 BT.601 查表法转换为 RGB32 显示；打开后通过 `VIDIOC_S_PARM` 向驱动请求 30 fps（不支持的驱动保持默认），底栏显示协商到的帧率。
- 打开流程依次尝试 640×480 与 320×240，最终以驱动接受值为准；画面按显示区尺寸以快速缩放输出，顶栏状态显示实测帧率，底栏显示设备节点、分辨率与像素格式。
- 采集运行在独立线程，界面不阻塞；返回菜单或退出程序自动停止视频流并释放设备。
- 默认设备 `/dev/video0`，可用环境变量 `CAMERA_DEVICE` 指定其他节点（如 `/dev/video1`）。需要运行用户对 video 设备节点有读写权限（通常在 `video` 用户组）。仅输出 MJPEG 的摄像头暂不支持，页面会明确提示。

### 音频录音与播放

- 录音由 `arecord` 执行，默认设备 `default`、格式 `S16_LE`、单声道、采样率 `16000 Hz`，输出默认写入私有随机临时目录 `<临时目录>/board-ui-XXXXXX/recording.wav`（Linux 通常在 `/tmp`，目录权限仅当前用户可访问，正常退出自动清理）。
- 按“开始录音”开始采集；再次按键向 `arecord` 发送终止信号，关闭 WAV 文件后自动调用 `aplay` 回放；强制杀死或异常退出、文件为空时不自动回放。离页停止使用异步 terminate/有界 kill 定时器，定时器随本次进程完成而取消，不会误杀下一次任务。
- “播放 /music.wav”使用 `aplay` 播放指定的音乐文件。
- 环境变量：`ARECORD_PATH`、`APLAY_PATH`、`AUDIO_CAPTURE_DEVICE`、`AUDIO_PLAYBACK_DEVICE`、`AUDIO_SAMPLE_RATE`、`AUDIO_RECORD_PATH`。采样率接受 8000–96000 Hz；默认音乐路径严格为 `/music.wav`。录音/播放用户须有 ALSA 设备访问权限，并安装 `alsa-utils`（提供 `arecord`、`aplay`）。

### 小智 Linux 语音与聊天字幕

点击菜单中的“小智语音”先检查 Wi-Fi 已关联/取得 IP，再异步检查小智服务主机的 DNS/TCP 连接（默认 4 秒超时）；通过后监听 GUI UDP 端口并启动默认程序 `/xiaozhi_linux_rs-armv7-gnueabihf`；离开页面时会停止进程。该路径是外部部署的 ARMv7 GNU/GLIBC 可执行文件，**不包含在本 Qt 工程 ZIP 中**；板端需匹配 ABI、执行权限和依赖库。可用 `XIAOZHI_EXECUTABLE` 指定其他程序，用 `XIAOZHI_WORKDIR` 指定其工作目录。

**网络不可用提示：**未连接 Wi-Fi、未取得 IPv4、服务主机 DNS 失败、TCP 连接失败或检查超时，均显示“网络不可用，请正确连接wifi后再次尝试。”，不启动 Core。停止待重启任务，清除旧的音频/在线状态；正确联网后点击右上角“启动小智”重试。网络检查不阻塞页面；检查期间仍可停止/返回。检查默认取运行配置的 `ws_url`，缺省为 `wss://api.tenclass.net/xiaozhi/v1/`，必要时可用 `XIAOZHI_NETWORK_CHECK_URL=https://实际服务地址/` 覆盖；`XIAOZHI_NETWORK_TIMEOUT_MS` 范围 500–10000 ms，默认 4000。此检查只验证 DNS/TCP，不代表 TLS、Token、激活或 WebSocket 协议已经成功，也不支持自动完成门户认证。

**首次激活与首次对话：**页面提供指向官方控制台 `https://xiaozhi.me/console/` 的二维码。Core 通过 `type: "activation"` 消息返回真实六码后，界面原样显示；未收到时只显示“等待激活码”，不会伪造或预填验证码。按提示扫码打开控制台、注册/登录，在设备管理中添加设备并输入该六码完成绑定（官网界面名称可能变化，请以控制台当前指引为准）。绑定前不显示正常对话界面。Core 会先报告“设备已激活”，之后才启动音频线程和云端连接；GUI 不只等待 `state: 3`，还要从 Core 日志确认录音与播放分别出现 `Recording started` 和 `Playback started`，两项都就绪才开放对话。这样避免把“已绑定/云端已连”误当成麦克风、扬声器已经可用，降低第一次讲话落在 ALSA 初始化竞态中的风险。若 Core 异常退出，或日志出现 `Recording thread error` / `Playback thread error`（ALSA/音频线程初始化失败），GUI 会自动重启核心，并按 2、5、12 秒间隔恢复，最多 3 次；每次重启前同样检查网络，网络不可用时停止重试并显示断网提示。若核心经自动恢复后 30 秒仍未同时进入云端在线和音频就绪，激活卡片会提示先点“停止小智”，待按钮变为“启动小智”后再点一次；连接恢复前不开放对话区。

小智核心使用本机 UDP/JSON IPC：默认 GUI 绑定本机回环地址并监听 `5679/UDP` 接收 Core 消息；Core 在 `5678/UDP` 接收 GUI 控制指令，但当前界面不发送用户文字命令。默认 Core 向 `127.0.0.1:5679` 发送状态与字幕。桥接会从 `xiaozhi_config.json` 读取 Core 指定的 GUI 监听地址/端口（`gui_remote_ip`、`gui_remote_port`）及 `enable_tts_display`；Core 端接收控制指令的 `gui_local_port` 保持由上游配置管理。必须启用 `enable_tts_display: true` 才会收到 TTS 字幕。助手 TTS `sentence_start` / `sentence_end` 消息显示为左侧气泡；用户语音识别结果显示为右侧绿色气泡。当前上游 Core 的 GUI UDP 协议尚未发送 STT，但 Core 会在合并输出日志中记录 `STT Result: ...`；`XiaozhiBridge` 从该日志提取识别完成后的用户文本并显示，不是实时逐字字幕。如果 Core 版本关闭 INFO 日志或更改该日志格式，需由 Core 通过 UDP 发送 `type: "stt"`，或同步调整 GUI 解析规则。状态、Toast 和激活码也在页面显示。小智 Core 的标准输出/错误输出会写入 Qt 应用日志，便于排查初始化失败。麦克风采集与扬声器播放由小智核心按其配置的 ALSA 设备处理。请按上游仓库的 [GUI 适配说明](https://github.com/haoyn231/xiaozhi_linux_rs/blob/main/docs/GUI%E9%80%82%E9%85%8D%E8%AF%B4%E6%98%8E.md) 配置核心音频设备、网络激活与 `xiaozhi_config.json`。如需指定配置文件，可设置 `XIAOZHI_CONFIG_PATH`，文件名必须为 `xiaozhi_config.json`，且与显式设置的 `XIAOZHI_WORKDIR` 位于同一目录；未显式指定工作目录时，桥接跟随找到的配置所在目录，避免与 Core 读取两份配置。桥接不会修改该文件，显式路径错误会提示。未显式指定配置且文件不存在时，小智核心会按自身行为尝试在工作目录生成默认配置，非 root 部署时请预先提供可写的 `XIAOZHI_WORKDIR` 和配置文件。

### CAN 总线 / 板载传感器

- CAN 下拉速率为 kbps，实际传给 iproute2 的是 bits/s（500k→500000）。`CanLinkSession` 异步串行执行带 1.5 秒单命令超时的 `ip -details` / `ip link set`，不会在 GUI 线程同步等待命令。
- 已 UP 的正常 CAN 接口沿用现有配置，不 down、不重设速率，关闭测试也不关闭外部链路；已 UP 接口不执行控制器内部回环自检。原 DOWN 接口由本应用启用时，正常收发明确关闭控制器 loopback，自检明确开启；关闭/失败/取消时恢复 DOWN、原 loopback 和可读取的原 nominal bitrate。恢复失败会告警并禁止覆盖快照重新打开；原本无 bitrate 的新接口保留本次 bitrate，但仍恢复 DOWN/原 loopback。不是任意高级 CAN 时序参数的完整快照，请不要让其他管理程序同时操作该接口。
- 需要包含 CAN 支持的完整 **iproute2** 和网络管理权限，不能保证仅 BusyBox ip 可用；可用 `IP_PROGRAM=/sbin/ip` 指定程序。SocketCAN 以非阻塞/CLOEXEC 打开，每批最多收 32 帧；发送支持 ID=0、标准/扩展 ID、0–8 字节数据。
- 传感器发现 thermal/hwmon/iio/标准 1-wire 节点。IIO 按 `(raw+offset)*scale` 换算，兼容通道级或共享 scale/offset；无有效 scale 时显示原始计数 `raw`，不误标成 V/°C。DS18B20 保持读取内核 sysfs，不使用用户态时序模拟。
- 数值读取在工作线程；刷新/离页会使旧结果失效。退出时请求中断，文件间停止，安全等待当前内核读取结束，不强制销毁仍运行的线程。若 BSP 驱动永远不返回，需要修复驱动，应用无法安全强制终止它。

### RS485 / Modbus RTU 与 STM32

串口由 POSIX `termios` 在工作线程访问，不依赖 Qt SerialPort 插件。默认 `/dev/ttymxc2`、`19200 baud`、`8E1`、站号 `1`；每秒以功能码 `03` 读取 4 个保持寄存器，使用标准 Modbus RTU CRC-16（多项式 `0xA001`、低字节先发），控制输出使用功能码 `06`。读超时为 400 ms；发送完成等待也有限时并响应线程退出，关闭时恢复可读取的原 termios/RS485 参数。重连操作按同一 worker 队列顺序执行，不会在离页后延迟重开；LED/蜂鸣器待写期间禁止重复操作，成功确认或失败回退后恢复。运行时可以通过 `MODBUS_DEVICE`、`MODBUS_BAUD`、`MODBUS_SLAVE_ID` 覆盖默认参数。

| 保持寄存器地址 | 字段 | 编码 / 写入约定 |
|---|---|---|
| `0x0000` | LED 输出 | `0` 关闭、`1` 打开；功能码 `06` 单寄存器写入 |
| `0x0001` | 蜂鸣器输出 | `0` 关闭、`1` 打开；功能码 `06` 单寄存器写入 |
| `0x0002` | 温度 | 有符号 16 位补码，单位 `0.01 °C`（例如 `2350` 表示 `23.50 °C`） |
| `0x0003` | 相对湿度 | 无符号 16 位，单位 `0.01 %RH`（例如 `4567` 表示 `45.67 %RH`） |

寄存器地址和传感器缩放是本项目约定，STM32 固件需按同一映射实现；标准只规定 Modbus RTU 帧、CRC 和功能码。客户端尝试用 Linux `TIOCSRS485` 配置发送方向；若 BSP/驱动不支持该 ioctl，页面会提示检查设备树/驱动方向控制，不能仅靠应用假定硬件已切换收发方向。曲线保留最近 60 次有效采样，温度显示范围按 `−10…60 °C`、湿度按 `0…100 %RH`；超出温度图范围的点会贴边显示，但状态值仍以寄存器解码。

当前不支持 WPA-Enterprise、WEP、仅 WPA3-SAE、隐藏网络手动添加、门户认证等特殊情形。

## 编译

需要目标机/交叉编译环境中安装 Qt 5 Widgets、Qt Network 开发包和 C++11 编译器（建议 Qt 5.9 或更新版本；Network 用于小智 UDP IPC、启动网络检查与 NTP 异步 DNS/UDP）。项目同时提供 qmake 和 CMake：

### qmake

```sh
cd qt_wifi_app
qmake board_wifi_ui.pro
make -j4
```

### CMake

```sh
cd qt_wifi_app
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/target/qt5
cmake --build build -j4
```

生成程序：`board_wifi_ui`。在开发板上以全屏、无边框方式运行。

## ARM 屏幕字体与颜色

- 程序可优先加载可执行文件旁 `fonts/NotoSansSC-Regular.otf`，也可用 `QT_APP_FONT=/path/to/font.otf` 指定板端字体；缺少该文件时会回退到系统中文字体。为缩小交付包，工程 ZIP 不包含字体文件；如需随程序携带 Noto Sans SC（SIL OFL 1.1），可单独将字体放入 `fonts/` 目录再构建。
- Qt 默认字体改为 13 像素，设置 FreeType full hinting 与 `QFont::PreferAntialias`；网络列表文字显式启用 `QPainter::TextAntialiasing`；UI 图标全部从 Qt 资源中的 PNG 图片加载并以平滑变换缩放，不使用运行时矢量绘图。界面小字加大并提高文字/边框对比度。针对固定 480×272 屏幕，在 Qt 5.6+ 禁用高 DPI 自动缩放，避免界面被非整数比例重采样。
- 正式 UI 使用深蓝色调色板：窗口/页面 `#0B1727`、顶栏 `#102036`、卡片 `#12253B`、按键 `#172B43`、描边 `#2A405A`、正文 `#E8F0FA`、辅助文字 `#ADBED2`、主操作亮蓝 `#5AAAF2`，并为 Wi-Fi、网络状态与告警使用高对比绿/红。各层使用不同深浅和描边区分；不使用浅蓝灰主背景或大面积纯白填充。正式页面的白色只保留在二维码局部扫码底和少量文字/图标上；纯白大色块仅出现在 `--display-test` 诊断模式。图标 PNG 按深色表面重配亮蓝与浅色，编入 Qt 资源。程序启动日志打印 Qt 实际 `Window` 色、屏幕分辨率、色深和 DPR，便于核对目标板渲染。
- 若文字仍像缺笔/方框，确认 Buildroot Qt 启用了 FreeType 字体引擎，且程序能读到字体文件。若整套颜色仍偏色、红蓝互换或灰阶不正常，这通常是 framebuffer/DRM 的通道位域或像素格式与 Qt QPA 平台插件不一致，单改 QSS 调色板无法可靠修复；请记录 `Qt display` 日志，并提供 Qt 版本、`QT_QPA_PLATFORM`、显示栈（linuxfb/EGLFS/X11/Wayland）及一张界面照片，再按实际像素格式修正驱动/平台插件。

## 显示左侧色差诊断

正常 UI 使用深蓝调色板背景（`#0B1727`），卡片以更亮的深蓝表面区分；不再使用全屏 PNG。若屏幕左侧仍有色差，可运行同一程序的纯色诊断模式：

```sh
./board_wifi_ui --display-test
```

此模式不创建主界面和控件，只用 Qt `QPainter` 的 `CompositionMode_Source` 全屏依次填充灰、红、绿、蓝、白、黑，每 3 秒切换。用手机拍摄灰/白和红绿蓝画面，并观察色差是否始终固定在屏幕最左侧；按 `Ctrl+C` 或结束进程退出。

- 若纯色测试中仍在同一位置出现色条，问题不在主界面背景图或卡片样式，应进一步检查 Qt QPA 输出、Framebuffer/DRM 的像素格式/stride/offset，以及面板扫描和连接。
- 若纯色测试正常、只有正式界面出现色条，则问题仍在控件层级或页面重绘，我们再按实际界面布局定位。

设备树 porch/sync/clock 配置影响整帧扫描时序；目前不建议仅凭照片改动 timing。`bus-width=24` 与 framebuffer `16 bpp` 是否匹配要按显示控制器驱动约定判断，不能只看数值决定。

## wpa_supplicant 前置配置

程序不会替系统启动 wpa_supplicant 守护进程或在 `/run` 中创建 socket。扫描通过 Unix 控制套接字工作；连接和状态操作通过 `wpa_cli`，因此目标板需安装 `wpa_cli` 并确保它在 `PATH` 中（或设置 `WPA_CLI_PATH`）。WPA 握手成功后，程序调用 BusyBox `udhcpc -i <接口>` 获取地址；目标板也需安装 `udhcpc`，并配置可用的 DHCP 事件脚本（默认通常为 `/usr/share/udhcpc/default.script`，具体以 Buildroot 配置为准）。**socket 不是单独的配置文件**：`ctrl_interface` 写在 wpa_supplicant 正在使用的配置文件里，守护进程启动后才会创建类似 `/run/wpa_supplicant/wlan0` 的 socket。示例见 `wpa_supplicant.conf.example`。

将下面配置合并到开发板当前实际使用的 wpa_supplicant 配置文件中，不要覆盖厂商已有的其他设置：

```ini
ctrl_interface=DIR=/run/wpa_supplicant
```

先用 root 联调时可不指定组；若 Qt 程序以普通用户运行，应改为板上确实存在的组，例如 `ctrl_interface=DIR=/run/wpa_supplicant GROUP=netdev`，并让运行用户加入该组后重新登录。若系统通过 systemd、NetworkManager 或其他服务管理 Wi-Fi，请修改/重启现有服务使用的配置，不要再启动第二个 wpa_supplicant 实例。此程序不会调用 `SAVE_CONFIG`，因此不依赖 `update_config=1`。请检查并删除活动 `wpa_supplicant.conf` 中旧版本遗留的含密码 `network={...}` 配置块；新凭据只由程序从独立凭据文件读取。

启动或重启现有服务后检查 socket 和权限：

```sh
ls -l /run/wpa_supplicant
wpa_cli -p /run/wpa_supplicant -i wlan0 ping   # 正常应返回 PONG
wpa_cli -p /run/wpa_supplicant -i wlan0 scan
sleep 3
wpa_cli -p /run/wpa_supplicant -i wlan0 scan_results
```

若 socket 在其他位置，用 `WPA_CTRL_DIR` 或 `WPA_CTRL_PATH` 指向实际路径。普通 WPA/WPA2-Personal 密码只通过控制接口以带引号的口令传给 wpa_supplicant，不写回活动配置文件；64 位十六进制 PSK 则直接按原始 PSK 设置。

### Buildroot / BusyBox 快速核对

1. 用 `ps | grep wpa_supplicant` 找出当前启动命令和 `-c` 指向的配置文件；编辑这份活动配置，不要只新建一份未被服务读取的文件。
2. 在活动配置中加入上面的 `ctrl_interface`。本程序不写回网络配置，`update_config=1` 不是必需项。首次联调建议以 root 启动 Qt 程序；如以普通用户运行，先确认组名存在并配置 `GROUP=...`。
3. 若已写入 `ctrl_interface` 但仍没有 socket，检查 Buildroot `make menuconfig` 中 wpa_supplicant 的 **Enable the Unix-socket control interface**（`BR2_PACKAGE_WPA_SUPPLICANT_CTRL_IFACE`）是否启用；wpa_supplicant 构建配置应包含 `CONFIG_CTRL_IFACE=y`。这是编译选项，后期版本并没有普遍取消每接口 socket。
4. 重启板上现有的 init 脚本/服务；不要在已有进程旁边再启动一个实例。若确认当前没有运行进程，才按板上实际配置路径手动测试，例如：

```sh
mkdir -p /run/wpa_supplicant
wpa_supplicant -B -D nl80211 -i wlan0 -c /etc/wpa_supplicant.conf
```

将示例中的接口名、驱动和配置路径替换成该板实际值。随后确认 `/run/wpa_supplicant/wlan0` 存在，并运行 `wpa_cli -p /run/wpa_supplicant -i wlan0 ping`（返回 `PONG` 表示控制接口可用）。
5. 确认 BusyBox 启用了 `udhcpc`，应用运行用户有权配置网卡，并且 DHCP 脚本存在且可执行。程序以 `udhcpc -i <接口> -p /run/udhcpc-<接口>.pid` 启动/复用客户端；等待最多 20 秒读取接口 IPv4 地址。没有地址时，Qt 仍会报告 Wi-Fi 已连接，但显示“未获取到 IP”；检查 DHCP 服务、脚本路径及其 `bound` 处理。程序通过 pidfile 避免重复启动，复用前核对 PID 范围、udhcpc 命令及同一 `-i` 接口，符合时请求续租。

如果 Buildroot 使用只读 rootfs，请把配置和启动脚本改动放进 rootfs overlay/镜像配置，否则重启后会丢失。

## 接口名称与控制目录

默认接口为 `wlan0`，控制目录为 `/run/wpa_supplicant`。可通过环境变量覆盖：

```sh
WIFI_IFACE=wlan0 WPA_CTRL_DIR=/run/wpa_supplicant \
WIFI_CREDENTIALS_PATH=/data/wifi_credentials.json \
WPA_CLI_PATH=/usr/sbin/wpa_cli UDHCPC_PATH=/sbin/udhcpc ./board_wifi_ui
```

`WIFI_CREDENTIALS_PATH` 可选；默认在当前运行用户的 Qt 应用配置目录中。`WPA_CLI_PATH`、`UDHCPC_PATH` 也可省略；程序会搜索常见目录，或从 `PATH` 查找。

或使用参数：

```sh
./board_wifi_ui --interface wlan0 --ctrl-dir /run/wpa_supplicant
```

也支持通过 `WPA_CTRL_PATH` 指定控制套接字完整路径，例如 `/run/wpa_supplicant/wlan0`。

## 触摸屏软键盘

密码输入使用程序内置的 **Qt Widgets 触摸键盘**，不依赖 Qt Virtual Keyboard 插件或系统输入法。扫描页不显示密码框；已保存网络点击“直接连接”直接使用其凭据，未保存的加密网络点击“连接”才进入独立密码页，密码输入行靠近页面上沿。键盘打开时隐藏密码页其他控件和底部操作栏；输入行与键盘之间留有约 8 px 间距，键盘底色仍铺满屏幕宽度，最外侧按键与屏幕边缘留约 6 px 空隙。点击绿色“完成”键会校验密码：格式合法时切回扫描页并发起连接，扫描页显示带动态省略号的“正在连接 Wi-Fi”提示；密码为空或格式不合法时返回扫描页提示用户点击“连接”重新输入。手动连接失败后留在扫描页；认证被拒绝或目标仍可见的连接超时会清除该网络密码，提示点击“连接”重新输入。手动连接成功后返回首页；后台重连不切换当前页面。Wi-Fi 扫描、密码页均不显示当前 IP（IP 只在首页顶栏显示）。底部操作按钮高 30 px，靠近屏幕下沿。

键盘包含 QWERTY 字母、大小写切换、数字/符号页、空格和退格；字母键字体约 15 px、功能键约 13 px，按键随键盘区域高度伸展（约 32–50 px）。模式键按字母、数字、符号循环显示 `ABC`、`123`、`#+=`，默认 `ABC` 为蓝色底，切换后的模式状态使用深蓝底；完成键使用绿色底色。WPA/WPA2 密码格式为 8–63 位可见 ASCII 或 64 位十六进制 PSK。密码默认隐藏，可用眼睛图标切换显示；输入上限 64 个字符。底部操作按钮高 30 px，建议在目标板上确认触摸驱动的点击精度和按键响应。

## 状态与凭据（v11：多网络 / 自动重连）

### 连接策略

1. **启动与断线恢复**：每 5 秒检查连接状态；确认断线后约 1 秒启动后台扫描。若没有可用的已保存网络，每轮扫描完成后约 5 秒再扫，信号重新出现时自动连接，无需重启程序。
2. **强信号优先**：只在“已保存 + 当前扫描可见 + 支持的安全类型 + 安全类型匹配”的网络中，按 RSSI dBm 从大到小选择。例如 `-42 dBm` 优于 `-65 dBm`。强网失败后转试其他已保存网络；暂时不可达的网络按 5 / 10 / 20 / 40 / 60 秒退避，避免反复抢连一个网络。
3. **免重复输入密码**：列表用“已保存”标注；点击“直接连接”复用该 SSID 的密码。只在连接认证成功后新增/更新该网络记录，其他网络记录保留；不会自动连接从未保存过的陌生开放热点，也不会把已保存的 WPA 网络降级当成同名开放网络自动连接。
4. **失败清理**：监听 wpa_supplicant 的 `WRONG_KEY` / `AUTH_FAILED`、关联/认证拒绝事件；或连接超时后重新扫描确认目标仍可见。这类真实连接失败会移除**该 SSID** 的凭据和本次运行期网络配置，清空密码输入框，再次选择该网络时进入密码页。不会清空其他网络密码。
5. **避免误删**：AP 关闭/移出覆盖范围、`NETWORK-NOT-FOUND`、控制套接字或 `wpa_cli` 暂时不可用，不作为密码失效处理，保留凭据继续等待信号；WPA 已认证但 DHCP 没有 IP 也保留密码，提示检查 DHCP。如果磁盘删除失败，界面告警且本次运行在内存中停用该密码，不会带着错误密码无限重试。
6. **不抢占界面**：已有稳定连接时不因另一个网络变强而频繁切换；强信号优先用于启动/断线后的选网。手动打开 Wi-Fi 设置后暂停后台选网，避免扫描/自动连接打断手动选择和密码输入，返回首页后恢复；手动点击的网络优先于后台策略。后台重连成功不会退出正在使用的外设测试页。
7. **串行工作线程**：扫描、WPA 命令和 DHCP 都在 Wi-Fi 工作线程中执行，UI 不阻塞；扫描/连接/状态请求去重，不会在工作线程队列里累积重试任务。

### 文件格式与兼容性

- 路径不变：`QStandardPaths::AppConfigLocation/wifi_credentials.json`，Linux 默认 `~/.config/BoardLab/PeripheralTest/wifi_credentials.json`；板上以 root 运行时通常为 `/root/.config/BoardLab/PeripheralTest/wifi_credentials.json`。`XDG_CONFIG_HOME` 可改变配置目录；`WIFI_CREDENTIALS_PATH=/data/wifi_credentials.json` 可直接覆盖整个文件路径（相对路径以进程工作目录为基准）。
- v2 示例（下列仅为示例占位密码）：

```json
{
  "version": 2,
  "networks": [
    {"ssid": "HomeWiFi", "password": "example-pass-a", "secured": true},
    {"ssid": "LabWiFi", "password": "example-pass-b", "secured": true}
  ]
}
```

- 自动兼容旧格式 `{"version":1,"ssid":"...","password":"...","secured":true}`，不必删除旧配置；下次保存写为 v2。每个 SSID 保留一条记录，更新密码不会重复添加。`QSaveFile` 原子替换，文件权限 `0600`，JSON 最大 1 MiB；开放网络的 `password` 为空。最后一个网络被移除时删除文件，下次启动重新进入 Wi-Fi 设置。
- 文件为明文 JSON，**不是加密保险箱**。不要放在公开可读目录，也不要打包进固件源码仓库。保存失败会提示，内存中仍可供本次运行重连，但不能保证重启后记住。
- 配置只在运行中的 wpa_supplicant 内存中创建，不执行 `SAVE_CONFIG`。新配置带 `id_str="board_ui_managed"` 标记，切换/重试会清理应用自己的旧条目，防止重复累积；不删除第三方/系统的未标记条目，不改 `wpa_supplicant.conf`。旧版遗留的含密码 `network={...}` 块需手动清理；同一网卡不应同时由另一个网络管理器抢占。
- 「恢复出厂设置」删除**全部**已保存 Wi-Fi 记录，停止自动重连，取消在途连接并清除本应用标记的运行期网络；旧连接任务迟到的成功结果不能重新写回密码。主题恢复午夜蓝并清空其设置键；不修改系统网络配置文件或其他用户文件。

## 本机验证与目标板验收

- v12 最终验证：Wi-Fi **19 passed / 0 failed**，审计 **36 passed / 0 failed**，同一审计套件 ASan/UBSan **36 passed / 0 failed**（未做 leak 检测）；按实际编译配置的 cppcheck warning/performance/portability 检查无诊断。
- v12 新增 `tests/audit_tests.pro`：小智离线/不可达/取消/重启网络检查、GUI 提示保持、YUV 全输入域（16,777,216 组）、帧行跨度/边界/背压、CAN 假命令与恢复、procfs 内存、IIO/1-wire、慢读取退出、迟到自检回调、录音旧 kill 定时器、PTY Modbus 和 NTP 协议测试。日志与 Sanitizer/static analysis 记录见 tests；检测边界见 `AUDIT_REPORT.md`。

- 已在 Linux x86_64 / Qt 5.15 下完成主程序 qmake / CMake 两套构建（无编译警告），以及 `tests/wifi_tests.pro` 自动化测试。测试使用隔离的 Unix datagram 假 wpa_supplicant 和假 `wpa_cli`，不操作宿主机无线网卡，不启动真实 DHCP；覆盖多网络保存/旧格式迁移、择强连接、断线/信号恢复、认证失败单网络删除与降级选网、已保存网络跳过键盘、新密码保存、DHCP/控制错误保留密码、退避、重复网络清理、恢复出厂取消在途任务，以及主题/1-wire 异步读取回归。运行方法见 [`tests/README.md`](tests/README.md)。
- **尚无目标板和真实路由器硬件验证**。请在 imx6ull/交叉编译环境构建后，重点验收：关闭/重开 AP 后自动恢复；两个已保存 AP 同时出现时断线后选择较强者；修改 AP 密码后只删除对应记录、重新输入可成功；无信号和 DHCP 故障不误删密码；重启后仍记住多组网络。
- ALSA 播放/录音、小智 ARMv7 Core、STM32 RS485 和板上 DS18B20 等硬件联调仍需在目标板进行；请同时检查 Wi-Fi 控制权限、DHCP 脚本、中文字体、触屏布局及驱动配置。

