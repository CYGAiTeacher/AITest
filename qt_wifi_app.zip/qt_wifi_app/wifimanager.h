#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <QObject>
#include <QList>
#include <QMetaType>
#include <QMutex>
#include <QString>
#include <QStringList>

struct WifiNetwork
{
    QString ssid;
    QString flags;
    int signalLevel = -100; // dBm; larger (less negative) is stronger.
    bool secured = false;
    bool supported = false;
};

// Never infer failure type by searching localized UI messages. A DHCP delay
// is not an authentication failure; disappearance/control errors retain PSKs.
enum class WifiFailureReason {
    None,
    InvalidCredentials,
    ConnectionRejected,
    NetworkUnavailable,
    ControlError,
    Cancelled
};

Q_DECLARE_METATYPE(WifiNetwork)
Q_DECLARE_METATYPE(QList<WifiNetwork>)
Q_DECLARE_METATYPE(WifiFailureReason)

// All blocking control/scan/DHCP work runs on the Wi-Fi worker thread.
class WifiWorker : public QObject
{
    Q_OBJECT
public:
    explicit WifiWorker(const QString &interfaceName,
                        const QString &controlDirectory,
                        QObject *parent = nullptr);

    // Thread-safe cancellation fence (short mutex-protected integer only); callers
    // can invalidate an in-flight request during a factory reset.
    void cancelConnectionsBefore(quint64 minimumRequestId);

public slots:
    void scan(bool forReconnect = false);
    void connectNetwork(quint64 requestId,
                        const QString &ssid,
                        const QString &password,
                        bool secured);
    void checkStatus();
    void forgetManagedNetworks();

signals:
    void scanFinished(const QList<WifiNetwork> &networks, const QString &error);
    void connectFinished(quint64 requestId,
                         bool success,
                         const QString &ssid,
                         const QString &ipAddress,
                         WifiFailureReason reason,
                         const QString &message);
    void statusChanged(bool connected, const QString &ssid, const QString &ipAddress);
    void statusCheckFailed(const QString &message);

private:
    bool isCancelled(quint64 requestId) const;
    bool removeManagedNetworks(QString *error = nullptr);
    QString m_interfaceName;
    QString m_controlDirectory;
    QStringList m_managedNetworkIds;
    mutable QMutex m_cancelMutex;
    quint64 m_minimumRequestId;
};

#endif // WIFI_MANAGER_H
