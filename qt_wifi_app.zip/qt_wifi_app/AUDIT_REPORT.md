# v12：小智网络拦截与全模块检查记录

## 本次需求

网络不可用时，打开“小智语音”或点击“启动小智”均显示：

> 网络不可用，请正确连接wifi后再次尝试。

保留既有 480×272 页面、四套主题、Wi-Fi 多网络记忆/自动重连、录放音、RS485、摄像头、传感器和 CAN 功能。DS18B20 仍只通过 Linux 内核标准 1-wire 的 sysfs 接口读取。

## 小智启动路径

1. Wi-Fi 必须已关联并取得 IPv4。未满足时立即显示上述原文，不启动 Core。
2. 异步解析小智服务主机并建立 TCP 连接；默认检查运行配置的 `ws_url`（缺省 `wss://api.tenclass.net/xiaozhi/v1/`），无该字段时可使用 `ota_url`。默认总检查超时 4 秒，UI 线程不等待 DNS/TCP。
3. 检查成功后才绑定 GUI UDP 端口、校验/启动 Core。检查失败时使用相同原文提示；具体原因保留为提示信息的 tooltip。
4. 自动恢复的每次重启也经过检查。Wi-Fi 断开、失去 IP 或检查失败时停止 Core/待重启任务，清除音频和在线状态；正确联网后由用户点击启动重试，避免无限启动风暴。
5. 激活卡片优先显示断网原因，不会被“等待激活码”、30 秒手动重启提示或旧的在线状态覆盖。

**检查边界**：这是 Wi-Fi/IP + DNS/TCP 可达性检查，不是 ICMP ping，也不是 TLS、Token、设备激活、WebSocket 握手或门户认证的完整验证。TCP 可达后仍需由真实 Core 报告云端和音频就绪。对服务端口拒绝连接的情况也提示网络不可用，详细原因可从 tooltip 排查。

可选部署参数：

| 参数 | 作用 |
|---|---|
| `XIAOZHI_NETWORK_CHECK_URL` | 覆盖检查地址，支持 http/https/ws/wss/tcp URL；建议与实际部署的小智服务一致 |
| `XIAOZHI_NETWORK_TIMEOUT_MS` | 500–10000 ms，超出范围钳位；默认 4000 ms |
| `XIAOZHI_CONFIG_PATH` | 指向名为 `xiaozhi_config.json` 的文件；须与显式设置的 `XIAOZHI_WORKDIR` 位于同一目录 |

Core 按工作目录加载 `xiaozhi_config.json`。未显式指定工作目录而桥接找到了其他位置的配置时，桥接会相应使用该配置所在目录，避免 GUI 与 Core 各读一份不一致的配置。无配置文件时仍允许 Core 首次创建默认配置。

## 检查范围与已修复问题

扫描范围为项目全部 12 个生产 `.cpp`、对应头文件、qmake/CMake 清单及已有测试。方法包括源码检查、按实际 Qt 编译参数运行 cppcheck、可复现的隔离回归测试和内存/未定义行为检测；不是仅凭“能编译”判定没有问题。

| 模块 | 发现的问题 / 修复 |
|---|---|
| `mainwindow` / `xiaozhibridge` | 两个手动入口均无网络拦截；现统一走异步检查，并覆盖自动重启。错误提示保持可见；停止期间禁止再次启动，避免重复占用声卡。 |
| `xiaozhibridge` | Core 退出后音频就绪标记残留；现退出/停止/启动失败均清零。停止改为 terminate + 可取消的 kill 定时器；正常导航不阻塞。无换行日志片段限制 64 KiB，单行解析最多 8 KiB。UDP 单包最多 16 KiB、每批最多 32 包，仅接受本机来源，防止远程消息伪装状态和无界 UI 工作。 |
| `cameraworker` | **已实际复现全局数组越界**：原 768 项钳位表在 Y=255/U=208 时蓝色索引为 780。扩展覆盖完整输入范围，并移除负数有符号右移的 C++11 可移植性问题。 |
| `cameraworker` | 忽略 V4L2 源行跨度，奇数宽度、异常尺寸、短帧、错误 mmap 索引/长度可能越界。现按 `bytesperline` 转换，检查尺寸与偶数宽度、缓冲容量和 `bytesused`，丢弃短帧/驱动错误帧；先协商帧率再开流。断开/错误 poll 事件终止采集，不忙循环。 |
| 摄像头生命周期 | stop-before-start 的停止标志会被启动函数清除；自检可能删除仍在运行的 worker；GUI 过慢会堆积大图。现启动前显式准备、停止标志不在 worker 内重置；线程退出后再删除对象，每次最多一个待消费图像，按单调时钟统计 FPS。 |
| `canlinksession` / CAN 页面 | **速率单位错误**：原 500 kbps 被直接写成 `bitrate 500`。现转换为 `500000`；合法帧 ID `0` 不再被拒绝。原同步 `ip` 调用全部改为带单命令 1.5 秒超时的异步串行任务，检查配置和启用结果。 |
| CAN 资源保护 | 已 UP 的接口正常测试只复用，不强制 down/改速率，也不会在关闭页面时 down 外部链路；其速率以读取的当前值显示。已 UP 接口不执行内部回环自检；若接口已在控制器回环模式，正常收发也拒绝静默复用。对应用启用的原 DOWN 接口，失败/取消/退出时恢复 DOWN、原回环状态及可读取的原 bitrate；配置/绑定 socket 失败同样清理。恢复失败显式告警并禁止覆盖原快照重新配置，退出时再作有界尝试。 |
| CAN 自检 / 收包 | 原只比较 ID，可能把其他数据当作通过。现匹配标准帧 ID、DLC=8 和全部 8 字节模式；开启自身帧接收、检查套接字选项。所有 CAN socket 直接以非阻塞/CLOEXEC 创建，UI 每次最多读 32 帧，持续流量不独占事件循环。 |
| 一键测试 | 摄像头、音频、串口 300 ms 汇总和 150 ms 下一项回调可能污染新一轮。现以轮次/条目 token 隔离，取消即失效；摄像头/音频异步释放。串口必须可配置且成功写入才通过“端口测试”，仅匹配 0x55 回显并恢复原 termios，不宣称已经验证 STM32 对端。音频须实际产生非空 WAV，传感器自检明确只是节点扫描。 |
| 传感器 | 刷新列表未失效在途读取；旧结果可能写入新标签。现列表/离页修改代数，按实际在途 token 释放 busy，过期数据丢弃。IIO 支持通道级和共享 `scale` / `offset`，按 `(raw+offset)*scale` 换算；缺失/无效比例时显示未经除 1000 的 `raw` 值。w1_slave 仅认可第一行的 YES 与有效温度范围。 |
| 传感器退出 | 原固定 wait(1000) 后销毁线程，慢速/多个 1-wire 转换可能触发“QThread destroyed while running”。现请求中断、每文件间检查，关闭时安全等待当前内核读取返回，不再继续读取后续器件；不使用危险的强制线程终止。 |
| 录音/播放 | 旧 singleShot 的 kill 可能杀死下一次复用同一 QProcess 的录音/播放。现采用可停止的专属定时器，完成时清除，停止期间禁止新操作；离页异步退出，最终析构才有界等待。不自动回放强杀/异常退出的录音。默认文件位于权限受限的随机临时目录，避免多人共享 /tmp 固定文件名；保留 `AUDIO_RECORD_PATH` 覆盖。 |
| `modbusworker` / RS485 | “重连”120 ms 后可能在离页后重开。现 stop/start 按同一 worker 队列顺序发送，离页的 stop 最后执行。原无界 `tcdrain` 改为有期限的 TIOCOUTQ 查询，读等待每 50 ms 检查退出。关闭时恢复可读取的原 termios / RS485 配置；停止后不再写输出。控制按钮写入期间禁用并保护待写状态，失败回退。 |
| CPU/内存曲线 | **已复现 procfs 读取错误**：文件 size=0 时 QFile.atEnd() 可在第一次读取前即为 true，导致内存读取为 0。现先读取再解析，支持旧 BSP 无 MemAvailable 的保守近似值，钳位避免无符号下溢；CPU idle 差分同样保护。 |
| `ntpsynchronizer` | 原阻塞 getaddrinfo / 长 poll 不响应退出。现 Qt 异步 DNS、限时 UDP 和 50 ms 中断检查；避免嵌套校时。拒绝 LI=3 未同步、无效层级/模式、空时间戳和请求不匹配响应，处理 2036 NTP era 回绕；系统 time_t 无法表示日期时不截断写入。 |
| `wifimanager` | 控制 socket 使用私有临时目录及非阻塞/CLOEXEC；事件/命令输出有界，扫描/命令等待支持退出中断。DHCP pidfile 检查 PID 范围、真实 udhcpc 程序和相同 `-i` 接口，避免误向其他接口进程发续租信号。保持 v11 的择强、认证分类和保存策略。 |
| `wificredentialstore` | JSON 读取/保存上限 1 MiB；保留 v1/v2、原子替换、0600 和明文存储说明。 |
| `main` / `uitheme` / `uiicons` / 重连策略 | 复核启动、主题持久化、图标 alpha 重着色、单调退避和已保存网络匹配；保留既有实现，不为风格性差异改动行为。动态来源的静态 QLabel 统一用 PlainText，避免 SSID/日志被误解析成 HTML。 |

## 验证记录

具体结果随 `tests/TEST_RESULTS.txt`、`tests/AUDIT_TEST_RESULTS.txt`、`tests/SANITIZER_RESULTS.txt` 和 `tests/STATIC_ANALYSIS.txt` 交付；命令见 `tests/README.md`。测试使用本机 TCP/UDP、私有假 Core/iproute2/音频进程、PTY 和合成 sysfs，不调用真实云服务、ALSA 或 CAN 控制器；NTP 协议测试不执行 settimeofday/RTC_SET_TIME。

本次最终结果：

- 主程序 qmake 与 CMake Release 构建成功，无 `warning:` / `error:` 编译诊断；生产程序 offscreen 启动 4 秒正常（测试主动 timeout 结束）。
- Wi-Fi 回归：QtTest 报告 **19 passed / 0 failed**，60991 ms。
- 审计回归：QtTest 报告 **36 passed / 0 failed**，7363 ms。
- 同一审计套件 ASan + UBSan：**36 passed / 0 failed**，8899 ms，无 sanitizer 错误；未启用 leak 检测。
- 按生产编译参数对 12 个 `.cpp` 运行 cppcheck 2.17.1 的 warning/performance/portability 检查：退出 0，无启用类别的诊断。
- 两套测试的上述 totals 包含各自 init/cleanup；不是 55 项硬件验收。YUV 全域检查覆盖 256³ 输入，旧越界点已纳入回归。

最终验证结果以这些记录为准，不把静态分析无诊断当作“完全没有 bug”。

## 仍需实板验收 / 不能保证的边界

- 无 imx6ull、真实路由器、真实 Xiaozhi ARMv7 Core、摄像头、ALSA、CAN 收发器、STM32、DS18B20 或 RTC 的硬件验证。交付为源码和资源，不是交叉编译的 ARM 二进制。
- 未实现 WPA 门户认证；TCP 可达不保证公网、TLS/鉴权和小智云服务功能正常。实际激活/录放音仍由 Core 确认。
- `ip -details` 需要完整 iproute2 的 CAN 支持，不保证仅含 BusyBox ip 的 rootfs 可以使用；配置权限通常需 root/CAP_NET_ADMIN。恢复范围是本应用改动的回环状态与可读取的原 nominal bitrate，不是任意外部高级 CAN 位时序/FD 参数的逐位快照；无原 bitrate 的新接口关闭后保留选定 bitrate，但恢复 DOWN 和原回环开关。若外部服务同时改动接口，应用不能提供跨进程事务保护，请确保只有一个链路管理者。
- 无法安全打断驱动中不可中断的 sysfs/V4L2 ioctl。正常 1-wire 转换可安全等待；若 BSP 驱动永久不返回，应修复驱动/硬件，应用不会冒险删除运行中的线程。进程被断电/SIGKILL 时也不能保证执行 CAN 恢复步骤。
- Modbus PTY 测试验证帧、CRC、负温度解码和参数恢复，不证明物理 RS485 自动方向、电气连接或现有 MCU 固件寄存器映射正确。
- 自检“通过”只对应界面说明的检测范围；串口可打开/写入不等于 STM32 在线，发现传感器节点不等于已验证实物精度，内部 CAN 回环不等于验证外部总线终端电阻/线路。
