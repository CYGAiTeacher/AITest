#ifndef UITHEME_H
#define UITHEME_H

#include <QColor>
#include <QString>

// ---------------------------------------------------------------------------
// 集中式配色主题（支持运行时在多套配色间自由切换）
//
// 界面所有颜色在此按“语义角色”统一定义一次（QSS 样式表、QPainter 绘制、
// 图标着色、QPalette 全部引用这里的变量）。Theme::setTheme() 一次性重载
// 全部取值；新配色只需在 uitheme.cpp 的 kThemes 表中加一行。
//
// 默认“午夜蓝”，另有“曜石黑 / 护眼墨绿 / 清爽白”，针对 4.3 英寸
// 480x272 横屏触摸 LCD 调校过对比度；选择会持久化保存，重启后保持。
// ---------------------------------------------------------------------------

class QApplication;

#define THEME_DECLARE(Name)                 \
    extern QColor Name;                     \
    extern QString Name##Hex;

namespace Theme {

// ---------- 基础表面层级（由深到浅） ----------
THEME_DECLARE(AppBackground)            // 应用/页面主背景
THEME_DECLARE(TopBarBackground)         // 顶栏、子页页眉背景
THEME_DECLARE(CardBackground)           // 卡片、大区块背景
THEME_DECLARE(ControlBackground)        // 常规按钮/控件背景
THEME_DECLARE(ControlBackgroundHover)   // 按钮悬停背景
THEME_DECLARE(ControlBackgroundPressed) // 按钮按下（触摸高亮）背景
THEME_DECLARE(ControlBackgroundDisabled)// 禁用控件背景
THEME_DECLARE(ControlBackgroundActive)  // 选中行/强调悬停/系统气泡背景
THEME_DECLARE(ControlBackgroundActivePressed) // 强调区按下背景
THEME_DECLARE(SunkenBackground)         // 凹陷区域：键盘面板、滚动条槽
THEME_DECLARE(InputBackground)          // 输入框背景
THEME_DECLARE(TooltipBackground)        // 悬浮提示背景

// ---------- 描边层级 ----------
THEME_DECLARE(BorderBase)   // 主要卡片/按钮描边
THEME_DECLARE(BorderSoft)   // 弱描边：禁用态、曲线网格
THEME_DECLARE(BorderInput)  // 输入框、软键盘按键描边
THEME_DECLARE(BorderHover)  // 悬停态描边
THEME_DECLARE(TooltipBorder)
THEME_DECLARE(ScrollbarHandle)

// ---------- 文字层级 ----------
THEME_DECLARE(TextPrimary)   // 正文
THEME_DECLARE(TextSecondary) // 辅助文字
THEME_DECLARE(TextHint)      // 弱化/禁用文字、次要图标
THEME_DECLARE(TextBright)    // 深色按钮上的高亮文字
THEME_DECLARE(TextNote)      // 说明文字（略亮于辅助文字）

// ---------- 品牌强调（蓝） ----------
THEME_DECLARE(Accent)               // 主强调色：焦点/hover/选中描边
THEME_DECLARE(AccentBright)         // 信息态：连接中、激活码、链接
THEME_DECLARE(Primary)              // 主操作按钮背景
THEME_DECLARE(PrimaryHover)
THEME_DECLARE(PrimaryPressed)
THEME_DECLARE(PrimaryBorder)
THEME_DECLARE(PrimaryPressedBorder)

// ---------- 成功绿 ----------
THEME_DECLARE(Success)           // 成功描边/图标态
THEME_DECLARE(SuccessBright)     // 已连接状态文字
THEME_DECLARE(SuccessText)       // 开关选中态文字
THEME_DECLARE(SuccessBackground) // 选中/已连接底色
THEME_DECLARE(SuccessBorder)
THEME_DECLARE(SuccessPressed)
THEME_DECLARE(DoneKeyBackground) // 软键盘“完成”键
THEME_DECLARE(DoneKeyBorder)
THEME_DECLARE(DoneKeyPressed)
THEME_DECLARE(DoneKeyPressedBorder)
THEME_DECLARE(ChatUserBubble)    // 聊天气泡（用户侧，偏绿的低饱和色）

// ---------- 告警红 ----------
THEME_DECLARE(Danger) // 错误/告警文字、不支持项、温度曲线

// ---------- 软键盘功能键 ----------
THEME_DECLARE(SoftKeyBackground)
THEME_DECLARE(SoftKeyBorder)
THEME_DECLARE(SoftKeyPressed)

// ---------- 二维码（唯一允许的大面积白色块，保证可扫描） ----------
THEME_DECLARE(QrBackground)
THEME_DECLARE(QrBorder)

// ---------- 仅 QPalette 使用的中间调 ----------
THEME_DECLARE(PaletteButtonText)
THEME_DECLARE(PaletteAlternateBase)
THEME_DECLARE(PaletteLight)
THEME_DECLARE(PaletteMidlight)
THEME_DECLARE(PaletteMid)
THEME_DECLARE(PaletteDark)
THEME_DECLARE(PaletteShadow)

// 消息/状态文字的色调（用于行内样式，如状态栏提示）
enum class Tone {
    Neutral, // 普通提示
    Info,    // 进行中/信息
    Warning  // 错误/告警
};

// 组装完整 QSS 样式表（颜色全部取自上面的变量，随当前主题变化）
QString styleSheet();

// 行内消息样式，例如 "color:#FF8C95;font-size:11px;"
QString messageStyleSheet(Tone tone);

// ---------- 运行时主题切换 ----------
int themeCount();
QString themeName(int index);
QString themeDesc(int index);
// 主题预览取色（主题行自绘用；不依赖当前激活主题）
enum PreviewSlot { PreviewBackground, PreviewCard, PreviewAccent, PreviewText, PreviewSuccess };
QColor themePreviewColor(int index, PreviewSlot slot);
int currentThemeIndex();
void setTheme(int index);
int loadSavedThemeIndex();  // QSettings 持久化读取（默认 0）
void saveThemeIndex(int index);
// 将当前主题的 QPalette 应用到 QApplication（样式表由调用方 setStyleSheet）
void applyPalette(QApplication &app);

} // namespace Theme

#undef THEME_DECLARE

#endif // UITHEME_H
