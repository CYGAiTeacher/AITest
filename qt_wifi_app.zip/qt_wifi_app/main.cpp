#include <QApplication>
#include <QByteArray>
#include <QColor>
#include <QCoreApplication>
#include <QCursor>
#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QFont>
#include <QFontDatabase>
#include <QPalette>
#include <QPaintEvent>
#include <QPainter>
#include <QScreen>
#include <QStringList>
#include <QStyle>
#include <QStyleFactory>
#include <QTimer>
#include <QWidget>
#include <QtGlobal>

#include "mainwindow.h"
#include "uitheme.h"

namespace {

QString loadUiFont()
{
    QStringList fontFiles;
    const QString overridePath = QString::fromLocal8Bit(qgetenv("QT_APP_FONT"));
    if (!overridePath.isEmpty())
        fontFiles << overridePath;

    const QDir applicationDirectory(QCoreApplication::applicationDirPath());
    fontFiles << applicationDirectory.filePath(QStringLiteral("fonts/NotoSansSC-Regular.otf"))
              << QStringLiteral("/usr/share/fonts/opentype/noto/NotoSansSC-Regular.otf")
              << QStringLiteral("/usr/share/fonts/truetype/noto/NotoSansSC-Regular.otf")
              << QStringLiteral("/usr/share/fonts/noto/NotoSansSC-Regular.otf");

    for (const QString &path : fontFiles) {
        if (!QFileInfo(path).isFile())
            continue;
        const int fontId = QFontDatabase::addApplicationFont(path);
        if (fontId >= 0) {
            const QStringList families = QFontDatabase::applicationFontFamilies(fontId);
            if (!families.isEmpty()) {
                qInfo().noquote() << "UI font loaded:" << families.first() << "from" << path;
                return families.first();
            }
        }
        qWarning().noquote() << "Unable to load UI font:" << path;
    }

    QFontDatabase database;
    const QStringList preferredFamilies = QStringList()
        << QStringLiteral("Noto Sans SC")
        << QStringLiteral("Noto Sans CJK SC")
        << QStringLiteral("Source Han Sans SC")
        << QStringLiteral("WenQuanYi Micro Hei")
        << QStringLiteral("WenQuanYi Zen Hei")
        << QStringLiteral("Droid Sans Fallback")
        << QStringLiteral("Microsoft YaHei");
    const QStringList installedFamilies = database.families();
    for (const QString &preferred : preferredFamilies) {
        for (const QString &installed : installedFamilies) {
            if (installed.compare(preferred, Qt::CaseInsensitive) == 0) {
                qInfo().noquote() << "Using installed UI font:" << installed;
                return installed;
            }
        }
    }

    const QString fallback = QFontDatabase::systemFont(QFontDatabase::GeneralFont).family();
    qWarning().noquote() << "No known CJK font found; using Qt system font:" << fallback
                         << "(set QT_APP_FONT to a readable CJK font file)";
    return fallback;
}


class DisplayColorTest : public QWidget
{
public:
    DisplayColorTest()
        : QWidget(nullptr),
          m_index(0)
    {
        m_colors[0] = QColor(QStringLiteral("#808080"));
        m_colors[1] = QColor(QStringLiteral("#FF0000"));
        m_colors[2] = QColor(QStringLiteral("#00FF00"));
        m_colors[3] = QColor(QStringLiteral("#0000FF"));
        // Pure white is kept only as a diagnostic swatch, not used by the normal UI.
        m_colors[4] = QColor(QStringLiteral("#FFFFFF"));
        m_colors[5] = QColor(QStringLiteral("#000000"));
        setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
        setAttribute(Qt::WA_OpaquePaintEvent, true);
        setAutoFillBackground(false);
    }

    void advanceColor()
    {
        m_index = (m_index + 1) % 6;
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter painter(this);
        painter.setCompositionMode(QPainter::CompositionMode_Source);
        painter.fillRect(rect(), m_colors[m_index]);
    }

private:
    QColor m_colors[6];
    int m_index;
};

} // namespace

int main(int argc, char *argv[])
{
#if QT_VERSION >= QT_VERSION_CHECK(5, 6, 0)
    // This UI is laid out for the panel's native 480x272 pixels. Avoid an
    // environment-provided fractional scale that would resample text and icons.
    QCoreApplication::setAttribute(Qt::AA_DisableHighDpiScaling);
#endif

    QApplication app(argc, argv);
    QApplication::setOverrideCursor(QCursor(Qt::BlankCursor));
    QCoreApplication::setOrganizationName(QStringLiteral("BoardLab"));
    QCoreApplication::setApplicationName(QStringLiteral("PeripheralTest"));

    QStyle *fusion = QStyleFactory::create(QStringLiteral("Fusion"));
    if (fusion)
        app.setStyle(fusion);
    // 启动时恢复上次选择的主题（默认 0 = 午夜蓝）
    Theme::setTheme(Theme::loadSavedThemeIndex());
    Theme::applyPalette(app);

    QFont font(loadUiFont());
    font.setPixelSize(13);
    font.setHintingPreference(QFont::PreferFullHinting);
    font.setStyleStrategy(QFont::PreferAntialias);
    app.setFont(font);

    QScreen *screen = app.primaryScreen();
    if (screen) {
        qInfo() << "Qt display:" << QApplication::platformName()
                << "geometry=" << screen->geometry()
                << "depth=" << screen->depth()
                << "DPR=" << screen->devicePixelRatio();
    }

    const QStringList args = app.arguments();
    if (args.contains(QStringLiteral("--display-test"))) {
        DisplayColorTest testWindow;
        QTimer colorTimer;
        QObject::connect(&colorTimer, &QTimer::timeout,
                         &testWindow, &DisplayColorTest::advanceColor);
        testWindow.showFullScreen();
        colorTimer.start(3000);
        return app.exec();
    }

    QString interfaceName = QString::fromLocal8Bit(qgetenv("WIFI_IFACE"));
    if (interfaceName.isEmpty())
        interfaceName = QStringLiteral("wlan0");
    QString controlDirectory = QString::fromLocal8Bit(qgetenv("WPA_CTRL_DIR"));
    if (controlDirectory.isEmpty())
        controlDirectory = QStringLiteral("/run/wpa_supplicant");

    // Optional overrides: --interface wlan1 --ctrl-dir /run/wpa_supplicant
    for (int i = 1; i + 1 < args.size(); ++i) {
        if (args.at(i) == QStringLiteral("--interface"))
            interfaceName = args.at(i + 1);
        else if (args.at(i) == QStringLiteral("--ctrl-dir"))
            controlDirectory = args.at(i + 1);
    }

    MainWindow window(interfaceName, controlDirectory);
    window.showFullScreen();
    return app.exec();
}
