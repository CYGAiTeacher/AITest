#ifndef MODBUSWORKER_H
#define MODBUSWORKER_H

#include <QByteArray>
#include <QList>
#include <QObject>
#include <QString>
#include <termios.h>
#include <linux/serial.h>

class QTimer;

class ModbusWorker : public QObject
{
    Q_OBJECT
public:
    explicit ModbusWorker(const QString &devicePath,
                          int baudRate,
                          int slaveAddress,
                          QObject *parent = nullptr);
    ~ModbusWorker() override;

public slots:
    void start();
    void stop();
    void setLed(bool enabled);
    void setBuzzer(bool enabled);

signals:
    void statusChanged(const QString &status);
    void sensorReading(double temperatureC, double humidityPercent,
                       bool ledOn, bool buzzerOn);
    void outputWriteFinished(bool isLed, bool enabled,
                             bool success, const QString &message);

private slots:
    void pollSensors();

private:
    bool openPort(QString *error);
    void closePort();
    bool readHoldingRegisters(quint16 address, quint16 count,
                              QList<quint16> *values, QString *error);
    bool writeSingleRegister(quint16 address, quint16 value, QString *error);
    bool exchange(const QByteArray &request, int expectedLength,
                  QByteArray *response, QString *error);
    void setStatus(const QString &status);

    QString m_devicePath;
    int m_baudRate;
    int m_slaveAddress;
    int m_fileDescriptor;
    QTimer *m_pollTimer;
    QString m_lastStatus;
    bool m_running;
    bool m_directionIoctlFailed;
    bool m_termiosSaved;
    bool m_rs485Saved;
    struct termios m_originalTermios;
    struct serial_rs485 m_originalRs485;
};

#endif // MODBUSWORKER_H
