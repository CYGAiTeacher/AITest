#ifndef CAMERAWORKER_H
#define CAMERAWORKER_H

#include <QElapsedTimer>
#include <QImage>
#include <QObject>
#include <QString>
#include <QVector>

#include <atomic>

// ---------------------------------------------------------------------------
// CameraWorker —— 基于 Linux V4L2 接口的摄像头采集线程内对象
//
// 直接通过 ioctl/mmap/流式缓冲（streaming I/O）捕获画面，不依赖
// Qt Multimedia / GStreamer。当前支持 YUYV 与 UYVY 两种打包像素格式
// （i.MX6 常见 ov5640/ov7740 及 UVC USB 摄像头均提供），软件转换为
// RGB32 后交由界面显示。设备节点默认 /dev/video0，可用环境变量
// CAMERA_DEVICE 覆盖。
// ---------------------------------------------------------------------------

class CameraWorker : public QObject
{
    Q_OBJECT

public:
    explicit CameraWorker(QObject *parent = nullptr);
    ~CameraWorker() override;

    // Call only while idle, before queueing startCapture. stopCapture never gets
    // cleared inside the worker, so an immediate page-leave cannot be lost.
    void prepareCapture();
    void acknowledgeFrame(); // Thread-safe: at most one queued image per consumer.

public slots:
    void startCapture();  // 打开设备、申请缓冲并开始循环取帧
    void stopCapture();   // 停止取帧并释放设备（可在任意线程调用，异步生效）

signals:
    void frameReady(const QImage &image);                    // 每帧画面
    void captureOpened(const QString &device, int width, int height,
                       const QString &formatName, int fps);  // 设备打开成功
    void captureClosed(const QString &reason);               // 正常停止
    void captureFailed(const QString &error);                // 出错（设备已关闭）
    void frameStats(int framesPerSecond);                    // 约每秒上报一次帧率

private:
    bool openDevice();
    bool configureFormat();
    int negotiateFrameRate();
    bool requestBuffers();
    bool streamOn();
    void captureLoop();
    void closeDevice(const QString &reason, bool failed);
    void convertFrame(const unsigned char *data, unsigned int bytesUsed);

    static QString pixelFormatName(unsigned int fourcc);

    QString m_devicePath;
    std::atomic<bool> m_stopRequested{false};
    std::atomic<bool> m_framePending{false};
    int m_fd;

    struct MmapBuffer {
        void *start;
        size_t length;
    };
    QVector<MmapBuffer> m_buffers;

    int m_width;
    int m_height;
    int m_sourceBytesPerLine;
    unsigned int m_pixelFormat;
    QImage m_frameImage;

    int m_statFrames;
    QElapsedTimer m_statElapsed;
};

#endif // CAMERAWORKER_H
