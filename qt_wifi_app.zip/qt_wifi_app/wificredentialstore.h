#ifndef WIFI_CREDENTIAL_STORE_H
#define WIFI_CREDENTIAL_STORE_H

#include <QList>
#include <QString>

struct WifiCredentials
{
    QString ssid;
    QString password;
    bool secured;

    WifiCredentials() : secured(false) {}
};

// Dedicated, owner-only JSON store. Version 2 remembers multiple networks;
// legacy version-1 (one-network) files are read without losing credentials.
// Each SSID has one profile. Security type must still match a scan result
// before reusing a password (in particular, never downgrade to an open AP).
class WifiCredentialStore
{
public:
    WifiCredentialStore();

    const QString &filePath() const;
    bool loadAll(QList<WifiCredentials> *credentials, QString *error = nullptr) const;
    bool saveAll(const QList<WifiCredentials> &credentials, QString *error = nullptr) const;
    bool load(WifiCredentials *credentials, QString *error = nullptr) const;
    bool save(const WifiCredentials &credentials, QString *error = nullptr) const;
    bool remove(const QString &ssid, QString *error = nullptr) const;
    bool clear(QString *error = nullptr) const;

private:
    QString m_filePath;
    bool m_customPath;
};

#endif // WIFI_CREDENTIAL_STORE_H
