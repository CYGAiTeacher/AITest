#ifndef CANLINKSESSION_H
#define CANLINKSESSION_H

#include <QObject>
#include <QProcess>
#include <QTimer>

// Asynchronous iproute2 configuration. Never downs an already-UP interface.
// A self-test only owns an originally-DOWN interface, and restores loopback /
// any previously configured bitrate before releasing it.
class CanLinkSession : public QObject
{
    Q_OBJECT
public:
    explicit CanLinkSession(QObject *parent = nullptr);
    ~CanLinkSession() override;
    bool begin(const QString &interfaceName, int bitrateBitsPerSecond, bool controllerLoopback);
    void close();
    bool isActive() const;
    bool isReady() const;
    const QString &interfaceName() const;
    int effectiveBitrate() const;

signals:
    void ready(bool reusedExistingLink);
    void failed(const QString &message);
    void closed(const QString &cleanupError);

private:
    enum State { Idle, Inspecting, Configuring, Enabling, Ready, Disabling, Restoring };
    void command(State state, const QStringList &arguments);
    void commandFinished(bool success, const QString &detail);
    void cleanup();
    void complete();
    QStringList restoreArguments() const;

    QProcess m_process;
    QTimer m_timeout;
    State m_state;
    QString m_program;
    QString m_interface;
    QByteArray m_output;
    QString m_cleanupError;
    int m_bitrate;
    int m_oldBitrate;
    bool m_loopback;
    bool m_oldLoopback;
    bool m_modified;
    bool m_closing;
    bool m_commandHandled;
    bool m_timedOut;
};

#endif // CANLINKSESSION_H
