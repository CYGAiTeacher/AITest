# 开发板外设测试台 · 480 × 272 UI 设计说明

## 目标与整体层级

界面运行于 **4.3 英寸、480 × 272、横屏触摸 LCD**，采用深蓝主题与浅色文字，避免浅蓝灰主背景及大面积纯白填充。窗口、顶栏、卡片和控件用不同深蓝层次及描边分区。首页保留 Wi-Fi 设置、北京时间和连接状态；外设入口连接到音频、小智语音和 RS485 测试子页。Wi-Fi 扫描和密码输入仍是两个独立页面。

### 首页顶栏（约 40 px）

- 强制 LTR：左侧“硬件测试”图标/标题固定最左；北京时间居中，日期为亮蓝、时分秒为浅色正文；Wi-Fi 图标、连接状态和 IP 固定最右。
- Wi-Fi 图标进入设置。IP 只在首页顶栏显示；扫描页、密码页不显示 IP，首页底部不重复显示。
- DHCP 获取 IP 后后台通过 NTP 获取北京时间（UTC+8），尝试校准系统时间和通过 `RTC_SET_TIME` 写入 RTC（RTC 按 Linux 习惯写 UTC）。

### 首页主体

- 深蓝层次圆角主卡片“外设测试”，副标题提示录音、小智、RS485 和摄像头；点击进入测试菜单。
- 主卡片下方为 CPU/内存使用率曲线卡（LoadChart，每秒采样，60 点滚动窗口，与温湿度曲线同风格）；原 RS485/CAN/LED/蜂鸣器 快捷按钮已移除。
- 菜单采用横向滑动卡片分页器：每屏同时显示 4 张大触摸入口卡片，超出 4 张自动分页；手指左右滑动即翻到相邻页（按手势方向翻页，轻滑也生效，松手即吸附对齐、无惯性滑行），底部圆点指示当前页；短按仍直接进入对应测试。当前八张卡片全部可用：录音/播放、小智语音、RS485/STM32、摄像头、传感器、CAN 总线、一键测试、主题风格。

### 传感器（板载 sysfs 通道）

- 进入页面自动扫描四类节点：`/sys/class/thermal/thermal_zoneN`、`/sys/class/hwmon/hwmonN`、`/sys/bus/iio/devices/iio:deviceN`、`/sys/bus/w1/devices`（1-wire）；SoC 温度、hwmon 温度/电压（`*_input`，支持 `tempN_label` 命名）、IIO ADC 原始值（`(raw+offset)*scale`，兼容通道级/共享系数，扫描时读一次缓存）、1-wire 温度各显示为一张数值卡，每 1.5 秒刷新，离开页面停止。单位换算自动完成（毫摄氏度→°C、毫伏→V）；IIO 无 scale 的通道显示原始值。未发现任何节点时显示提示而不是空白页。

#### DS18B20（Linux 内核 1-wire 驱动）

- 器件目录 `/sys/bus/w1/devices/<家族码>-<序列号>`，识别家族 `28-*`（DS18B20）、`10-*`（DS18S20）、`22-*`（DS1822）、`3B-*`/`3b-*`（DS1825）、`42-*`（DS28EA00），卡片名自动带出型号；无需用户空间 bit-banging 库。
- 优先读提供该接口的内核的纯数值 `temperature` 节点（毫摄氏度）；否则回退经典的 `w1_slave` 两段文本：第一行 `crc=XX YES` 校验有效后取第二行 `t=` 字段（毫摄氏度，内核已对家族分辨率差异归一化）。CRC 为 NO 或格式异常显示 `--`。
- **线程注意**：`w1_slave`/`temperature` 读取会让驱动同步触发一次转换并等待完成（12-bit 最长约 750ms）。温度/电压数值节点统一放在 `SensorPollWorker` 工作线程执行（信号回送 `QByteArrayList`，UI 线程只解析贴文案；发现节点及名称/scale/offset 等元数据在扫描阶段读取），上一轮未返回自动跳过本轮，1.5s 刷新节奏下界面不卡。刷新列表/离页会使旧代数结果失效；退出时安全等待当前内核读取返回，并取消后续文件读取，避免固定 1 秒后销毁仍运行的线程。器件树需启用 `w1` + `w1-gpio` 主控 + `w1_therm`（如 `onewire { compatible = "w1-gpio"; gpios = <&gpio1 3 GPIO_ACTIVE_HIGH>; };`）。


### 一键测试（外设自检）

- 顺序执行 5 项：摄像头（V4L2 打开并取到一帧）、音频采集（arecord 录 1 秒，不执行播放以免出噪声）、RS485 串口（默认 /dev/ttymxc2，可用 MODBUS_DEVICE 覆盖；需能打开、配置且成功写入才通过；匹配 0x55 回显作为附注，无回显明确标注「未验证对端」，退出恢复原 termios）、CAN 总线（自动 `ip link set canX type can bitrate 500000 loopback on`，仅对原 DOWN 接口执行；SocketCAN 收发 ID=0x123、DLC=8 且全部数据匹配的自检帧，控制器内部回环无需总线对端，已 UP 接口拒绝以免干扰现有链路）、板载传感器（sysfs 扫描 ≥1 通道，含 1-wire DS18B20）。
- 每项独立超时（采集/串口/回环各有限时；CAN 配置也有异步命令超时）防卡死；行状态：○ 待测（灰）/ … 检测中 / ✓ 通过（绿）/ ✗ 失败（红，附原因）；右上角汇总比分，结束后可「重新测试」。离开页面自动取消并释放摄像头/串口/CAN/进程资源（CAN 仅清理由本页启用的链路并恢复原 bitrate/loopback，失败告警）。所有异步回调均以测试代数/条目隔离，旧回调不能结束新一轮测试。

### 主题风格（运行时切换）

- 配色集中定义于 `uitheme.cpp` 的 `kThemes` 调色板表（54 个语义角色色 × 4 套主题），`Theme::setTheme()` 一次性重载全部颜色变量与同名 Hex 字符串；QSS、QPalette、自绘控件、图标着色全部引用这些变量，主页面 `setStyleSheet(Theme::styleSheet())` 重调即整体换肤。
- 四套预设：**午夜蓝**（默认）、**曜石黑**（纯黑省电）、**护眼墨绿**、**清爽白**（浅色高亮）。新主题只需向 `kThemes` 加一行。
- 主题页每一行即预览：行卡片直接用目标主题的卡面/底色/文字色自绘 + 左侧三色圆点（背景/强调/成功）；当前主题高亮强调描边 + 对勾。点选立即生效并通过 `QSettings`（imx6ull/board_ui）持久化，启动时 `loadSavedThemeIndex()` 恢复。
- 图标一致性：`makeUiIcon` 统一按角色色做保留 alpha 的运行时重着色（单色 PNG 字形＋染色），MainWindow 维护 `m_themedIconRegistry` 图标登记表（按钮/标签 30+ 处），切换时 `refreshThemedIcons()` 全部重染；分页器圆点经 `m_hubPager->refreshColors()` 刷新，CPU/内存与温湿度曲线等自绘控件整窗 `update()` 重绘。
- 页面底部为危险区「恢复出厂设置」按钮（红描边样式 `QPushButton#dangerButton`）：**两步确认**（再按一次确认，4 秒无操作或离开页面自动取消）；执行内容 = 删除 Wi-Fi 凭据 JSON + 清空主题持久化配置并把当前主题切回午夜蓝 + 全部已保存网络/密码框清空 + 停止自动重连并取消在途连接（清理本应用标记的运行期网络）。**不影响** wpa_supplicant.conf、系统网络配置与用户数据文件。

### CAN 总线（SocketCAN）

- 接口自动从 `/sys/class/net/can*` 扫描（默认 can0）；波特率 125k/250k/500k/800k/1M 可选（默认 500k），点「打开 CAN」时异步读取 `ip -details`，只配置原 DOWN 接口；kbps×1000 转 bits/s，显式 loopback off，逐步检查配置/启用结果并可取消。已 UP 接口沿用原配置，不修改/关闭外部链路；需 root/CAP_NET_ADMIN 与完整 iproute2，支持 `IP_PROGRAM` 路径覆盖。
- 打开后建立 `PF_CAN/SOCK_RAW/CAN_RAW` socket，`QSocketNotifier` 非阻塞接收；每批最多处理 32 帧避免独占 UI；发送帧 ID 为十六进制文本（允许 0，≤0x7FF 标准帧，更大自动按扩展帧），数据为 ≤8 字节 HEX（空格可省略）；日志区滚动显示带时间戳的 TX/RX 帧（保留最近 120 行，错误帧不显示）。
- 离开页面（返回枢纽）或退出程序自动关闭 socket；若由本页启用原 DOWN 接口，异步恢复 DOWN、原 loopback 和可读取的原 nominal bitrate。恢复失败保留快照并告警，不再静默重开；无原 bitrate 的新接口保留所选 bitrate，但仍恢复 DOWN/原 loopback；不承诺完整还原任意外部高级位时序参数。
## 外设页面与行为

### 音频测试

- 页面含“开始录音”和“播放 /music.wav”两个大按钮及状态提示。
- 录音由系统 `arecord` 启动，默认设备 `default`、单声道、`S16_LE`、16 kHz，输出私有随机临时目录下的 `board-ui-XXXXXX/recording.wav`（`AUDIO_RECORD_PATH` 可覆盖）。再次按录音键后停止采集、完成 WAV 文件并自动以 `aplay` 回放；异常/强杀或空文件不自动播放。停止定时器与本次运行绑定并在完成时取消，避免误杀下一次录音；离页不阻塞 UI。
- 音乐按钮以 `aplay` 播放固定默认文件 `/music.wav`。
- 采集/播放设备、采样率、录音路径和命令路径可由环境变量覆盖，详见 `qt_wifi_app/README.md`。目标系统需安装 `alsa-utils` 并授予应用 ALSA 设备权限。

### 小智 AI 语音对话

- 打开“小智语音”页时，GUI 先验证 Wi-Fi/IP 并异步检查服务 DNS/TCP（默认 4 秒），网络不可用时显示“网络不可用，请正确连接wifi后再次尝试。”且不执行 Core；通过后再绑定 UDP 接收端口并启动 `/xiaozhi_linux_rs-armv7-gnueabihf`；页内按钮保留手动停止入口，返回上级页时关闭进程。
- 首次绑定卡片包含通向 `https://xiaozhi.me/console/` 的官方控制台二维码和操作说明。六码只在收到 Core 的 `type: "activation"` 消息后显示，不伪造、不预填；未收到时显示等待状态。用户按控制台当前指引完成注册/登录、添加设备并输入该六码。激活完成前不开放正常对话显示。
- Core 的“设备已激活”Toast 早于音频线程初始化和云端连接。界面等待 `state: 3`（在线/待机），并要求 Core 日志同时确认 `Recording started` 与 `Playback started`，之后才显示聊天区并提示可以开始讲话；避免将 Core 进程已启动误认为 ALSA 音频已可用。`state: 4` 时收起聊天区并提示网络恢复状态。
- Core 非预期退出，或日志出现 `Recording thread error` / `Playback thread error`（音频线程初始化失败）时，GUI 自动重启核心并按 2、5、12 秒间隔重试，最多 3 次，每次重启仍检查网络；断网终止重启任务，正确联网后手动重试。Core 退出立即清空音频就绪；停止期间禁重启，终止/强杀使用专属可取消定时器。Core stdout/stderr 接入 Qt 应用日志。若设备已激活后 30 秒仍未同时达到云端在线、录音与播放就绪，激活卡片提示用户先点“停止小智”，待按钮变为“启动小智”后再点一次。
- 麦克风采集、语音识别及扬声器播放由小智核心处理，GUI 负责显示状态、真实激活码、Toast 和对话文本。助手 TTS 使用左侧微信风格气泡；用户识别文本使用右侧绿色气泡。上游 GUI 协议为 UDP/JSON；默认 Core 发送到本机 `127.0.0.1:5679/UDP`，接收状态、Toast、activation 与 `type: "tts"` 字幕。配置 `enable_tts_display: true` 才能显示助手字幕，UDP 端口从 `xiaozhi_config.json` 读取，默认 GUI 端口为 5679。
- 当前上游 Core 的 GUI UDP 协议尚未转发 STT；Core 会将识别完成的文本写入合并输出日志 `STT Result: ...`。`XiaozhiBridge` 从 Core 输出中提取该日志并作为用户消息加入右侧气泡；这是每轮识别完成后的最终文本，不是实时逐字字幕。若使用的 Core 关闭 INFO 日志或更改该日志格式，需扩展 Core IPC 发送 `type: "stt"`，或同步调整 GUI 的日志解析。
- 二进制和其 `xiaozhi_config.json`、ALSA 设备配置均需另行部署。默认二进制不是 Qt ZIP 的组成部分；程序路径/工作目录可通过 `XIAOZHI_EXECUTABLE`、`XIAOZHI_WORKDIR` 覆盖。完整协议参见小智仓库的 [GUI 适配说明](https://github.com/haoyn231/xiaozhi_linux_rs/blob/main/docs/GUI%E9%80%82%E9%85%8D%E8%AF%B4%E6%98%8E.md)。

### 摄像头测试（V4L2）

- 页眉右侧为实时状态（未打开/正在打开/运行中·fps/打开失败）；中部深色圆角画面区以等比例缩放显示视频帧；底栏左侧为设备/分辨率/像素格式信息，右侧为“打开/关闭摄像头”按钮。
- 采集由独立线程中的 `CameraWorker` 经 Linux V4L2 完成：`QUERYCAP` 校验 → `S_FMT` 依次尝试 YUYV/UYVY 与 640×480/320×240 → `S_PARM` 请求 30 fps → `REQBUFS` 申请 3 个 mmap 缓冲 → `QBUF`/`STREAMON` → `poll`+`DQBUF` 循环取帧，BT.601 查表转换 RGB32 后交给界面，界面按显示区尺寸快速缩放显示。停止时 `STREAMOFF`、`munmap`、关闭节点；返回菜单或退出自动停止。
- 默认 `/dev/video0`，环境变量 `CAMERA_DEVICE` 可覆盖；打开失败在画面区显示中文原因，便于现场排查。

### RS485 / STM32 温湿度、LED 与蜂鸣器

- 页面显示 Modbus 链路状态、实时温度/湿度、最近 60 次采样双曲线；LED 与蜂鸣器以保持寄存器写入控制，曲线和按钮状态由读回值更新。
- 默认串口 `/dev/ttymxc2`、19200 baud、8E1、Modbus 站号 1；每秒发起功能码 `03` 读取保持寄存器 `0x0000–0x0003`，通过功能码 `06` 写 LED/蜂鸣器，采用 Modbus RTU 标准 CRC-16/A001（低字节先发）。串口通过 POSIX `termios` 在工作线程访问，无 Qt SerialPort 插件依赖。
- 下表是本项目约定的 STM32 映射；Modbus 帧、CRC 和功能码是标准约定，寄存器地址/单位缩放由 MCU 固件同步实现。

| 地址 | 字段 | 读写 | 数据约定 |
|---|---|---|---|
| `0x0000` | LED 输出 | R/W | `0` 关、`1` 开；功能码 `06` 写 |
| `0x0001` | 蜂鸣器输出 | R/W | `0` 关、`1` 开；功能码 `06` 写 |
| `0x0002` | 温度 | R | 有符号 16 位（bit15 为符号位，负值 = 原码 − 0x10000），`0.01 °C/LSB`，例如 `2350` → 23.50 °C、`0xFC18` → −10.00 °C |
| `0x0003` | 相对湿度 | R | 无符号 16 位，`0.01 %RH/LSB`，例如 `4567` → 45.67 %RH |

#### Modbus RTU 指令格式（Qt 端实现，`modbusworker.cpp`）

链路：RS485 半双工，默认 `/dev/ttymxc2`，**19200-8E1**，站号 **0x01**；帧间隔 ≥3.5 字符；CRC-16/Modbus（多项式 0xA001，初值 0xFFFF），**校验低字节先发**。

**① 轮询（每秒一次）：功能码 0x03，读保持寄存器 0x0000 起共 4 个**

```
请求：  01 03 00 00 00 04 44 09
        │  │  │     │     └ CRC16=0x0944，低字节先发
        │  │  │     └ 寄存器数量 = 4
        │  │  └ 起始地址 0x0000（大端）
        │  └ 功能码 0x03
        └ 站号 0x01

正常响应（13 字节）：
        01 03 08 LL LL BB BB TT TT HH HH CRCL CRCH
        └ 字节数 8 = 4 寄存器 ×2 ── LED / 蜂鸣器 / 温度 / 湿度（大端 16 位）

示例：返回 00 01 00 00 09 2E 11 D7 → LED 开、蜂鸣器关、23.50 °C、45.67 %RH
异常响应（5 字节）：01 83 XX CRCL CRCH（功能码最高位置 1，XX = 异常码）
```

**② 控制写入：功能码 0x06，写单个保持寄存器（值只允许 0/1）**

```
LED 开：     01 06 00 00 00 01 48 0A
LED 关：     01 06 00 00 00 00 89 CA
蜂鸣器响：   01 06 00 01 00 01 19 CA
蜂鸣器关：   01 06 00 01 00 00 D8 0A

正常响应 = 请求帧原样回显（8 字节）；Qt 端校验前 6 字节回显一致 + CRC 正确才判成功。
```

**③ Qt 端判定/异常行为：** 读到的 LED/蜂鸣器寄存器 >1 或温度超 −40…125 °C、湿度 >100 %RH 视为固件映射不符，状态栏提示核对 STM32 映射；读失败 1 秒后继续轮询并在状态栏报错；写入期间禁重复操作并保护待写状态，写成功确认状态，写失败报状态栏并回退；后续轮询继续读回同步。RS485 收发方向优先走内核 `TIOCSRS485` 自动方向；BSP 不支持时状态会附注"自动方向待核对"，需由设备树/板级电路保证方向控制。

**④ 环境变量覆盖（出厂默认依次）：** `MODBUS_DEVICE=/dev/ttymxc2`、`MODBUS_BAUD=19200`、`MODBUS_SLAVE_ID=1`（合法范围 1–247）。

- 曲线温度轴固定 −10…60 °C、湿度轴固定 0…100 %RH；最近 60 个有效点。详细配置及异常排查见工程 README。

## Wi-Fi 设置交互（保持现有行为）

Wi-Fi 页面使用 `QStackedWidget` 管理扫描和独立密码页。

### 扫描子页

- 页头显示 Wi-Fi 标题、扫描状态/网络数量和扫描按钮。列表按信号强度排序，锁、信号强度和不支持状态使用 PNG 图片图标。
- **扫描页不创建也不显示密码输入框。**底部保留紧凑“返回”和“连接”按钮。
- 已保存且安全类型匹配的网络显示绿色“已保存”标记，按钮为“直接连接”，点击后跳过密码页；未保存的加密网络才进入密码页，开放网络直接连接。
- Wi-Fi 凭据支持多个 SSID：成功连接时只更新当前记录，旧版单网络 JSON 自动兼容。断线后扫描可见的已保存网络，按 RSSI 从强到弱连接；未保存/不支持/安全类型不匹配的网络不参与自动选网。无信号每轮完成后约 5 秒重扫；暂时不可达的单网络按 5/10/20/40/60 秒退避。已有稳定连接不主动切换。
- `WRONG_KEY` / `AUTH_FAILED`、关联拒绝或“超时后目标仍可见”会移除该网络密码（其他记录不动）；下次点击进入密码页。AP 消失、控制接口异常、DHCP 未取得 IP 不误删密码。
- 每 5 秒后台检查链路，断线后约 1 秒启动扫描；所有阻塞操作在 Wi-Fi 工作线程。手动进入设置期间暂停自动选网，返回首页恢复；后台重连不改变正在使用的外设页面。
- 请求 ID + 线程安全取消栅栏避免恢复出厂时的在途连接结果重新保存已删除的密码。

### 密码页与触摸键盘

- 密码输入行位于页面上部，含锁、键盘、显示/隐藏密码控件；扫描网络列表不会显示在键盘后面。
- 应用内 Qt Widgets 软键盘默认自动呼出。合法密码点击绿色“完成”后返回扫描页并连接，显示连接进度；空密码或格式错误返回扫描页提示用户点击“连接”重新输入。认证失败时清除该网络旧密码并要求重新输入；手动连接成功后进入首页。
- 密码长度上限 64 个字符；格式为 8–63 位可见 ASCII 或 64 位十六进制 PSK。键盘支持 QWERTY、大小写、数字/符号、空格、退格。

## 视觉、图标与触控

- 配色集中在 `uitheme.h` / `uitheme.cpp` 的 `Theme` 命名空间统一维护：每种颜色按语义角色命名（如 `AppBackground`、`ControlBackground`、`Accent`、`Danger`），QSS 样式表由 `Theme::styleSheet()` 从常量组装，QPainter 绘制、图标着色和 `QPalette` 全部引用同一组常量。调整配色修改 `uitheme.cpp` 中 `kThemes` 对应角色的值即可全局生效。主题色板：根窗口与页面深海军蓝 `AppBackground`，顶栏 `TopBarBackground`，卡片 `CardBackground`，常用按键 `ControlBackground`，描边 `BorderBase`；各表面以不同深浅和边框形成清楚分区。正常 UI 不使用浅蓝灰背景或大面积纯白填充。正式页面的白色仅作为二维码局部可扫描底色（`QrBackground`），少量偏白色只用于文字和图标；纯白大色块仍只保留在 `--display-test` 诊断模式。
- 正文 `TextPrimary`、辅助文字 `TextSecondary`、主操作亮蓝 `Accent`、成功绿 `Success`、告警红 `Danger`。图标来自 `qt_wifi_app/assets/icons/`，已针对深色表面提升亮度并由 `ui_resources.qrc` 编入程序；运行时不绘制矢量 UI 图标。温湿度曲线属于数据可视化，由自定义 QWidget 绘制。程序启动日志打印实际 `QPalette::Window` 色、分辨率、色深和 DPR。
- 固定 480 × 272 渲染，禁用非整数高 DPI 缩放；触屏隐藏鼠标指针。Noto Sans SC 为可选部署字体，交付 ZIP 不包含字体。

## Qt 页面与设备服务映射

- 顶层 `QStackedWidget` 切换首页、Wi-Fi 设置、外设测试；外设子页包括测试菜单、音频、小智和 RS485。
- `QProcess` 管理 `arecord`、`aplay` 和小智核心；`QUdpSocket` 解析小智 UDP/JSON；Modbus RTU 使用独立 `QThread` 与 POSIX `termios`，UI 线程只接收状态/采样信号。
- Wi-Fi 多网络凭据以独立 v2 JSON 的 `networks` 数组保存（兼容 v1）；`wpa_cli` 配置运行中的 wpa_supplicant，不执行 `SAVE_CONFIG`；DHCP 后 NTP 以限时异步 DNS/UDP 等待工作，支持退出中断并校验服务器同步状态。

## 当前范围与验证边界

- 已实现：Wi-Fi 设置、音频录放流程、小智进程/UDP 字幕页面、Modbus RTU 读写和温湿度曲线。
- 仍未接入：KEY、LCD/触摸屏专项测试。
- 小智 ARMv7 程序及兼容 STM32 固件需用户部署；本项目定义了 Modbus 映射，但未验证现有固件是否采用该映射。已完成 Linux x86_64 / Qt 5.15 构建及隔离的 Wi-Fi、网络门禁、协议/生命周期/边界自动化测试（见 tests 与 AUDIT_REPORT.md）；目标板、真实无线网卡/路由器、ALSA、小智首次就绪/自动恢复、UDP Core 和 RS485 硬件联调仍需在实板完成。

## 配置文件与外部路径速查

### 本程序持有的配置文件

| 用途 | 绝对路径（开发板 root 用户下） | 说明 |
|---|---|---|
| Wi-Fi 凭据 | `/root/.config/BoardLab/PeripheralTest/wifi_credentials.json` | v2 JSON：`networks` 数组内每项含 ssid/password/secured，兼容 v1；`WIFI_CREDENTIALS_PATH` 环境变量可覆盖 |
| 主题选择 | `/root/.config/imx6ull/board_ui.conf` 的 `ui/theme` 键 | `QSettings(NativeFormat)`，值域 0–3（午夜蓝/曜石黑/护眼墨绿/清爽白），缺省 0；删除即回默认 |
| wpa_supplicant 控制目录 | `/run/wpa_supplicant`（socket `<dir>/<ifname>`，兼容探测 `/var/run/wpa_supplicant`） | `WPA_CTRL_DIR` 或命令行 `--ctrl-dir` 覆盖；接口名 `--interface`（默认 `wlan0`） |

> Linux 上以上配置目录可受 `XDG_CONFIG_HOME` 影响。「恢复出厂设置」= 删除 Wi-Fi JSON、清空主题设置键并即时回默认主题，同时停止重连、取消在途连接、清除应用标记的 wpa_supplicant 内存网络；不改动 wpa_supplicant.conf、第三方未标记网络及系统文件。QSettings 清空键不保证删除其空 `.conf` 文件。

### 运行期依赖/产出路径

| 路径 | 用途 | 覆盖方式 |
|---|---|---|
| `/dev/ttymxc2`（19200 8E1，站号 1） | RS485 ↔ STM32 Modbus RTU | `MODBUS_DEVICE` / `MODBUS_BAUD` / `MODBUS_SLAVE_ID` |
| `/dev/video0` | V4L2 摄像头预览 | `CAMERA_DEVICE` |
| `/sys/class/net/can0` 等 | SocketCAN（`ip link set … type can bitrate …` 配置） | 页面内下拉选择接口/波特率 |
| `/sys/class/thermal`、`/sys/class/hwmon`、`/sys/bus/iio/devices` | 板载传感器扫描源 | —— |
| `/proc/stat`、`/proc/meminfo` | 主页 CPU/内存曲线采样源 | —— |
| `/music.wav` | 音频播放测试素材 | 部署时放置 |
| `<临时目录>/board-ui-XXXXXX/recording.wav` | 录音页临时录音，目录私有、正常退出清理 | `AUDIO_RECORD_PATH` |
| `<临时目录>/board-ui-XXXXXX/selftest.wav` | 一键测试音频文件（用后删除） | 私有随机目录 |
| `fonts/NotoSansSC-Regular.otf`（程序目录）或 `/usr/share/fonts/**/NotoSansSC*` | 中文 UI 字体 | `QT_APP_FONT` |
| 小智核心 + `xiaozhi_config.json`（UDP 127.0.0.1:5679） | 小智语音页 | `XIAOZHI_EXECUTABLE` / `XIAOZHI_WORKDIR` / `XIAOZHI_CONFIG_PATH`；网络检查支持 `XIAOZHI_NETWORK_CHECK_URL` / `XIAOZHI_NETWORK_TIMEOUT_MS` |

## v12 检查记录

全模块修复、网络检查参数和验证边界见 [`AUDIT_REPORT.md`](AUDIT_REPORT.md)。CPU/内存读 procfs 时先读后解析（不以 size=0 的 atEnd 作循环条件），兼容旧内核缺少 MemAvailable 的近似回退。页面保留四套实时主题及既有资源。
