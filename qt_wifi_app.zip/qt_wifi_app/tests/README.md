# 主机自动化回归测试（v12）

Linux 主机、Qt 5 Widgets / Network / Test 开发库、qmake、C++11 编译器、Python 3。
Python 只用于测试假服务；正式 Qt 程序不依赖 Python。
所有测试均应在可丢弃的开发/CI 主机执行，不要把这些假程序部署到开发板替代真实外设工具。

## 1. Wi-Fi 多网络与自动重连回归

```sh
mkdir -p /tmp/qt-wifi-tests
cd /tmp/qt-wifi-tests
qmake /你的源码路径/qt_wifi_app/tests/wifi_tests.pro
make -j2
QT_QPA_PLATFORM=offscreen ./wifi_tests -v1
```

约 1 分钟（包含两次真实 18 秒连接超时/迟到成功边界）。截图可选：

```sh
QT_QPA_PLATFORM=offscreen WIFI_TEST_SCREENSHOT=/tmp/wifi.png ./wifi_tests -v1
```

隔离：

- `QTemporaryDir` 隔离凭据与 QSettings；假 `wpa_cli` / wpa_supplicant 使用私有 Unix datagram socket。
- 不调用真实 Wi-Fi 服务，不配置无线网卡；DHCP 使用 `/bin/true` 或不存在的测试路径。
- `lo` / `127.0.0.1` 仅用于模拟 IPv4 查询，不代表目标板真实网络结果。
- 全部密码为虚构测试数据；假服务 `TEST_STATE` 不输出 PSK。
- 解压工具可能丢失脚本执行位，fixture 会为自己的假程序设置当前所有者的执行权限。

覆盖：v1/v2、多个网络、同 SSID 更新和单项删除、0600；损坏配置不被 `save()` 静默覆盖；RSSI 择强/退避/降级；拒绝陌生热点与同名开放降级；SSID 转义和去重及事件样式名称；认证失败与无信号/控制错误分类；其他网络事件过滤；本应用运行期条目去重及第三方条目保留；DHCP-only 失败和认证后信号消失保留密码；STATUS 错误不等于断线；超时新扫描/迟到成功；断线信号恢复、不抢占外设页；已保存网络跳过键盘、失败后重输、新密码保存；四主题和 w1_slave 异步读取；出厂恢复取消在途任务、迟到成功不可重建凭据。

## 2. 网络门禁与全模块审计回归

```sh
mkdir -p /tmp/qt-audit-tests
cd /tmp/qt-audit-tests
qmake /你的源码路径/qt_wifi_app/tests/audit_tests.pro
make -j2
QT_QPA_PLATFORM=offscreen ./audit_tests -v1
```

可用 `AUDIT_SCREENSHOT=/tmp/xiaozhi-offline.png` 保存 480×272 断网页面。通常约 8–12 秒。

隔离：

- 小智服务检查使用本机随机 TCP 端口；Core / arecord / aplay / iproute2 使用 `fake_core.py`、`fake_audio.py`、`fake_ip.py`。假 ip 只读写私有 JSON，不调用真实 `ip`。
- 所有凭据、设置、日志和合成 sysfs/FIFO 都放在临时目录；没有真实 CAN 网卡也可执行。
- Modbus/串口使用 PTY，验证数据帧、CRC、负温度和 termios 恢复，不需要 STM32。
- NTP 协议使用合成报文；中断测试仅向 `127.0.0.2:123` 查询，不调用同步器写时钟/RTC。
- 主窗口 fixture 禁止自动联网校时，Wi-Fi CLI 指向 `/bin/false`；不调用真实云服务、ALSA、DHCP、RTC 或无线控制接口。

重点覆盖：

1. Wi-Fi 未连时立即提示原文并不执行 Core；有 Wi-Fi/IP 但服务 TCP 拒绝时也不执行。
2. 服务可达才启动、停止不阻塞、退出重置音频；网络检查可取消，断线停止并禁止恢复风暴；自动重启重新做网络检查。
3. 无换行日志有界；两个 GUI 启动入口的提示不被激活页刷新或换主题覆盖；断线后不保留旧聊天就绪状态；无效配置错误原样显示。
4. YUV 完整输入域 256³=16,777,216 组，与有界算术比较；重现旧版 Y=255/U=208 的蓝色越界点。
5. 帧短/行跨度/奇数宽度和图像背压；stop-before-start 不能丢失。
6. CAN ID=0 和负例；500k→500000；原 DOWN 链路配置/恢复；原 UP 链路只读复用；自检拒绝干扰 UP 接口；up 失败、取消、超时、socket 失败清理；恢复失败告警并阻止覆盖快照。
7. procfs 先读后解析、MemAvailable=0、旧内核回退及饱和；合成 IIO 共享 scale/offset 和正确原始值单位；w1_slave CRC 行与范围；过期结果/busy 栅栏。
8. FIFO 模拟 >1 秒的当前内核读取：析构安全等待它结束，不再读取后续器件，不销毁仍运行线程。
9. 自检下一项和串口迟到定时器不能污染新轮次；termios 恢复；RS485 重连不能延迟到离页之后。
10. 旧录音 kill 定时器不能终止新录音；不合作进程的离页停止仍保持 UI 响应。
11. PTY Modbus CRC、负温度/湿度、写回显、参数恢复、停止后不写；NTP LI=3/请求匹配/长度拒绝、2036 era 展开和等待取消。

## 3. AddressSanitizer + UndefinedBehaviorSanitizer

与审计套件相同的测试，另建目录。低内存主机建议 `-O0 -g1` 和单任务编译：审计 fixture 在一个翻译单元中包含多个内部实现，`-O1 -g` 的调试优化编译可能占用很多内存。

```sh
mkdir -p /tmp/qt-audit-asan
cd /tmp/qt-audit-asan
qmake /你的源码路径/qt_wifi_app/tests/audit_tests.pro \
  'CONFIG+=sanitizers' 'QMAKE_CXXFLAGS_DEBUG=-g1 -O0 -fno-var-tracking'
make -j1
QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 ./audit_tests -v1
```

`-fno-var-tracking` 是 GCC 参数；其他编译器可去掉。关闭 leak 检测是为了排除宿主 Qt/platform/font 的进程级缓存；这**不等于做过泄漏检测**。ASan/UBSan 结果只覆盖已执行路径，不证明没有竞态或硬件缺陷，也不是 ThreadSanitizer。

## 4. cppcheck（按实际编译配置）

```sh
cmake -S /你的源码路径/qt_wifi_app -B /tmp/qt-audit-cmake \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
cppcheck --project=/tmp/qt-audit-cmake/compile_commands.json \
  --enable=warning,performance,portability --library=qt --inline-suppr \
  --suppress=missingIncludeSystem --check-level=exhaustive --error-exitcode=1 \
  -i/tmp/qt-audit-cmake --template=gcc
```

本次使用 cppcheck 2.17.1；旧版本可能没有 `--check-level=exhaustive`，届时去掉此参数。排除构建目录生成的 moc/qrc，仅扫描 12 个生产源文件；不以缺 Qt/Linux 宏的初始扫描误报来修改代码。

## 交付记录与限制

- `TEST_RESULTS.txt`：Wi-Fi 套件本次结果。
- `AUDIT_TEST_RESULTS.txt`：审计套件本次结果。
- `SANITIZER_RESULTS.txt`：同一审计套件的 ASan/UBSan 结果。
- `STATIC_ANALYSIS.txt`：按实际编译配置的 cppcheck 结果。
- `../AUDIT_REPORT.md`：具体修复、网络参数、硬件边界。

这些是 Linux x86_64 / Qt 5.15 的主机测试，不等于 imx6ull/真实路由器、声卡、CAN 控制器、DS18B20、摄像头或 MCU 的硬件验收。实际板上应验证 AP 开关/换密码、DHCP、首次激活、音频、回环后正常 CAN 收发、反复开关页面与退出、中文字体和触屏。
