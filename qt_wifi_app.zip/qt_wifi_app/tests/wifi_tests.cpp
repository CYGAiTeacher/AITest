#include <QtWidgets>
#include <QtNetwork>
#include <QtTest>

// Test internal protocol parsing without exporting it from the library.
#include "../wifimanager.cpp"
#define private public
#include "../mainwindow.h"
#undef private
#include "../uitheme.h"

namespace {
WifiCredentials profile(const QString &ssid, const QString &password = QStringLiteral("test-pass-123"),
                        bool secured = true)
{
    WifiCredentials p;
    p.ssid = ssid;
    p.password = secured ? password : QString();
    p.secured = secured;
    return p;
}
WifiNetwork network(const QString &ssid, int rssi, bool secured = true, bool supported = true)
{
    WifiNetwork n;
    n.ssid = ssid;
    n.signalLevel = rssi;
    n.secured = secured;
    n.supported = supported;
    return n;
}
QJsonArray visible(const QList<WifiNetwork> &networks)
{
    QJsonArray array;
    for (const WifiNetwork &n : networks) {
        QJsonObject obj;
        obj.insert(QStringLiteral("ssid"), n.ssid);
        obj.insert(QStringLiteral("signal"), n.signalLevel);
        obj.insert(QStringLiteral("secured"), n.secured);
        array.append(obj);
    }
    return array;
}
}

class WifiTests : public QObject
{
    Q_OBJECT
private:
    QTemporaryDir m_dir;
    QProcess m_server;
    QString m_fake;
    QString m_storePath;

    QString command(const QString &name, const QString &argument = QString())
    {
        QString response, error;
        QStringList args;
        args << name;
        if (!argument.isEmpty())
            args << argument;
        if (!runWpaCli(QStringLiteral("lo"), m_dir.path(), args, 4000, &response, &error))
            qFatal("Fake WPA admin command failed: %s", qPrintable(error));
        return response;
    }
    void configure(const QList<WifiNetwork> &networks, const QJsonObject &behavior = QJsonObject(),
                   bool disconnect = false)
    {
        QJsonObject obj;
        obj.insert(QStringLiteral("visible"), visible(networks));
        obj.insert(QStringLiteral("behavior"), behavior);
        obj.insert(QStringLiteral("disconnect"), disconnect);
        command(QStringLiteral("TEST_CONFIG"), QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact)));
    }
    QJsonObject state()
    {
        return QJsonDocument::fromJson(command(QStringLiteral("TEST_STATE")).toUtf8()).object();
    }
    QStringList attempts()
    {
        QStringList list;
        for (const QJsonValue &value : state().value(QStringLiteral("attempts")).toArray())
            list.append(value.toString());
        return list;
    }
    bool select(MainWindow &window, const QString &ssid)
    {
        for (int i = 0; i < window.m_networkList->count(); ++i) {
            if (window.m_networkList->item(i)->text() == ssid) {
                window.m_networkList->setCurrentRow(i);
                return true;
            }
        }
        return false;
    }
    QList<WifiCredentials> stored()
    {
        QList<WifiCredentials> records;
        QString error;
        if (!WifiCredentialStore().loadAll(&records, &error))
            qFatal("Cannot load test credentials: %s", qPrintable(error));
        return records;
    }
    void prepareWindow(MainWindow &window)
    {
        // No external NTP or hardware is exercised by this test fixture.
        window.m_timeSynchronized = true;
        window.m_statusTimer->setInterval(150);
        window.show();
    }

private slots:
    void initTestCase()
    {
        QVERIFY(m_dir.isValid());
        m_fake = QFileInfo(QString::fromUtf8(__FILE__)).dir().absoluteFilePath(QStringLiteral("fake_wpa.py"));
        QVERIFY(QFileInfo::exists(m_fake));
        QVERIFY(QFile::setPermissions(m_fake, QFile::permissions(m_fake) | QFileDevice::ExeOwner));
        m_storePath = m_dir.filePath(QStringLiteral("wifi_credentials.json"));
        qputenv("WIFI_CREDENTIALS_PATH", m_storePath.toUtf8());
        qputenv("XDG_CONFIG_HOME", m_dir.filePath(QStringLiteral("settings")).toUtf8());
        qputenv("WPA_CLI_PATH", m_fake.toUtf8());
        qputenv("WPA_CTRL_PATH", m_dir.filePath(QStringLiteral("lo")).toUtf8());
        qunsetenv("WPA_CTRL_DIR");
        qRegisterMetaType<WifiFailureReason>("WifiFailureReason");
        qRegisterMetaType<QList<WifiNetwork> >("QList<WifiNetwork>");
        m_server.setProgram(QStringLiteral("python3"));
        m_server.setArguments(QStringList() << m_fake << QStringLiteral("--serve")
                                            << m_dir.filePath(QStringLiteral("lo")));
        m_server.start();
        QVERIFY(m_server.waitForStarted(3000));
        QVERIFY(m_server.waitForReadyRead(3000));
        QVERIFY(m_server.readAllStandardOutput().contains("READY"));
    }
    void cleanupTestCase()
    {
        m_server.terminate();
        if (!m_server.waitForFinished(3000)) {
            m_server.kill();
            m_server.waitForFinished();
        }
    }
    void init()
    {
        command(QStringLiteral("TEST_RESET"));
        QFile::remove(m_storePath);
        qputenv("UDHCPC_PATH", "/bin/true");
        QSettings(QStringLiteral("imx6ull"), QStringLiteral("board_ui")).clear();
        Theme::setTheme(0);
        Theme::applyPalette(*qApp);
    }
    void credentialsMigrateAndRememberMultiple()
    {
        QFile file(m_storePath);
        QVERIFY(file.open(QIODevice::WriteOnly));
        file.write("{\"version\":1,\"ssid\":\"OldLab\",\"password\":\"old-test-pass\",\"secured\":true}");
        file.close();
        WifiCredentialStore store;
        QList<WifiCredentials> records;
        QVERIFY(store.loadAll(&records));
        QCOMPARE(records.size(), 1);
        QCOMPARE(records.first().ssid, QStringLiteral("OldLab"));
        QVERIFY(store.save(profile(QStringLiteral("SecondLab"))));
        QVERIFY(store.loadAll(&records));
        QCOMPARE(records.size(), 2);
        QVERIFY(file.open(QIODevice::ReadOnly));
        QCOMPARE(QJsonDocument::fromJson(file.readAll()).object().value(QStringLiteral("version")).toInt(), 2);
        file.close();
        QVERIFY(store.save(profile(QStringLiteral("OldLab"), QStringLiteral("replacement-test"))));
        QVERIFY(store.loadAll(&records));
        QCOMPARE(records.size(), 2);
        QCOMPARE(records.first().password, QStringLiteral("replacement-test"));
        const QFileDevice::Permissions forbidden = QFileDevice::ReadGroup | QFileDevice::WriteGroup |
            QFileDevice::ReadOther | QFileDevice::WriteOther;
        QVERIFY(!(QFile::permissions(m_storePath) & forbidden));
        QVERIFY(store.remove(QStringLiteral("OldLab")));
        QVERIFY(store.loadAll(&records));
        QCOMPARE(records.size(), 1);
        QCOMPARE(records.first().ssid, QStringLiteral("SecondLab"));
        QVERIFY(store.remove(QStringLiteral("SecondLab")));
        QVERIFY(!QFileInfo::exists(m_storePath));
    }
    void corruptStoreIsNotSilentlyOverwritten()
    {
        QFile f(m_storePath);
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.write("broken-json");
        f.close();
        WifiCredentialStore store;
        QString error;
        QList<WifiCredentials> records;
        QVERIFY(!store.loadAll(&records, &error));
        QVERIFY(!error.isEmpty());
        QVERIFY(!store.save(profile(QStringLiteral("NewLab")), &error));
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("broken-json"));
    }
    void strongestKnownNetworkAndBackoff()
    {
        WifiReconnectPolicy policy;
        const QList<WifiCredentials> saved = { profile(QStringLiteral("Weak")), profile(QStringLiteral("Strong")),
                                               profile(QStringLiteral("RememberedOpen"), QString(), false) };
        QList<WifiNetwork> seen = { network(QStringLiteral("Weak"), -78), network(QStringLiteral("Stranger"), -10, false),
                                    network(QStringLiteral("Strong"), -42), network(QStringLiteral("Enterprise"), -20, true, false) };
        WifiCredentials chosen;
        int rssi = 0;
        QVERIFY(policy.choose(seen, saved, &chosen, &rssi));
        QCOMPARE(chosen.ssid, QStringLiteral("Strong"));
        QCOMPARE(rssi, -42);
        policy.failed(QStringLiteral("Strong"));
        QVERIFY(policy.choose(seen, saved, &chosen));
        QCOMPARE(chosen.ssid, QStringLiteral("Weak"));
        policy.failed(QStringLiteral("Weak"));
        QVERIFY(!policy.choose(seen, saved, &chosen));
        policy.reset();
        QVERIFY(policy.choose(seen, saved, &chosen));
        QCOMPARE(chosen.ssid, QStringLiteral("Strong"));
        // A same-name open AP must never be selected using a remembered WPA profile.
        QVERIFY(!policy.choose({network(QStringLiteral("Strong"), -15, false)}, saved, &chosen));
        QVERIFY(policy.choose({network(QStringLiteral("RememberedOpen"), -50, false)}, saved, &chosen));
        QCOMPARE(chosen.ssid, QStringLiteral("RememberedOpen"));
    }
    void scanParserDecodesNamesAndDeduplicates()
    {
        const QString data = QStringLiteral("bssid / frequency / signal level / flags / ssid\n"
            "00:01\t2412\t-80\t[WPA2-PSK-CCMP][ESS]\tLab\n"
            "00:02\t2412\t-30\t[WPA2-PSK-CCMP][ESS]\tLab\n"
            "00:03\t2412\t-45\t[ESS]\t\\xe4\\xb8\\xad\\xe6\\x96\\x87\n"
            "00:04\t2412\t-55\t[ESS]\t space ");
        const QList<WifiNetwork> nets = parseScanResults(data);
        QCOMPARE(nets.size(), 3);
        QCOMPARE(nets.first().ssid, QStringLiteral("Lab"));
        QCOMPARE(nets.first().signalLevel, -30);
        QCOMPARE(nets.at(1).ssid, QStringLiteral("中文"));
        QCOMPARE(nets.at(2).ssid, QStringLiteral(" space "));
        QCOMPARE(decodeWpaSsid(QStringLiteral("a\\\\b")), QStringLiteral("a\\b"));
    }
    void controlReplyContainingEventLikeSsidIsStillAReply()
    {
        configure({network(QStringLiteral("CTRL-EVENT-MyWiFi"), -30), network(QStringLiteral("<3>Lab"), -50)});
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy scanned(&worker, &WifiWorker::scanFinished);
        worker.scan(false);
        QCOMPARE(scanned.size(), 1);
        QVERIFY(scanned.first().at(1).toString().isEmpty());
        QCOMPARE(scanned.first().at(0).value<QList<WifiNetwork> >().size(), 2);
    }
    void workerClassifiesAuthenticationAndTransientFailures()
    {
        const QString ssid = QStringLiteral("TestLab");
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("wrong_key")}});
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy result(&worker, &WifiWorker::connectFinished);
        worker.connectNetwork(1, ssid, QStringLiteral("test-pass-123"), true);
        QCOMPARE(result.size(), 1);
        QVERIFY(!result.at(0).at(1).toBool());
        QVERIFY(result.at(0).at(4).value<WifiFailureReason>() == WifiFailureReason::InvalidCredentials);
        QCOMPARE(state().value(QStringLiteral("networks")).toArray().size(), 0);
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("not_found")}});
        result.clear();
        worker.connectNetwork(2, ssid, QStringLiteral("test-pass-123"), true);
        QVERIFY(result.first().at(4).value<WifiFailureReason>() == WifiFailureReason::NetworkUnavailable);
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("control_error")}});
        result.clear();
        worker.connectNetwork(3, ssid, QStringLiteral("test-pass-123"), true);
        QVERIFY(result.first().at(4).value<WifiFailureReason>() == WifiFailureReason::ControlError);
    }
    void workerIgnoresOtherNetworkAuthEventsAndAvoidsDuplicates()
    {
        const QString ssid = QStringLiteral("TestLab");
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("wrong_id_first")}});
        command(QStringLiteral("TEST_CONFIG"), QStringLiteral("{\"external\":true}"));
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy result(&worker, &WifiWorker::connectFinished);
        worker.connectNetwork(1, ssid, QStringLiteral("test-pass-123"), true);
        QVERIFY(result.first().at(1).toBool());
        worker.connectNetwork(2, ssid, QStringLiteral("test-pass-123"), true);
        QCOMPARE(result.size(), 2);
        QVERIFY(result.last().at(1).toBool());
        QCOMPARE(state().value(QStringLiteral("networks")).toArray().size(), 2); // external + one managed
        worker.forgetManagedNetworks();
        const QJsonArray remaining = state().value(QStringLiteral("networks")).toArray();
        QCOMPARE(remaining.size(), 1);
        QCOMPARE(remaining.first().toObject().value(QStringLiteral("ssid")).toString(), QStringLiteral("SystemOwned"));
    }
    void dhcpFailureDoesNotInvalidatePassword()
    {
        const QString ssid = QStringLiteral("TestLab");
        configure({network(ssid, -35)});
        qputenv("UDHCPC_PATH", "/does-not-exist-udhcpc-test");
        WifiWorker worker(QStringLiteral("no-such-net-iface"), m_dir.path());
        QSignalSpy result(&worker, &WifiWorker::connectFinished);
        worker.connectNetwork(1, ssid, QStringLiteral("test-pass-123"), true);
        QCOMPARE(result.size(), 1);
        QVERIFY(result.first().at(1).toBool());
        QVERIFY(result.first().at(3).toString().isEmpty());
        QVERIFY(result.first().at(4).value<WifiFailureReason>() == WifiFailureReason::None);
    }
    void signalLostAfterAuthenticationKeepsValidCredentialResult()
    {
        const QString ssid = QStringLiteral("TestLab");
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("vanish_after_auth")}});
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy result(&worker, &WifiWorker::connectFinished);
        QSignalSpy status(&worker, &WifiWorker::statusChanged);
        worker.connectNetwork(1, ssid, QStringLiteral("test-pass-123"), true);
        QVERIFY(result.first().at(1).toBool()); // proven valid PSK is safe to remember
        QVERIFY(!status.last().first().toBool()); // later RF loss triggers normal retry
    }
    void statusControlErrorIsNotALinkDownEvent()
    {
        command(QStringLiteral("TEST_CONFIG"), QStringLiteral("{\"status_error\":true}"));
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy status(&worker, &WifiWorker::statusChanged);
        QSignalSpy error(&worker, &WifiWorker::statusCheckFailed);
        worker.checkStatus();
        QCOMPARE(status.size(), 0);
        QCOMPARE(error.size(), 1);
    }
    void visibleConnectionTimeoutRequiresNewPassword()
    {
        const QString ssid = QStringLiteral("TestLab");
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("hang")}});
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy result(&worker, &WifiWorker::connectFinished);
        worker.connectNetwork(1, ssid, QStringLiteral("test-pass-123"), true);
        QCOMPARE(result.size(), 1);
        QVERIFY(result.first().at(4).value<WifiFailureReason>() == WifiFailureReason::ConnectionRejected);
        QVERIFY(state().value(QStringLiteral("scans")).toInt() >= 1); // fresh visibility check, not stale cache
    }
    void lateAssociationDuringDiagnosticScanIsPreserved()
    {
        const QString ssid = QStringLiteral("TestLab");
        configure({network(ssid, -35)}, QJsonObject{{ssid, QStringLiteral("late_success")}});
        WifiWorker worker(QStringLiteral("lo"), m_dir.path());
        QSignalSpy result(&worker, &WifiWorker::connectFinished);
        worker.connectNetwork(1, ssid, QStringLiteral("test-pass-123"), true);
        QVERIFY(result.first().at(1).toBool());
    }
    void startupAndReconnectionChooseStrongestWithoutChangingPage()
    {
        const QList<WifiNetwork> seen = {network(QStringLiteral("Weak"), -75), network(QStringLiteral("Unknown"), -10, false),
                                         network(QStringLiteral("Strong"), -40)};
        QVERIFY(WifiCredentialStore().saveAll({profile(QStringLiteral("Weak")), profile(QStringLiteral("Strong"))}));
        configure(seen);
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        QTRY_VERIFY_WITH_TIMEOUT(window.m_wifiConnected && !window.m_connectionBusy, 7000);
        QCOMPARE(window.m_connectedSsid, QStringLiteral("Strong"));
        QCOMPARE(attempts(), QStringList{QStringLiteral("Strong")});
        window.openPeripheralHub();
        configure({network(QStringLiteral("Weak"), -25), network(QStringLiteral("Strong"), -65)});
        QTest::qWait(800);
        QCOMPARE(attempts().size(), 1); // no roaming while connected
        configure({network(QStringLiteral("Weak"), -25), network(QStringLiteral("Strong"), -65)}, QJsonObject(), true);
        QTRY_COMPARE_WITH_TIMEOUT(window.m_connectedSsid, QStringLiteral("Weak"), 7000);
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_connectionBusy, 3000);
        QCOMPARE(window.m_stack->currentWidget(), window.m_peripheralPage);
        QCOMPARE(stored().size(), 2);
        const int previousScans = state().value(QStringLiteral("scans")).toInt();
        const int previousAttempts = attempts().size();
        configure({}, QJsonObject(), true);
        QTRY_VERIFY_WITH_TIMEOUT(state().value(QStringLiteral("scans")).toInt() > previousScans, 6000);
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_scanBusy, 3000);
        QCOMPARE(stored().size(), 2);
        QCOMPARE(attempts().size(), previousAttempts);
        configure(seen);
        window.m_reconnectTimer->start(1); // accelerate the normal 5s no-signal wait
        QTRY_COMPARE_WITH_TIMEOUT(window.m_connectedSsid, QStringLiteral("Strong"), 6000);
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_connectionBusy, 3000);
        QCOMPARE(window.m_stack->currentWidget(), window.m_peripheralPage);
    }
    void failedStrongestProfileIsRemovedAndWeakerProfileStillWorks()
    {
        QVERIFY(WifiCredentialStore().saveAll({profile(QStringLiteral("Strong")), profile(QStringLiteral("Weak"))}));
        configure({network(QStringLiteral("Strong"), -30), network(QStringLiteral("Weak"), -75)},
                  QJsonObject{{QStringLiteral("Strong"), QStringLiteral("wrong_key")}});
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        QTRY_COMPARE_WITH_TIMEOUT(window.m_connectedSsid, QStringLiteral("Weak"), 9000);
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_connectionBusy, 3000);
        QCOMPARE(attempts(), (QStringList{QStringLiteral("Strong"), QStringLiteral("Weak")}));
        QCOMPARE(stored().size(), 1);
        QCOMPARE(stored().first().ssid, QStringLiteral("Weak"));
        QVERIFY(!window.savedCredentialsFor(QStringLiteral("Strong"), true));
    }
    void savedNetworkSkipsKeyboardFailureClearsAndNewPasswordIsSaved()
    {
        QVERIFY(WifiCredentialStore().saveAll({profile(QStringLiteral("Strong")), profile(QStringLiteral("Weak"))}));
        const QList<WifiNetwork> seen = {network(QStringLiteral("Strong"), -30), network(QStringLiteral("Weak"), -65)};
        configure(seen);
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.openWifiSettings(); // manual browsing suspends background auto-connect
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_scanBusy && window.m_networkList->count() == 2, 5000);
        QVERIFY(select(window, QStringLiteral("Strong")));
        QCOMPARE(window.m_connectButton->text(), QStringLiteral("直接连接"));
        window.onWifiScanConnectClicked();
        QVERIFY(window.m_connectionBusy);
        QCOMPARE(window.m_wifiPageStack->currentWidget(), window.m_scanPage);
        QVERIFY(!window.m_keyboardVisible);
        QTRY_VERIFY_WITH_TIMEOUT(window.m_wifiConnected && !window.m_connectionBusy, 5000);
        QCOMPARE(stored().size(), 2);
        configure(seen, QJsonObject{{QStringLiteral("Strong"), QStringLiteral("wrong_key")}}, true);
        window.openWifiSettings();
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_scanBusy, 5000);
        QVERIFY(select(window, QStringLiteral("Strong")));
        window.onWifiScanConnectClicked();
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_connectionBusy, 5000);
        QVERIFY(!window.savedCredentialsFor(QStringLiteral("Strong"), true));
        QCOMPARE(stored().size(), 1);
        QVERIFY(window.m_passwordEdit->text().isEmpty());
        QVERIFY(window.m_wifiMessage->text().contains(QStringLiteral("清除")));
        window.onWifiScanConnectClicked();
        QCOMPARE(window.m_wifiPageStack->currentWidget(), window.m_passwordPage);
        QVERIFY(window.m_keyboardVisible);
        window.m_passwordEdit->setText(QStringLiteral("new-test-pass-456"));
        window.tryAutoReconnect();
        QVERIFY(!window.m_scanBusy);
        QCOMPARE(window.m_passwordEdit->text(), QStringLiteral("new-test-pass-456"));
        configure(seen);
        window.onConnectClicked();
        QTRY_VERIFY_WITH_TIMEOUT(window.m_wifiConnected && !window.m_connectionBusy, 5000);
        QCOMPARE(stored().size(), 2);
        WifiCredentials changed;
        QVERIFY(window.savedCredentialsFor(QStringLiteral("Strong"), true, &changed));
        QCOMPARE(changed.password, QStringLiteral("new-test-pass-456"));
        const QByteArray screenshot = qgetenv("WIFI_TEST_SCREENSHOT");
        if (!screenshot.isEmpty()) {
            window.openWifiSettings();
            QTRY_VERIFY_WITH_TIMEOUT(!window.m_scanBusy, 5000);
            window.grab().save(QString::fromLocal8Bit(screenshot));
        }
    }
    void themesAndAsynchronousOneWirePageRegression()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        for (int i = 0; i < Theme::themeCount(); ++i) {
            window.applyThemeIndex(i);
            QCOMPARE(Theme::currentThemeIndex(), i);
            QCOMPARE(QSettings(QStringLiteral("imx6ull"), QStringLiteral("board_ui"))
                         .value(QStringLiteral("ui/theme")).toInt(), i);
        }
        QVERIFY(QSettings(QStringLiteral("imx6ull"), QStringLiteral("board_ui"))
                    .fileName().endsWith(QStringLiteral("/imx6ull/board_ui.conf")));
        window.openSensorPage();
        window.m_sensorTimer->stop();
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_sensorPollBusy, 2000);
        window.m_sensorEntries.clear();
        QFile data(m_dir.filePath(QStringLiteral("w1_slave")));
        QVERIFY(data.open(QIODevice::WriteOnly));
        data.write("50 05 4b 46 : crc=1c YES\n50 05 4b 46 t=-5625\n");
        data.close();
        MainWindow::SensorEntry entry;
        entry.valueLabel = new QLabel(&window);
        entry.valuePath = data.fileName();
        entry.scale = 1.0;
        entry.divisor = 1000.0;
        entry.unit = QStringLiteral("°C");
        entry.decimals = 1;
        entry.sourceType = 1;
        window.m_sensorEntries.append(entry);
        window.updateSensorValues();
        QTRY_COMPARE_WITH_TIMEOUT(entry.valueLabel->text(), QStringLiteral("-5.6°C"), 2000);
        window.returnToPeripheralHub();
    }
    void factoryResetCancelsPendingAttemptAndCannotResurrectCredentials()
    {
        QVERIFY(WifiCredentialStore().save(profile(QStringLiteral("Strong")))) ;
        configure({network(QStringLiteral("Strong"), -35)},
                  QJsonObject{{QStringLiteral("Strong"), QStringLiteral("hang")}});
        command(QStringLiteral("TEST_CONFIG"), QStringLiteral("{\"external\":true}"));
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        QTRY_VERIFY_WITH_TIMEOUT(window.m_connectionBusy && attempts().size() == 1, 6000);
        const quint64 oldRequest = window.m_connectionRequestId;
        window.applyThemeIndex(2);
        window.handleFactoryResetRequested();
        window.handleFactoryResetRequested();
        QVERIFY(!QFileInfo::exists(m_storePath));
        QVERIFY(window.m_savedNetworks.isEmpty());
        QCOMPARE(Theme::currentThemeIndex(), 0);
        QTRY_COMPARE_WITH_TIMEOUT(state().value(QStringLiteral("networks")).toArray().size(), 1, 5000);
        QTest::qWait(700);
        QVERIFY(!QFileInfo::exists(m_storePath));
        QVERIFY(!window.m_reconnectTimer->isActive());
        // Explicitly inject a stale success to prove the request fence works.
        window.onConnectFinished(oldRequest, true, QStringLiteral("Strong"), QStringLiteral("127.0.0.1"),
                                 WifiFailureReason::None, QStringLiteral("stale result"));
        QVERIFY(!QFileInfo::exists(m_storePath));
        QVERIFY(!window.m_hasCredentials);
        QCOMPARE(state().value(QStringLiteral("networks")).toArray().first().toObject()
                     .value(QStringLiteral("ssid")).toString(), QStringLiteral("SystemOwned"));
    }
};

int main(int argc, char **argv)
{
    if (qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM"))
        qputenv("QT_QPA_PLATFORM", "offscreen");
    QApplication app(argc, argv);
    app.setOrganizationName(QStringLiteral("BoardLab"));
    app.setApplicationName(QStringLiteral("PeripheralTest"));
    app.setStyle(QStringLiteral("Fusion"));
    QFont font = app.font();
    font.setPixelSize(13);
    app.setFont(font);
    WifiTests tests;
    return QTest::qExec(&tests, argc, argv);
}

#include "wifi_tests.moc"
