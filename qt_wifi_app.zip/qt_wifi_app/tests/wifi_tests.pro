QT += widgets network testlib
CONFIG += c++11 console testcase debug
CONFIG -= app_bundle release
TEMPLATE = app
TARGET = wifi_tests
INCLUDEPATH += ..
SOURCES += wifi_tests.cpp \
    ../mainwindow.cpp ../canlinksession.cpp ../cameraworker.cpp ../modbusworker.cpp \
    ../ntpsynchronizer.cpp ../xiaozhibridge.cpp ../uiicons.cpp ../uitheme.cpp \
    ../wifireconnectpolicy.cpp ../wificredentialstore.cpp
# wifimanager.cpp is included in wifi_tests.cpp so its internal protocol parsers
# can be tested too, without exposing them in the production API.
HEADERS += ../canlinksession.h ../mainwindow.h ../wifimanager.h ../cameraworker.h ../modbusworker.h \
    ../ntpsynchronizer.h ../xiaozhibridge.h ../uiicons.h ../uitheme.h \
    ../wifireconnectpolicy.h ../wificredentialstore.h
RESOURCES += ../ui_resources.qrc
