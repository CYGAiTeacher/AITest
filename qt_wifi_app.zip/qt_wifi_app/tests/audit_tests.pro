QT += widgets network testlib
CONFIG += c++11 console testcase debug
CONFIG -= app_bundle release
TEMPLATE = app
TARGET = audit_tests
INCLUDEPATH += ..
# Internal pure parsers/converters and worker operations are included in the
# fixture's single translation unit, not exported from the application API.
SOURCES += audit_tests.cpp ../canlinksession.cpp ../xiaozhibridge.cpp \
    ../wifimanager.cpp ../uiicons.cpp ../uitheme.cpp \
    ../wifireconnectpolicy.cpp ../wificredentialstore.cpp
HEADERS += ../mainwindow.h ../cameraworker.h ../modbusworker.h \
    ../ntpsynchronizer.h ../xiaozhibridge.h ../canlinksession.h \
    ../wifimanager.h ../uiicons.h ../uitheme.h \
    ../wifireconnectpolicy.h ../wificredentialstore.h
RESOURCES += ../ui_resources.qrc
LIBS += -lpthread
contains(CONFIG, sanitizers) {
    QMAKE_CXXFLAGS += -fsanitize=address,undefined -fno-omit-frame-pointer
    QMAKE_LFLAGS += -fsanitize=address,undefined
}
