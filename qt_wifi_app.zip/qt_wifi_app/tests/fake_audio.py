#!/usr/bin/env python3
"""Dummy arecord/aplay. Writes a tiny WAV only inside a test-selected directory."""
import os
import signal
import sys
import time
import wave

args = sys.argv[1:]
if os.environ.get('FAKE_AUDIO_IGNORE_TERM') == '1':
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
else:
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
if '-f' in args:
    with wave.open(args[-1], 'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(16000)
        output.writeframes(b'\0' * 320)
if '-d' in args:
    time.sleep(0.1)
    sys.exit(0)
while True:
    time.sleep(0.02)
