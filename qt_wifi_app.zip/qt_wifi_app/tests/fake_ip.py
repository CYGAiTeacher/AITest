#!/usr/bin/env python3
"""Unprivileged, private-file iproute2 fixture. Never touches a real link."""
import json
import os
import sys
import time
from pathlib import Path

args = sys.argv[1:]
path = Path(os.environ['FAKE_IP_STATE'])
log = Path(os.environ['FAKE_IP_LOG'])
with log.open('a') as stream:
    stream.write(json.dumps(args) + '\n')
state = json.loads(path.read_text())
if '-details' in args:
    flags = 'NOARP,ECHO,UP,LOWER_UP' if state.get('up') else 'NOARP,ECHO'
    mode = '<LOOPBACK> ' if state.get('loopback') else ''
    print(f'4: can0: <{flags}> mtu 16 qdisc noop state UNKNOWN mode DEFAULT')
    print('    link/can')
    print(f'    can {mode}state ERROR-ACTIVE restart-ms 0')
    if state.get('bitrate', 0):
        print(f"      bitrate {state['bitrate']} sample-point 0.875")
    sys.exit(0)
if 'bitrate' in args and args[args.index('bitrate') + 1] == '500000':
    time.sleep(int(os.environ.get('FAKE_IP_DELAY_MS', '0')) / 1000.0)
if args[-1] == 'up' and os.environ.get('FAKE_IP_FAIL') == 'up':
    print('fixture: cannot bring interface up', file=sys.stderr)
    sys.exit(1)
if 'type' in args and '125000' in args and os.environ.get('FAKE_IP_FAIL') == 'restore':
    print('fixture: restore failed', file=sys.stderr)
    sys.exit(1)
if 'type' in args:
    if 'bitrate' in args:
        state['bitrate'] = int(args[args.index('bitrate') + 1])
    if 'loopback' in args:
        state['loopback'] = args[args.index('loopback') + 1] == 'on'
else:
    state['up'] = args[-1] == 'up'
path.write_text(json.dumps(state))
