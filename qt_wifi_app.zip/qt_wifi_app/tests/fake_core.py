#!/usr/bin/env python3
"""Dummy Core for bridge lifecycle tests. No ALSA, cloud, files outside fixture."""
import os
import signal
import sys
import time
from pathlib import Path

with Path(os.environ['FAKE_CORE_LOG']).open('a') as stream:
    stream.write(str(os.getpid()) + '\n')
if os.environ.get('FAKE_CORE_EXIT_IMMEDIATE') == '1':
    sys.exit(3)
if os.environ.get('FAKE_CORE_IGNORE_TERM') == '1':
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
else:
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
print('Recording started: fixture', flush=True)
print('Playback started: fixture', flush=True)
if os.environ.get('FAKE_CORE_FRAGMENT') == '1':
    sys.stdout.write('x' * 200000)
    sys.stdout.flush()
while True:
    time.sleep(0.02)
