#include <QtWidgets>
#include <QtNetwork>
#include <QtTest>
#include <atomic>
#include <cmath>
#include <limits>
#include <thread>
#include <termios.h>
#include <sys/stat.h>
#include <poll.h>

#define private public
#include "../mainwindow.cpp"
#include "../cameraworker.cpp"
#include "../modbusworker.cpp"
#include "../ntpsynchronizer.cpp"
#undef private

namespace {
QByteArray contents(const QString &path)
{
    QFile file(path);
    return file.open(QIODevice::ReadOnly) ? file.readAll() : QByteArray();
}
bool writeData(const QString &path, const QByteArray &data)
{
    QDir().mkpath(QFileInfo(path).absolutePath());
    QFile file(path);
    return file.open(QIODevice::WriteOnly) && file.write(data) == data.size();
}
struct Pty {
    int master = -1;
    int slave = -1;
    QString path;
    Pty() {
        master = ::posix_openpt(O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
        if (master < 0 || ::grantpt(master) || ::unlockpt(master)) return;
        path = QString::fromLocal8Bit(::ptsname(master));
        slave = ::open(path.toLocal8Bit().constData(), O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
    }
    ~Pty() { if (slave >= 0) ::close(slave); if (master >= 0) ::close(master); }
};
}

class AuditTests : public QObject
{
    Q_OBJECT
    QTemporaryDir m_dir;
    QTcpServer m_cloud;
    QString m_fixtures;
    QString m_coreLog;
    QString m_ipState;
    QString m_ipLog;

    void configureCore()
    {
        QUdpSocket udp;
        QVERIFY(udp.bind(QHostAddress(QHostAddress::LocalHost), quint16(0)));
        QJsonObject config;
        config.insert(QStringLiteral("gui_remote_ip"), QStringLiteral("127.0.0.1"));
        config.insert(QStringLiteral("gui_remote_port"), int(udp.localPort()));
        config.insert(QStringLiteral("enable_tts_display"), true);
        QVERIFY(writeData(m_dir.filePath(QStringLiteral("xiaozhi_config.json")), QJsonDocument(config).toJson()));
    }
    void prepareWindow(MainWindow &window)
    {
        window.m_timeSynchronized = true;
        window.m_statusTimer->stop();
        window.m_reconnectTimer->stop();
        window.m_autoReconnectSuspended = true;
        window.show();
    }
    void fakeLink(bool up = false, int bitrate = 125000, bool loopback = false)
    {
        QJsonObject state{{QStringLiteral("up"), up}, {QStringLiteral("bitrate"), bitrate},
                          {QStringLiteral("loopback"), loopback}};
        QVERIFY(writeData(m_ipState, QJsonDocument(state).toJson()));
        QFile::remove(m_ipLog);
    }
    QJsonObject linkState() { return QJsonDocument::fromJson(contents(m_ipState)).object(); }
    void setSensor(MainWindow &window, const QString &path, int sourceType = 0)
    {
        MainWindow::SensorEntry entry;
        entry.valueLabel = new QLabel(&window);
        entry.valuePath = path;
        entry.scale = entry.divisor = 1.0;
        entry.unit = QStringLiteral(" raw");
        entry.decimals = 0;
        entry.sourceType = sourceType;
        window.m_sensorEntries.append(entry);
    }

private slots:
    void initTestCase()
    {
        QVERIFY(m_dir.isValid());
        m_fixtures = QFileInfo(QString::fromUtf8(__FILE__)).absolutePath();
        for (const QString &name : {QStringLiteral("fake_ip.py"), QStringLiteral("fake_core.py"), QStringLiteral("fake_audio.py")}) {
            const QString path = m_fixtures + QLatin1Char('/') + name;
            QVERIFY(QFile::setPermissions(path, QFile::permissions(path) | QFileDevice::ExeOwner));
        }
        m_coreLog = m_dir.filePath(QStringLiteral("core.log"));
        m_ipState = m_dir.filePath(QStringLiteral("ip.json"));
        m_ipLog = m_dir.filePath(QStringLiteral("ip.log"));
        qputenv("WIFI_CREDENTIALS_PATH", m_dir.filePath(QStringLiteral("wifi.json")).toUtf8());
        qputenv("XDG_CONFIG_HOME", m_dir.filePath(QStringLiteral("settings")).toUtf8());
        qputenv("WPA_CLI_PATH", "/bin/false");
        qputenv("WPA_CTRL_PATH", m_dir.filePath(QStringLiteral("no-wpa-socket")).toUtf8());
        qputenv("UDHCPC_PATH", "/bin/false");
        qputenv("XIAOZHI_EXECUTABLE", (m_fixtures + QStringLiteral("/fake_core.py")).toUtf8());
        qputenv("XIAOZHI_WORKDIR", m_dir.path().toUtf8());
        qputenv("XIAOZHI_CONFIG_PATH", m_dir.filePath(QStringLiteral("xiaozhi_config.json")).toUtf8());
        qputenv("XIAOZHI_NETWORK_TIMEOUT_MS", "500");
        qputenv("FAKE_CORE_LOG", m_coreLog.toUtf8());
        qputenv("IP_PROGRAM", (m_fixtures + QStringLiteral("/fake_ip.py")).toUtf8());
        qputenv("FAKE_IP_STATE", m_ipState.toUtf8());
        qputenv("FAKE_IP_LOG", m_ipLog.toUtf8());
        qputenv("ARECORD_PATH", (m_fixtures + QStringLiteral("/fake_audio.py")).toUtf8());
        qputenv("APLAY_PATH", (m_fixtures + QStringLiteral("/fake_audio.py")).toUtf8());
        qputenv("CAMERA_DEVICE", m_dir.filePath(QStringLiteral("no-video-device")).toUtf8());
        connect(&m_cloud, &QTcpServer::newConnection, this, [this]() {
            while (m_cloud.hasPendingConnections()) {
                QTcpSocket *socket = m_cloud.nextPendingConnection();
                connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
            }
        });
    }
    void init()
    {
        for (const char *name : {"FAKE_CORE_EXIT_IMMEDIATE", "FAKE_CORE_IGNORE_TERM", "FAKE_CORE_FRAGMENT",
                                 "FAKE_AUDIO_IGNORE_TERM", "FAKE_IP_FAIL", "FAKE_IP_DELAY_MS", "MODBUS_DEVICE"})
            qunsetenv(name);
        QFile::remove(m_coreLog);
        QFile::remove(m_dir.filePath(QStringLiteral("wifi.json")));
        m_cloud.close();
        QVERIFY(m_cloud.listen(QHostAddress::LocalHost, 0));
        qputenv("XIAOZHI_NETWORK_CHECK_URL", QStringLiteral("tcp://127.0.0.1:%1").arg(m_cloud.serverPort()).toUtf8());
        configureCore();
        fakeLink();
        Theme::setTheme(0);
        Theme::applyPalette(*qApp);
    }
    void offlineStartNeverLaunchesCore()
    {
        XiaozhiBridge bridge;
        QSignalSpy notice(&bridge, &XiaozhiBridge::networkUnavailable);
        QString error;
        QElapsedTimer elapsed; elapsed.start();
        QVERIFY(!bridge.start(&error));
        QVERIFY(elapsed.elapsed() < 100);
        QCOMPARE(error, QStringLiteral("网络不可用，请正确连接wifi后再次尝试。"));
        QCOMPARE(notice.size(), 1);
        QVERIFY(bridge.networkBlocked());
        QVERIFY(!bridge.isActive());
        QVERIFY(!QFileInfo::exists(m_coreLog));
    }
    void unreachableServiceBlocksEvenWithWifiIp()
    {
        const quint16 port = m_cloud.serverPort();
        m_cloud.close();
        qputenv("XIAOZHI_NETWORK_CHECK_URL", QStringLiteral("tcp://127.0.0.1:%1").arg(port).toUtf8());
        XiaozhiBridge bridge;
        bridge.setNetworkAvailable(true);
        QVERIFY(bridge.start());
        QTRY_VERIFY_WITH_TIMEOUT(bridge.networkBlocked(), 1500);
        QVERIFY(!bridge.isRunning());
        QVERIFY(!QFileInfo::exists(m_coreLog));
    }
    void reachableServiceLaunchesAndStopResetsAudio()
    {
        XiaozhiBridge bridge;
        bridge.setNetworkAvailable(true);
        QVERIFY(bridge.start());
        QTRY_VERIFY_WITH_TIMEOUT(bridge.m_captureReady && bridge.m_playbackReady, 2500);
        QVERIFY(bridge.isRunning());
        QElapsedTimer elapsed; elapsed.start();
        bridge.stop();
        QVERIFY(elapsed.elapsed() < 100);
        QVERIFY(!bridge.m_captureReady && !bridge.m_playbackReady);
        QTRY_VERIFY_WITH_TIMEOUT(!bridge.isActive(), 2000);
        QCOMPARE(contents(m_coreLog).trimmed().split('\n').size(), 1);
        QVERIFY(!bridge.m_killTimer->isActive());
    }
    void cancelDuringNetworkProbeNeverLaunchesLater()
    {
        XiaozhiBridge bridge;
        bridge.setNetworkAvailable(true);
        QVERIFY(bridge.start());
        bridge.stop();
        QTest::qWait(120);
        QVERIFY(!bridge.isActive());
        QVERIFY(!QFileInfo::exists(m_coreLog));
    }
    void linkLossStopsCoreAndSuppressesRestart()
    {
        XiaozhiBridge bridge;
        bridge.setNetworkAvailable(true);
        QVERIFY(bridge.start());
        QTRY_VERIFY_WITH_TIMEOUT(bridge.m_captureReady, 2500);
        bridge.setNetworkAvailable(false);
        QVERIFY(bridge.networkBlocked());
        QTRY_VERIFY_WITH_TIMEOUT(!bridge.isRunning(), 2000);
        QVERIFY(!bridge.m_restartTimer->isActive());
        QVERIFY(!bridge.m_captureReady && !bridge.m_playbackReady);
        bridge.setNetworkAvailable(true);
        QVERIFY(!bridge.isActive()); // Requires the user's explicit retry.
    }
    void automaticRestartAlsoChecksServiceReachability()
    {
        qputenv("FAKE_CORE_EXIT_IMMEDIATE", "1");
        XiaozhiBridge bridge;
        bridge.setNetworkAvailable(true);
        QVERIFY(bridge.start());
        QTRY_VERIFY_WITH_TIMEOUT(bridge.m_restartTimer->isActive(), 2500);
        m_cloud.close();
        bridge.m_restartTimer->start(1);
        QTRY_VERIFY_WITH_TIMEOUT(bridge.networkBlocked(), 2000);
        QCOMPARE(contents(m_coreLog).trimmed().split('\n').size(), 1);
    }
    void coreLogWithoutNewlineIsBounded()
    {
        qputenv("FAKE_CORE_FRAGMENT", "1");
        XiaozhiBridge bridge;
        bridge.setNetworkAvailable(true);
        QVERIFY(bridge.start());
        QTRY_COMPARE_WITH_TIMEOUT(bridge.m_logLineBuffer.size(), 65536, 2500);
        QVERIFY(bridge.isRunning());
    }
    void guiBothEntryPathsKeepExactOfflineMessage()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.openXiaozhiPage();
        const QString message = XiaozhiBridge::networkUnavailableMessage();
        QCOMPARE(window.m_xiaozhiStatus->text(), message);
        QCOMPARE(window.m_xiaozhiActivationMessage->text(), message);
        QVERIFY(window.m_xiaozhiActivationPanel->isVisible());
        QVERIFY(!window.m_xiaozhiBridge->isActive());
        window.updateXiaozhiActivationView();
        window.m_xiaozhiToggleButton->click();
        QCOMPARE(window.m_xiaozhiActivationMessage->text(), message);
        window.applyThemeIndex(2);
        QCOMPARE(window.m_xiaozhiActivationMessage->text(), message);
        const QByteArray screenshot = qgetenv("AUDIT_SCREENSHOT");
        if (!screenshot.isEmpty()) {
            window.applyThemeIndex(0);
            QTest::qWait(20);
            QVERIFY(window.grab().save(QString::fromLocal8Bit(screenshot)));
        }
    }
    void guiDisconnectClearsReadyConversation()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.onStatusChanged(true, QStringLiteral("Fixture"), QStringLiteral("127.0.0.1"));
        window.openXiaozhiPage();
        QTRY_VERIFY_WITH_TIMEOUT(window.m_xiaozhiAudioReady, 2500);
        emit window.m_xiaozhiBridge->coreStateChanged(3);
        QVERIFY(window.m_xiaozhiOnline);
        window.onStatusChanged(false, QString(), QString());
        QCOMPARE(window.m_xiaozhiActivationMessage->text(), XiaozhiBridge::networkUnavailableMessage());
        QVERIFY(!window.m_xiaozhiOnline && !window.m_xiaozhiAudioReady);
        QVERIFY(!window.m_chatList->isVisible());
    }
    void yuvLookupEntireInputDomainHasNoOutOfBounds()
    {
        const YuvToRgb32Lut &lut = yuvLut();
        unsigned char pixel[4];
        // Exhaust all 16,777,216 Y/U/V triples. Sanitizer builds check bounds.
        for (int y = 0; y < 256; ++y)
            for (int u = 0; u < 256; ++u)
                for (int v = 0; v < 256; ++v) {
                    lut.convert(y, u, v, pixel);
                    if (pixel[0] != clampByte(y + lut.bu[u]) || pixel[1] != clampByte(y - lut.gu[u] - lut.gv[v]) ||
                        pixel[2] != clampByte(y + lut.rt[v]) || pixel[3] != 255)
                        QFAIL("YUV conversion differs from bounded arithmetic");
                }
        lut.convert(255, 208, 128, pixel); // Reproduced v11 global-buffer-overflow.
        QCOMPARE(pixel[0], static_cast<unsigned char>(255));
    }
    void cameraHonorsStrideAndBoundsAndFrameBackpressure()
    {
        CameraWorker camera;
        camera.m_width = 2; camera.m_height = 2; camera.m_sourceBytesPerLine = 8;
        camera.m_pixelFormat = V4L2_PIX_FMT_YUYV;
        camera.m_frameImage = QImage(2, 2, QImage::Format_RGB32);
        const unsigned char data[16] = {10,128,20,128,255,0,255,0, 30,128,40,128,0,0,0,0};
        QSignalSpy frames(&camera, &CameraWorker::frameReady);
        camera.convertFrame(data, 11);
        QCOMPARE(frames.size(), 0); // Last pixel pair incomplete.
        camera.convertFrame(data, 12);
        QCOMPARE(frames.size(), 1);
        const QImage image = frames.first().first().value<QImage>();
        QCOMPARE(qRed(image.pixel(0, 0)), 10);
        QCOMPARE(qRed(image.pixel(0, 1)), 30); // Not padding from the previous row.
        camera.convertFrame(data, 16);
        QCOMPARE(frames.size(), 1); // Slow GUI cannot queue unlimited VGA images.
        camera.acknowledgeFrame();
        camera.convertFrame(data, 16);
        QCOMPARE(frames.size(), 2);
        camera.m_width = 3;
        camera.acknowledgeFrame();
        camera.convertFrame(data, 16);
        QCOMPARE(frames.size(), 2); // Odd packed-YUV widths rejected.
    }
    void cameraStopBeforeQueuedStartIsNotLost()
    {
        CameraWorker camera;
        QSignalSpy closed(&camera, &CameraWorker::captureClosed);
        QSignalSpy failed(&camera, &CameraWorker::captureFailed);
        camera.prepareCapture();
        camera.stopCapture();
        camera.startCapture();
        QCOMPARE(closed.size(), 1);
        QCOMPARE(failed.size(), 0); // Did not try opening the intentionally missing device.
        QCOMPARE(camera.m_fd, -1);
    }
    void canParserAcceptsZeroAndRejectsMalformedPayload()
    {
        quint32 id = 99; bool extended = true; QByteArray payload;
        QVERIFY(parseCanIdText(QStringLiteral("0"), &id, &extended));
        QCOMPARE(id, quint32(0)); QVERIFY(!extended);
        QVERIFY(parseCanIdText(QStringLiteral("1FFFFFFF"), &id, &extended)); QVERIFY(extended);
        QVERIFY(!parseCanIdText(QStringLiteral("20000000"), &id, &extended));
        QVERIFY(!parseCanIdText(QStringLiteral("-1"), &id, &extended));
        QVERIFY(parseCanDataText(QStringLiteral("00, 55_AA"), &payload));
        QCOMPARE(payload, QByteArray::fromHex("0055aa"));
        QVERIFY(!parseCanDataText(QStringLiteral("1"), &payload));
        QVERIFY(!parseCanDataText(QStringLiteral("GG"), &payload));
        QVERIFY(!parseCanDataText(QStringLiteral("001122334455667788"), &payload));
    }
    void canDownLinkUsesBitsPerSecondAndRestoresConfiguration()
    {
        fakeLink(false, 125000, true);
        CanLinkSession session;
        QSignalSpy ready(&session, &CanLinkSession::ready), closed(&session, &CanLinkSession::closed);
        QVERIFY(session.begin(QStringLiteral("can0"), 500000, false));
        QTRY_COMPARE_WITH_TIMEOUT(ready.size(), 1, 2500);
        QCOMPARE(linkState().value(QStringLiteral("bitrate")).toInt(), 500000);
        QVERIFY(!linkState().value(QStringLiteral("loopback")).toBool());
        QVERIFY(linkState().value(QStringLiteral("up")).toBool());
        session.close();
        QTRY_COMPARE_WITH_TIMEOUT(closed.size(), 1, 2500);
        QCOMPARE(linkState().value(QStringLiteral("bitrate")).toInt(), 125000);
        QVERIFY(linkState().value(QStringLiteral("loopback")).toBool());
        QVERIFY(!linkState().value(QStringLiteral("up")).toBool());
        QVERIFY(closed.first().first().toString().isEmpty());
    }
    void canExistingUpLinkIsNeverReconfiguredOrBroughtDown()
    {
        fakeLink(true, 250000);
        CanLinkSession session;
        QSignalSpy ready(&session, &CanLinkSession::ready);
        QVERIFY(session.begin(QStringLiteral("can0"), 500000, false));
        QTRY_COMPARE_WITH_TIMEOUT(ready.size(), 1, 2000);
        QVERIFY(ready.first().first().toBool());
        QCOMPARE(session.effectiveBitrate(), 250000);
        session.close();
        QVERIFY(!session.isActive());
        QCOMPARE(contents(m_ipLog).trimmed().split('\n').size(), 1); // Only link show.
        QVERIFY(linkState().value(QStringLiteral("up")).toBool());
    }
    void canSelfTestRefusesToDisruptAnUpInterface()
    {
        fakeLink(true, 250000);
        CanLinkSession session;
        QSignalSpy failure(&session, &CanLinkSession::failed);
        QVERIFY(session.begin(QStringLiteral("can0"), 500000, true));
        QTRY_COMPARE_WITH_TIMEOUT(failure.size(), 1, 2000);
        QVERIFY(!session.isActive());
        QCOMPARE(contents(m_ipLog).trimmed().split('\n').size(), 1);
        QVERIFY(linkState().value(QStringLiteral("up")).toBool());
    }
    void canFailedUpCommandRollsBack()
    {
        qputenv("FAKE_IP_FAIL", "up");
        CanLinkSession session;
        QSignalSpy closed(&session, &CanLinkSession::closed), failed(&session, &CanLinkSession::failed);
        QVERIFY(session.begin(QStringLiteral("can0"), 500000, true));
        QTRY_COMPARE_WITH_TIMEOUT(closed.size(), 1, 2500);
        QCOMPARE(failed.size(), 1);
        QCOMPARE(linkState().value(QStringLiteral("bitrate")).toInt(), 125000);
        QVERIFY(!linkState().value(QStringLiteral("loopback")).toBool());
        QVERIFY(!linkState().value(QStringLiteral("up")).toBool());
    }
    void canCancelDuringCommandIsResponsiveAndRestores()
    {
        qputenv("FAKE_IP_DELAY_MS", "250");
        CanLinkSession session;
        QSignalSpy ready(&session, &CanLinkSession::ready), closed(&session, &CanLinkSession::closed);
        int heartbeats = 0;
        QTimer heartbeat;
        connect(&heartbeat, &QTimer::timeout, this, [&heartbeats]() { ++heartbeats; });
        heartbeat.start(10);
        QVERIFY(session.begin(QStringLiteral("can0"), 500000, true));
        QTRY_VERIFY_WITH_TIMEOUT(contents(m_ipLog).contains("500000"), 2000);
        QElapsedTimer elapsed; elapsed.start();
        session.close();
        QVERIFY(elapsed.elapsed() < 50);
        QTRY_COMPARE_WITH_TIMEOUT(closed.size(), 1, 2500);
        QCOMPARE(ready.size(), 0);
        QVERIFY(heartbeats > 10);
        QCOMPARE(linkState().value(QStringLiteral("bitrate")).toInt(), 125000);
        QVERIFY(!linkState().value(QStringLiteral("loopback")).toBool());
    }
    void canTimeoutAndCleanupFailureAreVisible()
    {
        qputenv("FAKE_IP_DELAY_MS", "500");
        CanLinkSession timed;
        timed.m_timeout.setInterval(120);
        QSignalSpy failure(&timed, &CanLinkSession::failed), closed(&timed, &CanLinkSession::closed);
        QVERIFY(timed.begin(QStringLiteral("can0"), 500000, true));
        QTRY_COMPARE_WITH_TIMEOUT(closed.size(), 1, 2000);
        QCOMPARE(failure.size(), 1);
        QVERIFY(!linkState().value(QStringLiteral("loopback")).toBool());
        QCOMPARE(linkState().value(QStringLiteral("bitrate")).toInt(), 125000);
        qunsetenv("FAKE_IP_DELAY_MS");
        qputenv("FAKE_IP_FAIL", "restore");
        CanLinkSession badRestore;
        QSignalSpy ready(&badRestore, &CanLinkSession::ready), done(&badRestore, &CanLinkSession::closed);
        QVERIFY(badRestore.begin(QStringLiteral("can0"), 500000, true));
        QTRY_COMPARE_WITH_TIMEOUT(ready.size(), 1, 2000);
        badRestore.close();
        QTRY_COMPARE_WITH_TIMEOUT(done.size(), 1, 2000);
        QVERIFY(!done.first().first().toString().isEmpty());
        QVERIFY(!badRestore.begin(QStringLiteral("can0"), 500000, false));
        qunsetenv("FAKE_IP_FAIL"); // Destructor retries cleanup with the preserved snapshot.
    }
    void invalidCoreConfigDoesNotGetHiddenByWaitingMessage()
    {
        QVERIFY(writeData(m_dir.filePath(QStringLiteral("xiaozhi_config.json")), "not-json"));
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.onStatusChanged(true, QStringLiteral("Fixture"), QStringLiteral("127.0.0.1"));
        window.openXiaozhiPage();
        QVERIFY(window.m_xiaozhiStatus->text().contains(QStringLiteral("JSON")));
        QCOMPARE(window.m_xiaozhiActivationMessage->text(), window.m_xiaozhiStatus->text());
        QVERIFY(!window.m_xiaozhiBridge->isActive());
    }
    void rs485RetryCannotStartAfterLeavingPage()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        QSignalSpy starts(&window, &MainWindow::modbusStartRequested);
        window.openRs485Page();
        window.m_rs485RetryButton->click();
        const int count = starts.size();
        window.returnToPeripheralHub();
        QTest::qWait(220);
        QCOMPARE(starts.size(), count); // No delayed start 120 ms after page-leave.
    }
    void guiCanConvertsKbpsAndCleansUpSocketFailure()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.m_canIfCombo->clear();
        window.m_canIfCombo->addItem(QStringLiteral("can0"));
        window.m_canBitrateCombo->setCurrentIndex(window.m_canBitrateCombo->findData(500));
        window.m_peripheralPageStack->setCurrentWidget(window.m_canTestPage);
        window.toggleCanLink();
        QTRY_VERIFY_WITH_TIMEOUT(!window.m_canSession->isActive(), 2500);
        QVERIFY(contents(m_ipLog).contains("500000"));
        QCOMPARE(window.m_canFd, -1); // No real can0 exists in this isolated host test.
        QVERIFY(!linkState().value(QStringLiteral("up")).toBool());
        QCOMPARE(linkState().value(QStringLiteral("bitrate")).toInt(), 125000);
    }
    void memoryStatsReadZeroSizedProcAndHandleOldKernel()
    {
        QCOMPARE(memoryUsagePercent("MemTotal: 1000 kB\nMemAvailable: 400 kB\n"), 60.0);
        QCOMPARE(memoryUsagePercent("MemTotal: 1000 kB\nMemAvailable: 0 kB\n"), 100.0);
        QCOMPARE(memoryUsagePercent("MemTotal: 1000 kB\nMemFree: 100 kB\nBuffers: 100 kB\nCached: 200 kB\nSReclaimable: 100 kB\nShmem: 50 kB\n"), 55.0);
        QCOMPARE(memoryUsagePercent("MemTotal: 1000 kB\nMemAvailable: 1500 kB\n"), 0.0);
        QFile file(QStringLiteral("/proc/meminfo"));
        QVERIFY(file.open(QIODevice::ReadOnly));
        const QByteArray bytes = file.read(65536);
        QVERIFY(!bytes.isEmpty());
        QVERIFY(memoryUsagePercent(bytes) > 0.0);
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.sampleSystemLoad();
        QVERIFY(!window.m_loadChart->m_mem.isEmpty());
        QVERIFY(window.m_loadChart->m_mem.last() > 0.0);
    }
    void oneWireCrcAndRangeAreValidated()
    {
        double value = 0;
        QVERIFY(parseW1SlaveReading("ab cd : crc=1c YES\nab cd t=-5625\n", &value));
        QCOMPARE(value, -5625.0);
        QVERIFY(!parseW1SlaveReading("ab cd : crc=1c NO\nab cd YES t=12345\n", &value));
        QVERIFY(!parseW1SlaveReading("ab cd : crc=1c NOTYES\nab cd t=12345\n", &value));
        QVERIFY(!parseW1SlaveReading("ab cd : crc=1c YES\nab cd t=500000\n", &value));
    }
    void sensorDiscoveryFindsSharedScaleAndOffset()
    {
        QTemporaryDir root;
        const QString base = root.path() + QStringLiteral("/sys/bus/iio/devices/iio:device0/");
        QVERIFY(writeData(base + QStringLiteral("name"), "ADC\n"));
        QVERIFY(writeData(base + QStringLiteral("in_voltage0_raw"), "4095\n"));
        QVERIFY(writeData(base + QStringLiteral("in_voltage_scale"), "0.5\n"));
        QVERIFY(writeData(base + QStringLiteral("in_voltage_offset"), "-1\n"));
        QVERIFY(writeData(base + QStringLiteral("in_temp0_raw"), "2048\n"));
        const QList<SensorDef> defs = scanBoardSensors(root.path());
        QCOMPARE(defs.size(), 2);
        for (const SensorDef &def : defs) {
            if (def.caption.contains(QStringLiteral("voltage"))) {
                QVERIFY(def.scalePath.endsWith(QStringLiteral("in_voltage_scale")));
                QVERIFY(def.offsetPath.endsWith(QStringLiteral("in_voltage_offset")));
                QCOMPARE(def.divisor, 1000.0);
                QCOMPARE(def.unit, QStringLiteral("V"));
            } else {
                QCOMPARE(def.divisor, 1.0);
                QCOMPARE(def.unit, QStringLiteral(" raw"));
            }
        }
    }
    void sensorStaleResultsCannotClearNewBusyFlagOrPopulateLabels()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        setSensor(window, QStringLiteral("unused"));
        QLabel *label = window.m_sensorEntries.first().valueLabel;
        label->setText(QStringLiteral("--"));
        window.m_sensorPollBusy = true;
        window.m_sensorInFlightGeneration = 10;
        window.m_sensorPollGeneration = 11;
        window.onSensorPolled(9, {QByteArray("99")});
        QVERIFY(window.m_sensorPollBusy);
        QCOMPARE(label->text(), QStringLiteral("--"));
        window.onSensorPolled(10, {QByteArray("99")});
        QVERIFY(!window.m_sensorPollBusy);
        QCOMPARE(label->text(), QStringLiteral("--"));
        window.m_sensorEntries.first().offset = -1.0;
        window.m_sensorEntries.first().scale = 0.5;
        window.m_sensorEntries.first().divisor = 1000.0;
        window.m_sensorEntries.first().unit = QStringLiteral("V");
        window.m_sensorEntries.first().decimals = 3;
        window.m_sensorInFlightGeneration = window.m_sensorPollGeneration = 12;
        window.onSensorPolled(12, {QByteArray("4095")});
        QCOMPARE(label->text(), QStringLiteral("2.047V"));
    }
    void sensorShutdownWaitsForCurrentReadNotEveryRemainingDevice()
    {
        const QString first = m_dir.filePath(QStringLiteral("slow-first"));
        const QString second = m_dir.filePath(QStringLiteral("never-open-second"));
        QVERIFY(::mkfifo(first.toLocal8Bit().constData(), 0600) == 0);
        QVERIFY(::mkfifo(second.toLocal8Bit().constData(), 0600) == 0);
        MainWindow *window = new MainWindow(QStringLiteral("lo"), m_dir.path());
        prepareWindow(*window);
        setSensor(*window, first); setSensor(*window, second);
        std::atomic<bool> connected(false);
        std::thread writer([&]() {
            const int fd = ::open(first.toLocal8Bit().constData(), O_WRONLY | O_CLOEXEC);
            connected.store(true);
            std::this_thread::sleep_for(std::chrono::milliseconds(1300));
            if (fd >= 0) { ::write(fd, "123\n", 4); ::close(fd); }
        });
        window->updateSensorValues();
        // Do not use a QVERIFY before joining the writer on the success path.
        QElapsedTimer ready; ready.start();
        while (!connected.load() && ready.elapsed() < 2000) QTest::qWait(10);
        const bool hadReader = connected.load();
        QElapsedTimer elapsed; elapsed.start();
        delete window;
        writer.join();
        QVERIFY(hadReader);
        QVERIFY(elapsed.elapsed() >= 1000);
        QVERIFY(elapsed.elapsed() < 2500);
        QFile::remove(first); QFile::remove(second);
    }
    void oldSelfTestNextTimerCannotAdvanceANewRun()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.m_selfTestRunning = true; window.m_selfTestIndex = 0; window.m_selfTestItemDone = false;
        ++window.m_selfTestGeneration;
        window.finishSelfTestItem(false, QStringLiteral("old result"));
        window.cancelSelfTest();
        window.m_selfTestRunning = true; window.m_selfTestIndex = 1; window.m_selfTestItemDone = false;
        ++window.m_selfTestGeneration;
        QTest::qWait(250);
        QCOMPARE(window.m_selfTestIndex, 1);
        QVERIFY(!window.m_selfTestItemDone);
        window.cancelSelfTest();
    }
    void serialSelfTestRestoresTermiosAndLateTimerIsFenced()
    {
        Pty pty; QVERIFY(pty.slave >= 0);
        struct termios before; QVERIFY(::tcgetattr(pty.slave, &before) == 0);
        qputenv("MODBUS_DEVICE", pty.path.toUtf8());
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.m_selfTestRunning = true; window.m_selfTestIndex = 1;
        window.runSelfTestItem(); // RS485 is row 2.
        QVERIFY(window.m_selfTestSerialTermiosSaved);
        window.cancelSelfTest();
        struct termios after; QVERIFY(::tcgetattr(pty.slave, &after) == 0);
        QCOMPARE(after.c_iflag, before.c_iflag); QCOMPARE(after.c_oflag, before.c_oflag);
        QCOMPARE(after.c_cflag, before.c_cflag); QCOMPARE(after.c_lflag, before.c_lflag);
        window.m_selfTestRunning = true; window.m_selfTestIndex = 0; window.m_selfTestItemDone = false;
        ++window.m_selfTestGeneration;
        QTest::qWait(420);
        QVERIFY(!window.m_selfTestItemDone);
        QCOMPARE(window.m_selfTestIndex, 0);
        window.cancelSelfTest();
    }
    void recordingOldKillTimerCannotKillNextRecording()
    {
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.openAudioTestPage();
        window.startRecording();
        QTRY_VERIFY_WITH_TIMEOUT(QFileInfo(window.m_recordingPath).size() > 44, 2000);
        window.stopRecording(false);
        QTRY_COMPARE_WITH_TIMEOUT(window.m_recordProcess->state(), QProcess::NotRunning, 2000);
        QVERIFY(!window.m_recordKillTimer->isActive());
        window.startRecording();
        QTRY_COMPARE_WITH_TIMEOUT(window.m_recordProcess->state(), QProcess::Running, 2000);
        QTest::qWait(1900); // v11's first singleShot(1800) would kill this new run.
        QCOMPARE(window.m_recordProcess->state(), QProcess::Running);
        window.stopRecording(false);
        QTRY_COMPARE_WITH_TIMEOUT(window.m_recordProcess->state(), QProcess::NotRunning, 2000);
        QVERIFY(QFileInfo(window.m_recordingPath).absolutePath().startsWith(QDir::tempPath() + QStringLiteral("/board-ui-")));
    }
    void audioPageLeaveIsNonBlockingForUncooperativeProcess()
    {
        qputenv("FAKE_AUDIO_IGNORE_TERM", "1");
        MainWindow window(QStringLiteral("lo"), m_dir.path());
        prepareWindow(window);
        window.openAudioTestPage(); window.startRecording();
        QTRY_VERIFY_WITH_TIMEOUT(QFileInfo(window.m_recordingPath).size() > 44, 2000);
        QElapsedTimer elapsed; elapsed.start();
        window.returnToPeripheralHub();
        QVERIFY(elapsed.elapsed() < 100);
        window.m_recordKillTimer->start(100);
        QTRY_COMPARE_WITH_TIMEOUT(window.m_recordProcess->state(), QProcess::NotRunning, 2000);
        QVERIFY(window.m_recordForceKilled);
    }
    void modbusPtyCrcSignedValuesAndRestore()
    {
        Pty pty; QVERIFY(pty.slave >= 0);
        struct termios before; QVERIFY(::tcgetattr(pty.slave, &before) == 0);
        ModbusWorker worker(pty.path, 19200, 1);
        QString error; QVERIFY2(worker.openPort(&error), qPrintable(error));
        worker.m_running = true;
        std::atomic<bool> stop(false);
        std::thread simulator([&]() {
            QByteArray buffer;
            int responseNumber = 0;
            while (!stop.load()) {
                struct pollfd poller = {pty.master, POLLIN, 0};
                if (::poll(&poller, 1, 20) <= 0) continue;
                char chunk[128]; const ssize_t count = ::read(pty.master, chunk, sizeof(chunk));
                if (count > 0) buffer.append(chunk, static_cast<int>(count));
                while (buffer.size() >= 8) {
                    const QByteArray request = buffer.left(8); buffer.remove(0, 8);
                    QByteArray response = request.at(1) == char(3)
                        ? frameWithCrc(QByteArray::fromHex("01030800010000fe0c1388")) : request;
                    if (++responseNumber == 3) response[response.size() - 1] = char(response.back() ^ 1);
                    ::write(pty.master, response.constData(), static_cast<size_t>(response.size()));
                }
            }
        });
        QSignalSpy readings(&worker, &ModbusWorker::sensorReading);
        QSignalSpy writes(&worker, &ModbusWorker::outputWriteFinished);
        worker.pollSensors(); worker.setLed(false); worker.pollSensors();
        stop.store(true); simulator.join();
        QCOMPARE(readings.size(), 1);
        QCOMPARE(readings.first().at(0).toDouble(), -5.0);
        QCOMPARE(readings.first().at(1).toDouble(), 50.0);
        QCOMPARE(writes.size(), 1); QVERIFY(writes.first().at(2).toBool());
        QVERIFY(worker.m_lastStatus.contains(QStringLiteral("CRC")));
        worker.stop();
        struct termios after; QVERIFY(::tcgetattr(pty.slave, &after) == 0);
        QCOMPARE(after.c_cflag, before.c_cflag); QCOMPARE(after.c_lflag, before.c_lflag);
        worker.setLed(true);
        QVERIFY(!writes.last().at(2).toBool());
    }
    void ntpParserRejectsUnsynchronizedPacketsAndHandles2036Era()
    {
        const qint64 unixSeconds = QDateTime(QDate(2037, 4, 5), QTime(6, 7, 8), Qt::UTC).toSecsSinceEpoch();
        timeval t1 = {time_t(unixSeconds), 0};
        timeval t2 = {time_t(unixSeconds), 20000};
        timeval t3 = {time_t(unixSeconds), 21000};
        timeval t4 = {time_t(unixSeconds), 50000};
        QByteArray request(48, 0), response(48, 0);
        writeNtpTimestamp(request.data() + 40, t1);
        response[0] = char(0x24); response[1] = char(2);
        memcpy(response.data() + 24, request.constData() + 40, 8);
        writeNtpTimestamp(response.data() + 32, t2);
        writeNtpTimestamp(response.data() + 40, t3);
        qint64 result = 0; QString error;
        QVERIFY2(parseNtpReply(response, request, t1, t4, &result, &error), qPrintable(error));
        QVERIFY(std::llabs(result - (unixSeconds * 1000 + 45)) <= 1);
        response[0] = char(0xe4); // LI=3: server is not synchronized.
        QVERIFY(!parseNtpReply(response, request, t1, t4, &result, &error));
        response[0] = char(0x24); response[24] = char(response[24] ^ 1);
        QVERIFY(!parseNtpReply(response, request, t1, t4, &result, &error));
        QVERIFY(!parseNtpReply(QByteArray(10, 0), request, t1, t4, &result, &error));
    }
    void ntpWaitCanBeInterruptedWithoutSettingAnyClock()
    {
        QThread thread;
        QObject *context = new QObject;
        context->moveToThread(&thread);
        std::atomic<bool> started(false), finished(false);
        connect(&thread, &QThread::finished, context, &QObject::deleteLater);
        connect(&thread, &QThread::started, context, [&]() {
            started.store(true);
            qint64 ignored = 0; QString error;
            queryServer(QStringLiteral("127.0.0.2"), &ignored, &error); // Loopback only; no clock/RTC calls.
            finished.store(true);
        });
        thread.start();
        QElapsedTimer waiting; waiting.start();
        while (!started.load() && waiting.elapsed() < 1000) QTest::qWait(10);
        QElapsedTimer elapsed; elapsed.start();
        thread.requestInterruption(); thread.quit();
        const bool joined = thread.wait(1500);
        if (!joined) thread.wait();
        QVERIFY(joined); QVERIFY(finished.load());
        QVERIFY(elapsed.elapsed() < 800);
    }
};

int main(int argc, char **argv)
{
    if (qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM")) qputenv("QT_QPA_PLATFORM", "offscreen");
    QApplication app(argc, argv);
    app.setOrganizationName(QStringLiteral("BoardLab"));
    app.setApplicationName(QStringLiteral("PeripheralTest"));
    app.setStyle(QStringLiteral("Fusion"));
    QFont font(QStringLiteral("Noto Sans CJK SC")); font.setPixelSize(13); app.setFont(font);
    AuditTests tests;
    return QTest::qExec(&tests, argc, argv);
}

#include "audit_tests.moc"
