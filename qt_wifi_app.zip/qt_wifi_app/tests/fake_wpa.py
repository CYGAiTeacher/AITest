#!/usr/bin/env python3
"""Isolated Unix-datagram wpa_supplicant + wpa_cli fixture. No real radio/DHCP.
Only fictional credentials are used; TEST_STATE intentionally excludes PSKs.
"""
import json
import os
import signal
import socket
import sys
import tempfile
import uuid


def escaped(text):
    return ''.join(chr(b) if 32 <= b < 127 and b not in (34, 92)
                   else ('\\\\' if b == 92 else '\\x%02x' % b)
                   for b in text.encode('utf-8'))


def serve(path):
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    sock.bind(path)
    monitors = set()
    state = {}

    def reset():
        state.clear()
        state.update(visible=[], behavior={}, networks={}, next_id=0,
                     current=None, wpa_state='DISCONNECTED', attempts=[], scans=0,
                     status_error=False, attach=True, since_select=0)

    def event(text):
        for client in list(monitors):
            try:
                sock.sendto(('<3>' + text + '\n').encode(), client)
            except OSError:
                monitors.discard(client)

    reset()
    print('READY', flush=True)
    while True:
        raw, client = sock.recvfrom(65536)
        text = raw.decode()
        cmd, _, rest = text.partition(' ')
        cmd = cmd.upper()
        response = 'OK'
        pending = []
        if cmd == 'TEST_RESET':
            reset()
        elif cmd == 'TEST_CONFIG':
            config = json.loads(rest)
            for key in ('visible', 'behavior', 'status_error', 'attach'):
                if key in config:
                    state[key] = config[key]
            if config.get('disconnect'):
                state['current'] = None
                state['wpa_state'] = 'DISCONNECTED'
            if 'external' in config:
                state['networks'][900] = dict(ssid='SystemOwned', id_str='"external_manager"')
        elif cmd == 'TEST_STATE':
            response = json.dumps(dict(
                attempts=state['attempts'], scans=state['scans'],
                networks=[dict(id=k, ssid=v.get('ssid'), tag=v.get('id_str'))
                          for k, v in state['networks'].items()],
                wpa_state=state['wpa_state']))
        elif cmd == 'ATTACH':
            if state['attach']:
                monitors.add(client)
            else:
                response = 'FAIL'
        elif cmd == 'DETACH':
            monitors.discard(client)
        elif cmd == 'SCAN':
            state['scans'] += 1
            current = state['current']
            if current is not None and current in state['networks']:
                ssid = state['networks'][current].get('ssid')
                if state['behavior'].get(ssid) == 'late_success':
                    state['wpa_state'] = 'COMPLETED'
            pending.append('CTRL-EVENT-SCAN-RESULTS')
        elif cmd == 'SCAN_RESULTS':
            lines = ['bssid / frequency / signal level / flags / ssid']
            for i, net in enumerate(state['visible']):
                flags = net.get('flags', '[WPA2-PSK-CCMP][ESS]' if net.get('secured', True) else '[ESS]')
                lines.append('02:00:00:00:00:%02x\t2412\t%d\t%s\t%s' %
                             (i, net['signal'], flags, escaped(net['ssid'])))
            response = '\n'.join(lines)
        elif cmd == 'LIST_NETWORKS':
            response = 'network id / ssid / bssid / flags\n' + '\n'.join(
                '%d\t%s\tany\t%s' % (key, escaped(net.get('ssid', '')),
                    '[CURRENT]' if state['current'] == key else '[DISABLED]')
                for key, net in state['networks'].items())
        elif cmd == 'ADD_NETWORK':
            key = state['next_id']
            state['next_id'] += 1
            state['networks'][key] = {}
            response = str(key)
        elif cmd == 'SET_NETWORK':
            number, key, value = rest.split(' ', 2)
            key_id = int(number)
            if key_id not in state['networks']:
                response = 'FAIL'
            else:
                state['networks'][key_id][key] = (bytes.fromhex(value).decode()
                    if key == 'ssid' else value)
        elif cmd == 'GET_NETWORK':
            number, key = rest.split(' ', 1)
            response = state['networks'].get(int(number), {}).get(key, 'FAIL')
        elif cmd == 'REMOVE_NETWORK':
            key = int(rest)
            state['networks'].pop(key, None)
            if state['current'] == key:
                state['current'] = None
                state['wpa_state'] = 'DISCONNECTED'
        elif cmd == 'SELECT_NETWORK':
            key = int(rest)
            ssid = state['networks'][key]['ssid']
            state['attempts'].append(ssid)
            state['current'] = key
            state['since_select'] = 0
            behavior = state['behavior'].get(ssid, 'ok')
            if behavior == 'wrong_key':
                state['wpa_state'] = 'DISCONNECTED'
                pending.append('CTRL-EVENT-SSID-TEMP-DISABLED id=%d ssid="%s" reason=WRONG_KEY' % (key, ssid))
            elif behavior == 'reject':
                state['wpa_state'] = 'ASSOCIATING'
                pending.append('CTRL-EVENT-ASSOC-REJECT id=%d status_code=1' % key)
            elif behavior == 'not_found':
                state['wpa_state'] = 'SCANNING'
                pending.append('CTRL-EVENT-NETWORK-NOT-FOUND')
            elif behavior in ('hang', 'late_success'):
                state['wpa_state'] = '4WAY_HANDSHAKE'
            elif behavior == 'control_error':
                state['wpa_state'] = 'DISCONNECTED'
                response = 'FAIL'
            else:
                state['wpa_state'] = 'COMPLETED'
                if behavior == 'wrong_id_first':
                    pending.append('CTRL-EVENT-SSID-TEMP-DISABLED id=%d reason=WRONG_KEY' % (key + 999))
                pending.append('CTRL-EVENT-CONNECTED')
        elif cmd == 'STATUS':
            if state['status_error']:
                response = 'FAIL'
            else:
                state['since_select'] += 1
                current = state['current']
                profile = state['networks'].get(current, {})
                behavior = state['behavior'].get(profile.get('ssid'), 'ok')
                if behavior == 'vanish_after_auth' and state['since_select'] >= 2:
                    state['wpa_state'] = 'DISCONNECTED'
                response = 'wpa_state=' + state['wpa_state']
                if state['wpa_state'] == 'COMPLETED' and current in state['networks']:
                    response += '\nssid=%s\nid=%d' % (escaped(profile['ssid']), current)
        elif cmd != 'ENABLE_NETWORK':
            response = 'FAIL'
        sock.sendto((response + '\n').encode(), client)
        for message in pending:
            event(message)


def cli(argv):
    directory, interface = '/run/wpa_supplicant', 'wlan0'
    while argv and argv[0] in ('-p', '-i'):
        key, value = argv[:2]
        argv = argv[2:]
        if key == '-p':
            directory = value
        else:
            interface = value
    path = os.path.join(directory, interface)
    command = ' '.join(argv)
    local = os.path.join(tempfile.gettempdir(), 'fake_wpa_%d_%s' % (os.getpid(), uuid.uuid4().hex[:8]))
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    try:
        sock.bind(local)
        sock.settimeout(3)
        sock.connect(path)
        sock.send(command.encode())
        sys.stdout.buffer.write(sock.recv(65536))
    finally:
        sock.close()
        if os.path.exists(local):
            os.unlink(local)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--serve':
        serve(sys.argv[2])
    else:
        cli(sys.argv[1:])
