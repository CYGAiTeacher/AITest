cmake_minimum_required(VERSION 3.10)
project(board_wifi_ui LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 11)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

find_package(Qt5 REQUIRED COMPONENTS Widgets Network)

add_executable(board_wifi_ui
    main.cpp
    mainwindow.cpp
    mainwindow.h
    cameraworker.cpp
    cameraworker.h
    canlinksession.cpp
    canlinksession.h
    modbusworker.cpp
    modbusworker.h
    ntpsynchronizer.cpp
    ntpsynchronizer.h
    xiaozhibridge.cpp
    xiaozhibridge.h
    uiicons.cpp
    uiicons.h
    uitheme.cpp
    uitheme.h
    ui_resources.qrc
    wifimanager.cpp
    wifimanager.h
    wifireconnectpolicy.cpp
    wifireconnectpolicy.h
    wificredentialstore.cpp
    wificredentialstore.h
)

target_link_libraries(board_wifi_ui PRIVATE Qt5::Widgets Qt5::Network)

# The font is optional and intentionally omitted from the project ZIP.
# If a local copy is supplied in fonts/, copy/install it beside the executable.
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/fonts/NotoSansSC-Regular.otf")
    add_custom_command(TARGET board_wifi_ui POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E make_directory "$<TARGET_FILE_DIR:board_wifi_ui>/fonts"
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
                "${CMAKE_CURRENT_SOURCE_DIR}/fonts/NotoSansSC-Regular.otf"
                "$<TARGET_FILE_DIR:board_wifi_ui>/fonts/NotoSansSC-Regular.otf"
    )
    if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/fonts/OFL.txt")
        add_custom_command(TARGET board_wifi_ui POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/OFL.txt"
                    "$<TARGET_FILE_DIR:board_wifi_ui>/fonts/OFL.txt"
        )
    endif()
endif()

install(TARGETS board_wifi_ui RUNTIME DESTINATION bin)
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/fonts")
    install(DIRECTORY fonts/ DESTINATION bin/fonts)
endif()
